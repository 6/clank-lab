-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk88 :
    ∀ i : Fin (min 128 (40547 - 128 * 88)),
      targetCountsMatch (classAt (targetKernelClass ⟨88, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk88

theorem target_counts_kernel_chunk89 :
    ∀ i : Fin (min 128 (40547 - 128 * 89)),
      targetCountsMatch (classAt (targetKernelClass ⟨89, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk89

theorem target_counts_kernel_chunk90 :
    ∀ i : Fin (min 128 (40547 - 128 * 90)),
      targetCountsMatch (classAt (targetKernelClass ⟨90, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk90

theorem target_counts_kernel_chunk91 :
    ∀ i : Fin (min 128 (40547 - 128 * 91)),
      targetCountsMatch (classAt (targetKernelClass ⟨91, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk91


end TightCycleC5.Bridge.P33Arithmetic
