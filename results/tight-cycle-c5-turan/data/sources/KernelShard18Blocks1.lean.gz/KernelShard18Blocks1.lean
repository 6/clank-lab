import KernelRowIndex
import KernelWitness18

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_18_32 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 32 * 256 + i.val))
      kernelWitness18Row32[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_32

theorem kernelBlock_18_33 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 33 * 256 + i.val))
      kernelWitness18Row33[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_33

theorem kernelBlock_18_34 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 34 * 256 + i.val))
      kernelWitness18Row34[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_34

theorem kernelBlock_18_35 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 35 * 256 + i.val))
      kernelWitness18Row35[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_35

theorem kernelBlock_18_36 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 36 * 256 + i.val))
      kernelWitness18Row36[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_36

theorem kernelBlock_18_37 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 37 * 256 + i.val))
      kernelWitness18Row37[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_37

theorem kernelBlock_18_38 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 38 * 256 + i.val))
      kernelWitness18Row38[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_38

theorem kernelBlock_18_39 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 39 * 256 + i.val))
      kernelWitness18Row39[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_39

theorem kernelBlock_18_40 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 40 * 256 + i.val))
      kernelWitness18Row40[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_40

theorem kernelBlock_18_41 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 41 * 256 + i.val))
      kernelWitness18Row41[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_41

theorem kernelBlock_18_42 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 42 * 256 + i.val))
      kernelWitness18Row42[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_42

theorem kernelBlock_18_43 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 43 * 256 + i.val))
      kernelWitness18Row43[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_43

theorem kernelBlock_18_44 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 44 * 256 + i.val))
      kernelWitness18Row44[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_44

theorem kernelBlock_18_45 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 45 * 256 + i.val))
      kernelWitness18Row45[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_45

theorem kernelBlock_18_46 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 46 * 256 + i.val))
      kernelWitness18Row46[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_46

theorem kernelBlock_18_47 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 47 * 256 + i.val))
      kernelWitness18Row47[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_47

theorem kernelBlock_18_48 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 48 * 256 + i.val))
      kernelWitness18Row48[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_48

theorem kernelBlock_18_49 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 49 * 256 + i.val))
      kernelWitness18Row49[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_49

theorem kernelBlock_18_50 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 50 * 256 + i.val))
      kernelWitness18Row50[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_50

theorem kernelBlock_18_51 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 51 * 256 + i.val))
      kernelWitness18Row51[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_51

theorem kernelBlock_18_52 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 52 * 256 + i.val))
      kernelWitness18Row52[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_52

theorem kernelBlock_18_53 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 53 * 256 + i.val))
      kernelWitness18Row53[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_53

theorem kernelBlock_18_54 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 54 * 256 + i.val))
      kernelWitness18Row54[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_54

theorem kernelBlock_18_55 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 55 * 256 + i.val))
      kernelWitness18Row55[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_55

theorem kernelBlock_18_56 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 56 * 256 + i.val))
      kernelWitness18Row56[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_56

theorem kernelBlock_18_57 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 57 * 256 + i.val))
      kernelWitness18Row57[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_57

theorem kernelBlock_18_58 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 58 * 256 + i.val))
      kernelWitness18Row58[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_58

theorem kernelBlock_18_59 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 59 * 256 + i.val))
      kernelWitness18Row59[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_59

theorem kernelBlock_18_60 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 60 * 256 + i.val))
      kernelWitness18Row60[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_60

theorem kernelBlock_18_61 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 61 * 256 + i.val))
      kernelWitness18Row61[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_61

theorem kernelBlock_18_62 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 62 * 256 + i.val))
      kernelWitness18Row62[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_62

theorem kernelBlock_18_63 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 63 * 256 + i.val))
      kernelWitness18Row63[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_63

end TightCycleC5.Bridge.Cover
