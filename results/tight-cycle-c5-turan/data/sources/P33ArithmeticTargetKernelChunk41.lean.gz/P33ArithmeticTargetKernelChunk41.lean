-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk164 :
    ∀ i : Fin (min 128 (40547 - 128 * 164)),
      targetCountsMatch (classAt (targetKernelClass ⟨164, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk164

theorem target_counts_kernel_chunk165 :
    ∀ i : Fin (min 128 (40547 - 128 * 165)),
      targetCountsMatch (classAt (targetKernelClass ⟨165, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk165

theorem target_counts_kernel_chunk166 :
    ∀ i : Fin (min 128 (40547 - 128 * 166)),
      targetCountsMatch (classAt (targetKernelClass ⟨166, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk166

theorem target_counts_kernel_chunk167 :
    ∀ i : Fin (min 128 (40547 - 128 * 167)),
      targetCountsMatch (classAt (targetKernelClass ⟨167, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk167


end TightCycleC5.Bridge.P33Arithmetic
