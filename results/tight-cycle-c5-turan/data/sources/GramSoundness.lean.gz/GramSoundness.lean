import Mathlib

/-! Integer Gram witnesses imply real PSD matrices by ring casts.
This soundness theorem does not use native computation. -/
namespace TightCycleC5.Bridge
open Matrix

noncomputable def intMatrixReal {I J : Type*} (Q : Matrix I J ℤ) : Matrix I J ℝ :=
  fun i j => (Q i j : ℝ)

theorem int_gram_posSemidef {I J : Type*} [Finite I] [Fintype J]
    (Q : Matrix I I ℤ) (U : Matrix I J ℤ) (hgram : Q = U * U.transpose) :
    (intMatrixReal Q).PosSemidef := by
  have he : intMatrixReal Q = intMatrixReal U * (intMatrixReal U).transpose := by
    ext i j
    rw [hgram]
    simp only [intMatrixReal, Matrix.mul_apply, Matrix.transpose_apply, Int.cast_sum, Int.cast_mul]
  rw [he]
  simpa only [Matrix.conjTranspose_eq_transpose_of_trivial] using
    Matrix.posSemidef_self_mul_conjTranspose (intMatrixReal U)

theorem int_diagonal_bound {I : Type*} (Q : Matrix I I ℤ) (m : ℤ)
    (hdiag : ∀ i, Q i i ≤ m) : ∀ i, intMatrixReal Q i i ≤ (m : ℝ) := by
  intro i
  change (Q i i : ℝ) ≤ (m : ℝ)
  exact_mod_cast hdiag i

#print axioms int_gram_posSemidef
#print axioms int_diagonal_bound
end TightCycleC5.Bridge
