import FlagVectors

/-! Zero padding preserves PSD and diagonal caps, including an empty basis. -/
namespace TightCycleC5.Bridge
open Finset Matrix

/-- Padding does not change the quadratic form on the original coordinates. -/
theorem zeroExtend_quadratic {I : Type*} [Fintype I]
    (Q : Matrix I I ℝ) (x : Option I → ℝ) :
    star x ⬝ᵥ (zeroExtend Q).mulVec x =
      star (fun i => x (some i)) ⬝ᵥ Q.mulVec (fun i => x (some i)) := by
  simp [dotProduct, Matrix.mulVec, Fintype.sum_option, zeroExtend]

theorem zeroExtend_posSemidef {I : Type*} [Fintype I]
    {Q : Matrix I I ℝ} (hQ : Q.PosSemidef) : (zeroExtend Q).PosSemidef := by
  rw [Matrix.posSemidef_iff_dotProduct_mulVec]
  constructor
  · ext a b
    cases a <;> cases b <;> simp [Matrix.conjTranspose_apply, zeroExtend]
    exact hQ.1.apply _ _
  · intro x
    rw [zeroExtend_quadratic]
    exact hQ.dotProduct_mulVec_nonneg _

/-- Nonnegativity of m is necessary at the newly added zero diagonal. -/
theorem zeroExtend_diagonal_le {I : Type*} (Q : Matrix I I ℝ)
    {m : ℝ} (hm : 0 ≤ m) (hdiag : ∀ i, Q i i ≤ m) (a : Option I) :
    zeroExtend Q a a ≤ m := by
  cases a with
  | none => exact hm
  | some i => exact hdiag i

#print axioms zeroExtend_quadratic
#print axioms zeroExtend_posSemidef
#print axioms zeroExtend_diagonal_le
end TightCycleC5.Bridge
