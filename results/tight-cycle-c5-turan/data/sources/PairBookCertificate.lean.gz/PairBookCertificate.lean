import CLCertificate
import PairBookRows

/-! The literal P32 pair-book pattern and root conditions from PROOF §3a.
The exact list of weighted descriptors and arithmetic tables is separate. -/
namespace TightCycleC5.Bridge.PairBookCertificate
open Finset
open CLCertificate (actualEdge)

structure Descriptor where
  rootType : Fin 16
  weight : Fin 32 → ℝ

def rootPattern {V : Type*} (e : V → V → V → Bool) (x u v a : V) : Nat :=
  8 * (e x u v).toNat + 4 * (e x u a).toNat +
    2 * (e x v a).toNat + (e u v a).toNat

def pattern {V : Type*} (e : V → V → V → Bool) (x u v a z : V) : Fin 32 :=
  ⟨16 * (e x u z).toNat + 8 * (e x v z).toNat + 4 * (e u v z).toNat +
    2 * (e a u z).toNat + (e a v z).toNat, by
    have := Bool.toNat_le (e x u z)
    have := Bool.toNat_le (e x v z)
    have := Bool.toNat_le (e u v z)
    have := Bool.toNat_le (e a u z)
    have := Bool.toNat_le (e a v z)
    omega⟩

theorem rootPattern_lt {V : Type*} (e : V → V → V → Bool) (x u v a : V) :
    rootPattern e x u v a < 16 := by
  have := Bool.toNat_le (e x u v)
  have := Bool.toNat_le (e x u a)
  have := Bool.toNat_le (e x v a)
  have := Bool.toNat_le (e u v a)
  unfold rootPattern
  omega

def evaluate {V : Type*} (d : Descriptor) (e : V → V → V → Bool)
    (x u v a b z : V) : ℝ :=
  (if rootPattern e x u v a = d.rootType.val then 1 else 0) *
    d.weight (pattern e x u v a b) * d.weight (pattern e x u v a z) *
    ((if CLCertificate.cherry true e x a b z then 1 else 0) -
      (if CLCertificate.tetrahedron e x a b z then 1 else 0))

def row (d : Descriptor) (G : LabelledStructure 6) : ℝ :=
  evaluate d (fun a b c => G.edge {a, b, c}) 0 1 2 3 4 5

def rootIndicator {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (root : Fin 4 ↪ Fin n) : ℝ :=
  if rootPattern (actualEdge H) (root 0) (root 1) (root 2) (root 3) = d.rootType.val then 1 else 0

noncomputable def actualWeight {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (root : Fin 4 ↪ Fin n) (z : Fin n) : ℝ := by
  classical
  exact if z ∈ Set.range root then 0 else
    d.weight (pattern (actualEdge H) (root 0) (root 1) (root 2) (root 3) z)

theorem rootIndicator_zero_one {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (root : Fin 4 ↪ Fin n) : rootIndicator d H root = 0 ∨ rootIndicator d H root = 1 := by
  unfold rootIndicator
  split_ifs <;> simp

theorem actualWeight_nonneg {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (hw : ∀ p, 0 ≤ d.weight p) (root : Fin 4 ↪ Fin n) (z : Fin n) :
    0 ≤ actualWeight d H root z := by
  classical
  unfold actualWeight
  split_ifs
  · exact le_rfl
  · exact hw _

theorem actualWeight_le_one {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (hw : ∀ p, d.weight p ≤ 1) (root : Fin 4 ↪ Fin n) (z : Fin n) :
    actualWeight d H root z ≤ 1 := by
  classical
  unfold actualWeight
  split_ifs
  · norm_num
  · exact hw _

theorem actualWeight_root_zero {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (root : Fin 4 ↪ Fin n) (z : Fin n) (hz : z ∈ Set.range root) :
    actualWeight d H root z = 0 := by
  classical
  exact if_pos hz

theorem actualWeight_free {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (root : Fin 4 ↪ Fin n) (z : Outside root) :
    actualWeight d H root z.val =
      d.weight (pattern (actualEdge H) (root 0) (root 1) (root 2) (root 3) z.val) := by
  classical
  exact if_neg z.property

theorem kernel_actual {n : Nat} (H : Finset (Finset (Fin n)))
    (x a b z : Fin n) (w : Fin n → ℝ) :
    w b * w z * ((if CLCertificate.cherry true (actualEdge H) x a b z then 1 else 0) -
      (if CLCertificate.tetrahedron (actualEdge H) x a b z then 1 else 0)) =
      pairBookRow H x a w b z := by
  have h := CLCertificate.indicator_factor 1 (w b) (w z) 1
    (CLCertificate.cherry true (actualEdge H) x a b z)
    (CLCertificate.tetrahedron (actualEdge H) x a b z)
  simpa [CLCertificate.cherry, CLCertificate.tetrahedron, actualEdge,
    pairBookRow, HelperG.Lk, HelperG.K4] using h

theorem evaluate_actualWeight {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (root : Fin 4 ↪ Fin n) (free : Fin 2 ↪ Outside root) :
    evaluate d (actualEdge H) (root 0) (root 1) (root 2) (root 3) (free 0).val (free 1).val =
      rootIndicator d H root * pairBookRow H (root 0) (root 3) (actualWeight d H root)
        (free 0).val (free 1).val := by
  classical
  simp only [evaluate, ← actualWeight_free]
  change rootIndicator d H root * actualWeight d H root (free 0).val *
    actualWeight d H root (free 1).val * _ = _
  calc
    _ = rootIndicator d H root *
        (actualWeight d H root (free 0).val * actualWeight d H root (free 1).val *
          ((if CLCertificate.cherry true (actualEdge H) (root 0) (root 3) (free 0).val (free 1).val then 1 else 0) -
            (if CLCertificate.tetrahedron (actualEdge H) (root 0) (root 3) (free 0).val (free 1).val then 1 else 0))) := by ring
    _ = _ := by rw [kernel_actual]

theorem row_sample {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) :
    row d (sampleStructure σ H S) = evaluate d (actualEdge H)
      (σ 0) (σ 1) (σ 2) (σ 3) (σ 4) (σ 5) := by
  have he : (fun a b c => (sampleStructure σ H S).edge {a, b, c}) =
      (fun a b c => actualEdge H (σ a) (σ b) (σ c)) := by
    funext a b c
    simp [sampleStructure, actualEdge]
  unfold row
  rw [he]
  rfl

theorem row_join {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (root : Fin 4 ↪ Fin n) (free : Fin 2 ↪ Outside root) :
    row d (sampleStructure (joinSample root free) H S) =
      rootIndicator d H root * pairBookRow H (root 0) (root 3) (actualWeight d H root)
        (free 0).val (free 1).val := by
  rw [row_sample]
  change evaluate d (actualEdge H)
    (joinSample root free (Fin.castAdd 2 (0 : Fin 4)))
    (joinSample root free (Fin.castAdd 2 (1 : Fin 4)))
    (joinSample root free (Fin.castAdd 2 (2 : Fin 4)))
    (joinSample root free (Fin.castAdd 2 (3 : Fin 4)))
    (joinSample root free (Fin.natAdd 4 (0 : Fin 2)))
    (joinSample root free (Fin.natAdd 4 (1 : Fin 2))) = _
  simp only [joinSample_root, joinSample_free]
  exact evaluate_actualWeight d H root free

set_option maxHeartbeats 1000000 in
theorem row_as_pairBookSixRow {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) :
    row d (sampleStructure σ H S) = pairBookSixRow H (actualWeight d H) (rootIndicator d H) σ := by
  have h := row_join d H S (splitSampleEquiv (r := 4) (f := 2) σ).1
    (splitSampleEquiv (r := 4) (f := 2) σ).2
  rw [joinSample_split] at h
  exact h

/-- Pattern weights in [0,1] give the literal row its W=1 bound. -/
theorem row_mean_lower {n : Nat} (d : Descriptor) (hw0 : ∀ p, 0 ≤ d.weight p)
    (hw1 : ∀ p, d.weight p ≤ 1) (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (hn : 12 ≤ n) (S : Finset (Fin n)) :
    -(1 / ((n : ℝ) - 5)) ≤ uniformMean (fun σ : Fin 6 ↪ Fin n => row d (sampleStructure σ H S)) := by
  have he : (fun σ : Fin 6 ↪ Fin n => row d (sampleStructure σ H S)) =
      pairBookSixRow H (actualWeight d H) (rootIndicator d H) := funext (row_as_pairBookSixRow d H S)
  rw [he]
  simpa only [one_pow] using pair_book_six_row_lower H hH hC hn (actualWeight d H) 1
    (actualWeight_nonneg d H hw0) (actualWeight_le_one d H hw1)
    (actualWeight_root_zero d H) (rootIndicator d H) (rootIndicator_zero_one d H)

def indicatorDescriptor (k : Fin 16) (mask : BitVec 32) : Descriptor :=
  ⟨k, fun p => if mask.getLsbD p.val then 1 else 0⟩

theorem indicator_weight_bounds (k : Fin 16) (mask : BitVec 32) (p : Fin 32) :
    0 ≤ (indicatorDescriptor k mask).weight p ∧ (indicatorDescriptor k mask).weight p ≤ 1 := by
  change (0 : ℝ) ≤ (if mask.getLsbD p.val then 1 else 0) ∧
    (if mask.getLsbD p.val then 1 else 0) ≤ 1
  split_ifs <;> norm_num

theorem indicator_row_mean_lower {n : Nat} (k : Fin 16) (mask : BitVec 32)
    (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H)
    (hn : 12 ≤ n) (S : Finset (Fin n)) :
    -(1 / ((n : ℝ) - 5)) ≤ uniformMean (fun σ : Fin 6 ↪ Fin n =>
      row (indicatorDescriptor k mask) (sampleStructure σ H S)) :=
  row_mean_lower (indicatorDescriptor k mask)
    (fun p => (indicator_weight_bounds k mask p).1) (fun p => (indicator_weight_bounds k mask p).2)
    H hH hC hn S

#print axioms rootPattern_lt
#print axioms rootIndicator_zero_one
#print axioms actualWeight_nonneg
#print axioms actualWeight_le_one
#print axioms actualWeight_root_zero
#print axioms actualWeight_free
#print axioms kernel_actual
#print axioms evaluate_actualWeight
#print axioms row_sample
#print axioms row_join
#print axioms row_as_pairBookSixRow
#print axioms row_mean_lower
#print axioms indicator_weight_bounds
#print axioms indicator_row_mean_lower
end TightCycleC5.Bridge.PairBookCertificate
