-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk188 :
    ∀ i : Fin (min 128 (40547 - 128 * 188)),
      targetCountsMatch (classAt (targetKernelClass ⟨188, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk188

theorem target_counts_kernel_chunk189 :
    ∀ i : Fin (min 128 (40547 - 128 * 189)),
      targetCountsMatch (classAt (targetKernelClass ⟨189, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk189

theorem target_counts_kernel_chunk190 :
    ∀ i : Fin (min 128 (40547 - 128 * 190)),
      targetCountsMatch (classAt (targetKernelClass ⟨190, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk190

theorem target_counts_kernel_chunk191 :
    ∀ i : Fin (min 128 (40547 - 128 * 191)),
      targetCountsMatch (classAt (targetKernelClass ⟨191, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk191


end TightCycleC5.Bridge.P33Arithmetic
