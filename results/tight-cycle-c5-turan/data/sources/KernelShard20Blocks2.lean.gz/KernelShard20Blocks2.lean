import KernelRowIndex
import KernelWitness20

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_20_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 64 * 256 + i.val))
      kernelWitness20Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_64

theorem kernelBlock_20_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 65 * 256 + i.val))
      kernelWitness20Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_65

theorem kernelBlock_20_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 66 * 256 + i.val))
      kernelWitness20Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_66

theorem kernelBlock_20_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 67 * 256 + i.val))
      kernelWitness20Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_67

theorem kernelBlock_20_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 68 * 256 + i.val))
      kernelWitness20Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_68

theorem kernelBlock_20_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 69 * 256 + i.val))
      kernelWitness20Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_69

theorem kernelBlock_20_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 70 * 256 + i.val))
      kernelWitness20Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_70

theorem kernelBlock_20_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 71 * 256 + i.val))
      kernelWitness20Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_71

theorem kernelBlock_20_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 72 * 256 + i.val))
      kernelWitness20Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_72

theorem kernelBlock_20_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 73 * 256 + i.val))
      kernelWitness20Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_73

theorem kernelBlock_20_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 74 * 256 + i.val))
      kernelWitness20Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_74

theorem kernelBlock_20_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 75 * 256 + i.val))
      kernelWitness20Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_75

theorem kernelBlock_20_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 76 * 256 + i.val))
      kernelWitness20Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_76

theorem kernelBlock_20_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 77 * 256 + i.val))
      kernelWitness20Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_77

theorem kernelBlock_20_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 78 * 256 + i.val))
      kernelWitness20Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_78

theorem kernelBlock_20_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 79 * 256 + i.val))
      kernelWitness20Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_79

theorem kernelBlock_20_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 80 * 256 + i.val))
      kernelWitness20Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_80

theorem kernelBlock_20_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 81 * 256 + i.val))
      kernelWitness20Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_81

theorem kernelBlock_20_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 82 * 256 + i.val))
      kernelWitness20Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_82

theorem kernelBlock_20_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 83 * 256 + i.val))
      kernelWitness20Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_83

theorem kernelBlock_20_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 84 * 256 + i.val))
      kernelWitness20Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_84

theorem kernelBlock_20_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 85 * 256 + i.val))
      kernelWitness20Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_85

theorem kernelBlock_20_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 86 * 256 + i.val))
      kernelWitness20Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_86

theorem kernelBlock_20_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 87 * 256 + i.val))
      kernelWitness20Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_87

theorem kernelBlock_20_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 88 * 256 + i.val))
      kernelWitness20Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_88

theorem kernelBlock_20_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 89 * 256 + i.val))
      kernelWitness20Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_89

theorem kernelBlock_20_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 90 * 256 + i.val))
      kernelWitness20Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_90

theorem kernelBlock_20_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 91 * 256 + i.val))
      kernelWitness20Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_91

theorem kernelBlock_20_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 92 * 256 + i.val))
      kernelWitness20Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_92

theorem kernelBlock_20_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 93 * 256 + i.val))
      kernelWitness20Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_93

theorem kernelBlock_20_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 94 * 256 + i.val))
      kernelWitness20Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_94

theorem kernelBlock_20_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 95 * 256 + i.val))
      kernelWitness20Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_95

end TightCycleC5.Bridge.Cover
