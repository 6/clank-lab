-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk108 :
    ∀ i : Fin (min 128 (40547 - 128 * 108)),
      targetCountsMatch (classAt (targetKernelClass ⟨108, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk108

theorem target_counts_kernel_chunk109 :
    ∀ i : Fin (min 128 (40547 - 128 * 109)),
      targetCountsMatch (classAt (targetKernelClass ⟨109, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk109

theorem target_counts_kernel_chunk110 :
    ∀ i : Fin (min 128 (40547 - 128 * 110)),
      targetCountsMatch (classAt (targetKernelClass ⟨110, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk110

theorem target_counts_kernel_chunk111 :
    ∀ i : Fin (min 128 (40547 - 128 * 111)),
      targetCountsMatch (classAt (targetKernelClass ⟨111, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk111


end TightCycleC5.Bridge.P33Arithmetic
