import ColoredCoverSemantics

namespace TightCycleC5.Bridge.ColoredCover
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def coloredWitness192 : Array Nat := #[5919120, 5919840, 5919967, 5920560, 5920087, 5920584, 5921280, 5922000, 5920230, 5921407, 5920729, 5922127, 5920849, 5922247, 5922390, 5922720, 5923440, 5924160, 5924880, 5925600, 5924904, 5925624, 5926320, 5927040, 5924550, 5927760, 5925990, 5928480, 5926014, 5928504, 5927430, 5929200, 5923567, 5925007, 5924287, 5925727, 5924407, 5925847, 5927887, 5928607, 5925049, 5926447, 5925769, 5927167, 5925889, 5927287, 5928649, 5929327, 5929920, 5930640, 5930767, 5931360, 5930887, 5931384, 5932080, 5932800, 5931030, 5932207, 5931529, 5932927, 5931649, 5933047, 5933190, 5933520]

theorem colored_row192 : ∀ c : Fin 64,
    readRow witnessRows (192 * 64 + c.val) = coloredWitness192[c.val]! := by
  decide +kernel
#print axioms colored_row192

theorem colored_check192 : ∀ c : Fin 64,
    checkColored 192 (BitVec.ofNat 6 c.val) (coloredWitness192[c.val]!) = true := by
  decide +kernel
#print axioms colored_check192

theorem colored_family192 : ∀ c : Fin 64,
    checkColored 192 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (192 * 64 + c.val)) = true := by
  intro c
  rw [colored_row192]
  exact colored_check192 c
#print axioms colored_family192

def coloredWitness193 : Array Nat := #[5934240, 5934960, 5935680, 5936400, 5937120, 5937840, 5938560, 5939280, 5940000, 5940720, 5941440, 5942160, 5942880, 5943600, 5944320, 5945040, 5945760, 5946480, 5947200, 5947920, 5948640, 5949360, 5950080, 5950800, 5951520, 5952240, 5952960, 5953680, 5954400, 5955120, 5955840, 5956560, 5957280, 5958000, 5958720, 5959440, 5960160, 5960880, 5961600, 5962320, 5963040, 5963760, 5964480, 5965200, 5965920, 5966640, 5967360, 5968080, 5968800, 5969520, 5970240, 5970960, 5971680, 5972400, 5973120, 5973840, 5974560, 5975280, 5976000, 5976720, 5977440, 5978160, 5978880, 5979600]

theorem colored_row193 : ∀ c : Fin 64,
    readRow witnessRows (193 * 64 + c.val) = coloredWitness193[c.val]! := by
  decide +kernel
#print axioms colored_row193

theorem colored_check193 : ∀ c : Fin 64,
    checkColored 193 (BitVec.ofNat 6 c.val) (coloredWitness193[c.val]!) = true := by
  decide +kernel
#print axioms colored_check193

theorem colored_family193 : ∀ c : Fin 64,
    checkColored 193 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (193 * 64 + c.val)) = true := by
  intro c
  rw [colored_row193]
  exact colored_check193 c
#print axioms colored_family193

def coloredWitness194 : Array Nat := #[5980320, 5981040, 5981760, 5982480, 5983200, 5983920, 5984640, 5985360, 5986080, 5986800, 5987520, 5988240, 5988960, 5989680, 5990400, 5991120, 5991840, 5992560, 5993280, 5994000, 5994720, 5995440, 5996160, 5996880, 5997600, 5998320, 5999040, 5999760, 6000480, 6001200, 6001920, 6002640, 6003360, 6004080, 6004800, 6005520, 6006240, 6006960, 6007680, 6008400, 6009120, 6009840, 6010560, 6011280, 6012000, 6012720, 6013440, 6014160, 6014880, 6015600, 6016320, 6017040, 6017760, 6018480, 6019200, 6019920, 6020640, 6021360, 6022080, 6022800, 6023520, 6024240, 6024960, 6025680]

theorem colored_row194 : ∀ c : Fin 64,
    readRow witnessRows (194 * 64 + c.val) = coloredWitness194[c.val]! := by
  decide +kernel
#print axioms colored_row194

theorem colored_check194 : ∀ c : Fin 64,
    checkColored 194 (BitVec.ofNat 6 c.val) (coloredWitness194[c.val]!) = true := by
  decide +kernel
#print axioms colored_check194

theorem colored_family194 : ∀ c : Fin 64,
    checkColored 194 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (194 * 64 + c.val)) = true := by
  intro c
  rw [colored_row194]
  exact colored_check194 c
#print axioms colored_family194

def coloredWitness195 : Array Nat := #[6026400, 6027120, 6027840, 6028560, 6029280, 6030000, 6030720, 6031440, 6032160, 6032880, 6033600, 6034320, 6035040, 6035760, 6036480, 6037200, 6037920, 6038640, 6039360, 6040080, 6040800, 6041520, 6042240, 6042960, 6043680, 6044400, 6045120, 6045840, 6046560, 6047280, 6048000, 6048720, 6049440, 6050160, 6050880, 6051600, 6052320, 6053040, 6053760, 6054480, 6055200, 6055920, 6056640, 6057360, 6058080, 6058800, 6059520, 6060240, 6060960, 6061680, 6062400, 6063120, 6063840, 6064560, 6065280, 6066000, 6066720, 6067440, 6068160, 6068880, 6069600, 6070320, 6071040, 6071760]

theorem colored_row195 : ∀ c : Fin 64,
    readRow witnessRows (195 * 64 + c.val) = coloredWitness195[c.val]! := by
  decide +kernel
#print axioms colored_row195

theorem colored_check195 : ∀ c : Fin 64,
    checkColored 195 (BitVec.ofNat 6 c.val) (coloredWitness195[c.val]!) = true := by
  decide +kernel
#print axioms colored_check195

theorem colored_family195 : ∀ c : Fin 64,
    checkColored 195 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (195 * 64 + c.val)) = true := by
  intro c
  rw [colored_row195]
  exact colored_check195 c
#print axioms colored_family195

def coloredWitness196 : Array Nat := #[6072480, 6073200, 6073920, 6074640, 6075360, 6076080, 6076800, 6077520, 6078240, 6078960, 6079680, 6080400, 6081120, 6081840, 6082560, 6083280, 6084000, 6084720, 6085440, 6086160, 6086880, 6087600, 6088320, 6089040, 6089760, 6090480, 6091200, 6091920, 6092640, 6093360, 6094080, 6094800, 6095520, 6096240, 6096960, 6097680, 6098400, 6099120, 6099840, 6100560, 6101280, 6102000, 6102720, 6103440, 6104160, 6104880, 6105600, 6106320, 6107040, 6107760, 6108480, 6109200, 6109920, 6110640, 6111360, 6112080, 6112800, 6113520, 6114240, 6114960, 6115680, 6116400, 6117120, 6117840]

theorem colored_row196 : ∀ c : Fin 64,
    readRow witnessRows (196 * 64 + c.val) = coloredWitness196[c.val]! := by
  decide +kernel
#print axioms colored_row196

theorem colored_check196 : ∀ c : Fin 64,
    checkColored 196 (BitVec.ofNat 6 c.val) (coloredWitness196[c.val]!) = true := by
  decide +kernel
#print axioms colored_check196

theorem colored_family196 : ∀ c : Fin 64,
    checkColored 196 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (196 * 64 + c.val)) = true := by
  intro c
  rw [colored_row196]
  exact colored_check196 c
#print axioms colored_family196

def coloredWitness197 : Array Nat := #[6118560, 6119280, 6119407, 6120000, 6120720, 6121440, 6122160, 6122880, 6120847, 6122287, 6121567, 6123007, 6123600, 6124320, 6124447, 6125040, 6125760, 6126480, 6127200, 6127920, 6128640, 6129360, 6130080, 6130800, 6131520, 6132240, 6132960, 6133680, 6134400, 6135120, 6135840, 6136560, 6125887, 6127327, 6126607, 6128047, 6131647, 6133087, 6132367, 6133807, 6128767, 6130207, 6129487, 6130927, 6134527, 6135967, 6135247, 6136687, 6137280, 6138000, 6138127, 6138720, 6139440, 6140160, 6140880, 6141600, 6139567, 6141007, 6140287, 6141727, 6142320, 6143040, 6143167, 6143760]

theorem colored_row197 : ∀ c : Fin 64,
    readRow witnessRows (197 * 64 + c.val) = coloredWitness197[c.val]! := by
  decide +kernel
#print axioms colored_row197

theorem colored_check197 : ∀ c : Fin 64,
    checkColored 197 (BitVec.ofNat 6 c.val) (coloredWitness197[c.val]!) = true := by
  decide +kernel
#print axioms colored_check197

theorem colored_family197 : ∀ c : Fin 64,
    checkColored 197 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (197 * 64 + c.val)) = true := by
  intro c
  rw [colored_row197]
  exact colored_check197 c
#print axioms colored_family197

def coloredWitness198 : Array Nat := #[6144480, 6145200, 6145920, 6146640, 6147360, 6148080, 6148800, 6149520, 6150240, 6150960, 6151680, 6152400, 6153120, 6153840, 6154560, 6155280, 6156000, 6156720, 6157440, 6158160, 6158880, 6159600, 6160320, 6161040, 6161760, 6162480, 6163200, 6163920, 6164640, 6165360, 6166080, 6166800, 6167520, 6168240, 6168960, 6169680, 6170400, 6171120, 6171840, 6172560, 6173280, 6174000, 6174720, 6175440, 6176160, 6176880, 6177600, 6178320, 6179040, 6179760, 6180480, 6181200, 6181920, 6182640, 6183360, 6184080, 6184800, 6185520, 6186240, 6186960, 6187680, 6188400, 6189120, 6189840]

theorem colored_row198 : ∀ c : Fin 64,
    readRow witnessRows (198 * 64 + c.val) = coloredWitness198[c.val]! := by
  decide +kernel
#print axioms colored_row198

theorem colored_check198 : ∀ c : Fin 64,
    checkColored 198 (BitVec.ofNat 6 c.val) (coloredWitness198[c.val]!) = true := by
  decide +kernel
#print axioms colored_check198

theorem colored_family198 : ∀ c : Fin 64,
    checkColored 198 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (198 * 64 + c.val)) = true := by
  intro c
  rw [colored_row198]
  exact colored_check198 c
#print axioms colored_family198

def coloredWitness199 : Array Nat := #[6190560, 6191280, 6191407, 6192000, 6192720, 6193440, 6194160, 6194880, 6192847, 6194287, 6193567, 6195007, 6195600, 6196320, 6196447, 6197040, 6197760, 6198480, 6199200, 6199920, 6200640, 6201360, 6202080, 6202800, 6203520, 6204240, 6204960, 6205680, 6206400, 6207120, 6207840, 6208560, 6197887, 6199327, 6198607, 6200047, 6203647, 6205087, 6204367, 6205807, 6200767, 6202207, 6201487, 6202927, 6206527, 6207967, 6207247, 6208687, 6209280, 6210000, 6210127, 6210720, 6211440, 6212160, 6212880, 6213600, 6211567, 6213007, 6212287, 6213727, 6214320, 6215040, 6215167, 6215760]

theorem colored_row199 : ∀ c : Fin 64,
    readRow witnessRows (199 * 64 + c.val) = coloredWitness199[c.val]! := by
  decide +kernel
#print axioms colored_row199

theorem colored_check199 : ∀ c : Fin 64,
    checkColored 199 (BitVec.ofNat 6 c.val) (coloredWitness199[c.val]!) = true := by
  decide +kernel
#print axioms colored_check199

theorem colored_family199 : ∀ c : Fin 64,
    checkColored 199 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (199 * 64 + c.val)) = true := by
  intro c
  rw [colored_row199]
  exact colored_check199 c
#print axioms colored_family199

def coloredWitness200 : Array Nat := #[6216480, 6217200, 6217920, 6218640, 6217944, 6218664, 6219360, 6220080, 6220800, 6221520, 6222240, 6222960, 6222264, 6222984, 6223680, 6224400, 6225120, 6225840, 6226560, 6227280, 6226584, 6227304, 6228000, 6228720, 6229440, 6230160, 6230880, 6231600, 6230904, 6231624, 6232320, 6233040, 6233760, 6234480, 6235200, 6235920, 6235224, 6235944, 6236640, 6237360, 6238080, 6238800, 6239520, 6240240, 6239544, 6240264, 6240960, 6241680, 6242400, 6243120, 6243840, 6244560, 6243864, 6244584, 6245280, 6246000, 6246720, 6247440, 6248160, 6248880, 6248184, 6248904, 6249600, 6250320]

theorem colored_row200 : ∀ c : Fin 64,
    readRow witnessRows (200 * 64 + c.val) = coloredWitness200[c.val]! := by
  decide +kernel
#print axioms colored_row200

theorem colored_check200 : ∀ c : Fin 64,
    checkColored 200 (BitVec.ofNat 6 c.val) (coloredWitness200[c.val]!) = true := by
  decide +kernel
#print axioms colored_check200

theorem colored_family200 : ∀ c : Fin 64,
    checkColored 200 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (200 * 64 + c.val)) = true := by
  intro c
  rw [colored_row200]
  exact colored_check200 c
#print axioms colored_family200

def coloredWitness201 : Array Nat := #[6251040, 6251760, 6252480, 6253200, 6252504, 6253224, 6253920, 6254640, 6255360, 6256080, 6256800, 6257520, 6256824, 6257544, 6258240, 6258960, 6259680, 6260400, 6261120, 6261840, 6261144, 6261864, 6262560, 6263280, 6264000, 6264720, 6265440, 6266160, 6265464, 6266184, 6266880, 6267600, 6268320, 6269040, 6269760, 6270480, 6269784, 6270504, 6271200, 6271920, 6272640, 6273360, 6274080, 6274800, 6274104, 6274824, 6275520, 6276240, 6276960, 6277680, 6278400, 6279120, 6278424, 6279144, 6279840, 6280560, 6281280, 6282000, 6282720, 6283440, 6282744, 6283464, 6284160, 6284880]

theorem colored_row201 : ∀ c : Fin 64,
    readRow witnessRows (201 * 64 + c.val) = coloredWitness201[c.val]! := by
  decide +kernel
#print axioms colored_row201

theorem colored_check201 : ∀ c : Fin 64,
    checkColored 201 (BitVec.ofNat 6 c.val) (coloredWitness201[c.val]!) = true := by
  decide +kernel
#print axioms colored_check201

theorem colored_family201 : ∀ c : Fin 64,
    checkColored 201 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (201 * 64 + c.val)) = true := by
  intro c
  rw [colored_row201]
  exact colored_check201 c
#print axioms colored_family201

def coloredWitness202 : Array Nat := #[6285600, 6286320, 6287040, 6287760, 6288480, 6289200, 6289920, 6290640, 6291360, 6292080, 6292800, 6293520, 6294240, 6294960, 6295680, 6296400, 6297120, 6297840, 6298560, 6299280, 6300000, 6300720, 6301440, 6302160, 6302880, 6303600, 6304320, 6305040, 6305760, 6306480, 6307200, 6307920, 6308640, 6309360, 6310080, 6310800, 6311520, 6312240, 6312960, 6313680, 6314400, 6315120, 6315840, 6316560, 6317280, 6318000, 6318720, 6319440, 6320160, 6320880, 6321600, 6322320, 6323040, 6323760, 6324480, 6325200, 6325920, 6326640, 6327360, 6328080, 6328800, 6329520, 6330240, 6330960]

theorem colored_row202 : ∀ c : Fin 64,
    readRow witnessRows (202 * 64 + c.val) = coloredWitness202[c.val]! := by
  decide +kernel
#print axioms colored_row202

theorem colored_check202 : ∀ c : Fin 64,
    checkColored 202 (BitVec.ofNat 6 c.val) (coloredWitness202[c.val]!) = true := by
  decide +kernel
#print axioms colored_check202

theorem colored_family202 : ∀ c : Fin 64,
    checkColored 202 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (202 * 64 + c.val)) = true := by
  intro c
  rw [colored_row202]
  exact colored_check202 c
#print axioms colored_family202

def coloredWitness203 : Array Nat := #[6331680, 6332400, 6333120, 6333840, 6334560, 6335280, 6336000, 6336720, 6337440, 6338160, 6338880, 6339600, 6340320, 6341040, 6341760, 6342480, 6343200, 6343920, 6344640, 6345360, 6346080, 6346800, 6347520, 6348240, 6348960, 6349680, 6350400, 6351120, 6351840, 6352560, 6353280, 6354000, 6354720, 6355440, 6356160, 6356880, 6357600, 6358320, 6359040, 6359760, 6360480, 6361200, 6361920, 6362640, 6363360, 6364080, 6364800, 6365520, 6366240, 6366960, 6367680, 6368400, 6369120, 6369840, 6370560, 6371280, 6372000, 6372720, 6373440, 6374160, 6374880, 6375600, 6376320, 6377040]

theorem colored_row203 : ∀ c : Fin 64,
    readRow witnessRows (203 * 64 + c.val) = coloredWitness203[c.val]! := by
  decide +kernel
#print axioms colored_row203

theorem colored_check203 : ∀ c : Fin 64,
    checkColored 203 (BitVec.ofNat 6 c.val) (coloredWitness203[c.val]!) = true := by
  decide +kernel
#print axioms colored_check203

theorem colored_family203 : ∀ c : Fin 64,
    checkColored 203 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (203 * 64 + c.val)) = true := by
  intro c
  rw [colored_row203]
  exact colored_check203 c
#print axioms colored_family203

def coloredWitness204 : Array Nat := #[6377760, 6378480, 6379200, 6379920, 6380640, 6381360, 6382080, 6382800, 6383520, 6384240, 6384960, 6385680, 6386400, 6387120, 6387840, 6388560, 6389280, 6390000, 6390720, 6391440, 6392160, 6392880, 6393600, 6394320, 6395040, 6395760, 6396480, 6397200, 6397920, 6398640, 6399360, 6400080, 6400800, 6401520, 6402240, 6402960, 6403680, 6404400, 6405120, 6405840, 6406560, 6407280, 6408000, 6408720, 6409440, 6410160, 6410880, 6411600, 6412320, 6413040, 6413760, 6414480, 6415200, 6415920, 6416640, 6417360, 6418080, 6418800, 6419520, 6420240, 6420960, 6421680, 6422400, 6423120]

theorem colored_row204 : ∀ c : Fin 64,
    readRow witnessRows (204 * 64 + c.val) = coloredWitness204[c.val]! := by
  decide +kernel
#print axioms colored_row204

theorem colored_check204 : ∀ c : Fin 64,
    checkColored 204 (BitVec.ofNat 6 c.val) (coloredWitness204[c.val]!) = true := by
  decide +kernel
#print axioms colored_check204

theorem colored_family204 : ∀ c : Fin 64,
    checkColored 204 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (204 * 64 + c.val)) = true := by
  intro c
  rw [colored_row204]
  exact colored_check204 c
#print axioms colored_family204

def coloredWitness205 : Array Nat := #[6423840, 6424560, 6425280, 6426000, 6426720, 6427440, 6428160, 6428880, 6429600, 6430320, 6431040, 6431760, 6432480, 6433200, 6433920, 6434640, 6435360, 6436080, 6436800, 6437520, 6438240, 6438960, 6439680, 6440400, 6441120, 6441840, 6442560, 6443280, 6444000, 6444720, 6445440, 6446160, 6446880, 6447600, 6448320, 6449040, 6449760, 6450480, 6451200, 6451920, 6452640, 6453360, 6454080, 6454800, 6455520, 6456240, 6456960, 6457680, 6458400, 6459120, 6459840, 6460560, 6461280, 6462000, 6462720, 6463440, 6464160, 6464880, 6465600, 6466320, 6467040, 6467760, 6468480, 6469200]

theorem colored_row205 : ∀ c : Fin 64,
    readRow witnessRows (205 * 64 + c.val) = coloredWitness205[c.val]! := by
  decide +kernel
#print axioms colored_row205

theorem colored_check205 : ∀ c : Fin 64,
    checkColored 205 (BitVec.ofNat 6 c.val) (coloredWitness205[c.val]!) = true := by
  decide +kernel
#print axioms colored_check205

theorem colored_family205 : ∀ c : Fin 64,
    checkColored 205 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (205 * 64 + c.val)) = true := by
  intro c
  rw [colored_row205]
  exact colored_check205 c
#print axioms colored_family205

def coloredWitness206 : Array Nat := #[6469920, 6470640, 6471360, 6472080, 6472800, 6473520, 6474240, 6474960, 6475680, 6476400, 6477120, 6477840, 6478560, 6479280, 6480000, 6480720, 6481440, 6482160, 6482880, 6483600, 6484320, 6485040, 6485760, 6486480, 6487200, 6487920, 6488640, 6489360, 6490080, 6490800, 6491520, 6492240, 6492960, 6493680, 6494400, 6495120, 6495840, 6496560, 6497280, 6498000, 6498720, 6499440, 6500160, 6500880, 6501600, 6502320, 6503040, 6503760, 6504480, 6505200, 6505920, 6506640, 6507360, 6508080, 6508800, 6509520, 6510240, 6510960, 6511680, 6512400, 6513120, 6513840, 6514560, 6515280]

theorem colored_row206 : ∀ c : Fin 64,
    readRow witnessRows (206 * 64 + c.val) = coloredWitness206[c.val]! := by
  decide +kernel
#print axioms colored_row206

theorem colored_check206 : ∀ c : Fin 64,
    checkColored 206 (BitVec.ofNat 6 c.val) (coloredWitness206[c.val]!) = true := by
  decide +kernel
#print axioms colored_check206

theorem colored_family206 : ∀ c : Fin 64,
    checkColored 206 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (206 * 64 + c.val)) = true := by
  intro c
  rw [colored_row206]
  exact colored_check206 c
#print axioms colored_family206

def coloredWitness207 : Array Nat := #[6516000, 6516720, 6517440, 6518160, 6518880, 6519600, 6520320, 6521040, 6521760, 6522480, 6523200, 6523920, 6524640, 6525360, 6526080, 6526800, 6527520, 6528240, 6528960, 6529680, 6530400, 6531120, 6531840, 6532560, 6533280, 6534000, 6534720, 6535440, 6536160, 6536880, 6537600, 6538320, 6539040, 6539760, 6540480, 6541200, 6541920, 6542640, 6543360, 6544080, 6544800, 6545520, 6546240, 6546960, 6547680, 6548400, 6549120, 6549840, 6550560, 6551280, 6552000, 6552720, 6553440, 6554160, 6554880, 6555600, 6556320, 6557040, 6557760, 6558480, 6559200, 6559920, 6560640, 6561360]

theorem colored_row207 : ∀ c : Fin 64,
    readRow witnessRows (207 * 64 + c.val) = coloredWitness207[c.val]! := by
  decide +kernel
#print axioms colored_row207

theorem colored_check207 : ∀ c : Fin 64,
    checkColored 207 (BitVec.ofNat 6 c.val) (coloredWitness207[c.val]!) = true := by
  decide +kernel
#print axioms colored_check207

theorem colored_family207 : ∀ c : Fin 64,
    checkColored 207 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (207 * 64 + c.val)) = true := by
  intro c
  rw [colored_row207]
  exact colored_check207 c
#print axioms colored_family207

def coloredWitness208 : Array Nat := #[6562080, 6562800, 6563520, 6564240, 6564960, 6565680, 6566400, 6567120, 6567840, 6568560, 6569280, 6570000, 6570720, 6571440, 6572160, 6572880, 6573600, 6574320, 6575040, 6575760, 6576480, 6577200, 6577920, 6578640, 6579360, 6580080, 6580800, 6581520, 6582240, 6582960, 6583680, 6584400, 6585120, 6585840, 6586560, 6587280, 6588000, 6588720, 6589440, 6590160, 6590880, 6591600, 6592320, 6593040, 6593760, 6594480, 6595200, 6595920, 6596640, 6597360, 6598080, 6598800, 6599520, 6600240, 6600960, 6601680, 6602400, 6603120, 6603840, 6604560, 6605280, 6606000, 6606720, 6607440]

theorem colored_row208 : ∀ c : Fin 64,
    readRow witnessRows (208 * 64 + c.val) = coloredWitness208[c.val]! := by
  decide +kernel
#print axioms colored_row208

theorem colored_check208 : ∀ c : Fin 64,
    checkColored 208 (BitVec.ofNat 6 c.val) (coloredWitness208[c.val]!) = true := by
  decide +kernel
#print axioms colored_check208

theorem colored_family208 : ∀ c : Fin 64,
    checkColored 208 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (208 * 64 + c.val)) = true := by
  intro c
  rw [colored_row208]
  exact colored_check208 c
#print axioms colored_family208

def coloredWitness209 : Array Nat := #[6608160, 6608880, 6609600, 6610320, 6611040, 6611760, 6612480, 6613200, 6613920, 6614640, 6615360, 6616080, 6616800, 6617520, 6618240, 6618960, 6619680, 6620400, 6621120, 6621840, 6622560, 6623280, 6624000, 6624720, 6625440, 6626160, 6626880, 6627600, 6628320, 6629040, 6629760, 6630480, 6631200, 6631920, 6632640, 6633360, 6634080, 6634800, 6635520, 6636240, 6636960, 6637680, 6638400, 6639120, 6639840, 6640560, 6641280, 6642000, 6642720, 6643440, 6644160, 6644880, 6645600, 6646320, 6647040, 6647760, 6648480, 6649200, 6649920, 6650640, 6651360, 6652080, 6652800, 6653520]

theorem colored_row209 : ∀ c : Fin 64,
    readRow witnessRows (209 * 64 + c.val) = coloredWitness209[c.val]! := by
  decide +kernel
#print axioms colored_row209

theorem colored_check209 : ∀ c : Fin 64,
    checkColored 209 (BitVec.ofNat 6 c.val) (coloredWitness209[c.val]!) = true := by
  decide +kernel
#print axioms colored_check209

theorem colored_family209 : ∀ c : Fin 64,
    checkColored 209 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (209 * 64 + c.val)) = true := by
  intro c
  rw [colored_row209]
  exact colored_check209 c
#print axioms colored_family209

def coloredWitness210 : Array Nat := #[6654240, 6654960, 6655680, 6656400, 6657120, 6657840, 6658560, 6659280, 6660000, 6660720, 6661440, 6662160, 6662880, 6663600, 6664320, 6665040, 6665760, 6666480, 6667200, 6667920, 6668640, 6669360, 6670080, 6670800, 6671520, 6672240, 6672960, 6673680, 6674400, 6675120, 6675840, 6676560, 6677280, 6678000, 6678720, 6679440, 6680160, 6680880, 6681600, 6682320, 6683040, 6683760, 6684480, 6685200, 6685920, 6686640, 6687360, 6688080, 6688800, 6689520, 6690240, 6690960, 6691680, 6692400, 6693120, 6693840, 6694560, 6695280, 6696000, 6696720, 6697440, 6698160, 6698880, 6699600]

theorem colored_row210 : ∀ c : Fin 64,
    readRow witnessRows (210 * 64 + c.val) = coloredWitness210[c.val]! := by
  decide +kernel
#print axioms colored_row210

theorem colored_check210 : ∀ c : Fin 64,
    checkColored 210 (BitVec.ofNat 6 c.val) (coloredWitness210[c.val]!) = true := by
  decide +kernel
#print axioms colored_check210

theorem colored_family210 : ∀ c : Fin 64,
    checkColored 210 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (210 * 64 + c.val)) = true := by
  intro c
  rw [colored_row210]
  exact colored_check210 c
#print axioms colored_family210

def coloredWitness211 : Array Nat := #[6700320, 6701040, 6701760, 6702480, 6703200, 6703920, 6704640, 6705360, 6706080, 6706800, 6707520, 6708240, 6708960, 6709680, 6710400, 6711120, 6711840, 6712560, 6713280, 6714000, 6714720, 6715440, 6716160, 6716880, 6717600, 6718320, 6719040, 6719760, 6720480, 6721200, 6721920, 6722640, 6723360, 6724080, 6724800, 6725520, 6726240, 6726960, 6727680, 6728400, 6729120, 6729840, 6730560, 6731280, 6732000, 6732720, 6733440, 6734160, 6734880, 6735600, 6736320, 6737040, 6737760, 6738480, 6739200, 6739920, 6740640, 6741360, 6742080, 6742800, 6743520, 6744240, 6744960, 6745680]

theorem colored_row211 : ∀ c : Fin 64,
    readRow witnessRows (211 * 64 + c.val) = coloredWitness211[c.val]! := by
  decide +kernel
#print axioms colored_row211

theorem colored_check211 : ∀ c : Fin 64,
    checkColored 211 (BitVec.ofNat 6 c.val) (coloredWitness211[c.val]!) = true := by
  decide +kernel
#print axioms colored_check211

theorem colored_family211 : ∀ c : Fin 64,
    checkColored 211 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (211 * 64 + c.val)) = true := by
  intro c
  rw [colored_row211]
  exact colored_check211 c
#print axioms colored_family211

def coloredWitness212 : Array Nat := #[6746400, 6747120, 6747840, 6748560, 6747864, 6748584, 6749280, 6750000, 6750720, 6751440, 6752160, 6752880, 6752184, 6752904, 6753600, 6754320, 6755040, 6755760, 6756480, 6757200, 6756504, 6757224, 6757920, 6758640, 6759360, 6760080, 6760800, 6761520, 6760824, 6761544, 6762240, 6762960, 6763680, 6764400, 6765120, 6765840, 6765144, 6765864, 6766560, 6767280, 6768000, 6768720, 6769440, 6770160, 6769464, 6770184, 6770880, 6771600, 6772320, 6773040, 6773760, 6774480, 6773784, 6774504, 6775200, 6775920, 6776640, 6777360, 6778080, 6778800, 6778104, 6778824, 6779520, 6780240]

theorem colored_row212 : ∀ c : Fin 64,
    readRow witnessRows (212 * 64 + c.val) = coloredWitness212[c.val]! := by
  decide +kernel
#print axioms colored_row212

theorem colored_check212 : ∀ c : Fin 64,
    checkColored 212 (BitVec.ofNat 6 c.val) (coloredWitness212[c.val]!) = true := by
  decide +kernel
#print axioms colored_check212

theorem colored_family212 : ∀ c : Fin 64,
    checkColored 212 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (212 * 64 + c.val)) = true := by
  intro c
  rw [colored_row212]
  exact colored_check212 c
#print axioms colored_family212

def coloredWitness213 : Array Nat := #[6780960, 6781680, 6782400, 6783120, 6782424, 6783144, 6783840, 6784560, 6785280, 6786000, 6786720, 6787440, 6786744, 6787464, 6788160, 6788880, 6789600, 6790320, 6791040, 6791760, 6791064, 6791784, 6792480, 6793200, 6793920, 6794640, 6795360, 6796080, 6795384, 6796104, 6796800, 6797520, 6798240, 6798960, 6799680, 6800400, 6799704, 6800424, 6801120, 6801840, 6802560, 6803280, 6804000, 6804720, 6804024, 6804744, 6805440, 6806160, 6806880, 6807600, 6808320, 6809040, 6808344, 6809064, 6809760, 6810480, 6811200, 6811920, 6812640, 6813360, 6812664, 6813384, 6814080, 6814800]

theorem colored_row213 : ∀ c : Fin 64,
    readRow witnessRows (213 * 64 + c.val) = coloredWitness213[c.val]! := by
  decide +kernel
#print axioms colored_row213

theorem colored_check213 : ∀ c : Fin 64,
    checkColored 213 (BitVec.ofNat 6 c.val) (coloredWitness213[c.val]!) = true := by
  decide +kernel
#print axioms colored_check213

theorem colored_family213 : ∀ c : Fin 64,
    checkColored 213 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (213 * 64 + c.val)) = true := by
  intro c
  rw [colored_row213]
  exact colored_check213 c
#print axioms colored_family213

def coloredWitness214 : Array Nat := #[6815520, 6816240, 6816960, 6817680, 6818400, 6819120, 6819840, 6820560, 6821280, 6822000, 6822720, 6823440, 6824160, 6824880, 6825600, 6826320, 6827040, 6827760, 6828480, 6829200, 6829920, 6830640, 6831360, 6832080, 6832800, 6833520, 6834240, 6834960, 6835680, 6836400, 6837120, 6837840, 6838560, 6839280, 6840000, 6840720, 6841440, 6842160, 6842880, 6843600, 6844320, 6845040, 6845760, 6846480, 6847200, 6847920, 6848640, 6849360, 6850080, 6850800, 6851520, 6852240, 6852960, 6853680, 6854400, 6855120, 6855840, 6856560, 6857280, 6858000, 6858720, 6859440, 6860160, 6860880]

theorem colored_row214 : ∀ c : Fin 64,
    readRow witnessRows (214 * 64 + c.val) = coloredWitness214[c.val]! := by
  decide +kernel
#print axioms colored_row214

theorem colored_check214 : ∀ c : Fin 64,
    checkColored 214 (BitVec.ofNat 6 c.val) (coloredWitness214[c.val]!) = true := by
  decide +kernel
#print axioms colored_check214

theorem colored_family214 : ∀ c : Fin 64,
    checkColored 214 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (214 * 64 + c.val)) = true := by
  intro c
  rw [colored_row214]
  exact colored_check214 c
#print axioms colored_family214

def coloredWitness215 : Array Nat := #[6861600, 6862320, 6863040, 6863760, 6864480, 6865200, 6865920, 6866640, 6867360, 6868080, 6868800, 6869520, 6870240, 6870960, 6871680, 6872400, 6873120, 6873840, 6874560, 6875280, 6876000, 6876720, 6877440, 6878160, 6878880, 6879600, 6880320, 6881040, 6881760, 6882480, 6883200, 6883920, 6884640, 6885360, 6886080, 6886800, 6887520, 6888240, 6888960, 6889680, 6890400, 6891120, 6891840, 6892560, 6893280, 6894000, 6894720, 6895440, 6896160, 6896880, 6897600, 6898320, 6899040, 6899760, 6900480, 6901200, 6901920, 6902640, 6903360, 6904080, 6904800, 6905520, 6906240, 6906960]

theorem colored_row215 : ∀ c : Fin 64,
    readRow witnessRows (215 * 64 + c.val) = coloredWitness215[c.val]! := by
  decide +kernel
#print axioms colored_row215

theorem colored_check215 : ∀ c : Fin 64,
    checkColored 215 (BitVec.ofNat 6 c.val) (coloredWitness215[c.val]!) = true := by
  decide +kernel
#print axioms colored_check215

theorem colored_family215 : ∀ c : Fin 64,
    checkColored 215 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (215 * 64 + c.val)) = true := by
  intro c
  rw [colored_row215]
  exact colored_check215 c
#print axioms colored_family215

def coloredWitness216 : Array Nat := #[6907680, 6908400, 6909120, 6909840, 6910560, 6911280, 6912000, 6912720, 6913440, 6914160, 6914880, 6915600, 6916320, 6917040, 6917760, 6918480, 6919200, 6919920, 6920640, 6921360, 6922080, 6922800, 6923520, 6924240, 6924960, 6925680, 6926400, 6927120, 6927840, 6928560, 6929280, 6930000, 6930720, 6931440, 6932160, 6932880, 6933600, 6934320, 6935040, 6935760, 6936480, 6937200, 6937920, 6938640, 6939360, 6940080, 6940800, 6941520, 6942240, 6942960, 6943680, 6944400, 6945120, 6945840, 6946560, 6947280, 6948000, 6948720, 6949440, 6950160, 6950880, 6951600, 6952320, 6953040]

theorem colored_row216 : ∀ c : Fin 64,
    readRow witnessRows (216 * 64 + c.val) = coloredWitness216[c.val]! := by
  decide +kernel
#print axioms colored_row216

theorem colored_check216 : ∀ c : Fin 64,
    checkColored 216 (BitVec.ofNat 6 c.val) (coloredWitness216[c.val]!) = true := by
  decide +kernel
#print axioms colored_check216

theorem colored_family216 : ∀ c : Fin 64,
    checkColored 216 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (216 * 64 + c.val)) = true := by
  intro c
  rw [colored_row216]
  exact colored_check216 c
#print axioms colored_family216

def coloredWitness217 : Array Nat := #[6953760, 6954480, 6955200, 6955920, 6956640, 6957360, 6958080, 6958800, 6959520, 6960240, 6960960, 6961680, 6962400, 6963120, 6963840, 6964560, 6965280, 6966000, 6966720, 6967440, 6968160, 6968880, 6969600, 6970320, 6971040, 6971760, 6972480, 6973200, 6973920, 6974640, 6975360, 6976080, 6976800, 6977520, 6978240, 6978960, 6979680, 6980400, 6981120, 6981840, 6982560, 6983280, 6984000, 6984720, 6985440, 6986160, 6986880, 6987600, 6988320, 6989040, 6989760, 6990480, 6991200, 6991920, 6992640, 6993360, 6994080, 6994800, 6995520, 6996240, 6996960, 6997680, 6998400, 6999120]

theorem colored_row217 : ∀ c : Fin 64,
    readRow witnessRows (217 * 64 + c.val) = coloredWitness217[c.val]! := by
  decide +kernel
#print axioms colored_row217

theorem colored_check217 : ∀ c : Fin 64,
    checkColored 217 (BitVec.ofNat 6 c.val) (coloredWitness217[c.val]!) = true := by
  decide +kernel
#print axioms colored_check217

theorem colored_family217 : ∀ c : Fin 64,
    checkColored 217 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (217 * 64 + c.val)) = true := by
  intro c
  rw [colored_row217]
  exact colored_check217 c
#print axioms colored_family217

def coloredWitness218 : Array Nat := #[6999840, 7000560, 7001280, 7002000, 7002720, 7003440, 7004160, 7004880, 7005600, 7006320, 7007040, 7007760, 7008480, 7009200, 7009920, 7010640, 7011360, 7012080, 7012800, 7013520, 7014240, 7014960, 7015680, 7016400, 7017120, 7017840, 7018560, 7019280, 7020000, 7020720, 7021440, 7022160, 7022880, 7023600, 7024320, 7025040, 7025760, 7026480, 7027200, 7027920, 7028640, 7029360, 7030080, 7030800, 7031520, 7032240, 7032960, 7033680, 7034400, 7035120, 7035840, 7036560, 7037280, 7038000, 7038720, 7039440, 7040160, 7040880, 7041600, 7042320, 7043040, 7043760, 7044480, 7045200]

theorem colored_row218 : ∀ c : Fin 64,
    readRow witnessRows (218 * 64 + c.val) = coloredWitness218[c.val]! := by
  decide +kernel
#print axioms colored_row218

theorem colored_check218 : ∀ c : Fin 64,
    checkColored 218 (BitVec.ofNat 6 c.val) (coloredWitness218[c.val]!) = true := by
  decide +kernel
#print axioms colored_check218

theorem colored_family218 : ∀ c : Fin 64,
    checkColored 218 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (218 * 64 + c.val)) = true := by
  intro c
  rw [colored_row218]
  exact colored_check218 c
#print axioms colored_family218

def coloredWitness219 : Array Nat := #[7045920, 7046640, 7047360, 7048080, 7048800, 7049520, 7050240, 7050960, 7051680, 7052400, 7053120, 7053840, 7054560, 7055280, 7056000, 7056720, 7057440, 7058160, 7058880, 7059600, 7060320, 7061040, 7061760, 7062480, 7063200, 7063920, 7064640, 7065360, 7066080, 7066800, 7067520, 7068240, 7068960, 7069680, 7070400, 7071120, 7071840, 7072560, 7073280, 7074000, 7074720, 7075440, 7076160, 7076880, 7077600, 7078320, 7079040, 7079760, 7080480, 7081200, 7081920, 7082640, 7083360, 7084080, 7084800, 7085520, 7086240, 7086960, 7087680, 7088400, 7089120, 7089840, 7090560, 7091280]

theorem colored_row219 : ∀ c : Fin 64,
    readRow witnessRows (219 * 64 + c.val) = coloredWitness219[c.val]! := by
  decide +kernel
#print axioms colored_row219

theorem colored_check219 : ∀ c : Fin 64,
    checkColored 219 (BitVec.ofNat 6 c.val) (coloredWitness219[c.val]!) = true := by
  decide +kernel
#print axioms colored_check219

theorem colored_family219 : ∀ c : Fin 64,
    checkColored 219 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (219 * 64 + c.val)) = true := by
  intro c
  rw [colored_row219]
  exact colored_check219 c
#print axioms colored_family219

def coloredWitness220 : Array Nat := #[7092000, 7092720, 7093440, 7094160, 7094880, 7095600, 7096320, 7097040, 7097760, 7098480, 7099200, 7099920, 7100640, 7101360, 7102080, 7102800, 7103520, 7104240, 7104960, 7105680, 7106400, 7107120, 7107840, 7108560, 7109280, 7110000, 7110720, 7111440, 7112160, 7112880, 7113600, 7114320, 7115040, 7115760, 7116480, 7117200, 7117920, 7118640, 7119360, 7120080, 7120800, 7121520, 7122240, 7122960, 7123680, 7124400, 7125120, 7125840, 7126560, 7127280, 7128000, 7128720, 7129440, 7130160, 7130880, 7131600, 7132320, 7133040, 7133760, 7134480, 7135200, 7135920, 7136640, 7137360]

theorem colored_row220 : ∀ c : Fin 64,
    readRow witnessRows (220 * 64 + c.val) = coloredWitness220[c.val]! := by
  decide +kernel
#print axioms colored_row220

theorem colored_check220 : ∀ c : Fin 64,
    checkColored 220 (BitVec.ofNat 6 c.val) (coloredWitness220[c.val]!) = true := by
  decide +kernel
#print axioms colored_check220

theorem colored_family220 : ∀ c : Fin 64,
    checkColored 220 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (220 * 64 + c.val)) = true := by
  intro c
  rw [colored_row220]
  exact colored_check220 c
#print axioms colored_family220

def coloredWitness221 : Array Nat := #[7138080, 7138800, 7139520, 7140240, 7140960, 7141680, 7142400, 7143120, 7143840, 7144560, 7145280, 7146000, 7146720, 7147440, 7148160, 7148880, 7149600, 7150320, 7151040, 7151760, 7152480, 7153200, 7153920, 7154640, 7155360, 7156080, 7156800, 7157520, 7158240, 7158960, 7159680, 7160400, 7161120, 7161840, 7162560, 7163280, 7164000, 7164720, 7165440, 7166160, 7166880, 7167600, 7168320, 7169040, 7169760, 7170480, 7171200, 7171920, 7172640, 7173360, 7174080, 7174800, 7175520, 7176240, 7176960, 7177680, 7178400, 7179120, 7179840, 7180560, 7181280, 7182000, 7182720, 7183440]

theorem colored_row221 : ∀ c : Fin 64,
    readRow witnessRows (221 * 64 + c.val) = coloredWitness221[c.val]! := by
  decide +kernel
#print axioms colored_row221

theorem colored_check221 : ∀ c : Fin 64,
    checkColored 221 (BitVec.ofNat 6 c.val) (coloredWitness221[c.val]!) = true := by
  decide +kernel
#print axioms colored_check221

theorem colored_family221 : ∀ c : Fin 64,
    checkColored 221 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (221 * 64 + c.val)) = true := by
  intro c
  rw [colored_row221]
  exact colored_check221 c
#print axioms colored_family221

def coloredWitness222 : Array Nat := #[7184160, 7184880, 7185600, 7186320, 7185624, 7186344, 7187040, 7187760, 7188480, 7189200, 7189920, 7190640, 7189944, 7190664, 7191360, 7192080, 7192800, 7193520, 7194240, 7194960, 7194264, 7194984, 7195680, 7196400, 7197120, 7197840, 7198560, 7199280, 7198584, 7199304, 7200000, 7200720, 7185513, 7201440, 7186953, 7202160, 7186977, 7202184, 7188393, 7202880, 7189833, 7203600, 7191273, 7204320, 7191297, 7204344, 7192713, 7205040, 7194153, 7205760, 7195593, 7206480, 7195617, 7206504, 7197033, 7207200, 7198473, 7207920, 7199913, 7208640, 7199937, 7208664, 7201353, 7209360]

theorem colored_row222 : ∀ c : Fin 64,
    readRow witnessRows (222 * 64 + c.val) = coloredWitness222[c.val]! := by
  decide +kernel
#print axioms colored_row222

theorem colored_check222 : ∀ c : Fin 64,
    checkColored 222 (BitVec.ofNat 6 c.val) (coloredWitness222[c.val]!) = true := by
  decide +kernel
#print axioms colored_check222

theorem colored_family222 : ∀ c : Fin 64,
    checkColored 222 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (222 * 64 + c.val)) = true := by
  intro c
  rw [colored_row222]
  exact colored_check222 c
#print axioms colored_family222

def coloredWitness223 : Array Nat := #[7210080, 7210800, 7211520, 7212240, 7211544, 7212264, 7212960, 7213680, 7214400, 7215120, 7215840, 7216560, 7215864, 7216584, 7217280, 7218000, 7218720, 7219440, 7220160, 7220880, 7220184, 7220904, 7221600, 7222320, 7223040, 7223760, 7224480, 7225200, 7224504, 7225224, 7225920, 7226640, 7227360, 7228080, 7228800, 7229520, 7228824, 7229544, 7230240, 7230960, 7231680, 7232400, 7233120, 7233840, 7233144, 7233864, 7234560, 7235280, 7236000, 7236720, 7237440, 7238160, 7237464, 7238184, 7238880, 7239600, 7240320, 7241040, 7241760, 7242480, 7241784, 7242504, 7243200, 7243920]

theorem colored_row223 : ∀ c : Fin 64,
    readRow witnessRows (223 * 64 + c.val) = coloredWitness223[c.val]! := by
  decide +kernel
#print axioms colored_row223

theorem colored_check223 : ∀ c : Fin 64,
    checkColored 223 (BitVec.ofNat 6 c.val) (coloredWitness223[c.val]!) = true := by
  decide +kernel
#print axioms colored_check223

theorem colored_family223 : ∀ c : Fin 64,
    checkColored 223 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (223 * 64 + c.val)) = true := by
  intro c
  rw [colored_row223]
  exact colored_check223 c
#print axioms colored_family223

end TightCycleC5.Bridge.ColoredCover
