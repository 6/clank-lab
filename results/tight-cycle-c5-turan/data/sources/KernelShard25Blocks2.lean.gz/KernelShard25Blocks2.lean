import KernelRowIndex
import KernelWitness25

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_25_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 64 * 256 + i.val))
      kernelWitness25Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_64

theorem kernelBlock_25_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 65 * 256 + i.val))
      kernelWitness25Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_65

theorem kernelBlock_25_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 66 * 256 + i.val))
      kernelWitness25Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_66

theorem kernelBlock_25_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 67 * 256 + i.val))
      kernelWitness25Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_67

theorem kernelBlock_25_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 68 * 256 + i.val))
      kernelWitness25Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_68

theorem kernelBlock_25_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 69 * 256 + i.val))
      kernelWitness25Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_69

theorem kernelBlock_25_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 70 * 256 + i.val))
      kernelWitness25Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_70

theorem kernelBlock_25_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 71 * 256 + i.val))
      kernelWitness25Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_71

theorem kernelBlock_25_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 72 * 256 + i.val))
      kernelWitness25Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_72

theorem kernelBlock_25_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 73 * 256 + i.val))
      kernelWitness25Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_73

theorem kernelBlock_25_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 74 * 256 + i.val))
      kernelWitness25Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_74

theorem kernelBlock_25_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 75 * 256 + i.val))
      kernelWitness25Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_75

theorem kernelBlock_25_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 76 * 256 + i.val))
      kernelWitness25Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_76

theorem kernelBlock_25_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 77 * 256 + i.val))
      kernelWitness25Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_77

theorem kernelBlock_25_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 78 * 256 + i.val))
      kernelWitness25Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_78

theorem kernelBlock_25_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 79 * 256 + i.val))
      kernelWitness25Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_79

theorem kernelBlock_25_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 80 * 256 + i.val))
      kernelWitness25Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_80

theorem kernelBlock_25_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 81 * 256 + i.val))
      kernelWitness25Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_81

theorem kernelBlock_25_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 82 * 256 + i.val))
      kernelWitness25Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_82

theorem kernelBlock_25_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 83 * 256 + i.val))
      kernelWitness25Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_83

theorem kernelBlock_25_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 84 * 256 + i.val))
      kernelWitness25Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_84

theorem kernelBlock_25_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 85 * 256 + i.val))
      kernelWitness25Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_85

theorem kernelBlock_25_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 86 * 256 + i.val))
      kernelWitness25Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_86

theorem kernelBlock_25_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 87 * 256 + i.val))
      kernelWitness25Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_87

theorem kernelBlock_25_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 88 * 256 + i.val))
      kernelWitness25Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_88

theorem kernelBlock_25_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 89 * 256 + i.val))
      kernelWitness25Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_89

theorem kernelBlock_25_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 90 * 256 + i.val))
      kernelWitness25Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_90

theorem kernelBlock_25_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 91 * 256 + i.val))
      kernelWitness25Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_91

theorem kernelBlock_25_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 92 * 256 + i.val))
      kernelWitness25Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_92

theorem kernelBlock_25_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 93 * 256 + i.val))
      kernelWitness25Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_93

theorem kernelBlock_25_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 94 * 256 + i.val))
      kernelWitness25Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_94

theorem kernelBlock_25_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 95 * 256 + i.val))
      kernelWitness25Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_95

end TightCycleC5.Bridge.Cover
