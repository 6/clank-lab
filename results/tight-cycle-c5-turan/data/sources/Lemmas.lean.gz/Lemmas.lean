import Statement

/-!
Lemmas of the hand arguments recorded in the NOTE, machine-checked.

* `L1` (`injective_of_c5_edges`): every pair of vertices of `C₅³` lies in a
  common edge, so any map of the cycle sending its edges to edges of a
  3-graph is injective. This is why the `C₅³`-free family is closed under
  blow-ups (a copy in a blow-up projects to a copy in the original).
* `L2` (`containsC5_of_path`): five distinct vertices `a, b, c, d, v` with
  edges `abc, bcd, cdv, dva, vab` form a `C₅³`. Hence in a `C₅³`-free
  3-graph, a vertex `v` outside a `K₄³` on `{a, b, c, d}` sees no three
  pairs of it forming a Hamiltonian path (`c-d-a-b` here).
-/

namespace TightCycleC5

/-- Every two vertices of the tight 5-cycle lie in a common edge. -/
theorem pair_in_edge :
    ∀ i j : Fin 5, ∃ k : Fin 5,
      i ∈ ({k, k + 1, k + 2} : Finset (Fin 5)) ∧ j ∈ ({k, k + 1, k + 2} : Finset (Fin 5)) := by
  decide

theorem triple_card : ∀ k : Fin 5, ({k, k + 1, k + 2} : Finset (Fin 5)).card = 3 := by
  decide

/-- L1: a map of the tight 5-cycle sending each edge onto an edge of a
3-graph is injective. -/
theorem injective_of_c5_edges {n : ℕ} {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H)
    (f : Fin 5 → Fin n) (hf : ∀ i : Fin 5, ({f i, f (i + 1), f (i + 2)} : Finset (Fin n)) ∈ H) :
    Function.Injective f := by
  intro i j hij
  obtain ⟨k, hi, hj⟩ := pair_in_edge i j
  have himg : ({k, k + 1, k + 2} : Finset (Fin 5)).image f = {f k, f (k + 1), f (k + 2)} := by
    simp [Finset.image_insert, Finset.image_singleton]
  have hcard : (({k, k + 1, k + 2} : Finset (Fin 5)).image f).card =
      ({k, k + 1, k + 2} : Finset (Fin 5)).card := by
    rw [himg, hH _ (hf k), triple_card k]
  exact (Finset.card_image_iff.mp hcard) hi hj hij

/-- L2: an explicit tight 5-cycle on five distinct vertices. -/
theorem containsC5_of_path {n : ℕ} {H : Finset (Finset (Fin n))} {a b c d v : Fin n}
    (hdist : [a, b, c, d, v].Nodup)
    (h1 : ({a, b, c} : Finset (Fin n)) ∈ H) (h2 : ({b, c, d} : Finset (Fin n)) ∈ H)
    (h3 : ({c, d, v} : Finset (Fin n)) ∈ H) (h4 : ({d, v, a} : Finset (Fin n)) ∈ H)
    (h5 : ({v, a, b} : Finset (Fin n)) ∈ H) : ContainsC5 H := by
  simp only [List.nodup_cons, List.mem_cons, List.not_mem_nil, or_false, List.nodup_nil,
    and_true, not_or] at hdist
  obtain ⟨⟨hab, hac, had, hav⟩, ⟨hbc, hbd, hbv⟩, ⟨hcd, hcv⟩, hdv⟩ := hdist
  refine ⟨⟨![a, b, c, d, v], ?_⟩, ?_⟩
  · intro i j hij
    fin_cases i <;> fin_cases j <;> simp_all [eq_comm]
  · intro i
    fin_cases i <;> simp <;> first | exact h1 | exact h2 | exact h3 | exact h4 | exact h5

end TightCycleC5
