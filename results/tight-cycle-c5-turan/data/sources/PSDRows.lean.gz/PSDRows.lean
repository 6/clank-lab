import TupleSampling
import OutsideSums

/-! PROOF §3 Lemma 3: PSD bounds for actual uniform six-vertex injections.
Flag maps and root indicators are parameters; concrete certificate matrices
and their flag-index semantics remain separate obligations. -/
namespace TightCycleC5.Bridge
open Finset Matrix
variable {n : ℕ} {I : Type*} [Fintype I] [DecidableEq I]

theorem psd_four_root_free_mean {Q : Matrix I I ℝ} (hQ : Q.PosSemidef)
    {m : ℝ} (hdiag : ∀ i, Q i i ≤ m) (hn : 12 ≤ n)
    (root : Fin 4 ↪ Fin n) (flag : Outside root → I) :
    -m / ((n : ℝ) - 5) ≤ uniformMean (fun free : Fin 2 ↪ Outside root =>
      Q (flag (free 0)) (flag (free 1))) := by
  classical
  rw [pair_injection_mean (fun a b : Outside root => Q (flag a) (flag b))]
  apply psd_four_root_average hQ hdiag hn
  simpa only [card_univ, Fintype.card_fin] using outside_card root

theorem psd_two_root_free_mean {Q : Matrix I I ℝ} (hQ : Q.PosSemidef)
    {m : ℝ} (hdiag : ∀ i, Q i i ≤ m) (hn : 12 ≤ n)
    (root : Fin 2 ↪ Fin n) (flag : Outside root × Outside root → I) :
    -((4 * (n : ℝ) - 14) * m / (((n : ℝ) - 4) * ((n : ℝ) - 5))) ≤
      uniformMean (fun free : Fin 4 ↪ Outside root =>
        Q (flag (free 0, free 1)) (flag (free 2, free 3))) := by
  classical
  rw [quad_injection_mean (fun a b : Outside root × Outside root => Q (flag a) (flag b))]
  apply psd_two_root_average hQ hdiag hn
  simpa only [card_univ, Fintype.card_fin] using outside_card root

noncomputable def psdFourRootSixRow (Q : Matrix I I ℝ)
    (flag : (root : Fin 4 ↪ Fin n) → Outside root → I)
    (g : (Fin 4 ↪ Fin n) → ℝ) (σ : Fin 6 ↪ Fin n) : ℝ :=
  let rf := splitSampleEquiv (r := 4) (f := 2) σ
  g rf.1 * Q (flag rf.1 (rf.2 0)) (flag rf.1 (rf.2 1))

noncomputable def psdTwoRootSixRow (Q : Matrix I I ℝ)
    (flag : (root : Fin 2 ↪ Fin n) → Outside root × Outside root → I)
    (g : (Fin 2 ↪ Fin n) → ℝ) (σ : Fin 6 ↪ Fin n) : ℝ :=
  let rf := splitSampleEquiv (r := 2) (f := 4) σ
  g rf.1 * Q (flag rf.1 (rf.2 0, rf.2 1)) (flag rf.1 (rf.2 2, rf.2 3))

/-- Four-root part of Lemma 3, without an assumed sampling identity. -/
theorem psd_four_root_six_row_lower {Q : Matrix I I ℝ} (hQ : Q.PosSemidef)
    {m : ℝ} (hm : 0 ≤ m) (hdiag : ∀ i, Q i i ≤ m) (hn : 12 ≤ n)
    (flag : (root : Fin 4 ↪ Fin n) → Outside root → I)
    (g : (Fin 4 ↪ Fin n) → ℝ) (hg : ∀ root, g root = 0 ∨ g root = 1) :
    -m / ((n : ℝ) - 5) ≤ uniformMean (psdFourRootSixRow Q flag g) := by
  classical
  letI : Nonempty (Fin 4 ↪ Fin n) := ⟨Fin.castLEEmb (by omega : 4 ≤ n)⟩
  rw [uniformMean_joinSample (r := 4) (f := 2)]
  have he : ∀ (root : Fin 4 ↪ Fin n) (free : Fin 2 ↪ Outside root),
      psdFourRootSixRow Q flag g (joinSample root free) =
      g root * Q (flag root (free 0)) (flag root (free 1)) := by
    intro root free
    change (fun rf : Σ root : Fin 4 ↪ Fin n, Fin 2 ↪ Outside root =>
      g rf.1 * Q (flag rf.1 (rf.2 0)) (flag rf.1 (rf.2 1)))
        (splitSampleEquiv (joinSample root free)) = _
    rw [splitSampleEquiv_join]
  simp_rw [he]
  apply root_mean_lower
  intro root
  rw [uniformMean_const_mul]
  apply root_indicator_lower _ (psd_four_root_free_mean hQ hdiag hn root (flag root)) (hg root)
  apply div_nonpos_of_nonpos_of_nonneg (neg_nonpos.mpr hm)
  have hnR : (12 : ℝ) ≤ n := by exact_mod_cast hn
  linarith

/-- Two-root part of Lemma 3, deleting every overlap of the two ordered
pairs. The error is exactly (4n−14)m/((n−4)(n−5)). -/
theorem psd_two_root_six_row_lower {Q : Matrix I I ℝ} (hQ : Q.PosSemidef)
    {m : ℝ} (hm : 0 ≤ m) (hdiag : ∀ i, Q i i ≤ m) (hn : 12 ≤ n)
    (flag : (root : Fin 2 ↪ Fin n) → Outside root × Outside root → I)
    (g : (Fin 2 ↪ Fin n) → ℝ) (hg : ∀ root, g root = 0 ∨ g root = 1) :
    -((4 * (n : ℝ) - 14) * m / (((n : ℝ) - 4) * ((n : ℝ) - 5))) ≤
      uniformMean (psdTwoRootSixRow Q flag g) := by
  classical
  letI : Nonempty (Fin 2 ↪ Fin n) := ⟨Fin.castLEEmb (by omega : 2 ≤ n)⟩
  rw [uniformMean_joinSample (r := 2) (f := 4)]
  have he : ∀ (root : Fin 2 ↪ Fin n) (free : Fin 4 ↪ Outside root),
      psdTwoRootSixRow Q flag g (joinSample root free) =
      g root * Q (flag root (free 0, free 1)) (flag root (free 2, free 3)) := by
    intro root free
    change (fun rf : Σ root : Fin 2 ↪ Fin n, Fin 4 ↪ Outside root =>
      g rf.1 * Q (flag rf.1 (rf.2 0, rf.2 1)) (flag rf.1 (rf.2 2, rf.2 3)))
        (splitSampleEquiv (joinSample root free)) = _
    rw [splitSampleEquiv_join]
  simp_rw [he]
  apply root_mean_lower
  intro root
  rw [uniformMean_const_mul]
  apply root_indicator_lower _ (psd_two_root_free_mean hQ hdiag hn root (flag root)) (hg root)
  have hnR : (12 : ℝ) ≤ n := by exact_mod_cast hn
  apply neg_nonpos.mpr
  exact div_nonneg (mul_nonneg (by linarith) hm)
    (mul_nonneg (by linarith) (by linarith))

#print axioms psd_four_root_free_mean
#print axioms psd_two_root_free_mean
#print axioms psd_four_root_six_row_lower
#print axioms psd_two_root_six_row_lower
end TightCycleC5.Bridge
