import Mathlib

/-! Finite class expansion for PROOF §3 Lemma 0. Coverage and compatibility
with the concrete six-vertex encodings remain explicit premises. -/

namespace TightCycleC5.Bridge

open Finset

/-- Uniform finite sampling, with the usual zero value on an empty space. -/
noncomputable def uniformMean {Ω : Type*} [Fintype Ω] (f : Ω → ℝ) : ℝ :=
  (∑ x, f x) / (Fintype.card Ω : ℝ)

/-- The probability of a class under uniform sampling. -/
noncomputable def classMass {Ω K : Type*} [Fintype Ω]
    (classOf : Ω → K) (k : K) : ℝ :=
  open Classical in uniformMean (fun x => if classOf x = k then 1 else 0)

theorem uniformMean_const {Ω : Type*} [Fintype Ω] [Nonempty Ω] (c : ℝ) :
    uniformMean (fun _ : Ω => c) = c := by
  have hc : (Fintype.card Ω : ℝ) ≠ 0 := by exact_mod_cast Fintype.card_ne_zero
  simp [uniformMean, hc]

theorem uniformMean_nonneg {Ω : Type*} [Fintype Ω] {f : Ω → ℝ}
    (hf : ∀ x, 0 ≤ f x) : 0 ≤ uniformMean f := by
  exact div_nonneg (Finset.sum_nonneg (fun x _ => hf x)) (Nat.cast_nonneg _)

theorem classMass_nonneg {Ω K : Type*} [Fintype Ω] (classOf : Ω → K) (k : K) :
    0 ≤ classMass classOf k := by
  classical
  apply uniformMean_nonneg
  intro x
  split_ifs <;> norm_num

/-- Exact expansion for any function which is constant on the chosen
classes; class completeness is expressed by the total classOf function. -/
theorem uniformMean_class {Ω K : Type*} [Fintype Ω] [Fintype K]
    (classOf : Ω → K) (v : K → ℝ) :
    uniformMean (fun x => v (classOf x)) = ∑ k, classMass classOf k * v k := by
  classical
  simp only [classMass, uniformMean, div_mul_eq_mul_div, Finset.sum_mul,
    ite_mul, one_mul, zero_mul]
  rw [← Finset.sum_div, Finset.sum_comm]
  congr 1
  apply Finset.sum_congr rfl
  intro x _
  simp [eq_comm]

theorem classMass_sum {Ω K : Type*} [Fintype Ω] [Nonempty Ω] [Fintype K]
    (classOf : Ω → K) : ∑ k, classMass classOf k = 1 := by
  have h := uniformMean_class classOf (fun _ => (1 : ℝ))
  simpa [uniformMean_const] using h.symm

/-- Uniform means are invariant under a bijection of the sample space. -/
theorem uniformMean_equiv {Ω : Type*} [Fintype Ω] (e : Ω ≃ Ω) (f : Ω → ℝ) :
    uniformMean (fun x => f (e x)) = uniformMean f := by
  unfold uniformMean
  rw [Equiv.sum_comp]

/-- Reindexing between different, bijective uniform sample spaces. -/
theorem uniformMean_equiv_between {Ω Λ : Type*} [Fintype Ω] [Fintype Λ]
    (e : Ω ≃ Λ) (f : Λ → ℝ) :
    uniformMean (fun x => f (e x)) = uniformMean f := by
  unfold uniformMean
  rw [Equiv.sum_comp, Fintype.card_congr e]

/-- Interchanging two independent uniform finite samples. -/
theorem uniformMean_comm {Ω P : Type*} [Fintype Ω] [Fintype P] (f : Ω → P → ℝ) :
    uniformMean (fun x => uniformMean (f x)) =
      uniformMean (fun p => uniformMean (fun x => f x p)) := by
  simp only [uniformMean, ← Finset.sum_div, div_div]
  rw [Finset.sum_comm, mul_comm]

/-- Averaging a row over any family of sample-space bijections preserves
its expectation, even when the family is not a group action. -/
theorem uniformMean_symmetrize {Ω P : Type*} [Fintype Ω] [Fintype P] [Nonempty P]
    (action : P → Ω ≃ Ω) (f : Ω → ℝ) :
    uniformMean (fun x => uniformMean (fun p => f (action p x))) = uniformMean f := by
  rw [uniformMean_comm]
  calc
    _ = uniformMean (fun _ : P => uniformMean f) := by
      congr 1
      funext p
      exact uniformMean_equiv (action p) f
    _ = _ := uniformMean_const _

/-- Class expansion after symmetrizing a labelled row. The hypothesis
identifies each symmetrized row with its representative coefficient;
the next theorem obtains it from an explicit orbit cover. -/
theorem class_expansion_of_symmetrization {Ω P K : Type*}
    [Fintype Ω] [Fintype P] [Nonempty P] [Fintype K]
    (action : P → Ω ≃ Ω) (classOf : Ω → K) (f : Ω → ℝ) (bar : K → ℝ)
    (hbar : ∀ x, uniformMean (fun p => f (action p x)) = bar (classOf x)) :
    uniformMean f = ∑ k, classMass classOf k * bar k := by
  rw [← uniformMean_symmetrize action f]
  simp_rw [hbar]
  exact uniformMean_class classOf bar

/-- Orbit representatives suffice for the class expansion. Every input
sample must have a representative and a genuine group element transporting
it to that representative. The concrete certificate cover must provide
these witnesses; a count of representatives alone cannot satisfy hcover. -/
theorem class_expansion_of_orbit_cover {Ω P K Γ : Type*}
    [Fintype Ω] [Group P] [Fintype P] [Fintype K] [MulAction P Γ]
    (action : P → Ω ≃ Ω) (induced : Ω → Γ) (classOf : Ω → K) (rep : K → Γ)
    (hequiv : ∀ p x, induced (action p x) = p • induced x)
    (hcover : ∀ x, ∃ p : P, induced x = p • rep (classOf x)) (row : Γ → ℝ) :
    uniformMean (fun x => row (induced x)) =
      ∑ k, classMass classOf k * uniformMean (fun p : P => row (p • rep k)) := by
  apply class_expansion_of_symmetrization action classOf
  intro x
  obtain ⟨p, hp⟩ := hcover x
  simp_rw [hequiv, hp, ← mul_smul]
  exact uniformMean_equiv (Equiv.mulRight p) (fun g : P => row (g • rep (classOf x)))

#print axioms uniformMean_const
#print axioms uniformMean_nonneg
#print axioms classMass_nonneg
#print axioms uniformMean_class
#print axioms classMass_sum
#print axioms uniformMean_equiv
#print axioms uniformMean_equiv_between
#print axioms uniformMean_comm
#print axioms uniformMean_symmetrize
#print axioms class_expansion_of_symmetrization
#print axioms class_expansion_of_orbit_cover

end TightCycleC5.Bridge
