import EndpointAssembly

/-! Import/type preflight only; this is not the final positive endpoint. -/
set_option pp.fullNames true

example :
    (∀ k : Fin 40547,
      TightCycleC5.Bridge.P33Arithmetic.classCheck
        (TightCycleC5.Bridge.P33Arithmetic.classAt k) = true) →
      type_of% @TightCycleC5.mubayi_rodl :=
  @TightCycleC5.Bridge.mubayi_rodl_of_checked_p33_classes

#check @TightCycleC5.Bridge.mubayi_rodl_of_checked_p33_classes
