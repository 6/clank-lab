import KernelShard15Blocks0
import KernelShard15Blocks1
import KernelShard15Blocks2
import KernelShard15Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard15 : kernelShardCheck 15 kernelWitness15 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (15 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness15 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_15_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard15
end TightCycleC5.Bridge.Cover
