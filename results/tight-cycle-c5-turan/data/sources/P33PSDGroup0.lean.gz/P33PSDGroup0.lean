import P33PSDData

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33PSD

theorem terms0_psd : ∀ k, (intMatrixReal (terms0 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector0x0
  · exact int_outer_posSemidef vector0x1
  · exact int_outer_posSemidef vector0x2
  · exact int_outer_posSemidef vector0x3
  · exact int_outer_posSemidef vector0x4
  · exact int_outer_posSemidef vector0x5
  · exact int_outer_posSemidef vector0x6
  · exact int_outer_posSemidef vector0x7
  · exact int_outer_posSemidef vector0x8
  · exact int_outer_posSemidef vector0x9
  · exact int_outer_posSemidef vector0x10
  · exact int_outer_posSemidef vector0x11
  · exact int_outer_posSemidef vector0x12
  · exact int_outer_posSemidef vector0x13
  · exact int_outer_posSemidef vector0x14
  · exact int_outer_posSemidef vector0x15
  · exact int_outer_posSemidef vector0x16
theorem terms0_diagonal : ∀ k i, terms0 k i i ≤ (diagBounds0 k : ℤ) := by
  decide +kernel
theorem psd0 : (intMatrixReal q0).PosSemidef :=
  integer_sos_posSemidef weights0 terms0 terms0_psd
theorem diagonal0 : ∀ i, q0 i i ≤ (m0 : ℤ) :=
  integer_sos_diagonal weights0 diagBounds0 terms0 terms0_diagonal
theorem normalized_psd0 : matrix0.PosSemidef :=
  scale_int_posSemidef q0 scale psd0
theorem normalized_diagonal0 : ∀ i, matrix0 i i ≤ bound0 :=
  scale_int_diagonal q0 scale m0 diagonal0
theorem normalized_nonneg0 : 0 ≤ bound0 :=
  scale_int_bound_nonneg scale m0 (Nat.cast_nonneg _)

#print axioms psd0
#print axioms diagonal0
#print axioms normalized_psd0
#print axioms normalized_diagonal0
#print axioms normalized_nonneg0
#print axioms terms0_psd
#print axioms terms0_diagonal

theorem terms6_psd : ∀ k, (intMatrixReal (terms6 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector6x0
  · exact int_outer_posSemidef vector6x1
  · exact int_outer_posSemidef vector6x2
  · exact int_outer_posSemidef vector6x3
  · exact int_outer_posSemidef vector6x4
  · exact int_outer_posSemidef vector6x5
  · exact int_outer_posSemidef vector6x6
  · exact int_outer_posSemidef vector6x7
theorem terms6_diagonal : ∀ k i, terms6 k i i ≤ (diagBounds6 k : ℤ) := by
  decide +kernel
theorem psd6 : (intMatrixReal q6).PosSemidef :=
  integer_sos_posSemidef weights6 terms6 terms6_psd
theorem diagonal6 : ∀ i, q6 i i ≤ (m6 : ℤ) :=
  integer_sos_diagonal weights6 diagBounds6 terms6 terms6_diagonal
theorem normalized_psd6 : matrix6.PosSemidef :=
  scale_int_posSemidef q6 scale psd6
theorem normalized_diagonal6 : ∀ i, matrix6 i i ≤ bound6 :=
  scale_int_diagonal q6 scale m6 diagonal6
theorem normalized_nonneg6 : 0 ≤ bound6 :=
  scale_int_bound_nonneg scale m6 (Nat.cast_nonneg _)

#print axioms psd6
#print axioms diagonal6
#print axioms normalized_psd6
#print axioms normalized_diagonal6
#print axioms normalized_nonneg6
#print axioms terms6_psd
#print axioms terms6_diagonal

theorem terms12_psd : ∀ k, (intMatrixReal (terms12 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector12x0
  · exact int_outer_posSemidef vector12x1
  · exact int_outer_posSemidef vector12x2
  · exact int_outer_posSemidef vector12x3
  · exact int_outer_posSemidef vector12x4
  · exact int_outer_posSemidef vector12x5
  · exact int_outer_posSemidef vector12x6
  · exact int_outer_posSemidef vector12x7
  · exact int_outer_posSemidef vector12x8
theorem terms12_diagonal : ∀ k i, terms12 k i i ≤ (diagBounds12 k : ℤ) := by
  decide +kernel
theorem psd12 : (intMatrixReal q12).PosSemidef :=
  integer_sos_posSemidef weights12 terms12 terms12_psd
theorem diagonal12 : ∀ i, q12 i i ≤ (m12 : ℤ) :=
  integer_sos_diagonal weights12 diagBounds12 terms12 terms12_diagonal
theorem normalized_psd12 : matrix12.PosSemidef :=
  scale_int_posSemidef q12 scale psd12
theorem normalized_diagonal12 : ∀ i, matrix12 i i ≤ bound12 :=
  scale_int_diagonal q12 scale m12 diagonal12
theorem normalized_nonneg12 : 0 ≤ bound12 :=
  scale_int_bound_nonneg scale m12 (Nat.cast_nonneg _)

#print axioms psd12
#print axioms diagonal12
#print axioms normalized_psd12
#print axioms normalized_diagonal12
#print axioms normalized_nonneg12
#print axioms terms12_psd
#print axioms terms12_diagonal

theorem terms18_psd : ∀ k, (intMatrixReal (terms18 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector18x0
  · exact int_outer_posSemidef vector18x1
  · exact int_outer_posSemidef vector18x2
  · exact int_outer_posSemidef vector18x3
  · exact int_outer_posSemidef vector18x4
  · exact int_outer_posSemidef vector18x5
  · exact int_outer_posSemidef vector18x6
  · exact int_outer_posSemidef vector18x7
  · exact int_outer_posSemidef vector18x8
  · exact int_outer_posSemidef vector18x9
  · exact int_outer_posSemidef vector18x10
  · exact int_outer_posSemidef vector18x11
theorem terms18_diagonal : ∀ k i, terms18 k i i ≤ (diagBounds18 k : ℤ) := by
  decide +kernel
theorem psd18 : (intMatrixReal q18).PosSemidef :=
  integer_sos_posSemidef weights18 terms18 terms18_psd
theorem diagonal18 : ∀ i, q18 i i ≤ (m18 : ℤ) :=
  integer_sos_diagonal weights18 diagBounds18 terms18 terms18_diagonal
theorem normalized_psd18 : matrix18.PosSemidef :=
  scale_int_posSemidef q18 scale psd18
theorem normalized_diagonal18 : ∀ i, matrix18 i i ≤ bound18 :=
  scale_int_diagonal q18 scale m18 diagonal18
theorem normalized_nonneg18 : 0 ≤ bound18 :=
  scale_int_bound_nonneg scale m18 (Nat.cast_nonneg _)

#print axioms psd18
#print axioms diagonal18
#print axioms normalized_psd18
#print axioms normalized_diagonal18
#print axioms normalized_nonneg18
#print axioms terms18_psd
#print axioms terms18_diagonal

theorem terms24_psd : ∀ k, (intMatrixReal (terms24 k)).PosSemidef := by
  intro k
  fin_cases k
theorem terms24_diagonal : ∀ k i, terms24 k i i ≤ (diagBounds24 k : ℤ) := by
  decide +kernel
theorem psd24 : (intMatrixReal q24).PosSemidef :=
  integer_sos_posSemidef weights24 terms24 terms24_psd
theorem diagonal24 : ∀ i, q24 i i ≤ (m24 : ℤ) :=
  integer_sos_diagonal weights24 diagBounds24 terms24 terms24_diagonal
theorem normalized_psd24 : matrix24.PosSemidef :=
  scale_int_posSemidef q24 scale psd24
theorem normalized_diagonal24 : ∀ i, matrix24 i i ≤ bound24 :=
  scale_int_diagonal q24 scale m24 diagonal24
theorem normalized_nonneg24 : 0 ≤ bound24 :=
  scale_int_bound_nonneg scale m24 (Nat.cast_nonneg _)

#print axioms psd24
#print axioms diagonal24
#print axioms normalized_psd24
#print axioms normalized_diagonal24
#print axioms normalized_nonneg24
#print axioms terms24_psd
#print axioms terms24_diagonal

theorem terms30_psd : ∀ k, (intMatrixReal (terms30 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector30x0
  · exact int_outer_posSemidef vector30x1
  · exact int_outer_posSemidef vector30x2
  · exact int_outer_posSemidef vector30x3
  · exact int_outer_posSemidef vector30x4
  · exact int_outer_posSemidef vector30x5
  · exact int_outer_posSemidef vector30x6
  · exact int_outer_posSemidef vector30x7
  · exact int_outer_posSemidef vector30x8
  · exact int_outer_posSemidef vector30x9
  · exact int_outer_posSemidef vector30x10
theorem terms30_diagonal : ∀ k i, terms30 k i i ≤ (diagBounds30 k : ℤ) := by
  decide +kernel
theorem psd30 : (intMatrixReal q30).PosSemidef :=
  integer_sos_posSemidef weights30 terms30 terms30_psd
theorem diagonal30 : ∀ i, q30 i i ≤ (m30 : ℤ) :=
  integer_sos_diagonal weights30 diagBounds30 terms30 terms30_diagonal
theorem normalized_psd30 : matrix30.PosSemidef :=
  scale_int_posSemidef q30 scale psd30
theorem normalized_diagonal30 : ∀ i, matrix30 i i ≤ bound30 :=
  scale_int_diagonal q30 scale m30 diagonal30
theorem normalized_nonneg30 : 0 ≤ bound30 :=
  scale_int_bound_nonneg scale m30 (Nat.cast_nonneg _)

#print axioms psd30
#print axioms diagonal30
#print axioms normalized_psd30
#print axioms normalized_diagonal30
#print axioms normalized_nonneg30
#print axioms terms30_psd
#print axioms terms30_diagonal

theorem terms36_psd : ∀ k, (intMatrixReal (terms36 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector36x0
  · exact int_outer_posSemidef vector36x1
  · exact int_outer_posSemidef vector36x2
theorem terms36_diagonal : ∀ k i, terms36 k i i ≤ (diagBounds36 k : ℤ) := by
  decide +kernel
theorem psd36 : (intMatrixReal q36).PosSemidef :=
  integer_sos_posSemidef weights36 terms36 terms36_psd
theorem diagonal36 : ∀ i, q36 i i ≤ (m36 : ℤ) :=
  integer_sos_diagonal weights36 diagBounds36 terms36 terms36_diagonal
theorem normalized_psd36 : matrix36.PosSemidef :=
  scale_int_posSemidef q36 scale psd36
theorem normalized_diagonal36 : ∀ i, matrix36 i i ≤ bound36 :=
  scale_int_diagonal q36 scale m36 diagonal36
theorem normalized_nonneg36 : 0 ≤ bound36 :=
  scale_int_bound_nonneg scale m36 (Nat.cast_nonneg _)

#print axioms psd36
#print axioms diagonal36
#print axioms normalized_psd36
#print axioms normalized_diagonal36
#print axioms normalized_nonneg36
#print axioms terms36_psd
#print axioms terms36_diagonal

end TightCycleC5.Bridge.P33PSD
