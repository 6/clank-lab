-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk272 :
    ∀ i : Fin (min 128 (40547 - 128 * 272)),
      targetCountsMatch (classAt (targetKernelClass ⟨272, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk272

theorem target_counts_kernel_chunk273 :
    ∀ i : Fin (min 128 (40547 - 128 * 273)),
      targetCountsMatch (classAt (targetKernelClass ⟨273, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk273

theorem target_counts_kernel_chunk274 :
    ∀ i : Fin (min 128 (40547 - 128 * 274)),
      targetCountsMatch (classAt (targetKernelClass ⟨274, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk274

theorem target_counts_kernel_chunk275 :
    ∀ i : Fin (min 128 (40547 - 128 * 275)),
      targetCountsMatch (classAt (targetKernelClass ⟨275, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk275


end TightCycleC5.Bridge.P33Arithmetic
