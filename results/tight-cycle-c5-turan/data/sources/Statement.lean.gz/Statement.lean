import Mathlib

/-!
# The Mubayi–Rödl conjecture: the Turán density of the tight 5-cycle

A 3-graph on `Fin n` is a set of 3-element vertex sets. The tight 5-cycle
`C₅³` has vertices `0, …, 4` and edges `{i, i+1, i+2}` (indices mod 5).
`ex n` is the largest number of edges of a `C₅³`-free 3-graph on `n`
vertices, and the conjecture says `ex n / C(n,3) → 2√3 − 3`.

`mubayi_rodl` is the endpoint (claim (P) of the NOTE); claim (D) would be
a proof of its negation. It is stated here, with `sorry`, before any lemma.
-/

namespace TightCycleC5

open Filter Topology

/-- A 3-graph on `Fin n`: every edge has exactly three vertices. -/
def IsThreeGraph {n : ℕ} (H : Finset (Finset (Fin n))) : Prop :=
  ∀ e ∈ H, e.card = 3

/-- `H` contains a (not necessarily induced) copy of the tight 5-cycle:
an injective `f : Fin 5 → Fin n` sending every triple of cyclically
consecutive vertices onto an edge. -/
def ContainsC5 {n : ℕ} (H : Finset (Finset (Fin n))) : Prop :=
  ∃ f : Fin 5 ↪ Fin n, ∀ i : Fin 5, ({f i, f (i + 1), f (i + 2)} : Finset (Fin n)) ∈ H

/-- The Turán number of `C₅³`: the most edges of a `C₅³`-free 3-graph on `n` vertices. -/
noncomputable def ex (n : ℕ) : ℕ :=
  open Classical in
  ((Finset.univ : Finset (Finset (Finset (Fin n)))).filter
      (fun H => IsThreeGraph H ∧ ¬ ContainsC5 H)).sup Finset.card

/-- The Mubayi–Rödl conjecture: `π(C₅³) = 2√3 − 3`. -/
theorem mubayi_rodl :
    Tendsto (fun n : ℕ => (ex n : ℝ) / (n.choose 3 : ℝ)) atTop
      (𝓝 (2 * Real.sqrt 3 - 3)) := by
  sorry

end TightCycleC5
