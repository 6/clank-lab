import P33RowsCore

namespace TightCycleC5.Bridge.P33Rows

/-- Every raw tuple retains the first colour in bit 0, even with repeated vertices. -/
theorem raw4_rootColor {V : Type*} (e : EdgeFn V) (c : ColorFn V) (x a b d : V) :
    raw4 e c x a b d % 2 = (c x).toNat := by
  have := Bool.toNat_le (c x)
  unfold raw4
  omega

/-- The two root colour bits retain their labelled order 0,1. -/
theorem raw4_rootColors {V : Type*} (e : EdgeFn V) (c : ColorFn V) (x u b d : V) :
    raw4 e c x u b d % 4 = (c x).toNat + 2 * (c u).toNat := by
  have := Bool.toNat_le (c x)
  have := Bool.toNat_le (c u)
  unfold raw4
  omega

theorem min_mod_same (a b modulus root : Nat)
    (ha : a % modulus = root) (hb : b % modulus = root) :
    min a b % modulus = root := by
  rw [min_def]
  split_ifs <;> assumption

theorem canonicalLocal_rootColor {V : Type*} (e : EdgeFn V) (c : ColorFn V) (x a b d : V) :
    canonicalLocal e c x a b d % 2 = (c x).toNat := by
  unfold canonicalLocal
  repeat' apply min_mod_same
  all_goals exact raw4_rootColor e c _ _ _ _

theorem canonicalRegular_rootColors {V : Type*} (e : EdgeFn V) (c : ColorFn V) (x u b d : V) :
    canonicalRegular e c x u b d % 4 = (c x).toNat + 2 * (c u).toNat := by
  exact min_mod_same _ _ _ _ (raw4_rootColors e c x u b d) (raw4_rootColors e c x u d b)

theorem canonicalRegular_free_swap {V : Type*} (e : EdgeFn V) (c : ColorFn V) (x u b d : V) :
    canonicalRegular e c x u d b = canonicalRegular e c x u b d := by
  simp only [canonicalRegular, min_comm]

/-- Adjacent transpositions generate all permutations of the three free labels. -/
theorem canonicalLocal_free_swap01 {V : Type*} (e : EdgeFn V) (c : ColorFn V) (x a b d : V) :
    canonicalLocal e c x b a d = canonicalLocal e c x a b d := by
  unfold canonicalLocal
  ac_rfl

theorem canonicalLocal_free_swap12 {V : Type*} (e : EdgeFn V) (c : ColorFn V) (x a b d : V) :
    canonicalLocal e c x a d b = canonicalLocal e c x a b d := by
  unfold canonicalLocal
  ac_rfl

/-- For a typed literal flag, the explicit root-colour test is redundant;
canonical equality already implies the root bit, exactly as in the checker. -/
theorem localFlag_of_typed {V : Type*} (q : LocalDescriptor)
    (hq : q.flag % 2 = q.rootColor.toNat) (e : EdgeFn V) (c : ColorFn V) (x a b d : V) :
    localFlag q e c x a b d = if canonicalLocal e c x a b d = q.flag then 1 else 0 := by
  by_cases hf : canonicalLocal e c x a b d = q.flag
  · have hr := canonicalLocal_rootColor e c x a b d
    rw [hf, hq] at hr
    have hc : c x = q.rootColor := by
      cases hx : c x <;> cases hy : q.rootColor <;> simp_all
    simp [localFlag, hf, hc]
  · simp [localFlag, hf]

theorem regularFlag_of_typed {V : Type*} (q : RegularDescriptor)
    (hq : q.flag % 4 = q.rootColors) (e : EdgeFn V) (c : ColorFn V) (x u b d : V) :
    regularFlag q e c x u b d = if canonicalRegular e c x u b d = q.flag then 1 else 0 := by
  by_cases hf : canonicalRegular e c x u b d = q.flag
  · have hr := canonicalRegular_rootColors e c x u b d
    rw [hf, hq] at hr
    simp [regularFlag, hf, hr.symm]
  · simp [regularFlag, hf]

#print axioms raw4_rootColor
#print axioms raw4_rootColors
#print axioms min_mod_same
#print axioms canonicalLocal_rootColor
#print axioms canonicalRegular_rootColors
#print axioms canonicalRegular_free_swap
#print axioms canonicalLocal_free_swap01
#print axioms canonicalLocal_free_swap12
#print axioms localFlag_of_typed
#print axioms regularFlag_of_typed
end TightCycleC5.Bridge.P33Rows
