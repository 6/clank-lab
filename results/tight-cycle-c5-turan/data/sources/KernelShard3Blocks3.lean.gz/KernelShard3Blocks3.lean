import KernelRowIndex
import KernelWitness3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_3_96 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 96 * 256 + i.val))
      kernelWitness3Row96[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_96

theorem kernelBlock_3_97 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 97 * 256 + i.val))
      kernelWitness3Row97[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_97

theorem kernelBlock_3_98 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 98 * 256 + i.val))
      kernelWitness3Row98[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_98

theorem kernelBlock_3_99 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 99 * 256 + i.val))
      kernelWitness3Row99[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_99

theorem kernelBlock_3_100 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 100 * 256 + i.val))
      kernelWitness3Row100[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_100

theorem kernelBlock_3_101 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 101 * 256 + i.val))
      kernelWitness3Row101[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_101

theorem kernelBlock_3_102 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 102 * 256 + i.val))
      kernelWitness3Row102[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_102

theorem kernelBlock_3_103 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 103 * 256 + i.val))
      kernelWitness3Row103[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_103

theorem kernelBlock_3_104 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 104 * 256 + i.val))
      kernelWitness3Row104[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_104

theorem kernelBlock_3_105 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 105 * 256 + i.val))
      kernelWitness3Row105[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_105

theorem kernelBlock_3_106 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 106 * 256 + i.val))
      kernelWitness3Row106[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_106

theorem kernelBlock_3_107 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 107 * 256 + i.val))
      kernelWitness3Row107[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_107

theorem kernelBlock_3_108 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 108 * 256 + i.val))
      kernelWitness3Row108[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_108

theorem kernelBlock_3_109 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 109 * 256 + i.val))
      kernelWitness3Row109[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_109

theorem kernelBlock_3_110 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 110 * 256 + i.val))
      kernelWitness3Row110[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_110

theorem kernelBlock_3_111 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 111 * 256 + i.val))
      kernelWitness3Row111[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_111

theorem kernelBlock_3_112 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 112 * 256 + i.val))
      kernelWitness3Row112[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_112

theorem kernelBlock_3_113 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 113 * 256 + i.val))
      kernelWitness3Row113[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_113

theorem kernelBlock_3_114 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 114 * 256 + i.val))
      kernelWitness3Row114[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_114

theorem kernelBlock_3_115 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 115 * 256 + i.val))
      kernelWitness3Row115[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_115

theorem kernelBlock_3_116 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 116 * 256 + i.val))
      kernelWitness3Row116[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_116

theorem kernelBlock_3_117 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 117 * 256 + i.val))
      kernelWitness3Row117[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_117

theorem kernelBlock_3_118 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 118 * 256 + i.val))
      kernelWitness3Row118[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_118

theorem kernelBlock_3_119 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 119 * 256 + i.val))
      kernelWitness3Row119[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_119

theorem kernelBlock_3_120 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 120 * 256 + i.val))
      kernelWitness3Row120[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_120

theorem kernelBlock_3_121 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 121 * 256 + i.val))
      kernelWitness3Row121[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_121

theorem kernelBlock_3_122 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 122 * 256 + i.val))
      kernelWitness3Row122[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_122

theorem kernelBlock_3_123 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 123 * 256 + i.val))
      kernelWitness3Row123[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_123

theorem kernelBlock_3_124 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 124 * 256 + i.val))
      kernelWitness3Row124[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_124

theorem kernelBlock_3_125 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 125 * 256 + i.val))
      kernelWitness3Row125[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_125

theorem kernelBlock_3_126 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 126 * 256 + i.val))
      kernelWitness3Row126[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_126

theorem kernelBlock_3_127 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 127 * 256 + i.val))
      kernelWitness3Row127[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_127

end TightCycleC5.Bridge.Cover
