import P32UniformAveraging
import P32RowMatchingAll

/-! The actual P32 certificate, kernel class cover and finite row bounds
supply the exact P32Statement with no additional mathematical hypothesis. -/
namespace TightCycleC5.Bridge.P32ClassBridge
set_option maxRecDepth 100000
set_option maxHeartbeats 2000000

theorem checked_class_mean (k : Fin 835) :
    (1 : ℝ)/10000 + uniformMean (fun p : Equiv.Perm (Fin 6) =>
      P32UniformAveraging.nuisanceRows (p • Cover.p32KernelClassRep k)) ≤
    uniformMean (fun p : Equiv.Perm (Fin 6) =>
      P32Selector.margin (p • Cover.p32KernelClassRep k)) := by
  simpa only [Cover.p32KernelClassRep, P32UniformAveraging.nuisanceRows,
    P32RowMatching.literalNuisance] using
    P32RowMatching.cover_class_margin_bound_literal k

theorem p32 : P32Statement :=
  P32UniformAveraging.p32_of_literal_class_means checked_class_mean

#print axioms checked_class_mean
#print axioms p32
end TightCycleC5.Bridge.P32ClassBridge
