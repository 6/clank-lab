import SubsetSampling

/-! PROOF §3 Lemma 7: exact six-sample target normalization. -/
namespace TightCycleC5.Bridge
open Finset
variable {n : ℕ}

noncomputable def sixSubsetMean (w : Finset (Fin n) → ℝ) (σ : Fin 6 ↪ Fin n) : ℝ :=
  (∑ e ∈ (univ : Finset (Fin 6)).powersetCard 3, w (e.map σ)) / 20

theorem sixSubsetMean_ordered (w : Finset (Fin n) → ℝ) (σ : Fin 6 ↪ Fin n) :
    sixSubsetMean w σ =
      uniformMean (fun labels : Fin 3 ↪ Fin 6 => w (embeddingSet (labels.trans σ))) := by
  have hp : ∀ labels : Fin 3 ↪ Fin 6,
      embeddingSet (labels.trans σ) = (embeddingSet labels).map σ := by
    intro labels
    simp only [embeddingSet, Finset.map_map]
  simp_rw [hp]
  rw [embeddingSet_mean 3 (fun e : Finset (Fin 6) => w (e.map σ))]
  norm_num [sixSubsetMean, Nat.choose]

theorem sixSubsetMean_normalization (hn : 6 ≤ n) (w : Finset (Fin n) → ℝ) :
    uniformMean (sixSubsetMean w) =
      (∑ e ∈ (univ : Finset (Fin n)).powersetCard 3, w e) / (n.choose 3 : ℝ) := by
  classical
  have hp : sixSubsetMean w = fun σ : Fin 6 ↪ Fin n =>
      uniformMean (fun labels : Fin 3 ↪ Fin 6 => w (embeddingSet (labels.trans σ))) :=
    funext (sixSubsetMean_ordered w)
  rw [hp, uniformMean_comm]
  have he : ∀ labels : Fin 3 ↪ Fin 6,
      uniformMean (fun σ : Fin 6 ↪ Fin n => w (embeddingSet (labels.trans σ))) =
        uniformMean (fun σ : Fin 3 ↪ Fin n => w (embeddingSet σ)) := by
    intro labels
    exact uniformMean_restrict_three hn labels (fun σ => w (embeddingSet σ))
  simp_rw [he]
  letI : Nonempty (Fin 3 ↪ Fin 6) := ⟨Fin.castLEEmb (by norm_num)⟩
  rw [uniformMean_const, embeddingSet_mean, Fintype.card_fin]

def tripleTarget (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) (c : ℝ)
    (e : Finset (Fin n)) : ℝ :=
  (if e ∈ H ∧ ((e ∩ S).card = 1 ∨ (e ∩ S).card = 3) then 1 else 0) -
    c * (if (e ∩ S).card = 2 ∧ e ∉ H then 1 else 0)

/-- Filtering all triples by a three-graph gives exactly that graph. -/
theorem filter_all_triples (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H) :
    ((univ : Finset (Fin n)).powersetCard 3).filter (fun e => e ∈ H) = H := by
  ext e
  simp only [mem_filter, mem_powersetCard, subset_univ, true_and]
  exact ⟨fun h => h.2, fun h => ⟨hH e h, h⟩⟩

theorem tripleTarget_sum (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (S : Finset (Fin n)) (c : ℝ) :
    (∑ e ∈ (univ : Finset (Fin n)).powersetCard 3, tripleTarget H S c e) =
      (badCount H S : ℝ) - c * (missCount H S : ℝ) := by
  have hb : (∑ e ∈ (univ : Finset (Fin n)).powersetCard 3,
      if e ∈ H ∧ ((e ∩ S).card = 1 ∨ (e ∩ S).card = 3) then (1 : ℝ) else 0) =
      (badCount H S : ℝ) := by
    have hp : ∀ e : Finset (Fin n),
        (if e ∈ H ∧ ((e ∩ S).card = 1 ∨ (e ∩ S).card = 3) then (1 : ℝ) else 0) =
        if e ∈ H then (if (e ∩ S).card = 1 ∨ (e ∩ S).card = 3 then 1 else 0) else 0 := by
      intro e
      split_ifs <;> simp_all
    simp_rw [hp]
    rw [← sum_filter, filter_all_triples H hH]
    rw [badCount, Finset.card_eq_sum_ones]
    simp only [Nat.cast_sum, sum_filter]
    apply sum_congr rfl
    intro e _
    split_ifs <;> norm_num
  have hm : (∑ e ∈ (univ : Finset (Fin n)).powersetCard 3,
      if (e ∩ S).card = 2 ∧ e ∉ H then (1 : ℝ) else 0) = (missCount H S : ℝ) := by
    rw [missCount, Finset.card_eq_sum_ones]
    simp only [Nat.cast_sum, sum_filter]
    apply sum_congr rfl
    intro e _
    split_ifs <;> norm_num
  simp only [tripleTarget, sum_sub_distrib, ← mul_sum, hb, hm]

/-- The target (#bad−c·#missing)/20 on a six-sample has exactly the
normalized global expectation, with no finite error term. -/
theorem p33_target_normalization (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (S : Finset (Fin n)) (c : ℝ) (hn : 6 ≤ n) :
    uniformMean (sixSubsetMean (tripleTarget H S c)) =
      ((badCount H S : ℝ) - c * (missCount H S : ℝ)) / (n.choose 3 : ℝ) := by
  rw [sixSubsetMean_normalization hn, tripleTarget_sum H hH S c]

#print axioms sixSubsetMean_ordered
#print axioms sixSubsetMean_normalization
#print axioms filter_all_triples
#print axioms tripleTarget_sum
#print axioms p33_target_normalization
end TightCycleC5.Bridge
