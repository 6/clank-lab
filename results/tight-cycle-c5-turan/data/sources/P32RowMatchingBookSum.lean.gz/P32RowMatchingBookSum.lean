import P32RowMatchingBook
import P32RowMatchingIndexSums

namespace TightCycleC5.Bridge.P32RowMatching
open Finset
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000
set_option backward.isDefEq.respectTransparency false

noncomputable def indicatorBookRows (G : LabelledStructure 6) : ℝ :=
  ∑ i : Fin 8464, CertificateDescriptors.p32BookWeight i *
    PairBookCertificate.row (CertificateDescriptors.p32BookDescriptor i) G

noncomputable def weightedBookRows (G : LabelledStructure 6) : ℝ :=
  ∑ i : Fin 25, CertificateDescriptors.p32Weight ⟨9484+i.val, by omega⟩ *
    PairBookCertificate.row (P32Book.descriptor i) G

theorem book_coefficient_eq (k : Fin 16) (r : Fin 529) :
    CertificateDescriptors.p32BookWeight (CertificateDescriptors.bookFlatIndex k r) =
      ((P32Arithmetic.multipliers.get ⟨1020+k.val*529+r.val, by omega⟩ : ℤ) : ℝ) /
        (P32Arithmetic.weightScale : ℝ) := by
  simp only [CertificateDescriptors.p32BookWeight, CertificateDescriptors.p32Weight,
    ← numerator_eq, ← weight_scale_eq]
  congr 2
  apply congrArg P32Arithmetic.multipliers.get
  apply Fin.ext
  simp only [CertificateDescriptors.p32BookSourceIndex, CertificateDescriptors.bookFlatIndex]
  omega

theorem indicator_book_contribution_eq (G : LabelledStructure 6) :
    ((P32Arithmetic.indicatorBookNumerator (P32Arithmetic.features G) : ℤ) : ℝ) /
      (P32Arithmetic.weightScale : ℝ) = indicatorBookRows G := by
  unfold indicatorBookRows P32Arithmetic.indicatorBookNumerator
  rw [← sum_book_flat (fun i => CertificateDescriptors.p32BookWeight i *
    PairBookCertificate.row (CertificateDescriptors.p32BookDescriptor i) G)]
  rw [Int.cast_sum, Finset.sum_div]
  apply Finset.sum_congr rfl
  intro k _
  by_cases h : (P32Arithmetic.features G).bookRoot = k
  · simp only [h, ↓reduceIte, Int.cast_sum, Finset.sum_div]
    apply Finset.sum_congr rfl
    intro r _
    rw [book_coefficient_eq, indicator_book_row_features]
    cases ha : (P32Arithmetic.bookRestriction r).testBit (P32Arithmetic.features G).bookA.val <;>
      cases hb : (P32Arithmetic.bookRestriction r).testBit (P32Arithmetic.features G).bookB.val <;>
      simp [h, ha, hb, Int.cast_mul] <;> ring
  · simp [h, indicator_book_row_features]

theorem weighted_book_contribution_eq (G : LabelledStructure 6) :
    ((P32Arithmetic.weightedBookNumerator (P32Arithmetic.features G) : ℤ) : ℝ) /
      ((P32Arithmetic.weightScale : ℝ) * (P32Arithmetic.probScale : ℝ)^2) = weightedBookRows G := by
  unfold weightedBookRows P32Arithmetic.weightedBookNumerator
  rw [Int.cast_sum, Finset.sum_div]
  apply Finset.sum_congr rfl
  intro i _
  rw [weighted_book_row_features]
  simp only [CertificateDescriptors.p32Weight, ← numerator_eq, ← weight_scale_eq]
  split_ifs <;> simp only [Int.cast_mul, Int.cast_zero, zero_div, mul_zero]
  field_simp

theorem book_contribution_split (G : LabelledStructure 6) :
    P32Arithmetic.bookContribution G =
      ((P32Arithmetic.indicatorBookNumerator (P32Arithmetic.features G) : ℤ) : ℝ) /
        (P32Arithmetic.weightScale : ℝ) +
      ((P32Arithmetic.weightedBookNumerator (P32Arithmetic.features G) : ℤ) : ℝ) /
        ((P32Arithmetic.weightScale : ℝ) * (P32Arithmetic.probScale : ℝ)^2) := by
  simp only [P32Arithmetic.bookContribution, Rat.cast_div, Rat.cast_mul, Rat.cast_pow,
    Rat.cast_intCast, Rat.cast_add, P32Arithmetic.bookNumerator, Int.cast_add, Int.cast_mul, Int.cast_pow]
  have hp : (P32Arithmetic.probScale : ℝ) ≠ 0 := by norm_num [P32Arithmetic.probScale]
  have hw : (P32Arithmetic.weightScale : ℝ) ≠ 0 := by norm_num [P32Arithmetic.weightScale]
  field_simp

/-- All 8464 indicator and 25 weighted rows, in exact certificate order. -/
theorem book_contribution_eq (G : LabelledStructure 6) :
    P32Arithmetic.bookContribution G = indicatorBookRows G + weightedBookRows G := by
  rw [book_contribution_split, indicator_book_contribution_eq, weighted_book_contribution_eq]

#print axioms book_coefficient_eq
#print axioms indicator_book_contribution_eq
#print axioms weighted_book_contribution_eq
#print axioms book_contribution_split
#print axioms book_contribution_eq
end TightCycleC5.Bridge.P32RowMatching
