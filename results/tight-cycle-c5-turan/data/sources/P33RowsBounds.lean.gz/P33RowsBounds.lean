import P33RowsCore
import LocalRows
import RegularityRows
import TripleProducts

namespace TightCycleC5.Bridge.P33Rows
open Finset

noncomputable def localIndicator {n : Nat} (q : LocalDescriptor)
    (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (root : Fin 1 ↪ Fin n) (t : Fin 3 ↪ Outside root) : ℝ :=
  localFlag q (actualEdge H) (actualColor S) (root 0) (t 0).val (t 1).val (t 2).val

noncomputable def regularIndicator {n : Nat} (q : RegularDescriptor)
    (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (root : Fin 2 ↪ Fin n) (t : Fin 2 ↪ Outside root) : ℝ :=
  regularFlag q (actualEdge H) (actualColor S) (root 0) (root 1) (t 0).val (t 1).val

theorem localRow_join {n : Nat} (q : LocalDescriptor) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (root : Fin 1 ↪ Fin n) (free : Fin 5 ↪ Outside root) :
    localRow q (sampleStructure (joinSample root free) H S) =
      localGain H S (root 0) (free 0).val (free 1).val *
        localFlag q (actualEdge H) (actualColor S) (root 0)
          (free 2).val (free 3).val (free 4).val := by
  rw [localRow_sample]
  change localEvaluate q (actualEdge H) (actualColor S)
    (joinSample root free (Fin.castAdd 5 (0 : Fin 1)))
    (joinSample root free (Fin.natAdd 1 (0 : Fin 5)))
    (joinSample root free (Fin.natAdd 1 (1 : Fin 5)))
    (joinSample root free (Fin.natAdd 1 (2 : Fin 5)))
    (joinSample root free (Fin.natAdd 1 (3 : Fin 5)))
    (joinSample root free (Fin.natAdd 1 (4 : Fin 5))) = _
  simp only [joinSample_root, joinSample_free, localEvaluate, literalEll_actual]

theorem localRow_asSix {n : Nat} (q : LocalDescriptor) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) :
    localRow q (sampleStructure σ H S) = localSixRow H S (localIndicator q H S) σ := by
  have he : ∀ (root : Fin 1 ↪ Fin n) (free : Fin 5 ↪ Outside root),
      localRow q (sampleStructure (joinSample root free) H S) =
        localSixRow H S (localIndicator q H S) (joinSample root free) := by
    intro root free
    rw [localRow_join, localSixRow_join]
    rfl
  have h := he (splitSampleEquiv (r := 1) (f := 5) σ).1
    (splitSampleEquiv (r := 1) (f := 5) σ).2
  simpa only [joinSample_split] using h

theorem localRow_mean_lower {n : Nat} (q : LocalDescriptor)
    (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (S : Finset (Fin n)) (hS : LocallyMaximal H S) (hn : 12 ≤ n) :
    -(6 * ((n : ℝ) - 3) / (((n : ℝ) - 4) * ((n : ℝ) - 5))) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => localRow q (sampleStructure σ H S)) := by
  have he := funext (localRow_asSix q H S)
  rw [he]
  exact local_six_row_lower H hH S hS hn (localIndicator q H S)
    (fun root t => localFlag_zero_one q _ _ _ _ _ _)

theorem regularEvaluate_actual {n : Nat} (q : RegularDescriptor)
    (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) (x u v a b d : Fin n) :
    regularEvaluate q (actualEdge H) (actualColor S) x u v a b d =
      linkDifference H x u v a * regularFlag q (actualEdge H) (actualColor S) x u b d := by
  simp [regularEvaluate, actualEdge, linkDifference, edgeIndicator]

theorem regularRow_join {n : Nat} (q : RegularDescriptor) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (root : Fin 2 ↪ Fin n) (free : Fin 4 ↪ Outside root) :
    regularRow q (sampleStructure (joinSample root free) H S) =
      linkDifference H (root 0) (root 1) (free 0).val (free 1).val *
        regularFlag q (actualEdge H) (actualColor S) (root 0) (root 1)
          (free 2).val (free 3).val := by
  rw [regularRow_sample]
  change regularEvaluate q (actualEdge H) (actualColor S)
    (joinSample root free (Fin.castAdd 4 (0 : Fin 2)))
    (joinSample root free (Fin.castAdd 4 (1 : Fin 2)))
    (joinSample root free (Fin.natAdd 2 (0 : Fin 4)))
    (joinSample root free (Fin.natAdd 2 (1 : Fin 4)))
    (joinSample root free (Fin.natAdd 2 (2 : Fin 4)))
    (joinSample root free (Fin.natAdd 2 (3 : Fin 4))) = _
  simp only [joinSample_root, joinSample_free, regularEvaluate_actual]

theorem regularRow_asSix {n : Nat} (q : RegularDescriptor) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) :
    regularRow q (sampleStructure σ H S) = regularSixRow H (regularIndicator q H S) σ := by
  have he : ∀ (root : Fin 2 ↪ Fin n) (free : Fin 4 ↪ Outside root),
      regularRow q (sampleStructure (joinSample root free) H S) =
        regularSixRow H (regularIndicator q H S) (joinSample root free) := by
    intro root free
    rw [regularRow_join, regularSixRow_join]
    rfl
  have h := he (splitSampleEquiv (r := 2) (f := 4) σ).1
    (splitSampleEquiv (r := 2) (f := 4) σ).2
  simpa only [joinSample_split] using h

theorem regularRow_mean_abs_le {n : Nat} (q : RegularDescriptor)
    (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H) (S : Finset (Fin n))
    (hn : 12 ≤ n) (δ : ℝ)
    (hreg : ∀ x u, (deg H x : ℝ) ≤ deg H u + δ * (n : ℝ) ^ 2) :
    |uniformMean (fun σ : Fin 6 ↪ Fin n => regularRow q (sampleStructure σ H S))| ≤
      (2 * δ * (n : ℝ) ^ 2 + 4 * (n : ℝ) - 14) /
        (((n : ℝ) - 4) * ((n : ℝ) - 5)) := by
  have he := funext (regularRow_asSix q H S)
  rw [he]
  exact regularity_six_row_abs_le H hH hn δ hreg (regularIndicator q H S)
    (fun root t => regularFlag_zero_one q _ _ _ _ _ _)

/-- Finite means commute with arbitrary real weighted sums, even on empty spaces. -/
theorem mean_weighted {I Ω : Type*} [Fintype I] [Fintype Ω]
    (w : I → ℝ) (f : I → Ω → ℝ) :
    uniformMean (fun x => ∑ i, w i * f i x) = ∑ i, w i * uniformMean (f i) := by
  unfold uniformMean
  rw [Finset.sum_comm, Finset.sum_div]
  apply Finset.sum_congr rfl
  intro i _
  rw [← Finset.mul_sum]
  ring

theorem weighted_localRow_mean_lower {I : Type*} [Fintype I] {n : Nat}
    (q : I → LocalDescriptor) (w : I → ℝ) (hw : ∀ i, 0 ≤ w i)
    (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H) (S : Finset (Fin n))
    (hS : LocallyMaximal H S) (hn : 12 ≤ n) :
    (∑ i, w i) * -(6 * ((n : ℝ) - 3) / (((n : ℝ) - 4) * ((n : ℝ) - 5))) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => ∑ i, w i * localRow (q i) (sampleStructure σ H S)) := by
  rw [mean_weighted, Finset.sum_mul]
  exact Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_left
    (localRow_mean_lower (q i) H hH S hS hn) (hw i))

theorem weighted_regularRow_mean_abs_le {I : Type*} [Fintype I] {n : Nat}
    (q : I → RegularDescriptor) (w : I → ℝ)
    (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H) (S : Finset (Fin n))
    (hn : 12 ≤ n) (δ : ℝ)
    (hreg : ∀ x u, (deg H x : ℝ) ≤ deg H u + δ * (n : ℝ) ^ 2) :
    |uniformMean (fun σ : Fin 6 ↪ Fin n => ∑ i, w i * regularRow (q i) (sampleStructure σ H S))| ≤
      (∑ i, |w i|) * ((2 * δ * (n : ℝ) ^ 2 + 4 * (n : ℝ) - 14) /
        (((n : ℝ) - 4) * ((n : ℝ) - 5))) := by
  rw [mean_weighted]
  calc
    _ ≤ ∑ i, |w i * uniformMean (fun σ : Fin 6 ↪ Fin n => regularRow (q i) (sampleStructure σ H S))| :=
      abs_sum_le_sum_abs _ _
    _ = ∑ i, |w i| * |uniformMean (fun σ : Fin 6 ↪ Fin n => regularRow (q i) (sampleStructure σ H S))| := by
      simp only [abs_mul]
    _ ≤ ∑ i, |w i| * ((2 * δ * (n : ℝ) ^ 2 + 4 * (n : ℝ) - 14) /
        (((n : ℝ) - 4) * ((n : ℝ) - 5))) :=
      Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_left
        (regularRow_mean_abs_le (q i) H hH S hn δ hreg) (abs_nonneg (w i)))
    _ = _ := (Finset.sum_mul _ _ _).symm

#print axioms localRow_join
#print axioms localRow_asSix
#print axioms localRow_mean_lower
#print axioms regularEvaluate_actual
#print axioms regularRow_join
#print axioms regularRow_asSix
#print axioms regularRow_mean_abs_le
#print axioms mean_weighted
#print axioms weighted_localRow_mean_lower
#print axioms weighted_regularRow_mean_abs_le
end TightCycleC5.Bridge.P33Rows
