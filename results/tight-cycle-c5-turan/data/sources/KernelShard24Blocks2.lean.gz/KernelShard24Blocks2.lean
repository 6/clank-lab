import KernelRowIndex
import KernelWitness24

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_24_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 64 * 256 + i.val))
      kernelWitness24Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_64

theorem kernelBlock_24_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 65 * 256 + i.val))
      kernelWitness24Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_65

theorem kernelBlock_24_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 66 * 256 + i.val))
      kernelWitness24Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_66

theorem kernelBlock_24_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 67 * 256 + i.val))
      kernelWitness24Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_67

theorem kernelBlock_24_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 68 * 256 + i.val))
      kernelWitness24Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_68

theorem kernelBlock_24_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 69 * 256 + i.val))
      kernelWitness24Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_69

theorem kernelBlock_24_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 70 * 256 + i.val))
      kernelWitness24Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_70

theorem kernelBlock_24_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 71 * 256 + i.val))
      kernelWitness24Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_71

theorem kernelBlock_24_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 72 * 256 + i.val))
      kernelWitness24Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_72

theorem kernelBlock_24_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 73 * 256 + i.val))
      kernelWitness24Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_73

theorem kernelBlock_24_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 74 * 256 + i.val))
      kernelWitness24Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_74

theorem kernelBlock_24_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 75 * 256 + i.val))
      kernelWitness24Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_75

theorem kernelBlock_24_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 76 * 256 + i.val))
      kernelWitness24Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_76

theorem kernelBlock_24_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 77 * 256 + i.val))
      kernelWitness24Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_77

theorem kernelBlock_24_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 78 * 256 + i.val))
      kernelWitness24Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_78

theorem kernelBlock_24_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 79 * 256 + i.val))
      kernelWitness24Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_79

theorem kernelBlock_24_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 80 * 256 + i.val))
      kernelWitness24Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_80

theorem kernelBlock_24_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 81 * 256 + i.val))
      kernelWitness24Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_81

theorem kernelBlock_24_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 82 * 256 + i.val))
      kernelWitness24Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_82

theorem kernelBlock_24_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 83 * 256 + i.val))
      kernelWitness24Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_83

theorem kernelBlock_24_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 84 * 256 + i.val))
      kernelWitness24Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_84

theorem kernelBlock_24_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 85 * 256 + i.val))
      kernelWitness24Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_85

theorem kernelBlock_24_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 86 * 256 + i.val))
      kernelWitness24Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_86

theorem kernelBlock_24_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 87 * 256 + i.val))
      kernelWitness24Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_87

theorem kernelBlock_24_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 88 * 256 + i.val))
      kernelWitness24Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_88

theorem kernelBlock_24_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 89 * 256 + i.val))
      kernelWitness24Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_89

theorem kernelBlock_24_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 90 * 256 + i.val))
      kernelWitness24Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_90

theorem kernelBlock_24_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 91 * 256 + i.val))
      kernelWitness24Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_91

theorem kernelBlock_24_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 92 * 256 + i.val))
      kernelWitness24Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_92

theorem kernelBlock_24_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 93 * 256 + i.val))
      kernelWitness24Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_93

theorem kernelBlock_24_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 94 * 256 + i.val))
      kernelWitness24Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_94

theorem kernelBlock_24_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 95 * 256 + i.val))
      kernelWitness24Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_95

end TightCycleC5.Bridge.Cover
