import P33FlagData
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace TightCycleC5.Bridge.P33Flag
open ColouredFlags

theorem canonicalTable_size : canonicalTable.size = 256 := by decide +kernel
theorem canonicalTable_exact : ∀ i : Fin 256,
    canonicalTable[i.val]! = canonical4 (BitVec.ofNat 8 i.val) := by decide +kernel
#print axioms canonicalTable_size
#print axioms canonicalTable_exact
end TightCycleC5.Bridge.P33Flag
