import P32ArithmeticCore
namespace TightCycleC5.Bridge.P32Arithmetic
set_option maxHeartbeats 0
theorem class_group31 : ∀ j : Fin 16, ClassStatement
    ⟨496 + j.val, by have := j.isLt; omega⟩ := by native_decide
#print axioms class_group31
end TightCycleC5.Bridge.P32Arithmetic
