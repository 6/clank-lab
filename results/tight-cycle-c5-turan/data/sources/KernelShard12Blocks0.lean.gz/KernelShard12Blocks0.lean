import KernelRowIndex
import KernelWitness12

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_12_0 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 0 * 256 + i.val))
      kernelWitness12Row0[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_0

theorem kernelBlock_12_1 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 1 * 256 + i.val))
      kernelWitness12Row1[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_1

theorem kernelBlock_12_2 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 2 * 256 + i.val))
      kernelWitness12Row2[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_2

theorem kernelBlock_12_3 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 3 * 256 + i.val))
      kernelWitness12Row3[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_3

theorem kernelBlock_12_4 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 4 * 256 + i.val))
      kernelWitness12Row4[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_4

theorem kernelBlock_12_5 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 5 * 256 + i.val))
      kernelWitness12Row5[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_5

theorem kernelBlock_12_6 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 6 * 256 + i.val))
      kernelWitness12Row6[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_6

theorem kernelBlock_12_7 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 7 * 256 + i.val))
      kernelWitness12Row7[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_7

theorem kernelBlock_12_8 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 8 * 256 + i.val))
      kernelWitness12Row8[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_8

theorem kernelBlock_12_9 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 9 * 256 + i.val))
      kernelWitness12Row9[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_9

theorem kernelBlock_12_10 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 10 * 256 + i.val))
      kernelWitness12Row10[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_10

theorem kernelBlock_12_11 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 11 * 256 + i.val))
      kernelWitness12Row11[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_11

theorem kernelBlock_12_12 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 12 * 256 + i.val))
      kernelWitness12Row12[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_12

theorem kernelBlock_12_13 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 13 * 256 + i.val))
      kernelWitness12Row13[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_13

theorem kernelBlock_12_14 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 14 * 256 + i.val))
      kernelWitness12Row14[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_14

theorem kernelBlock_12_15 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 15 * 256 + i.val))
      kernelWitness12Row15[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_15

theorem kernelBlock_12_16 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 16 * 256 + i.val))
      kernelWitness12Row16[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_16

theorem kernelBlock_12_17 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 17 * 256 + i.val))
      kernelWitness12Row17[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_17

theorem kernelBlock_12_18 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 18 * 256 + i.val))
      kernelWitness12Row18[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_18

theorem kernelBlock_12_19 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 19 * 256 + i.val))
      kernelWitness12Row19[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_19

theorem kernelBlock_12_20 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 20 * 256 + i.val))
      kernelWitness12Row20[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_20

theorem kernelBlock_12_21 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 21 * 256 + i.val))
      kernelWitness12Row21[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_21

theorem kernelBlock_12_22 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 22 * 256 + i.val))
      kernelWitness12Row22[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_22

theorem kernelBlock_12_23 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 23 * 256 + i.val))
      kernelWitness12Row23[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_23

theorem kernelBlock_12_24 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 24 * 256 + i.val))
      kernelWitness12Row24[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_24

theorem kernelBlock_12_25 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 25 * 256 + i.val))
      kernelWitness12Row25[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_25

theorem kernelBlock_12_26 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 26 * 256 + i.val))
      kernelWitness12Row26[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_26

theorem kernelBlock_12_27 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 27 * 256 + i.val))
      kernelWitness12Row27[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_27

theorem kernelBlock_12_28 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 28 * 256 + i.val))
      kernelWitness12Row28[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_28

theorem kernelBlock_12_29 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 29 * 256 + i.val))
      kernelWitness12Row29[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_29

theorem kernelBlock_12_30 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 30 * 256 + i.val))
      kernelWitness12Row30[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_30

theorem kernelBlock_12_31 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 31 * 256 + i.val))
      kernelWitness12Row31[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_31

end TightCycleC5.Bridge.Cover
