import P33FlagRowsBase
import P33PSDGroup1
import P33FlagFacts1

namespace TightCycleC5.Bridge.P33Flag
open Finset Matrix

noncomputable def row1 (G : LabelledStructure 6) : ℝ :=
  pairRow P33PSD.matrix1 basis1 type1 G

theorem row1_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row1 (sampleStructure σ H S)) =
      psdTwoRootSixRow (zeroExtend P33PSD.matrix1)
        (fun root a => flagLookup basis1 (pairKey H S root a)) (pairIndicator type1 S) :=
  pair_row_eq P33PSD.matrix1 basis1 basis1_injective type1 H S

theorem row1_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -((4 * (n : ℝ) - 14) * P33PSD.bound1 / (((n : ℝ) - 4) * ((n : ℝ) - 5))) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row1 (sampleStructure σ H S)) :=
  pair_row_lower P33PSD.normalized_psd1 P33PSD.normalized_nonneg1
    P33PSD.normalized_diagonal1 hn basis1 basis1_injective type1 H S

#print axioms row1_eq_optional
#print axioms row1_lower

noncomputable def row7 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix7 basis7 type7 G

theorem row7_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row7 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix7)
        (fun root a => flagLookup basis7 (fourKey H S root a)) (fourIndicator type7 H S) :=
  four_row_eq P33PSD.matrix7 basis7 basis7_injective type7 H S

theorem row7_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound7 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row7 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd7 P33PSD.normalized_nonneg7
    P33PSD.normalized_diagonal7 hn basis7 basis7_injective type7 H S

#print axioms row7_eq_optional
#print axioms row7_lower

noncomputable def row13 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix13 basis13 type13 G

theorem row13_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row13 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix13)
        (fun root a => flagLookup basis13 (fourKey H S root a)) (fourIndicator type13 H S) :=
  four_row_eq P33PSD.matrix13 basis13 basis13_injective type13 H S

theorem row13_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound13 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row13 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd13 P33PSD.normalized_nonneg13
    P33PSD.normalized_diagonal13 hn basis13 basis13_injective type13 H S

#print axioms row13_eq_optional
#print axioms row13_lower

noncomputable def row19 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix19 basis19 type19 G

theorem row19_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row19 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix19)
        (fun root a => flagLookup basis19 (fourKey H S root a)) (fourIndicator type19 H S) :=
  four_row_eq P33PSD.matrix19 basis19 basis19_injective type19 H S

theorem row19_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound19 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row19 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd19 P33PSD.normalized_nonneg19
    P33PSD.normalized_diagonal19 hn basis19 basis19_injective type19 H S

#print axioms row19_eq_optional
#print axioms row19_lower

noncomputable def row25 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix25 basis25 type25 G

theorem row25_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row25 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix25)
        (fun root a => flagLookup basis25 (fourKey H S root a)) (fourIndicator type25 H S) :=
  four_row_eq P33PSD.matrix25 basis25 basis25_injective type25 H S

theorem row25_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound25 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row25 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd25 P33PSD.normalized_nonneg25
    P33PSD.normalized_diagonal25 hn basis25 basis25_injective type25 H S

#print axioms row25_eq_optional
#print axioms row25_lower

noncomputable def row31 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix31 basis31 type31 G

theorem row31_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row31 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix31)
        (fun root a => flagLookup basis31 (fourKey H S root a)) (fourIndicator type31 H S) :=
  four_row_eq P33PSD.matrix31 basis31 basis31_injective type31 H S

theorem row31_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound31 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row31 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd31 P33PSD.normalized_nonneg31
    P33PSD.normalized_diagonal31 hn basis31 basis31_injective type31 H S

#print axioms row31_eq_optional
#print axioms row31_lower

noncomputable def row37 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix37 basis37 type37 G

theorem row37_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row37 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix37)
        (fun root a => flagLookup basis37 (fourKey H S root a)) (fourIndicator type37 H S) :=
  four_row_eq P33PSD.matrix37 basis37 basis37_injective type37 H S

theorem row37_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound37 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row37 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd37 P33PSD.normalized_nonneg37
    P33PSD.normalized_diagonal37 hn basis37 basis37_injective type37 H S

#print axioms row37_eq_optional
#print axioms row37_lower

end TightCycleC5.Bridge.P33Flag
