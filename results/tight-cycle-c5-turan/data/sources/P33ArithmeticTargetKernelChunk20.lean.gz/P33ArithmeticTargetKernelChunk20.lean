-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk80 :
    ∀ i : Fin (min 128 (40547 - 128 * 80)),
      targetCountsMatch (classAt (targetKernelClass ⟨80, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk80

theorem target_counts_kernel_chunk81 :
    ∀ i : Fin (min 128 (40547 - 128 * 81)),
      targetCountsMatch (classAt (targetKernelClass ⟨81, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk81

theorem target_counts_kernel_chunk82 :
    ∀ i : Fin (min 128 (40547 - 128 * 82)),
      targetCountsMatch (classAt (targetKernelClass ⟨82, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk82

theorem target_counts_kernel_chunk83 :
    ∀ i : Fin (min 128 (40547 - 128 * 83)),
      targetCountsMatch (classAt (targetKernelClass ⟨83, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk83


end TightCycleC5.Bridge.P33Arithmetic
