-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk216 :
    ∀ i : Fin (min 128 (40547 - 128 * 216)),
      targetCountsMatch (classAt (targetKernelClass ⟨216, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk216

theorem target_counts_kernel_chunk217 :
    ∀ i : Fin (min 128 (40547 - 128 * 217)),
      targetCountsMatch (classAt (targetKernelClass ⟨217, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk217

theorem target_counts_kernel_chunk218 :
    ∀ i : Fin (min 128 (40547 - 128 * 218)),
      targetCountsMatch (classAt (targetKernelClass ⟨218, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk218

theorem target_counts_kernel_chunk219 :
    ∀ i : Fin (min 128 (40547 - 128 * 219)),
      targetCountsMatch (classAt (targetKernelClass ⟨219, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk219


end TightCycleC5.Bridge.P33Arithmetic
