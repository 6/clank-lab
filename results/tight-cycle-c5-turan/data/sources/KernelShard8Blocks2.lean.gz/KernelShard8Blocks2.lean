import KernelQuarterIndex
import KernelWitness8

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_8_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 64 * 256 + i.val))
      kernelWitness8Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_64

theorem kernelBlock_8_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 65 * 256 + i.val))
      kernelWitness8Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_65

theorem kernelBlock_8_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 66 * 256 + i.val))
      kernelWitness8Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_66

theorem kernelBlock_8_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 67 * 256 + i.val))
      kernelWitness8Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_67

theorem kernelBlock_8_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 68 * 256 + i.val))
      kernelWitness8Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_68

theorem kernelBlock_8_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 69 * 256 + i.val))
      kernelWitness8Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_69

theorem kernelBlock_8_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 70 * 256 + i.val))
      kernelWitness8Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_70

theorem kernelBlock_8_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 71 * 256 + i.val))
      kernelWitness8Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_71

theorem kernelBlock_8_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 72 * 256 + i.val))
      kernelWitness8Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_72

theorem kernelBlock_8_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 73 * 256 + i.val))
      kernelWitness8Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_73

theorem kernelBlock_8_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 74 * 256 + i.val))
      kernelWitness8Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_74

theorem kernelBlock_8_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 75 * 256 + i.val))
      kernelWitness8Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_75

theorem kernelBlock_8_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 76 * 256 + i.val))
      kernelWitness8Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_76

theorem kernelBlock_8_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 77 * 256 + i.val))
      kernelWitness8Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_77

theorem kernelBlock_8_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 78 * 256 + i.val))
      kernelWitness8Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_78

theorem kernelBlock_8_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 79 * 256 + i.val))
      kernelWitness8Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_79

theorem kernelBlock_8_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 80 * 256 + i.val))
      kernelWitness8Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_80

theorem kernelBlock_8_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 81 * 256 + i.val))
      kernelWitness8Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_81

theorem kernelBlock_8_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 82 * 256 + i.val))
      kernelWitness8Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_82

theorem kernelBlock_8_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 83 * 256 + i.val))
      kernelWitness8Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_83

theorem kernelBlock_8_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 84 * 256 + i.val))
      kernelWitness8Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_84

theorem kernelBlock_8_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 85 * 256 + i.val))
      kernelWitness8Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_85

theorem kernelBlock_8_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 86 * 256 + i.val))
      kernelWitness8Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_86

theorem kernelBlock_8_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 87 * 256 + i.val))
      kernelWitness8Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_87

theorem kernelBlock_8_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 88 * 256 + i.val))
      kernelWitness8Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_88

theorem kernelBlock_8_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 89 * 256 + i.val))
      kernelWitness8Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_89

theorem kernelBlock_8_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 90 * 256 + i.val))
      kernelWitness8Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_90

theorem kernelBlock_8_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 91 * 256 + i.val))
      kernelWitness8Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_91

theorem kernelBlock_8_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 92 * 256 + i.val))
      kernelWitness8Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_92

theorem kernelBlock_8_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 93 * 256 + i.val))
      kernelWitness8Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_93

theorem kernelBlock_8_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 94 * 256 + i.val))
      kernelWitness8Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_94

theorem kernelBlock_8_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 95 * 256 + i.val))
      kernelWitness8Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_95

end TightCycleC5.Bridge.Cover
