import CoverSemantics
import CoverWitness0

/-! First fixed 32768-mask unit of the exhaustive P32 cover. -/
namespace TightCycleC5.Bridge.Cover

set_option maxHeartbeats 0 in
theorem shard0 : shardCheck 0 witnessHex0 := by
  unfold shardCheck shardCheckBytes
  native_decide

def changedCoverBytes : ByteArray :=
  (((((witnessHex0.toUTF8.set! 0 48).set! 1 48).set! 2 48).set! 3 48).set! 4 48).set! 5 48

theorem rejects_cover_gap : ¬ shardCheckBytes 0 changedCoverBytes := by
  unfold shardCheckBytes
  native_decide

#print axioms shard0
#print axioms rejects_cover_gap
end TightCycleC5.Bridge.Cover
