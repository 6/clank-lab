import FlagRows

/-! Frozen P32 §3a flags at actual six-injections; no support premise. -/
namespace TightCycleC5.Bridge.P32Flag
open Finset Matrix

def edge {V : Type*} [DecidableEq V] (G : Finset (Finset V)) (x u v : V) : Bool :=
  decide ({x, u, v} ∈ G)

theorem edge_swap {V : Type*} [DecidableEq V] (G : Finset (Finset V)) (x u v : V) :
    edge G x u v = edge G x v u := by
  simp only [edge, Finset.pair_comm u v]

/-- Lexicographic pairs xu,xv,xa,uv,ua,va, least significant first. -/
def fourKey {V : Type*} [DecidableEq V] (G : Finset (Finset V))
    (r : Fin 4 → V) (z : V) : ℕ :=
  (edge G (r 0) (r 1) z).toNat + 2 * (edge G (r 0) (r 2) z).toNat +
  4 * (edge G (r 0) (r 3) z).toNat + 8 * (edge G (r 1) (r 2) z).toNat +
  16 * (edge G (r 1) (r 3) z).toNat + 32 * (edge G (r 2) (r 3) z).toNat

/-- Ordered root bits are (1)^e(0)^(4-e), not merely e present edges. -/
def rootPass {V : Type*} [DecidableEq V] (e : Fin 5) (G : Finset (Finset V))
    (r : Fin 4 → V) : Prop :=
  edge G (r 0) (r 1) (r 2) = decide (0 < e.val) ∧
  edge G (r 0) (r 1) (r 3) = decide (1 < e.val) ∧
  edge G (r 0) (r 2) (r 3) = decide (2 < e.val) ∧
  edge G (r 1) (r 2) (r 3) = decide (3 < e.val)

instance {V : Type*} [DecidableEq V] (e : Fin 5) (G : Finset (Finset V))
    (r : Fin 4 → V) : Decidable (rootPass e G r) := by
  unfold rootPass
  infer_instance

def rootIndicator {V : Type*} [DecidableEq V] (e : Fin 5) (G : Finset (Finset V))
    (r : Fin 4 → V) : ℝ := if rootPass e G r then 1 else 0

theorem rootIndicator_bit {V : Type*} [DecidableEq V] (e : Fin 5)
    (G : Finset (Finset V)) (r : Fin 4 → V) :
    rootIndicator e G r = 0 ∨ rootIndicator e G r = 1 := by
  unfold rootIndicator
  split_ifs <;> simp

/-- Sixth-block pair code, exactly as in check_embeddings.py. -/
def twoKey {V : Type*} [DecidableEq V] (G : Finset (Finset V))
    (r : Fin 2 → V) (a b : V) : ℕ :=
  4 * ((edge G (r 0) (r 1) a).toNat + (edge G (r 0) (r 1) b).toNat) +
  2 * (edge G (r 0) a b).toNat + (edge G (r 1) a b).toNat

theorem twoKey_swap {V : Type*} [DecidableEq V] (G : Finset (Finset V))
    (r : Fin 2 → V) (a b : V) : twoKey G r a b = twoKey G r b a := by
  simp only [twoKey, edge_swap G _ b a, add_comm]

/-- Full indicator trace at labels x,u,v,a,b,d = 0,1,2,3,4,5. -/
noncomputable def literalFourRow {n k : ℕ} (e : Fin 5)
    (Q : Matrix (Fin k) (Fin k) ℝ) (code : Fin k → ℕ)
    (G : Finset (Finset (Fin n))) (σ : Fin 6 ↪ Fin n) : ℝ :=
  let r : Fin 4 → Fin n := fun i => σ (Fin.castAdd 2 i)
  rootIndicator e G r * (∑ i, ∑ j, Q i j *
    (if fourKey G r (σ 4) = code i then 1 else 0) *
    (if fourKey G r (σ 5) = code j then 1 else 0))

/-- Unconditional two-root row pairing (v,a) against (b,d). -/
noncomputable def literalTwoRow {n k : ℕ}
    (Q : Matrix (Fin k) (Fin k) ℝ) (code : Fin k → ℕ)
    (G : Finset (Finset (Fin n))) (σ : Fin 6 ↪ Fin n) : ℝ :=
  let r : Fin 2 → Fin n := fun i => σ (Fin.castAdd 4 i)
  ∑ i, ∑ j, Q i j * (if twoKey G r (σ 2) (σ 3) = code i then 1 else 0) *
    (if twoKey G r (σ 4) (σ 5) = code j then 1 else 0)

theorem literalFourRow_join {n k : ℕ} (e : Fin 5)
    (Q : Matrix (Fin k) (Fin k) ℝ) (code : Fin k → ℕ)
    (G : Finset (Finset (Fin n))) (root : Fin 4 ↪ Fin n)
    (free : Fin 2 ↪ Outside root) :
    literalFourRow e Q code G (joinSample root free) =
      rootIndicator e G root * (∑ i, ∑ j, Q i j *
        (if fourKey G root (free 0).val = code i then 1 else 0) *
        (if fourKey G root (free 1).val = code j then 1 else 0)) := by
  have hr : (fun i : Fin 4 => joinSample root free (Fin.castAdd 2 i)) = root :=
    funext (joinSample_root root free)
  have h4 : joinSample root free 4 = (free 0).val := joinSample_free root free 0
  have h5 : joinSample root free 5 = (free 1).val := joinSample_free root free 1
  simp only [literalFourRow, hr, h4, h5]

theorem literalTwoRow_join {n k : ℕ}
    (Q : Matrix (Fin k) (Fin k) ℝ) (code : Fin k → ℕ)
    (G : Finset (Finset (Fin n))) (root : Fin 2 ↪ Fin n)
    (free : Fin 4 ↪ Outside root) :
    literalTwoRow Q code G (joinSample root free) =
      ∑ i, ∑ j, Q i j * (if twoKey G root (free 0).val (free 1).val = code i then 1 else 0) *
        (if twoKey G root (free 2).val (free 3).val = code j then 1 else 0) := by
  have hr : (fun i : Fin 2 => joinSample root free (Fin.castAdd 4 i)) = root :=
    funext (joinSample_root root free)
  have h2 : joinSample root free 2 = (free 0).val := joinSample_free root free 0
  have h3 : joinSample root free 3 = (free 1).val := joinSample_free root free 1
  have h4 : joinSample root free 4 = (free 2).val := joinSample_free root free 2
  have h5 : joinSample root free 5 = (free 3).val := joinSample_free root free 3
  simp only [literalTwoRow, hr, h2, h3, h4, h5]

/-- Full trace equals the optional PSD row at every actual injection. -/
theorem literalFourRow_eq {n k : ℕ} (e : Fin 5)
    (Q : Matrix (Fin k) (Fin k) ℝ) (code : Fin k → ℕ) (hinj : Function.Injective code)
    (G : Finset (Finset (Fin n))) :
    literalFourRow e Q code G = psdFourRootSixRow (zeroExtend Q)
      (fun root z => flagLookup code (fourKey G root z.val))
      (fun root => rootIndicator e G root) := by
  funext σ
  obtain ⟨⟨root, free⟩, rfl⟩ := (splitSampleEquiv (r := 4) (f := 2) (n := n)).symm.surjective σ
  change literalFourRow e Q code G (joinSample root free) = _
  rw [literalFourRow_join, flag_indicator_trace Q code hinj]
  change _ = (fun rf : Σ root : Fin 4 ↪ Fin n, Fin 2 ↪ Outside root =>
    rootIndicator e G rf.1 * zeroExtend Q
      (flagLookup code (fourKey G rf.1 (rf.2 0).val))
      (flagLookup code (fourKey G rf.1 (rf.2 1).val)))
        (splitSampleEquiv (joinSample root free))
  rw [splitSampleEquiv_join]

theorem literalTwoRow_eq {n k : ℕ}
    (Q : Matrix (Fin k) (Fin k) ℝ) (code : Fin k → ℕ) (hinj : Function.Injective code)
    (G : Finset (Finset (Fin n))) :
    literalTwoRow Q code G = psdTwoRootSixRow (zeroExtend Q)
      (fun root p => flagLookup code (twoKey G root p.1.val p.2.val)) (fun _ => 1) := by
  funext σ
  obtain ⟨⟨root, free⟩, rfl⟩ := (splitSampleEquiv (r := 2) (f := 4) (n := n)).symm.surjective σ
  change literalTwoRow Q code G (joinSample root free) = _
  rw [literalTwoRow_join, flag_indicator_trace Q code hinj]
  change _ = (fun rf : Σ root : Fin 2 ↪ Fin n, Fin 4 ↪ Outside root =>
    1 * zeroExtend Q
      (flagLookup code (twoKey G rf.1 (rf.2 0).val (rf.2 1).val))
      (flagLookup code (twoKey G rf.1 (rf.2 2).val (rf.2 3).val)))
        (splitSampleEquiv (joinSample root free))
  rw [splitSampleEquiv_join]
  dsimp only
  exact (one_mul _).symm

theorem literalFourRow_lower {n k : ℕ} (e : Fin 5)
    {Q : Matrix (Fin k) (Fin k) ℝ} (hQ : Q.PosSemidef)
    {m : ℝ} (hm : 0 ≤ m) (hdiag : ∀ i, Q i i ≤ m) (hn : 12 ≤ n)
    (code : Fin k → ℕ) (hinj : Function.Injective code)
    (G : Finset (Finset (Fin n))) :
    -m / ((n : ℝ) - 5) ≤ uniformMean (literalFourRow e Q code G) := by
  rw [literalFourRow_eq e Q code hinj]
  exact flag_optional_four_root_six_row_lower hQ hm hdiag hn _ _
    (fun root => rootIndicator_bit e G root)

theorem literalTwoRow_lower {n k : ℕ}
    {Q : Matrix (Fin k) (Fin k) ℝ} (hQ : Q.PosSemidef)
    {m : ℝ} (hm : 0 ≤ m) (hdiag : ∀ i, Q i i ≤ m) (hn : 12 ≤ n)
    (code : Fin k → ℕ) (hinj : Function.Injective code)
    (G : Finset (Finset (Fin n))) :
    -((4 * (n : ℝ) - 14) * m / (((n : ℝ) - 4) * ((n : ℝ) - 5))) ≤
      uniformMean (literalTwoRow Q code G) := by
  rw [literalTwoRow_eq Q code hinj]
  exact flag_optional_two_root_six_row_lower hQ hm hdiag hn _ _ (fun _ => Or.inr rfl)

#print axioms literalFourRow_lower
#print axioms literalTwoRow_lower
#print axioms edge_swap
#print axioms rootIndicator_bit
#print axioms twoKey_swap
#print axioms literalFourRow_join
#print axioms literalTwoRow_join
#print axioms literalFourRow_eq
#print axioms literalTwoRow_eq
end TightCycleC5.Bridge.P32Flag
