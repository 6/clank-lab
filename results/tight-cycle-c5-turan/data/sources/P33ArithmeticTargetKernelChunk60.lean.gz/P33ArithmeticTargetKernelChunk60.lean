-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk240 :
    ∀ i : Fin (min 128 (40547 - 128 * 240)),
      targetCountsMatch (classAt (targetKernelClass ⟨240, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk240

theorem target_counts_kernel_chunk241 :
    ∀ i : Fin (min 128 (40547 - 128 * 241)),
      targetCountsMatch (classAt (targetKernelClass ⟨241, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk241

theorem target_counts_kernel_chunk242 :
    ∀ i : Fin (min 128 (40547 - 128 * 242)),
      targetCountsMatch (classAt (targetKernelClass ⟨242, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk242

theorem target_counts_kernel_chunk243 :
    ∀ i : Fin (min 128 (40547 - 128 * 243)),
      targetCountsMatch (classAt (targetKernelClass ⟨243, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk243


end TightCycleC5.Bridge.P33Arithmetic
