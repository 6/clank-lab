import P32ArithmeticCore
namespace TightCycleC5.Bridge.P32Arithmetic
set_option maxHeartbeats 0
theorem class_group23 : ∀ j : Fin 16, ClassStatement
    ⟨368 + j.val, by have := j.isLt; omega⟩ := by native_decide
#print axioms class_group23
end TightCycleC5.Bridge.P32Arithmetic
