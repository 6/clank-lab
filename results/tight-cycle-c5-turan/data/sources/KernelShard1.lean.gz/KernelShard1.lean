import KernelShard1Blocks0
import KernelShard1Blocks1
import KernelShard1Blocks2
import KernelShard1Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard1 : kernelShardCheck 1 kernelWitness1 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (1 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness1 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_1_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard1
end TightCycleC5.Bridge.Cover
