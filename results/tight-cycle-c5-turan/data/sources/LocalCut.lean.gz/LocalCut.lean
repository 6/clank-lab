import RootIncidence

/-! The cut-change identity in PROOF §3 Lemma 5. Colour 1 means outside S. -/
namespace TightCycleC5.Bridge
open Finset
variable {n : ℕ}

def vertexColour (S : Finset (Fin n)) (x : Fin n) : ℝ := if x ∈ S then 0 else 1

def localSign (S : Finset (Fin n)) (x u v : Fin n) : ℝ :=
  (if x ∈ S then 1 else -1) *
    ((if (u ∈ S ∧ v ∉ S) ∨ (u ∉ S ∧ v ∈ S) then 1 else 0) -
      (if u ∈ S ∧ v ∈ S then 1 else 0))

def localGain (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (x u v : Fin n) : ℝ := if ({x, u, v} : Finset (Fin n)) ∈ H then localSign S x u v else 0

def edgeCutIndicator (S e : Finset (Fin n)) : ℝ := if (e ∩ S).card = 2 then 1 else 0

def edgeCutDelta (S : Finset (Fin n)) (x : Fin n) (e : Finset (Fin n)) : ℝ :=
  edgeCutIndicator S e - edgeCutIndicator (symmDiff S {x}) e

/-- Identification with the literal colour expression in the frozen proof. -/
theorem localSign_colour_expression (S : Finset (Fin n)) (x u v : Fin n) :
    localSign S x u v =
      ((if vertexColour S u + vertexColour S v = 1 then 1 else 0) -
        (if vertexColour S u + vertexColour S v = 0 then 1 else 0)) *
        (1 - 2 * vertexColour S x) := by
  by_cases hx : x ∈ S <;> by_cases hu : u ∈ S <;> by_cases hv : v ∈ S <;>
    norm_num [localSign, vertexColour, hx, hu, hv]

theorem localSign_eq_cutDelta (S : Finset (Fin n)) (x u v : Fin n)
    (hxu : x ≠ u) (hxv : x ≠ v) (huv : u ≠ v) :
    localSign S x u v = edgeCutDelta S x {x, u, v} := by
  by_cases hx : x ∈ S <;> by_cases hu : u ∈ S <;> by_cases hv : v ∈ S <;>
    simp [localSign, edgeCutDelta, edgeCutIndicator,
      mem_symmDiff, hx, hu, hv, hxu, hxv, huv, hxu.symm, hxv.symm]

theorem edgeCutDelta_zero_of_not_mem (S : Finset (Fin n)) (x : Fin n)
    (e : Finset (Fin n)) (hx : x ∉ e) : edgeCutDelta S x e = 0 := by
  have he : e ∩ symmDiff S {x} = e ∩ S := by
    ext a
    by_cases ha : a ∈ e
    · have hax : a ≠ x := fun h => hx (h ▸ ha)
      simp [ha, mem_symmDiff, hax]
    · simp [ha]
  simp [edgeCutDelta, edgeCutIndicator, he]

theorem sum_edgeCutIndicator (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (∑ e ∈ H, edgeCutIndicator S e) = (cutCount H S : ℝ) := by
  rw [cutCount, Finset.card_eq_sum_ones]
  simp only [Nat.cast_sum, Finset.sum_filter, edgeCutIndicator]
  apply Finset.sum_congr rfl
  intro e _
  split_ifs <;> norm_num

theorem localGain_pair_sum (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (S : Finset (Fin n)) (x : Fin n) :
    (∑ u, ∑ v, localGain H S x u v) =
      2 * ((cutCount H S : ℝ) - (cutCount H (symmDiff S {x}) : ℝ)) := by
  have hp : ∀ u v, localGain H S x u v =
      if ({x, u, v} : Finset (Fin n)) ∈ H then edgeCutDelta S x {x, u, v} else 0 := by
    intro u v
    by_cases he : ({x, u, v} : Finset (Fin n)) ∈ H
    · obtain ⟨hxu, hxv, huv⟩ := card_triple_eq_three_iff.mp (hH _ he)
      simp only [localGain, if_pos he, localSign_eq_cutDelta S x u v hxu hxv huv]
    · simp [localGain, he]
  simp_rw [hp]
  rw [root_pair_sum H hH x (edgeCutDelta S x)]
  have hs : (∑ e ∈ H.filter (fun e => x ∈ e), edgeCutDelta S x e) =
      ∑ e ∈ H, edgeCutDelta S x e := by
    rw [sum_filter]
    apply Finset.sum_congr rfl
    intro e _
    by_cases hx : x ∈ e
    · simp [hx]
    · simp [hx, edgeCutDelta_zero_of_not_mem S x e hx]
  rw [hs]
  simp only [edgeCutDelta, Finset.sum_sub_distrib, sum_edgeCutIndicator]

theorem localGain_pair_sum_nonneg (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (S : Finset (Fin n)) (hS : LocallyMaximal H S) (x : Fin n) :
    0 ≤ ∑ u, ∑ v, localGain H S x u v := by
  rw [localGain_pair_sum H hH S x]
  have hx : (cutCount H (symmDiff S {x}) : ℝ) ≤ cutCount H S := by exact_mod_cast hS x
  linarith

theorem localSign_abs_le (S : Finset (Fin n)) (x u v : Fin n) :
    |localSign S x u v| ≤ 1 := by
  by_cases hx : x ∈ S <;> by_cases hu : u ∈ S <;> by_cases hv : v ∈ S <;>
    norm_num [localSign, hx, hu, hv]

theorem localGain_abs_le (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (x u v : Fin n) : |localGain H S x u v| ≤ 1 := by
  unfold localGain
  split_ifs
  · exact localSign_abs_le S x u v
  · norm_num

theorem localGain_diagonal_zero (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (S : Finset (Fin n)) (x u : Fin n) : localGain H S x u u = 0 := by
  simp [localGain, three_graph_no_pair hH x u]

theorem localGain_root_left_zero (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (S : Finset (Fin n)) (x v : Fin n) : localGain H S x x v = 0 := by
  simp [localGain, three_graph_no_pair hH x v]

theorem localGain_root_right_zero (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (S : Finset (Fin n)) (x u : Fin n) : localGain H S x u x = 0 := by
  simp [localGain, three_graph_no_pair hH u x]

#print axioms localSign_abs_le
#print axioms localGain_abs_le
#print axioms localGain_diagonal_zero
#print axioms localGain_root_left_zero
#print axioms localGain_root_right_zero
#print axioms localSign_colour_expression
#print axioms localSign_eq_cutDelta
#print axioms edgeCutDelta_zero_of_not_mem
#print axioms sum_edgeCutIndicator
#print axioms localGain_pair_sum
#print axioms localGain_pair_sum_nonneg
end TightCycleC5.Bridge
