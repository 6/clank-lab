-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk196 :
    ∀ i : Fin (min 128 (40547 - 128 * 196)),
      targetCountsMatch (classAt (targetKernelClass ⟨196, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk196

theorem target_counts_kernel_chunk197 :
    ∀ i : Fin (min 128 (40547 - 128 * 197)),
      targetCountsMatch (classAt (targetKernelClass ⟨197, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk197

theorem target_counts_kernel_chunk198 :
    ∀ i : Fin (min 128 (40547 - 128 * 198)),
      targetCountsMatch (classAt (targetKernelClass ⟨198, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk198

theorem target_counts_kernel_chunk199 :
    ∀ i : Fin (min 128 (40547 - 128 * 199)),
      targetCountsMatch (classAt (targetKernelClass ⟨199, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk199


end TightCycleC5.Bridge.P33Arithmetic
