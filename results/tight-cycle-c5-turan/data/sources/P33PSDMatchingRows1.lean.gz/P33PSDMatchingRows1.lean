import P33PSDMatchingRowsBase
import P33PSDMatchingEntries1
import P33FlagRows1
namespace TightCycleC5.Bridge.P33PSDMatching

theorem source_row1 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block1 K p) :
    (sourceContribution P33Arithmetic.block1 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row1 (p.symm • decoded K.mask K.colours) :=
  pair_contribution_eq P33Arithmetic.block1 rfl P33PSD.q1 P33PSD.scale source_entry1
    P33Flag.basis1 P33Flag.basis1_injective rfl (fun _ => rfl) P33Flag.type1 rfl K p hv
#print axioms source_row1

theorem source_row7 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block7 K p) :
    (sourceContribution P33Arithmetic.block7 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row7 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block7 rfl P33PSD.q7 P33PSD.scale source_entry7
    P33Flag.basis7 P33Flag.basis7_injective rfl (fun _ => rfl) P33Flag.type7 rfl K p hv
#print axioms source_row7

theorem source_row13 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block13 K p) :
    (sourceContribution P33Arithmetic.block13 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row13 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block13 rfl P33PSD.q13 P33PSD.scale source_entry13
    P33Flag.basis13 P33Flag.basis13_injective rfl (fun _ => rfl) P33Flag.type13 rfl K p hv
#print axioms source_row13

theorem source_row19 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block19 K p) :
    (sourceContribution P33Arithmetic.block19 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row19 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block19 rfl P33PSD.q19 P33PSD.scale source_entry19
    P33Flag.basis19 P33Flag.basis19_injective rfl (fun _ => rfl) P33Flag.type19 rfl K p hv
#print axioms source_row19

theorem source_row25 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block25 K p) :
    (sourceContribution P33Arithmetic.block25 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row25 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block25 rfl P33PSD.q25 P33PSD.scale source_entry25
    P33Flag.basis25 P33Flag.basis25_injective rfl (fun _ => rfl) P33Flag.type25 rfl K p hv
#print axioms source_row25

theorem source_row31 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block31 K p) :
    (sourceContribution P33Arithmetic.block31 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row31 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block31 rfl P33PSD.q31 P33PSD.scale source_entry31
    P33Flag.basis31 P33Flag.basis31_injective rfl (fun _ => rfl) P33Flag.type31 rfl K p hv
#print axioms source_row31

theorem source_row37 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block37 K p) :
    (sourceContribution P33Arithmetic.block37 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row37 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block37 rfl P33PSD.q37 P33PSD.scale source_entry37
    P33Flag.basis37 P33Flag.basis37_injective rfl (fun _ => rfl) P33Flag.type37 rfl K p hv
#print axioms source_row37

end TightCycleC5.Bridge.P33PSDMatching
