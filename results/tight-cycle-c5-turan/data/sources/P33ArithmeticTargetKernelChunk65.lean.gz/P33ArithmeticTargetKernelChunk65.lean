-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk260 :
    ∀ i : Fin (min 128 (40547 - 128 * 260)),
      targetCountsMatch (classAt (targetKernelClass ⟨260, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk260

theorem target_counts_kernel_chunk261 :
    ∀ i : Fin (min 128 (40547 - 128 * 261)),
      targetCountsMatch (classAt (targetKernelClass ⟨261, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk261

theorem target_counts_kernel_chunk262 :
    ∀ i : Fin (min 128 (40547 - 128 * 262)),
      targetCountsMatch (classAt (targetKernelClass ⟨262, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk262

theorem target_counts_kernel_chunk263 :
    ∀ i : Fin (min 128 (40547 - 128 * 263)),
      targetCountsMatch (classAt (targetKernelClass ⟨263, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk263


end TightCycleC5.Bridge.P33Arithmetic
