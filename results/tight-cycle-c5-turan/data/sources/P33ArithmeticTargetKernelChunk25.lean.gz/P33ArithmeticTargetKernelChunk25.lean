-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk100 :
    ∀ i : Fin (min 128 (40547 - 128 * 100)),
      targetCountsMatch (classAt (targetKernelClass ⟨100, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk100

theorem target_counts_kernel_chunk101 :
    ∀ i : Fin (min 128 (40547 - 128 * 101)),
      targetCountsMatch (classAt (targetKernelClass ⟨101, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk101

theorem target_counts_kernel_chunk102 :
    ∀ i : Fin (min 128 (40547 - 128 * 102)),
      targetCountsMatch (classAt (targetKernelClass ⟨102, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk102

theorem target_counts_kernel_chunk103 :
    ∀ i : Fin (min 128 (40547 - 128 * 103)),
      targetCountsMatch (classAt (targetKernelClass ⟨103, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk103


end TightCycleC5.Bridge.P33Arithmetic
