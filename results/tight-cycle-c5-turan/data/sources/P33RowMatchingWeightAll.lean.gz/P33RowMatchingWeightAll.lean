import P33RowMatchingWeights
import P33RowMatchingData
import P33RowMatchingAggregate

namespace TightCycleC5.Bridge.P33RowMatching
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem full_weights_aligned (i : Fin 12847) :
    P33Arithmetic.denseInequalities[i.val]! = CertificateDescriptors.p33aYData[i.val]! := by
  rw [dense_source_array]

#print axioms full_weights_aligned

theorem inequality_weight_match (i : Fin 12847) :
    (P33Arithmetic.denseInequalities[i.val]! : ℝ) / (P33Arithmetic.sosScale : ℝ) =
      actualInequalityWeight i := by
  unfold actualInequalityWeight
  split_ifs with hi
  · rw [local_global_weights_aligned ⟨i.val,hi⟩,source_scale_aligned]
    simp only [P33Rows.inequalityWeight,Int.cast_natCast]
  · rw [full_weights_aligned i,cl_source_scale_aligned]
    simp only [CertificateDescriptors.p33CLWeight,CertificateDescriptors.p33Weight,
      CertificateDescriptors.p33Numerator,CertificateDescriptors.p33Scale,
      CertificateDescriptors.p33CLSourceIndex, Bool.false_eq_true, if_false]
    change (CertificateDescriptors.p33aYData[i.val]! : ℝ) / (CertificateDescriptors.p33aScale : ℝ) =
      (CertificateDescriptors.p33aYData[97+(i.val-97)]! : ℝ) / (CertificateDescriptors.p33aScale : ℝ)
    exact congrArg (fun q : Nat => (CertificateDescriptors.p33aYData[q]! : ℝ) /
      (CertificateDescriptors.p33aScale : ℝ)) (by omega)

#print axioms inequality_weight_match

theorem regular_weight_match (i : Fin 120) :
    (P33Arithmetic.denseRegularity[i.val]! : ℝ) / (P33Arithmetic.sosScale : ℝ) =
      P33Rows.regularWeight i := by
  rw [regular_weights_aligned i,source_scale_aligned]
  simp only [P33Rows.regularWeight,Int.cast_natCast]

#print axioms regular_weight_match
end TightCycleC5.Bridge.P33RowMatching
