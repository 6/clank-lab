import KernelRowIndex
import KernelWitness7

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_7_96 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 96 * 256 + i.val))
      kernelWitness7Row96[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_96

theorem kernelBlock_7_97 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 97 * 256 + i.val))
      kernelWitness7Row97[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_97

theorem kernelBlock_7_98 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 98 * 256 + i.val))
      kernelWitness7Row98[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_98

theorem kernelBlock_7_99 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 99 * 256 + i.val))
      kernelWitness7Row99[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_99

theorem kernelBlock_7_100 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 100 * 256 + i.val))
      kernelWitness7Row100[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_100

theorem kernelBlock_7_101 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 101 * 256 + i.val))
      kernelWitness7Row101[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_101

theorem kernelBlock_7_102 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 102 * 256 + i.val))
      kernelWitness7Row102[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_102

theorem kernelBlock_7_103 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 103 * 256 + i.val))
      kernelWitness7Row103[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_103

theorem kernelBlock_7_104 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 104 * 256 + i.val))
      kernelWitness7Row104[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_104

theorem kernelBlock_7_105 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 105 * 256 + i.val))
      kernelWitness7Row105[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_105

theorem kernelBlock_7_106 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 106 * 256 + i.val))
      kernelWitness7Row106[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_106

theorem kernelBlock_7_107 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 107 * 256 + i.val))
      kernelWitness7Row107[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_107

theorem kernelBlock_7_108 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 108 * 256 + i.val))
      kernelWitness7Row108[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_108

theorem kernelBlock_7_109 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 109 * 256 + i.val))
      kernelWitness7Row109[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_109

theorem kernelBlock_7_110 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 110 * 256 + i.val))
      kernelWitness7Row110[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_110

theorem kernelBlock_7_111 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 111 * 256 + i.val))
      kernelWitness7Row111[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_111

theorem kernelBlock_7_112 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 112 * 256 + i.val))
      kernelWitness7Row112[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_112

theorem kernelBlock_7_113 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 113 * 256 + i.val))
      kernelWitness7Row113[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_113

theorem kernelBlock_7_114 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 114 * 256 + i.val))
      kernelWitness7Row114[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_114

theorem kernelBlock_7_115 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 115 * 256 + i.val))
      kernelWitness7Row115[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_115

theorem kernelBlock_7_116 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 116 * 256 + i.val))
      kernelWitness7Row116[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_116

theorem kernelBlock_7_117 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 117 * 256 + i.val))
      kernelWitness7Row117[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_117

theorem kernelBlock_7_118 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 118 * 256 + i.val))
      kernelWitness7Row118[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_118

theorem kernelBlock_7_119 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 119 * 256 + i.val))
      kernelWitness7Row119[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_119

theorem kernelBlock_7_120 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 120 * 256 + i.val))
      kernelWitness7Row120[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_120

theorem kernelBlock_7_121 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 121 * 256 + i.val))
      kernelWitness7Row121[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_121

theorem kernelBlock_7_122 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 122 * 256 + i.val))
      kernelWitness7Row122[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_122

theorem kernelBlock_7_123 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 123 * 256 + i.val))
      kernelWitness7Row123[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_123

theorem kernelBlock_7_124 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 124 * 256 + i.val))
      kernelWitness7Row124[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_124

theorem kernelBlock_7_125 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 125 * 256 + i.val))
      kernelWitness7Row125[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_125

theorem kernelBlock_7_126 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 126 * 256 + i.val))
      kernelWitness7Row126[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_126

theorem kernelBlock_7_127 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 127 * 256 + i.val))
      kernelWitness7Row127[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_127

end TightCycleC5.Bridge.Cover
