import KernelShard12Blocks0
import KernelShard12Blocks1
import KernelShard12Blocks2
import KernelShard12Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard12 : kernelShardCheck 12 kernelWitness12 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (12 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness12 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_12_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard12
end TightCycleC5.Bridge.Cover
