import KernelRowIndex
import KernelWitness27

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_27_32 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 32 * 256 + i.val))
      kernelWitness27Row32[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_32

theorem kernelBlock_27_33 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 33 * 256 + i.val))
      kernelWitness27Row33[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_33

theorem kernelBlock_27_34 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 34 * 256 + i.val))
      kernelWitness27Row34[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_34

theorem kernelBlock_27_35 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 35 * 256 + i.val))
      kernelWitness27Row35[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_35

theorem kernelBlock_27_36 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 36 * 256 + i.val))
      kernelWitness27Row36[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_36

theorem kernelBlock_27_37 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 37 * 256 + i.val))
      kernelWitness27Row37[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_37

theorem kernelBlock_27_38 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 38 * 256 + i.val))
      kernelWitness27Row38[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_38

theorem kernelBlock_27_39 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 39 * 256 + i.val))
      kernelWitness27Row39[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_39

theorem kernelBlock_27_40 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 40 * 256 + i.val))
      kernelWitness27Row40[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_40

theorem kernelBlock_27_41 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 41 * 256 + i.val))
      kernelWitness27Row41[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_41

theorem kernelBlock_27_42 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 42 * 256 + i.val))
      kernelWitness27Row42[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_42

theorem kernelBlock_27_43 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 43 * 256 + i.val))
      kernelWitness27Row43[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_43

theorem kernelBlock_27_44 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 44 * 256 + i.val))
      kernelWitness27Row44[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_44

theorem kernelBlock_27_45 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 45 * 256 + i.val))
      kernelWitness27Row45[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_45

theorem kernelBlock_27_46 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 46 * 256 + i.val))
      kernelWitness27Row46[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_46

theorem kernelBlock_27_47 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 47 * 256 + i.val))
      kernelWitness27Row47[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_47

theorem kernelBlock_27_48 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 48 * 256 + i.val))
      kernelWitness27Row48[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_48

theorem kernelBlock_27_49 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 49 * 256 + i.val))
      kernelWitness27Row49[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_49

theorem kernelBlock_27_50 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 50 * 256 + i.val))
      kernelWitness27Row50[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_50

theorem kernelBlock_27_51 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 51 * 256 + i.val))
      kernelWitness27Row51[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_51

theorem kernelBlock_27_52 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 52 * 256 + i.val))
      kernelWitness27Row52[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_52

theorem kernelBlock_27_53 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 53 * 256 + i.val))
      kernelWitness27Row53[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_53

theorem kernelBlock_27_54 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 54 * 256 + i.val))
      kernelWitness27Row54[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_54

theorem kernelBlock_27_55 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 55 * 256 + i.val))
      kernelWitness27Row55[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_55

theorem kernelBlock_27_56 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 56 * 256 + i.val))
      kernelWitness27Row56[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_56

theorem kernelBlock_27_57 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 57 * 256 + i.val))
      kernelWitness27Row57[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_57

theorem kernelBlock_27_58 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 58 * 256 + i.val))
      kernelWitness27Row58[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_58

theorem kernelBlock_27_59 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 59 * 256 + i.val))
      kernelWitness27Row59[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_59

theorem kernelBlock_27_60 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 60 * 256 + i.val))
      kernelWitness27Row60[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_60

theorem kernelBlock_27_61 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 61 * 256 + i.val))
      kernelWitness27Row61[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_61

theorem kernelBlock_27_62 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 62 * 256 + i.val))
      kernelWitness27Row62[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_62

theorem kernelBlock_27_63 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 63 * 256 + i.val))
      kernelWitness27Row63[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_63

end TightCycleC5.Bridge.Cover
