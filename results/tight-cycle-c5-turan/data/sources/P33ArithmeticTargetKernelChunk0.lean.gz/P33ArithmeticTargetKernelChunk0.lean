-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk0 :
    ∀ i : Fin (min 128 (40547 - 128 * 0)),
      targetCountsMatch (classAt (targetKernelClass ⟨0, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk0

theorem target_counts_kernel_chunk1 :
    ∀ i : Fin (min 128 (40547 - 128 * 1)),
      targetCountsMatch (classAt (targetKernelClass ⟨1, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk1

theorem target_counts_kernel_chunk2 :
    ∀ i : Fin (min 128 (40547 - 128 * 2)),
      targetCountsMatch (classAt (targetKernelClass ⟨2, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk2

theorem target_counts_kernel_chunk3 :
    ∀ i : Fin (min 128 (40547 - 128 * 3)),
      targetCountsMatch (classAt (targetKernelClass ⟨3, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk3


end TightCycleC5.Bridge.P33Arithmetic
