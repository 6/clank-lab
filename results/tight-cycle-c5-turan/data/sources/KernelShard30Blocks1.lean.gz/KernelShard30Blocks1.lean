import KernelRowIndex
import KernelWitness30

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_30_32 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 32 * 256 + i.val))
      kernelWitness30Row32[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_32

theorem kernelBlock_30_33 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 33 * 256 + i.val))
      kernelWitness30Row33[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_33

theorem kernelBlock_30_34 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 34 * 256 + i.val))
      kernelWitness30Row34[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_34

theorem kernelBlock_30_35 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 35 * 256 + i.val))
      kernelWitness30Row35[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_35

theorem kernelBlock_30_36 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 36 * 256 + i.val))
      kernelWitness30Row36[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_36

theorem kernelBlock_30_37 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 37 * 256 + i.val))
      kernelWitness30Row37[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_37

theorem kernelBlock_30_38 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 38 * 256 + i.val))
      kernelWitness30Row38[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_38

theorem kernelBlock_30_39 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 39 * 256 + i.val))
      kernelWitness30Row39[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_39

theorem kernelBlock_30_40 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 40 * 256 + i.val))
      kernelWitness30Row40[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_40

theorem kernelBlock_30_41 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 41 * 256 + i.val))
      kernelWitness30Row41[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_41

theorem kernelBlock_30_42 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 42 * 256 + i.val))
      kernelWitness30Row42[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_42

theorem kernelBlock_30_43 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 43 * 256 + i.val))
      kernelWitness30Row43[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_43

theorem kernelBlock_30_44 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 44 * 256 + i.val))
      kernelWitness30Row44[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_44

theorem kernelBlock_30_45 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 45 * 256 + i.val))
      kernelWitness30Row45[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_45

theorem kernelBlock_30_46 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 46 * 256 + i.val))
      kernelWitness30Row46[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_46

theorem kernelBlock_30_47 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 47 * 256 + i.val))
      kernelWitness30Row47[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_47

theorem kernelBlock_30_48 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 48 * 256 + i.val))
      kernelWitness30Row48[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_48

theorem kernelBlock_30_49 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 49 * 256 + i.val))
      kernelWitness30Row49[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_49

theorem kernelBlock_30_50 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 50 * 256 + i.val))
      kernelWitness30Row50[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_50

theorem kernelBlock_30_51 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 51 * 256 + i.val))
      kernelWitness30Row51[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_51

theorem kernelBlock_30_52 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 52 * 256 + i.val))
      kernelWitness30Row52[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_52

theorem kernelBlock_30_53 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 53 * 256 + i.val))
      kernelWitness30Row53[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_53

theorem kernelBlock_30_54 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 54 * 256 + i.val))
      kernelWitness30Row54[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_54

theorem kernelBlock_30_55 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 55 * 256 + i.val))
      kernelWitness30Row55[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_55

theorem kernelBlock_30_56 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 56 * 256 + i.val))
      kernelWitness30Row56[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_56

theorem kernelBlock_30_57 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 57 * 256 + i.val))
      kernelWitness30Row57[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_57

theorem kernelBlock_30_58 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 58 * 256 + i.val))
      kernelWitness30Row58[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_58

theorem kernelBlock_30_59 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 59 * 256 + i.val))
      kernelWitness30Row59[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_59

theorem kernelBlock_30_60 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 60 * 256 + i.val))
      kernelWitness30Row60[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_60

theorem kernelBlock_30_61 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 61 * 256 + i.val))
      kernelWitness30Row61[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_61

theorem kernelBlock_30_62 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 62 * 256 + i.val))
      kernelWitness30Row62[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_62

theorem kernelBlock_30_63 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 63 * 256 + i.val))
      kernelWitness30Row63[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_63

end TightCycleC5.Bridge.Cover
