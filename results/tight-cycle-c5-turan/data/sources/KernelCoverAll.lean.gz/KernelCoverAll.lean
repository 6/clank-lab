import KernelShard0
import KernelShard1
import KernelShard2
import KernelShard3
import KernelShard4
import KernelShard5
import KernelShard6
import KernelShard7
import KernelShard8
import KernelShard9
import KernelShard10
import KernelShard11
import KernelShard12
import KernelShard13
import KernelShard14
import KernelShard15
import KernelShard16
import KernelShard17
import KernelShard18
import KernelShard19
import KernelShard20
import KernelShard21
import KernelShard22
import KernelShard23
import KernelShard24
import KernelShard25
import KernelShard26
import KernelShard27
import KernelShard28
import KernelShard29
import KernelShard30
import KernelShard31

/-! Kernel-checked coverage of every twenty-bit labelled graph mask. -/
namespace TightCycleC5.Bridge.Cover
open MaskEncoding

def kernelShardRows (j : Fin 32) : Array (Array Nat) :=
  match j.val with
  | 0 => kernelWitness0
  | 1 => kernelWitness1
  | 2 => kernelWitness2
  | 3 => kernelWitness3
  | 4 => kernelWitness4
  | 5 => kernelWitness5
  | 6 => kernelWitness6
  | 7 => kernelWitness7
  | 8 => kernelWitness8
  | 9 => kernelWitness9
  | 10 => kernelWitness10
  | 11 => kernelWitness11
  | 12 => kernelWitness12
  | 13 => kernelWitness13
  | 14 => kernelWitness14
  | 15 => kernelWitness15
  | 16 => kernelWitness16
  | 17 => kernelWitness17
  | 18 => kernelWitness18
  | 19 => kernelWitness19
  | 20 => kernelWitness20
  | 21 => kernelWitness21
  | 22 => kernelWitness22
  | 23 => kernelWitness23
  | 24 => kernelWitness24
  | 25 => kernelWitness25
  | 26 => kernelWitness26
  | 27 => kernelWitness27
  | 28 => kernelWitness28
  | 29 => kernelWitness29
  | 30 => kernelWitness30
  | _ => kernelWitness31

theorem kernel_all_shards : ∀ j, kernelShardCheck j.val (kernelShardRows j) := by
  intro j
  fin_cases j
  · exact kernel_shard0
  · exact kernel_shard1
  · exact kernel_shard2
  · exact kernel_shard3
  · exact kernel_shard4
  · exact kernel_shard5
  · exact kernel_shard6
  · exact kernel_shard7
  · exact kernel_shard8
  · exact kernel_shard9
  · exact kernel_shard10
  · exact kernel_shard11
  · exact kernel_shard12
  · exact kernel_shard13
  · exact kernel_shard14
  · exact kernel_shard15
  · exact kernel_shard16
  · exact kernel_shard17
  · exact kernel_shard18
  · exact kernel_shard19
  · exact kernel_shard20
  · exact kernel_shard21
  · exact kernel_shard22
  · exact kernel_shard23
  · exact kernel_shard24
  · exact kernel_shard25
  · exact kernel_shard26
  · exact kernel_shard27
  · exact kernel_shard28
  · exact kernel_shard29
  · exact kernel_shard30
  · exact kernel_shard31

theorem p32_kernel_mask_cover (m : BitVec 20) (hC : ¬ CodeContainsC5 m) :
    ∃ k : Fin 835, ∃ p : Equiv.Perm (Fin 6),
      m = permuteMask p (representative k) := by
  have hm : m.toNat < 1048576 := m.toFin.isLt
  let j : Fin 32 := ⟨m.toNat / 32768, by omega⟩
  let i : Fin 32768 := ⟨m.toNat % 32768, Nat.mod_lt _ (by decide)⟩
  have h := kernel_all_shards j i
  have he : BitVec.ofNat 20 (j.val * 32768 + i.val) = m := by
    have hs : j.val * 32768 + i.val = m.toNat := by
      dsimp [j, i]
      omega
    rw [hs]
    simp
  have hs := kernel_witness_sound _ _ h
  rw [he] at hs
  exact hs.resolve_left hC


#print axioms kernel_all_shards
#print axioms p32_kernel_mask_cover
end TightCycleC5.Bridge.Cover
