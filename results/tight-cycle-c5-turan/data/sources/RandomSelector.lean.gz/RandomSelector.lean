import Mathlib
import Statement

/-!
                                                        

Put each vertex `v` in `V₁` independently with probability `π v`. The expected number of
edges avoiding the root's vertex set `R` with exactly two vertices in `V₁` is at most the
max cut. With `π v = π(pattern of v w.r.t. the root)`, averaging over roots of one type
gives G4's `μ ≥ φ(Y_π)/φ(τ)`; `π ∈ {0, 1}` is G2 (`Selector.lean`).
Definitions `cut`, `maxCut`, `sel` as in `Selector.lean` (repeated so that this file
checks on its own).
-/

open Finset

namespace TightCycleC5.HelperG.Random

variable {n : ℕ}

def cut (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) : ℕ :=
  (H.filter fun e => (e ∩ S).card = 2).card

def maxCut (H : Finset (Finset (Fin n))) : ℕ :=
  (Finset.univ : Finset (Finset (Fin n))).sup (cut H)

def sel (H : Finset (Finset (Fin n))) (R S : Finset (Fin n)) : ℕ :=
  (H.filter fun e => Disjoint e R ∧ (e ∩ S).card = 2).card

/-- The probability of the outcome `V₁ = S` when each `v` joins `V₁` with probability `π v`. -/
def wt (π : Fin n → ℝ) (S : Finset (Fin n)) : ℝ :=
  ∏ v, if v ∈ S then π v else 1 - π v

lemma wt_nonneg (π : Fin n → ℝ) (h0 : ∀ v, 0 ≤ π v) (h1 : ∀ v, π v ≤ 1) (S : Finset (Fin n)) :
    0 ≤ wt π S :=
  Finset.prod_nonneg fun v _ => by split_ifs <;> linarith [h0 v, h1 v]

lemma sum_wt (π : Fin n → ℝ) : ∑ S : Finset (Fin n), wt π S = 1 := by
  have h := Finset.prod_add (s := (Finset.univ : Finset (Fin n))) π (fun v => 1 - π v)
  simp only [add_sub_cancel, Finset.prod_const_one] at h
  rw [h, ← Finset.powerset_univ]
  refine Finset.sum_congr rfl fun S _ => ?_
  rw [wt, Finset.prod_ite, Finset.filter_mem_eq_inter, Finset.univ_inter]
  congr 1
  refine Finset.prod_congr ?_ fun _ _ => rfl
  ext v; simp

/-- **G4.** The expected selected cut of the random partition is at most the max cut. -/
theorem random_selector (H : Finset (Finset (Fin n))) (R : Finset (Fin n)) (π : Fin n → ℝ)
    (h0 : ∀ v, 0 ≤ π v) (h1 : ∀ v, π v ≤ 1) :
    ∑ S : Finset (Fin n), wt π S * (sel H R S : ℝ) ≤ (maxCut H : ℝ) := by
  have hle : ∀ S : Finset (Fin n), (sel H R S : ℝ) ≤ maxCut H := fun S => by
    have h1 : sel H R S ≤ cut H S :=
      Finset.card_le_card (Finset.monotone_filter_right _ fun _ _ h => h.2)
    have h2 : cut H S ≤ maxCut H := Finset.le_sup (f := cut H) (Finset.mem_univ S)
    exact_mod_cast h1.trans h2
  calc ∑ S : Finset (Fin n), wt π S * (sel H R S : ℝ)
      ≤ ∑ S : Finset (Fin n), wt π S * (maxCut H : ℝ) :=
        Finset.sum_le_sum fun S _ => mul_le_mul_of_nonneg_left (hle S) (wt_nonneg π h0 h1 S)
    _ = maxCut H := by rw [← Finset.sum_mul, sum_wt, one_mul]

end TightCycleC5.HelperG.Random

#print axioms TightCycleC5.HelperG.Random.random_selector
