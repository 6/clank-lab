import P33FlagData
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace TightCycleC5.Bridge.P33Flag
open ColouredFlags

theorem basis1_size : basis1Data.size = 40 := by decide +kernel
theorem basis1_psd_data : ∀ i, basis1 i = P33PSD.flags1[i.val]! := by decide +kernel
theorem basis1_steps : ∀ i : Fin 39,
    basis1 i.castSucc < basis1 i.succ := by decide +kernel
theorem basis1_injective : Function.Injective basis1 :=
  (Fin.strictMono_iff_lt_succ.mpr basis1_steps).injective
theorem basis1_range : ∀ i, basis1 i < 256 := by decide +kernel
theorem basis1_canonical : ∀ i, canonical4 (BitVec.ofNat 8 (basis1 i)) = basis1 i := by decide +kernel
theorem basis1_root : ∀ i, basis1 i % 4 = type1 := by decide +kernel
#print axioms basis1_size
#print axioms basis1_psd_data
#print axioms basis1_steps
#print axioms basis1_injective
#print axioms basis1_range
#print axioms basis1_canonical
#print axioms basis1_root

theorem basis7_size : basis7Data.size = 128 := by decide +kernel
theorem basis7_psd_data : ∀ i, basis7 i = P33PSD.flags7[i.val]! := by decide +kernel
theorem basis7_steps : ∀ i : Fin 127,
    basis7 i.castSucc < basis7 i.succ := by decide +kernel
theorem basis7_injective : Function.Injective basis7 :=
  (Fin.strictMono_iff_lt_succ.mpr basis7_steps).injective
theorem basis7_range : ∀ i, basis7 i < 32768 := by decide +kernel
theorem basis7_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis7 i))).toNat = type7 := by decide +kernel
#print axioms basis7_size
#print axioms basis7_psd_data
#print axioms basis7_steps
#print axioms basis7_injective
#print axioms basis7_range
#print axioms basis7_root

theorem basis13_size : basis13Data.size = 128 := by decide +kernel
theorem basis13_psd_data : ∀ i, basis13 i = P33PSD.flags13[i.val]! := by decide +kernel
theorem basis13_steps : ∀ i : Fin 127,
    basis13 i.castSucc < basis13 i.succ := by decide +kernel
theorem basis13_injective : Function.Injective basis13 :=
  (Fin.strictMono_iff_lt_succ.mpr basis13_steps).injective
theorem basis13_range : ∀ i, basis13 i < 32768 := by decide +kernel
theorem basis13_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis13 i))).toNat = type13 := by decide +kernel
#print axioms basis13_size
#print axioms basis13_psd_data
#print axioms basis13_steps
#print axioms basis13_injective
#print axioms basis13_range
#print axioms basis13_root

theorem basis19_size : basis19Data.size = 100 := by decide +kernel
theorem basis19_psd_data : ∀ i, basis19 i = P33PSD.flags19[i.val]! := by decide +kernel
theorem basis19_steps : ∀ i : Fin 99,
    basis19 i.castSucc < basis19 i.succ := by decide +kernel
theorem basis19_injective : Function.Injective basis19 :=
  (Fin.strictMono_iff_lt_succ.mpr basis19_steps).injective
theorem basis19_range : ∀ i, basis19 i < 32768 := by decide +kernel
theorem basis19_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis19 i))).toNat = type19 := by decide +kernel
#print axioms basis19_size
#print axioms basis19_psd_data
#print axioms basis19_steps
#print axioms basis19_injective
#print axioms basis19_range
#print axioms basis19_root

theorem basis25_size : basis25Data.size = 78 := by decide +kernel
theorem basis25_psd_data : ∀ i, basis25 i = P33PSD.flags25[i.val]! := by decide +kernel
theorem basis25_steps : ∀ i : Fin 77,
    basis25 i.castSucc < basis25 i.succ := by decide +kernel
theorem basis25_injective : Function.Injective basis25 :=
  (Fin.strictMono_iff_lt_succ.mpr basis25_steps).injective
theorem basis25_range : ∀ i, basis25 i < 32768 := by decide +kernel
theorem basis25_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis25 i))).toNat = type25 := by decide +kernel
#print axioms basis25_size
#print axioms basis25_psd_data
#print axioms basis25_steps
#print axioms basis25_injective
#print axioms basis25_range
#print axioms basis25_root

theorem basis31_size : basis31Data.size = 78 := by decide +kernel
theorem basis31_psd_data : ∀ i, basis31 i = P33PSD.flags31[i.val]! := by decide +kernel
theorem basis31_steps : ∀ i : Fin 77,
    basis31 i.castSucc < basis31 i.succ := by decide +kernel
theorem basis31_injective : Function.Injective basis31 :=
  (Fin.strictMono_iff_lt_succ.mpr basis31_steps).injective
theorem basis31_range : ∀ i, basis31 i < 32768 := by decide +kernel
theorem basis31_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis31 i))).toNat = type31 := by decide +kernel
#print axioms basis31_size
#print axioms basis31_psd_data
#print axioms basis31_steps
#print axioms basis31_injective
#print axioms basis31_range
#print axioms basis31_root

theorem basis37_size : basis37Data.size = 60 := by decide +kernel
theorem basis37_psd_data : ∀ i, basis37 i = P33PSD.flags37[i.val]! := by decide +kernel
theorem basis37_steps : ∀ i : Fin 59,
    basis37 i.castSucc < basis37 i.succ := by decide +kernel
theorem basis37_injective : Function.Injective basis37 :=
  (Fin.strictMono_iff_lt_succ.mpr basis37_steps).injective
theorem basis37_range : ∀ i, basis37 i < 32768 := by decide +kernel
theorem basis37_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis37 i))).toNat = type37 := by decide +kernel
#print axioms basis37_size
#print axioms basis37_psd_data
#print axioms basis37_steps
#print axioms basis37_injective
#print axioms basis37_range
#print axioms basis37_root

end TightCycleC5.Bridge.P33Flag
