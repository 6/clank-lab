-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk136 :
    ∀ i : Fin (min 128 (40547 - 128 * 136)),
      targetCountsMatch (classAt (targetKernelClass ⟨136, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk136

theorem target_counts_kernel_chunk137 :
    ∀ i : Fin (min 128 (40547 - 128 * 137)),
      targetCountsMatch (classAt (targetKernelClass ⟨137, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk137

theorem target_counts_kernel_chunk138 :
    ∀ i : Fin (min 128 (40547 - 128 * 138)),
      targetCountsMatch (classAt (targetKernelClass ⟨138, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk138

theorem target_counts_kernel_chunk139 :
    ∀ i : Fin (min 128 (40547 - 128 * 139)),
      targetCountsMatch (classAt (targetKernelClass ⟨139, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk139


end TightCycleC5.Bridge.P33Arithmetic
