import CertificateDescriptorsFinite
import CLCertificate

/-! Exact CL descriptor and multiplier indexing, independent of A/B arithmetic. -/
namespace TightCycleC5.Bridge.CertificateDescriptors
open Finset

/-- Bits 0 and 1 designate the two possible free colours. -/
def colorsFromCode (code : Nat) : Finset Bool :=
  univ.filter (fun b => code.testBit b.toNat)

theorem colors_one : colorsFromCode 1 = {false} := by decide +kernel
theorem colors_two : colorsFromCode 2 = {true} := by decide +kernel
theorem colors_three : colorsFromCode 3 = univ := by decide +kernel

def p32CL (i : Fin 1020) : CLCertificate.Descriptor :=
  ⟨decide (i.val / 510 = 1), decide ((i.val % 510) / 255 = 1),
    BitVec.ofNat 8 (i.val % 255 + 1), none, univ⟩

theorem p32_cl_index_bounds (i : Fin 1020) :
    i.val / 510 < 2 ∧ (i.val % 510) / 255 < 2 ∧
      1 ≤ i.val % 255 + 1 ∧ i.val % 255 + 1 ≤ 255 := by
  have := Nat.mod_lt i.val (by decide : 0 < 510)
  have := Nat.mod_lt i.val (by decide : 0 < 255)
  omega

theorem p32_cl_fields (i : Fin 1020) :
    (p32CL i).strong = decide (i.val / 510 = 1) ∧
    (p32CL i).rootEdge = decide ((i.val % 510) / 255 = 1) ∧
    (p32CL i).patternMask.toNat = i.val % 255 + 1 ∧
    (p32CL i).rootColors = none ∧ (p32CL i).freeColors = univ := by
  have h := (p32_cl_index_bounds i).2.2.2
  simp [p32CL, BitVec.toNat_ofNat]
  omega

/-- Interpret every signed raw predicate field without changing its meaning. -/
def clFromRecord (strong : Bool) (r : CLRecord) : CLCertificate.Descriptor :=
  ⟨strong, decide (r.tau = 1), BitVec.ofNat 8 r.mask,
    if r.rootColor < 0 then none else some (BitVec.ofNat 3 r.rootColor.toNat),
    colorsFromCode r.colors⟩

def p33CL (j : Fin 12750) : CLCertificate.Descriptor :=
  clFromRecord false (p33IndexRecord j)

/-- This identifies every actual descriptor with the frozen cl_predicates row. -/
theorem p33_cl_quotation (j : Fin 12750) :
    p33CL j = clFromRecord false (p33CLRecordAt j) := by
  rw [p33_records_exact j]
  rfl

theorem p33_cl_weak (j : Fin 12750) : (p33CL j).strong = false := rfl

def p32Numerator (i : Fin 9511) : Int := p32YData[i.val]!
def p33Numerator (variant : Bool) (i : Fin 12847) : Int :=
  if variant then p33bYData[i.val]! else p33aYData[i.val]!
def p33Scale (variant : Bool) : Int := if variant then p33bScale else p33aScale

theorem p32_numerator_nonneg (i : Fin 9511) : 0 ≤ p32Numerator i := p32_signed_checked.2 i

theorem p33_numerator_nonneg (variant : Bool) (i : Fin 12847) :
    0 ≤ p33Numerator variant i := by
  cases variant with
  | false => exact p33a_signed_checked.2 i
  | true => exact p33b_signed_checked.2 i

theorem p33_scale_pos (variant : Bool) : 0 < p33Scale variant := by
  cases variant with
  | false => exact p33_scales_positive.1
  | true => exact p33_scales_positive.2.1

noncomputable def p32Weight (i : Fin 9511) : ℝ :=
  (p32Numerator i : ℝ) / (p32WeightScale : ℝ)
noncomputable def p33Weight (variant : Bool) (i : Fin 12847) : ℝ :=
  (p33Numerator variant i : ℝ) / (p33Scale variant : ℝ)

theorem p32_weight_nonneg (i : Fin 9511) : 0 ≤ p32Weight i := by
  exact div_nonneg (by exact_mod_cast p32_numerator_nonneg i)
    (by exact_mod_cast p32_scales_positive.2.1.le)

theorem p33_weight_nonneg (variant : Bool) (i : Fin 12847) : 0 ≤ p33Weight variant i := by
  exact div_nonneg (by exact_mod_cast p33_numerator_nonneg variant i)
    (by exact_mod_cast (p33_scale_pos variant).le)

def p32CLSourceIndex (i : Fin 1020) : Fin 9511 := ⟨i.val, by omega⟩
def p33CLSourceIndex (j : Fin 12750) : Fin 12847 := ⟨97 + j.val, by omega⟩

theorem p32_cl_source_index (i : Fin 1020) : (p32CLSourceIndex i).val = i.val := rfl
theorem p33_cl_source_index (j : Fin 12750) : (p33CLSourceIndex j).val = 97 + j.val := rfl

noncomputable def p32CLWeight (i : Fin 1020) : ℝ := p32Weight (p32CLSourceIndex i)
noncomputable def p33CLWeight (variant : Bool) (j : Fin 12750) : ℝ :=
  p33Weight variant (p33CLSourceIndex j)
noncomputable def p32CLMass : ℝ := ∑ i : Fin 1020, p32CLWeight i
noncomputable def p33CLMass (variant : Bool) : ℝ := ∑ j : Fin 12750, p33CLWeight variant j

theorem p32_cl_weight_nonneg (i : Fin 1020) : 0 ≤ p32CLWeight i :=
  p32_weight_nonneg _
theorem p33_cl_weight_nonneg (variant : Bool) (j : Fin 12750) : 0 ≤ p33CLWeight variant j :=
  p33_weight_nonneg variant _

theorem p32_cl_mass_nonneg : 0 ≤ p32CLMass := Finset.sum_nonneg (fun i _ => p32_cl_weight_nonneg i)
theorem p33_cl_mass_nonneg (variant : Bool) : 0 ≤ p33CLMass variant :=
  Finset.sum_nonneg (fun j _ => p33_cl_weight_nonneg variant j)

/-- All 1020 actual P32 CL rows with their exact normalized multipliers. -/
theorem p32_cl_mean_lower {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (hn : 12 ≤ n) (S : Finset (Fin n)) :
    -p32CLMass / ((n : ℝ) - 5) ≤ uniformMean (fun σ : Fin 6 ↪ Fin n =>
      ∑ i : Fin 1020, p32CLWeight i * CLCertificate.row (p32CL i) (sampleStructure σ H S)) :=
  CLCertificate.weighted_row_mean_lower p32CL p32CLWeight p32_cl_weight_nonneg H hH hC hn S

/-- Both P33 variants: all 12750 weak CL rows, using source indices 97+j. -/
theorem p33_cl_mean_lower (variant : Bool) {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (hn : 12 ≤ n) (S : Finset (Fin n)) :
    -p33CLMass variant / ((n : ℝ) - 5) ≤ uniformMean (fun σ : Fin 6 ↪ Fin n =>
      ∑ j : Fin 12750, p33CLWeight variant j * CLCertificate.row (p33CL j) (sampleStructure σ H S)) :=
  CLCertificate.weighted_row_mean_lower p33CL (p33CLWeight variant)
    (p33_cl_weight_nonneg variant) H hH hC hn S

#print axioms colors_one
#print axioms colors_two
#print axioms colors_three
#print axioms p32_cl_index_bounds
#print axioms p32_cl_fields
#print axioms p33_cl_quotation
#print axioms p33_cl_weak
#print axioms p32_numerator_nonneg
#print axioms p33_numerator_nonneg
#print axioms p33_scale_pos
#print axioms p32_weight_nonneg
#print axioms p33_weight_nonneg
#print axioms p32_cl_source_index
#print axioms p33_cl_source_index
#print axioms p32_cl_weight_nonneg
#print axioms p33_cl_weight_nonneg
#print axioms p32_cl_mass_nonneg
#print axioms p33_cl_mass_nonneg
#print axioms p32_cl_mean_lower
#print axioms p33_cl_mean_lower
end TightCycleC5.Bridge.CertificateDescriptors
