import CertificateDescriptorsBook

namespace TightCycleC5.Bridge.P32RowMatching
open Finset

/-- Exactly the frozen root-major 16×529 restriction order. -/
def bookIndexEquiv : (Fin 16 × Fin 529) ≃ Fin 8464 where
  toFun p := CertificateDescriptors.bookFlatIndex p.1 p.2
  invFun i := (CertificateDescriptors.bookRoot i, CertificateDescriptors.bookRestriction i)
  left_inv p := by
    simp only [CertificateDescriptors.book_flat_root, CertificateDescriptors.book_flat_restriction]
  right_inv i := by
    apply Fin.ext
    simp only [CertificateDescriptors.bookFlatIndex, CertificateDescriptors.bookRoot,
      CertificateDescriptors.bookRestriction]
    omega

theorem sum_book_flat (f : Fin 8464 → ℝ) :
    (∑ k : Fin 16, ∑ r : Fin 529, f (CertificateDescriptors.bookFlatIndex k r)) =
      ∑ i : Fin 8464, f i := by
  have h := Equiv.sum_comp bookIndexEquiv f
  rw [Fintype.sum_prod_type] at h
  convert h using 1 <;> rfl

theorem sum_bool_true_false (f : Bool → ℝ) : (∑ b : Bool, f b) = f true + f false := by
  have hu : (univ : Finset Bool) = {true,false} := by decide +kernel
  rw [hu]
  simp

#print axioms sum_book_flat
#print axioms sum_bool_true_false
end TightCycleC5.Bridge.P32RowMatching
