import P32ArithmeticCore
namespace TightCycleC5.Bridge.P32Arithmetic
set_option maxHeartbeats 0
theorem class_group46 : ∀ j : Fin 16, ClassStatement
    ⟨736 + j.val, by have := j.isLt; omega⟩ := by native_decide
#print axioms class_group46
end TightCycleC5.Bridge.P32Arithmetic
