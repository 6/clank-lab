import P33ArithmeticFinite

/-! A deliberately partial, genuine all-family arithmetic timing unit.
No full-class or concrete semantic-transport theorem is claimed here. -/
namespace TightCycleC5.Bridge.P33Arithmetic
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem exact_scales_positive : 0 < sosScale ∧ (0 : Int) < 720000000000 := by decide +kernel

theorem sparse_inequalities_match : ∀ i : Fin 12847,
    sparseCoefficient inequalitySupport i = denseInequalities[i.val]! := by native_decide

theorem sparse_regularity_match : ∀ i : Fin 120,
    sparseCoefficient regularitySupport i = denseRegularity[i.val]! := by native_decide

theorem arithmetic_unit_exercises_all_families : unitExercisesAllFamilies = true := by
  native_decide

theorem p33_arithmetic_unit : unitCheck = true := by native_decide

/-- This corrupted class has a different frozen target. The same finite
class predicate rejects it; no trusted Python receipt is used. -/
theorem arithmetic_target_corruption_rejected :
    classCheck { classAt 20273 with quotedTarget := (classAt 20273).quotedTarget + 1 } = false := by
  native_decide

/-- Regularity multipliers remain signed; only inequality coefficients
are constrained to be nonnegative. -/
theorem negative_inequality_corruption_rejected :
    (denseInequalities.set! 0 (-1)).all (· ≥ 0) = false := by native_decide

#print axioms exact_scales_positive
#print axioms sparse_inequalities_match
#print axioms sparse_regularity_match
#print axioms arithmetic_unit_exercises_all_families
#print axioms p33_arithmetic_unit
#print axioms arithmetic_target_corruption_rejected
#print axioms negative_inequality_corruption_rejected
end TightCycleC5.Bridge.P33Arithmetic
