-- Generated from the pinned P33 manifest; untrusted proof quotation.
import P33PSDMatchingCore
import P33FlagData
import P33ArithmeticBlocks0
import P33ArithmeticBlocks1
import P33ArithmeticBlocks2
import P33ArithmeticBlocks3
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000
namespace TightCycleC5.Bridge.P33PSDMatching
open Finset Matrix

theorem source_metadata4 :
    P33Arithmetic.block4.flags = P33Flag.basis4Data ∧
    P33Arithmetic.block4.roots = 4 ∧
    P33Arithmetic.block4.typeCode = P33Flag.type4 := by decide +kernel
theorem source_terms4 : ∀ k : Fin 8, ∀ i j : Fin 128,
    P33Arithmetic.termEntry P33Arithmetic.block4.terms[k.val]! i.val j.val =
      (P33PSD.weights4 k : ℤ) * P33PSD.terms4 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry4 : ∀ i j : Fin 128,
    P33Arithmetic.blockEntry P33Arithmetic.block4 i.val j.val = P33PSD.q4 i j :=
  blockEntry_eq_sos P33Arithmetic.block4 P33PSD.weights4 P33PSD.terms4 rfl source_terms4
#print axioms source_metadata4
#print axioms source_terms4
#print axioms source_entry4

theorem source_metadata10 :
    P33Arithmetic.block10.flags = P33Flag.basis10Data ∧
    P33Arithmetic.block10.roots = 4 ∧
    P33Arithmetic.block10.typeCode = P33Flag.type10 := by decide +kernel
theorem source_terms10 : ∀ k : Fin 14, ∀ i j : Fin 128,
    P33Arithmetic.termEntry P33Arithmetic.block10.terms[k.val]! i.val j.val =
      (P33PSD.weights10 k : ℤ) * P33PSD.terms10 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry10 : ∀ i j : Fin 128,
    P33Arithmetic.blockEntry P33Arithmetic.block10 i.val j.val = P33PSD.q10 i j :=
  blockEntry_eq_sos P33Arithmetic.block10 P33PSD.weights10 P33PSD.terms10 rfl source_terms10
#print axioms source_metadata10
#print axioms source_terms10
#print axioms source_entry10

theorem source_metadata16 :
    P33Arithmetic.block16.flags = P33Flag.basis16Data ∧
    P33Arithmetic.block16.roots = 4 ∧
    P33Arithmetic.block16.typeCode = P33Flag.type16 := by decide +kernel
theorem source_terms16 : ∀ k : Fin 10, ∀ i j : Fin 100,
    P33Arithmetic.termEntry P33Arithmetic.block16.terms[k.val]! i.val j.val =
      (P33PSD.weights16 k : ℤ) * P33PSD.terms16 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry16 : ∀ i j : Fin 100,
    P33Arithmetic.blockEntry P33Arithmetic.block16 i.val j.val = P33PSD.q16 i j :=
  blockEntry_eq_sos P33Arithmetic.block16 P33PSD.weights16 P33PSD.terms16 rfl source_terms16
#print axioms source_metadata16
#print axioms source_terms16
#print axioms source_entry16

theorem source_metadata22 :
    P33Arithmetic.block22.flags = P33Flag.basis22Data ∧
    P33Arithmetic.block22.roots = 4 ∧
    P33Arithmetic.block22.typeCode = P33Flag.type22 := by decide +kernel
theorem source_terms22 : ∀ k : Fin 13, ∀ i j : Fin 100,
    P33Arithmetic.termEntry P33Arithmetic.block22.terms[k.val]! i.val j.val =
      (P33PSD.weights22 k : ℤ) * P33PSD.terms22 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry22 : ∀ i j : Fin 100,
    P33Arithmetic.blockEntry P33Arithmetic.block22 i.val j.val = P33PSD.q22 i j :=
  blockEntry_eq_sos P33Arithmetic.block22 P33PSD.weights22 P33PSD.terms22 rfl source_terms22
#print axioms source_metadata22
#print axioms source_terms22
#print axioms source_entry22

theorem source_metadata28 :
    P33Arithmetic.block28.flags = P33Flag.basis28Data ∧
    P33Arithmetic.block28.roots = 4 ∧
    P33Arithmetic.block28.typeCode = P33Flag.type28 := by decide +kernel
theorem source_terms28 : ∀ k : Fin 19, ∀ i j : Fin 78,
    P33Arithmetic.termEntry P33Arithmetic.block28.terms[k.val]! i.val j.val =
      (P33PSD.weights28 k : ℤ) * P33PSD.terms28 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry28 : ∀ i j : Fin 78,
    P33Arithmetic.blockEntry P33Arithmetic.block28 i.val j.val = P33PSD.q28 i j :=
  blockEntry_eq_sos P33Arithmetic.block28 P33PSD.weights28 P33PSD.terms28 rfl source_terms28
#print axioms source_metadata28
#print axioms source_terms28
#print axioms source_entry28

theorem source_metadata34 :
    P33Arithmetic.block34.flags = P33Flag.basis34Data ∧
    P33Arithmetic.block34.roots = 4 ∧
    P33Arithmetic.block34.typeCode = P33Flag.type34 := by decide +kernel
theorem source_terms34 : ∀ k : Fin 1, ∀ i j : Fin 60,
    P33Arithmetic.termEntry P33Arithmetic.block34.terms[k.val]! i.val j.val =
      (P33PSD.weights34 k : ℤ) * P33PSD.terms34 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry34 : ∀ i j : Fin 60,
    P33Arithmetic.blockEntry P33Arithmetic.block34 i.val j.val = P33PSD.q34 i j :=
  blockEntry_eq_sos P33Arithmetic.block34 P33PSD.weights34 P33PSD.terms34 rfl source_terms34
#print axioms source_metadata34
#print axioms source_terms34
#print axioms source_entry34

end TightCycleC5.Bridge.P33PSDMatching
