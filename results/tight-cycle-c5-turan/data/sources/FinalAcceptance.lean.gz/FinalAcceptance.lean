import P33ReplayEndpoint

/-! Acceptance probe only. No placeholder proof or assumed class checks.
The explicit declarations also prevent accidental extra endpoint arguments. -/
open Filter Topology

example : type_of% @TightCycleC5.mubayi_rodl :=
  @TightCycleC5.Bridge.mubayi_rodl_checked

example :
    Tendsto (fun n : ℕ => (TightCycleC5.ex n : ℝ) / (n.choose 3 : ℝ)) atTop
      (𝓝 (2 * Real.sqrt 3 - 3)) :=
  @TightCycleC5.Bridge.mubayi_rodl_checked

example : TightCycleC5.P32Statement :=
  @TightCycleC5.Bridge.P32ClassBridge.p32

example : TightCycleC5.P33Statement :=
  @TightCycleC5.Bridge.p33_checked

example : ∀ k : Fin 40547,
    TightCycleC5.Bridge.P33Arithmetic.classCheck
      (TightCycleC5.Bridge.P33Arithmetic.classAt k) = true :=
  @TightCycleC5.Bridge.P33Arithmetic.p33_arithmetic_replay

example : TightCycleC5.P32Statement =
    (∀ ε > (0 : ℝ), ∃ N : ℕ, ∀ n ≥ N, ∀ H : Finset (Finset (Fin n)),
      TightCycleC5.IsThreeGraph H → ¬ TightCycleC5.ContainsC5 H →
      (H.card : ℝ) ≥ 4641 / 10000 * (n.choose 3 : ℝ) →
      (TightCycleC5.maxCut H : ℝ) ≥ (2 / 5 - ε) * (n.choose 3 : ℝ)) := rfl

example : TightCycleC5.P33Statement =
    (∀ ξ > (0 : ℝ), ∃ δ > (0 : ℝ), ∃ N : ℕ, ∀ n ≥ N,
      ∀ (H : Finset (Finset (Fin n))) (S : Finset (Fin n)),
      TightCycleC5.IsThreeGraph H → ¬ TightCycleC5.ContainsC5 H →
      TightCycleC5.LocallyMaximal H S →
      (∀ u v, (TightCycleC5.deg H u : ℝ) ≤
        TightCycleC5.deg H v + δ * (n : ℝ) ^ 2) →
      (TightCycleC5.cutCount H S : ℝ) ≥ (2 / 5 - δ) * (n.choose 3 : ℝ) →
      (H.card : ℝ) ≥ (464101615 / 10 ^ 9 - δ) * (n.choose 3 : ℝ) →
      (TightCycleC5.badCount H S : ℝ) - TightCycleC5.missCount H S ≤
        ξ * (n : ℝ) ^ 3) := rfl

#print axioms TightCycleC5.Bridge.P32ClassBridge.p32
#print axioms TightCycleC5.Bridge.p33_checked
#print axioms TightCycleC5.Bridge.P33Arithmetic.p33_arithmetic_replay
#print axioms TightCycleC5.Bridge.mubayi_rodl_checked
