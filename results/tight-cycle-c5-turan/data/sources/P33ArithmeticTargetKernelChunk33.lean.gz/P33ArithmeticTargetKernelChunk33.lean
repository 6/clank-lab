-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk132 :
    ∀ i : Fin (min 128 (40547 - 128 * 132)),
      targetCountsMatch (classAt (targetKernelClass ⟨132, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk132

theorem target_counts_kernel_chunk133 :
    ∀ i : Fin (min 128 (40547 - 128 * 133)),
      targetCountsMatch (classAt (targetKernelClass ⟨133, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk133

theorem target_counts_kernel_chunk134 :
    ∀ i : Fin (min 128 (40547 - 128 * 134)),
      targetCountsMatch (classAt (targetKernelClass ⟨134, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk134

theorem target_counts_kernel_chunk135 :
    ∀ i : Fin (min 128 (40547 - 128 * 135)),
      targetCountsMatch (classAt (targetKernelClass ⟨135, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk135


end TightCycleC5.Bridge.P33Arithmetic
