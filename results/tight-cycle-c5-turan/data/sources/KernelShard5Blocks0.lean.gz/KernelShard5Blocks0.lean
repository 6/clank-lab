import KernelRowIndex
import KernelWitness5

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_5_0 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 0 * 256 + i.val))
      kernelWitness5Row0[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_0

theorem kernelBlock_5_1 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 1 * 256 + i.val))
      kernelWitness5Row1[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_1

theorem kernelBlock_5_2 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 2 * 256 + i.val))
      kernelWitness5Row2[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_2

theorem kernelBlock_5_3 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 3 * 256 + i.val))
      kernelWitness5Row3[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_3

theorem kernelBlock_5_4 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 4 * 256 + i.val))
      kernelWitness5Row4[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_4

theorem kernelBlock_5_5 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 5 * 256 + i.val))
      kernelWitness5Row5[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_5

theorem kernelBlock_5_6 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 6 * 256 + i.val))
      kernelWitness5Row6[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_6

theorem kernelBlock_5_7 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 7 * 256 + i.val))
      kernelWitness5Row7[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_7

theorem kernelBlock_5_8 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 8 * 256 + i.val))
      kernelWitness5Row8[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_8

theorem kernelBlock_5_9 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 9 * 256 + i.val))
      kernelWitness5Row9[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_9

theorem kernelBlock_5_10 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 10 * 256 + i.val))
      kernelWitness5Row10[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_10

theorem kernelBlock_5_11 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 11 * 256 + i.val))
      kernelWitness5Row11[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_11

theorem kernelBlock_5_12 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 12 * 256 + i.val))
      kernelWitness5Row12[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_12

theorem kernelBlock_5_13 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 13 * 256 + i.val))
      kernelWitness5Row13[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_13

theorem kernelBlock_5_14 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 14 * 256 + i.val))
      kernelWitness5Row14[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_14

theorem kernelBlock_5_15 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 15 * 256 + i.val))
      kernelWitness5Row15[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_15

theorem kernelBlock_5_16 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 16 * 256 + i.val))
      kernelWitness5Row16[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_16

theorem kernelBlock_5_17 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 17 * 256 + i.val))
      kernelWitness5Row17[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_17

theorem kernelBlock_5_18 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 18 * 256 + i.val))
      kernelWitness5Row18[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_18

theorem kernelBlock_5_19 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 19 * 256 + i.val))
      kernelWitness5Row19[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_19

theorem kernelBlock_5_20 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 20 * 256 + i.val))
      kernelWitness5Row20[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_20

theorem kernelBlock_5_21 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 21 * 256 + i.val))
      kernelWitness5Row21[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_21

theorem kernelBlock_5_22 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 22 * 256 + i.val))
      kernelWitness5Row22[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_22

theorem kernelBlock_5_23 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 23 * 256 + i.val))
      kernelWitness5Row23[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_23

theorem kernelBlock_5_24 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 24 * 256 + i.val))
      kernelWitness5Row24[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_24

theorem kernelBlock_5_25 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 25 * 256 + i.val))
      kernelWitness5Row25[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_25

theorem kernelBlock_5_26 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 26 * 256 + i.val))
      kernelWitness5Row26[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_26

theorem kernelBlock_5_27 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 27 * 256 + i.val))
      kernelWitness5Row27[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_27

theorem kernelBlock_5_28 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 28 * 256 + i.val))
      kernelWitness5Row28[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_28

theorem kernelBlock_5_29 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 29 * 256 + i.val))
      kernelWitness5Row29[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_29

theorem kernelBlock_5_30 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 30 * 256 + i.val))
      kernelWitness5Row30[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_30

theorem kernelBlock_5_31 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 31 * 256 + i.val))
      kernelWitness5Row31[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_31

end TightCycleC5.Bridge.Cover
