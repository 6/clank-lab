import P33ArithmeticRelabel
import P33ArithmeticData
import InducedTargets

/-! Match the integer target with literal bad/missing counts of the actual
finite graph and cut. The target has coefficient one, with no SOS scale. -/
namespace TightCycleC5.Bridge.P33Arithmetic
open Finset
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def classGraph (K : Class) : Finset (Finset (Fin 6)) :=
  MaskEncoding.decodeGraph (BitVec.ofNat 20 K.mask)

def classCut (K : Class) : Finset (Fin 6) :=
  univ.filter fun v => (decodedClass K).color v = false

noncomputable def countedTarget (K : Class) : ℝ :=
  ((badCount (classGraph K) (classCut K) : ℝ) -
    (missCount (classGraph K) (classCut K) : ℝ)) / 20

theorem classGraph_three (K : Class) : IsThreeGraph (classGraph K) :=
  MaskEncoding.decodeGraph_three _

/-- The chosen cut consists exactly of colour-zero vertices. -/
theorem classCut_mem (K : Class) (v : Fin 6) :
    v ∈ classCut K ↔ (decodedClass K).color v = false := by
  simp only [classCut, mem_filter, mem_univ, true_and]

/-- Actual graph and cut recover the original labelled structure. -/
theorem sample_classGraph_cut (K : Class) :
    sampleStructure (Function.Embedding.refl (Fin 6)) (classGraph K) (classCut K) =
      decodedClass K := by
  apply LabelledStructure.ext
  · funext e
    change decide (e.map (Function.Embedding.refl (Fin 6)) ∈ classGraph K) =
      (decodedClass K).edge e
    simp only [Finset.map_refl]
    have h := MaskEncoding.decodeGraph_edge (BitVec.ofNat 20 K.mask)
      (BitVec.ofNat 6 K.colours) e
    change (e ∈ classGraph K ↔ (decodedClass K).edge e = true) at h
    cases he : (decodedClass K).edge e <;> simp_all
  · funext v
    change decide (v ∉ classCut K) = (decodedClass K).color v
    cases hc : (decodedClass K).color v <;> simp [classCut_mem,hc]

/-- Recover actual edges and the cut directly from a labelled structure. -/
def structureGraph (G : LabelledStructure 6) : Finset (Finset (Fin 6)) :=
  univ.filter fun e => G.edge e = true

def structureCut (G : LabelledStructure 6) : Finset (Fin 6) :=
  univ.filter fun v => G.color v = false

noncomputable def literalTarget (G : LabelledStructure 6) : ℝ :=
  ((badCount (structureGraph G) (structureCut G) : ℝ) -
    (missCount (structureGraph G) (structureCut G) : ℝ)) / 20

theorem structureGraph_decoded (K : Class) :
    structureGraph (decodedClass K) = classGraph K := by
  ext e
  simp only [structureGraph, mem_filter, mem_univ, true_and]
  exact (MaskEncoding.decodeGraph_edge (BitVec.ofNat 20 K.mask)
    (BitVec.ofNat 6 K.colours) e).symm

theorem literalTarget_decoded (K : Class) :
    literalTarget (decodedClass K) = countedTarget K := by
  simp only [literalTarget, structureGraph_decoded, structureCut,
    countedTarget, classCut]

theorem structureGraph_sample {n : Nat} (σ : Fin 6 ↪ Fin n)
    (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    structureGraph (sampleStructure σ H S) = inducedGraph σ H := by
  ext e
  simp [structureGraph, sampleStructure, inducedGraph]

theorem structureCut_sample {n : Nat} (σ : Fin 6 ↪ Fin n)
    (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    structureCut (sampleStructure σ H S) = inducedCut σ S := by
  ext v
  simp [structureCut, sampleStructure, inducedCut]

theorem literalTarget_sample {n : Nat} (σ : Fin 6 ↪ Fin n)
    (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    literalTarget (sampleStructure σ H S) =
      ((badCount (inducedGraph σ H) (inducedCut σ S) : ℝ) -
        (missCount (inducedGraph σ H) (inducedCut σ S) : ℝ)) / 20 := by
  simp only [literalTarget, structureGraph_sample, structureCut_sample]

/-- The literal row has exactly the original finite bad/missing target mean. -/
theorem literalTarget_normalization {n : Nat}
    (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H) (S : Finset (Fin n))
    (hn : 6 ≤ n) :
    uniformMean (fun σ : Fin 6 ↪ Fin n => literalTarget (sampleStructure σ H S)) =
      ((badCount H S : ℝ) - (missCount H S : ℝ)) / (n.choose 3 : ℝ) := by
  simpa only [literalTarget_sample, one_mul] using
    p33_induced_target_normalization H hH S 1 hn

#print axioms classGraph_three
#print axioms classCut_mem
#print axioms sample_classGraph_cut
#print axioms structureGraph_decoded
#print axioms literalTarget_decoded
#print axioms structureGraph_sample
#print axioms structureCut_sample
#print axioms literalTarget_sample
#print axioms literalTarget_normalization
end TightCycleC5.Bridge.P33Arithmetic
