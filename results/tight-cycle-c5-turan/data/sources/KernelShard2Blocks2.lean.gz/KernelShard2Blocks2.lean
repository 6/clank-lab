import KernelRowIndex
import KernelWitness2

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_2_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 64 * 256 + i.val))
      kernelWitness2Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_64

theorem kernelBlock_2_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 65 * 256 + i.val))
      kernelWitness2Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_65

theorem kernelBlock_2_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 66 * 256 + i.val))
      kernelWitness2Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_66

theorem kernelBlock_2_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 67 * 256 + i.val))
      kernelWitness2Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_67

theorem kernelBlock_2_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 68 * 256 + i.val))
      kernelWitness2Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_68

theorem kernelBlock_2_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 69 * 256 + i.val))
      kernelWitness2Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_69

theorem kernelBlock_2_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 70 * 256 + i.val))
      kernelWitness2Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_70

theorem kernelBlock_2_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 71 * 256 + i.val))
      kernelWitness2Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_71

theorem kernelBlock_2_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 72 * 256 + i.val))
      kernelWitness2Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_72

theorem kernelBlock_2_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 73 * 256 + i.val))
      kernelWitness2Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_73

theorem kernelBlock_2_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 74 * 256 + i.val))
      kernelWitness2Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_74

theorem kernelBlock_2_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 75 * 256 + i.val))
      kernelWitness2Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_75

theorem kernelBlock_2_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 76 * 256 + i.val))
      kernelWitness2Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_76

theorem kernelBlock_2_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 77 * 256 + i.val))
      kernelWitness2Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_77

theorem kernelBlock_2_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 78 * 256 + i.val))
      kernelWitness2Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_78

theorem kernelBlock_2_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 79 * 256 + i.val))
      kernelWitness2Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_79

theorem kernelBlock_2_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 80 * 256 + i.val))
      kernelWitness2Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_80

theorem kernelBlock_2_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 81 * 256 + i.val))
      kernelWitness2Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_81

theorem kernelBlock_2_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 82 * 256 + i.val))
      kernelWitness2Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_82

theorem kernelBlock_2_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 83 * 256 + i.val))
      kernelWitness2Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_83

theorem kernelBlock_2_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 84 * 256 + i.val))
      kernelWitness2Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_84

theorem kernelBlock_2_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 85 * 256 + i.val))
      kernelWitness2Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_85

theorem kernelBlock_2_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 86 * 256 + i.val))
      kernelWitness2Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_86

theorem kernelBlock_2_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 87 * 256 + i.val))
      kernelWitness2Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_87

theorem kernelBlock_2_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 88 * 256 + i.val))
      kernelWitness2Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_88

theorem kernelBlock_2_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 89 * 256 + i.val))
      kernelWitness2Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_89

theorem kernelBlock_2_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 90 * 256 + i.val))
      kernelWitness2Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_90

theorem kernelBlock_2_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 91 * 256 + i.val))
      kernelWitness2Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_91

theorem kernelBlock_2_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 92 * 256 + i.val))
      kernelWitness2Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_92

theorem kernelBlock_2_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 93 * 256 + i.val))
      kernelWitness2Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_93

theorem kernelBlock_2_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 94 * 256 + i.val))
      kernelWitness2Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_94

theorem kernelBlock_2_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 95 * 256 + i.val))
      kernelWitness2Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_95

end TightCycleC5.Bridge.Cover
