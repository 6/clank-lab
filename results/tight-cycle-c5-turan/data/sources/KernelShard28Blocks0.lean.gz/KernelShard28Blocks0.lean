import KernelRowIndex
import KernelWitness28

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_28_0 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 0 * 256 + i.val))
      kernelWitness28Row0[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_0

theorem kernelBlock_28_1 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 1 * 256 + i.val))
      kernelWitness28Row1[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_1

theorem kernelBlock_28_2 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 2 * 256 + i.val))
      kernelWitness28Row2[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_2

theorem kernelBlock_28_3 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 3 * 256 + i.val))
      kernelWitness28Row3[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_3

theorem kernelBlock_28_4 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 4 * 256 + i.val))
      kernelWitness28Row4[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_4

theorem kernelBlock_28_5 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 5 * 256 + i.val))
      kernelWitness28Row5[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_5

theorem kernelBlock_28_6 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 6 * 256 + i.val))
      kernelWitness28Row6[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_6

theorem kernelBlock_28_7 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 7 * 256 + i.val))
      kernelWitness28Row7[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_7

theorem kernelBlock_28_8 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 8 * 256 + i.val))
      kernelWitness28Row8[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_8

theorem kernelBlock_28_9 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 9 * 256 + i.val))
      kernelWitness28Row9[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_9

theorem kernelBlock_28_10 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 10 * 256 + i.val))
      kernelWitness28Row10[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_10

theorem kernelBlock_28_11 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 11 * 256 + i.val))
      kernelWitness28Row11[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_11

theorem kernelBlock_28_12 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 12 * 256 + i.val))
      kernelWitness28Row12[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_12

theorem kernelBlock_28_13 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 13 * 256 + i.val))
      kernelWitness28Row13[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_13

theorem kernelBlock_28_14 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 14 * 256 + i.val))
      kernelWitness28Row14[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_14

theorem kernelBlock_28_15 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 15 * 256 + i.val))
      kernelWitness28Row15[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_15

theorem kernelBlock_28_16 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 16 * 256 + i.val))
      kernelWitness28Row16[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_16

theorem kernelBlock_28_17 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 17 * 256 + i.val))
      kernelWitness28Row17[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_17

theorem kernelBlock_28_18 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 18 * 256 + i.val))
      kernelWitness28Row18[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_18

theorem kernelBlock_28_19 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 19 * 256 + i.val))
      kernelWitness28Row19[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_19

theorem kernelBlock_28_20 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 20 * 256 + i.val))
      kernelWitness28Row20[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_20

theorem kernelBlock_28_21 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 21 * 256 + i.val))
      kernelWitness28Row21[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_21

theorem kernelBlock_28_22 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 22 * 256 + i.val))
      kernelWitness28Row22[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_22

theorem kernelBlock_28_23 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 23 * 256 + i.val))
      kernelWitness28Row23[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_23

theorem kernelBlock_28_24 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 24 * 256 + i.val))
      kernelWitness28Row24[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_24

theorem kernelBlock_28_25 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 25 * 256 + i.val))
      kernelWitness28Row25[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_25

theorem kernelBlock_28_26 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 26 * 256 + i.val))
      kernelWitness28Row26[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_26

theorem kernelBlock_28_27 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 27 * 256 + i.val))
      kernelWitness28Row27[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_27

theorem kernelBlock_28_28 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 28 * 256 + i.val))
      kernelWitness28Row28[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_28

theorem kernelBlock_28_29 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 29 * 256 + i.val))
      kernelWitness28Row29[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_29

theorem kernelBlock_28_30 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 30 * 256 + i.val))
      kernelWitness28Row30[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_30

theorem kernelBlock_28_31 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 31 * 256 + i.val))
      kernelWitness28Row31[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_31

end TightCycleC5.Bridge.Cover
