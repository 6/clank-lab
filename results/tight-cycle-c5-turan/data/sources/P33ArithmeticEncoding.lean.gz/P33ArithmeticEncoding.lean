import P33ArithmeticCore
import PermutationEnumeration

/-! The arithmetic's literal bits and orders refer to the genuine accepted
six-vertex mask encoding and kernel permutations, with no table hypothesis. -/
namespace TightCycleC5.Bridge.P33Arithmetic
open Finset

/-- The evaluator's order is definitionally the actual checked permutation. -/
theorem order_eq_kernelPermutation (j : Fin 720) :
    order j = Cover.kernelPermutation j := rfl

/-- Every computed order therefore has six distinct vertices. -/
theorem order_injective (j : Fin 720) : Function.Injective (order j) := by
  rw [order_eq_kernelPermutation]
  exact (Cover.kernelPermutation j).injective

/-- Small structural arithmetic uses the kernel rather than native trust. -/
theorem tripleIndex_fin_lt : ∀ a b c : Fin 6, a ≠ b → a ≠ c → b ≠ c →
    tripleIndex a.val b.val c.val < 20 := by decide +kernel

/-- The original integer bit index has exactly the accepted lexicographic
triple meaning, on all distinct labels. -/
theorem tripleIndex_eq_maskIndex (a b c : Fin 6) (hab : a ≠ b) (hac : a ≠ c)
    (hbc : b ≠ c) :
    tripleIndex a.val b.val c.val = MaskEncoding.tripleIndex {a,b,c} :=
  MaskEncoding.family_tripleIndex_eq a b c hab hac hbc

/-- No range assumption on the integer mask is needed for this equality:
only its first twenty bits are queried by a distinct triple. -/
theorem edge_eq_decoded (mask colours : Nat) (a b c : Fin 6)
    (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c) :
    edge mask a.val b.val c.val =
      ((MaskEncoding.decodeStructure (BitVec.ofNat 20 mask)
        (BitVec.ofNat 6 colours)).edge {a,b,c}).toNat := by
  have hcard : ({a,b,c} : Finset (Fin 6)).card = 3 := by simp [hab,hac,hbc]
  have hi := tripleIndex_fin_lt a b c hab hac hbc
  simp only [MaskEncoding.decodeStructure, hcard, ↓reduceIte]
  rw [← tripleIndex_eq_maskIndex a b c hab hac hbc]
  rw [BitVec.getLsbD_ofNat]
  simp only [hi, decide_true, Bool.true_and]
  cases hbit : mask.testBit (tripleIndex a.val b.val c.val) <;>
    simp [edge, hbit]

/-- Colour 1 is literally the complement colour used by MaskEncoding. -/
theorem colour_eq_decoded (mask colours : Nat) (v : Fin 6) :
    colour colours v.val =
      ((MaskEncoding.decodeStructure (BitVec.ofNat 20 mask)
        (BitVec.ofNat 6 colours)).color v).toNat := by
  change colour colours v.val = ((BitVec.ofNat 6 colours).getLsbD v.val).toNat
  rw [BitVec.getLsbD_ofNat]
  simp only [v.isLt, decide_true, Bool.true_and]
  cases hbit : colours.testBit v.val <;> simp [colour, hbit]

#print axioms order_eq_kernelPermutation
#print axioms order_injective
#print axioms tripleIndex_fin_lt
#print axioms tripleIndex_eq_maskIndex
#print axioms edge_eq_decoded
#print axioms colour_eq_decoded
end TightCycleC5.Bridge.P33Arithmetic
