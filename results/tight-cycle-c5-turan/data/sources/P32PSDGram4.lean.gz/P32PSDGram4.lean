import P32PSDGram4Rows0
import P32PSDGram4Rows1
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace TightCycleC5.Bridge.P32PSD.Kernel
theorem gram4 : q4 = u4 * u4.transpose := by
  ext i j
  fin_cases i
  · exact gram4_row0 j
  · exact gram4_row1 j
  · exact gram4_row2 j
  · exact gram4_row3 j
  · exact gram4_row4 j
  · exact gram4_row5 j
  · exact gram4_row6 j
  · exact gram4_row7 j
  · exact gram4_row8 j
  · exact gram4_row9 j
  · exact gram4_row10 j
  · exact gram4_row11 j
  · exact gram4_row12 j
  · exact gram4_row13 j
  · exact gram4_row14 j
  · exact gram4_row15 j
  · exact gram4_row16 j
  · exact gram4_row17 j
  · exact gram4_row18 j
  · exact gram4_row19 j
  · exact gram4_row20 j
  · exact gram4_row21 j
  · exact gram4_row22 j
  · exact gram4_row23 j
  · exact gram4_row24 j
  · exact gram4_row25 j
  · exact gram4_row26 j
  · exact gram4_row27 j
  · exact gram4_row28 j
  · exact gram4_row29 j
theorem diagonal4 : ∀ i, q4 i i ≤ m4 := by decide +kernel
#print axioms gram4
#print axioms diagonal4
end TightCycleC5.Bridge.P32PSD.Kernel
