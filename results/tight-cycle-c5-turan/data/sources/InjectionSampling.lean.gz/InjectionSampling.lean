import ClassSampling

/-! Splitting a uniform injective sample into roots and free vertices. -/

namespace TightCycleC5.Bridge

open Finset

/-- Vertices outside the range of an injective root assignment. -/
abbrev Outside {R V : Type*} (r : R ↪ V) := {v : V // v ∉ Set.range r}

noncomputable instance {R V : Type*} [Fintype V] (r : R ↪ V) : Fintype (Outside r) :=
  Fintype.ofFinite _

/-- The free vertex space has exactly |V|-|R| vertices. -/
theorem outside_card {R V : Type*} [Fintype R] [Fintype V] (r : R ↪ V) :
    Fintype.card (Outside r) = Fintype.card V - Fintype.card R := by
  classical
  rw [Fintype.card_subtype_compl, Fintype.card_range]

/-- Exact decomposition of an injection into ordered roots and an
injection of the remaining labels into the complement of those roots. -/
def splitEmbeddingEquiv {R F V : Type*} :
    ((R ⊕ F) ↪ V) ≃ (Σ r : R ↪ V, F ↪ Outside r) where
  toFun σ :=
    let r : R ↪ V := (Function.Embedding.inl : R ↪ R ⊕ F).trans σ
    ⟨r, ⟨fun b => ⟨σ (Sum.inr b), by
      rintro ⟨a, ha⟩
      have h := σ.injective ha
      change (Sum.inl a : R ⊕ F) = Sum.inr b at h
      cases h⟩,
      fun b c h => Sum.inr_injective (σ.injective (congrArg Subtype.val h))⟩⟩
  invFun rf := ⟨Sum.elim rf.1 (fun b => (rf.2 b).val), by
    intro a b h
    rcases a with a | a <;> rcases b with b | b
    · exact congrArg Sum.inl (rf.1.injective h)
    · exact False.elim ((rf.2 b).property ⟨a, h⟩)
    · exact False.elim ((rf.2 a).property ⟨b, h.symm⟩)
    · exact congrArg Sum.inr (rf.2.injective (Subtype.ext h))⟩
  left_inv σ := by
    ext a
    cases a <;> rfl
  right_inv rf := by
    rcases rf with ⟨r, f⟩
    rfl

/-- Uniform sampling can be split over constant-size fibres. The size
condition is explicit, so no conditional weighting is lost. -/
theorem uniformMean_sigma {R : Type*} {F : R → Type*}
    [Fintype R] [∀ r, Fintype (F r)] (m : ℕ)
    (hm : ∀ r, Fintype.card (F r) = m) (f : (Σ r, F r) → ℝ) :
    uniformMean f = uniformMean (fun r => uniformMean (fun a : F r => f ⟨r, a⟩)) := by
  simp only [uniformMean, Fintype.sum_sigma, Fintype.card_sigma]
  simp_rw [hm]
  simp only [Finset.sum_const, nsmul_eq_mul, Nat.cast_mul]
  rw [← Finset.sum_div, div_div, mul_comm]
  simp

/-- The exact rooted-injection averaging identity. Its fibre size is
constant by the embedding-cardinality formula; it needs no asymptotics. -/
theorem uniformMean_splitEmbedding {R F V : Type*}
    [Fintype R] [Fintype F] [Fintype V]
    (f : ((R ⊕ F) ↪ V) → ℝ) :
    uniformMean f = uniformMean (fun r : R ↪ V =>
      uniformMean (fun a : F ↪ Outside r => f (splitEmbeddingEquiv.symm ⟨r, a⟩))) := by
  classical
  have he : uniformMean f = uniformMean (fun z => f (splitEmbeddingEquiv.symm z)) := by
    unfold uniformMean
    rw [Fintype.card_congr splitEmbeddingEquiv]
    congr 1
    exact (Equiv.sum_comp splitEmbeddingEquiv.symm f).symm
  rw [he]
  apply uniformMean_sigma ((Fintype.card V - Fintype.card R).descFactorial (Fintype.card F))
  intro r
  rw [Fintype.card_embedding_eq, outside_card]

/-- Combine a root injection and an injection into its complement, with
the roots occupying the first labels. -/
def joinSample {r f n : ℕ} (root : Fin r ↪ Fin n) (free : Fin f ↪ Outside root) :
    Fin (r + f) ↪ Fin n :=
  Equiv.embeddingCongr finSumFinEquiv (Equiv.refl _)
    (splitEmbeddingEquiv.symm ⟨root, free⟩)

@[simp] theorem joinSample_root {r f n : ℕ} (root : Fin r ↪ Fin n)
    (free : Fin f ↪ Outside root) (i : Fin r) :
    joinSample root free (Fin.castAdd f i) = root i := by
  simp [joinSample, Equiv.embeddingCongr, Function.Embedding.congr,
    finSumFinEquiv_symm_apply_castAdd, splitEmbeddingEquiv]

@[simp] theorem joinSample_free {r f n : ℕ} (root : Fin r ↪ Fin n)
    (free : Fin f ↪ Outside root) (i : Fin f) :
    joinSample root free (Fin.natAdd r i) = (free i).val := by
  simp [joinSample, Equiv.embeddingCongr, Function.Embedding.congr,
    finSumFinEquiv_symm_apply_natAdd, splitEmbeddingEquiv]

/-- Uniform injections of r+f labels split into uniform roots and
uniform free injections, with no unproved sampling-independence premise. -/
theorem uniformMean_joinSample {r f n : ℕ} (v : (Fin (r + f) ↪ Fin n) → ℝ) :
    uniformMean v = uniformMean (fun root : Fin r ↪ Fin n =>
      uniformMean (fun free : Fin f ↪ Outside root => v (joinSample root free))) := by
  classical
  let e : ((Fin r ⊕ Fin f) ↪ Fin n) ≃ (Fin (r + f) ↪ Fin n) :=
    Equiv.embeddingCongr finSumFinEquiv (Equiv.refl _)
  rw [← uniformMean_equiv_between e v, uniformMean_splitEmbedding]
  rfl

#print axioms outside_card
#print axioms uniformMean_sigma
#print axioms uniformMean_splitEmbedding
#print axioms joinSample_root
#print axioms joinSample_free
#print axioms uniformMean_joinSample

end TightCycleC5.Bridge
