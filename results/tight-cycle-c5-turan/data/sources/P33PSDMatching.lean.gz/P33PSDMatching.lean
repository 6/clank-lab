import P33PSDMatchingRows0
import P33PSDMatchingRows1
import P33PSDMatchingRows2
import P33PSDMatchingRows3
import P33PSDMatchingRows4
import P33PSDMatchingRows5
import P33ArithmeticData
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000
namespace TightCycleC5.Bridge.P33PSDMatching
open Finset

noncomputable def literalRow (b : Fin 38) (G : LabelledStructure 6) : ℝ :=
  match b.val with
  | 0 => P33Flag.row0 G
  | 1 => P33Flag.row1 G
  | 2 => P33Flag.row2 G
  | 3 => P33Flag.row3 G
  | 4 => P33Flag.row4 G
  | 5 => P33Flag.row5 G
  | 6 => P33Flag.row6 G
  | 7 => P33Flag.row7 G
  | 8 => P33Flag.row8 G
  | 9 => P33Flag.row9 G
  | 10 => P33Flag.row10 G
  | 11 => P33Flag.row11 G
  | 12 => P33Flag.row12 G
  | 13 => P33Flag.row13 G
  | 14 => P33Flag.row14 G
  | 15 => P33Flag.row15 G
  | 16 => P33Flag.row16 G
  | 17 => P33Flag.row17 G
  | 18 => P33Flag.row18 G
  | 19 => P33Flag.row19 G
  | 20 => P33Flag.row20 G
  | 21 => P33Flag.row21 G
  | 22 => P33Flag.row22 G
  | 23 => P33Flag.row23 G
  | 24 => P33Flag.row24 G
  | 25 => P33Flag.row25 G
  | 26 => P33Flag.row26 G
  | 27 => P33Flag.row27 G
  | 28 => P33Flag.row28 G
  | 29 => P33Flag.row29 G
  | 30 => P33Flag.row30 G
  | 31 => P33Flag.row31 G
  | 32 => P33Flag.row32 G
  | 33 => P33Flag.row33 G
  | 34 => P33Flag.row34 G
  | 35 => P33Flag.row35 G
  | 36 => P33Flag.row36 G
  | 37 => P33Flag.row37 G
  | _ => 0

noncomputable def totalRows (G : LabelledStructure 6) : ℝ := ∑ b : Fin 38, literalRow b G

theorem source_scale : P33Arithmetic.sosScale = (P33PSD.scale : ℤ) := rfl

theorem source_scale_real : (P33Arithmetic.sosScale : ℝ) = (P33PSD.scale : ℝ) := by
  rw [source_scale, Int.cast_natCast]

theorem source_row (b : Fin 38) (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.blocks[b.val]! K p) :
    (sourceContribution P33Arithmetic.blocks[b.val]! K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      literalRow b (p.symm • decoded K.mask K.colours) := by
  fin_cases b
  · exact source_row0 K p hv
  · exact source_row1 K p hv
  · exact source_row2 K p hv
  · exact source_row3 K p hv
  · exact source_row4 K p hv
  · exact source_row5 K p hv
  · exact source_row6 K p hv
  · exact source_row7 K p hv
  · exact source_row8 K p hv
  · exact source_row9 K p hv
  · exact source_row10 K p hv
  · exact source_row11 K p hv
  · exact source_row12 K p hv
  · exact source_row13 K p hv
  · exact source_row14 K p hv
  · exact source_row15 K p hv
  · exact source_row16 K p hv
  · exact source_row17 K p hv
  · exact source_row18 K p hv
  · exact source_row19 K p hv
  · exact source_row20 K p hv
  · exact source_row21 K p hv
  · exact source_row22 K p hv
  · exact source_row23 K p hv
  · exact source_row24 K p hv
  · exact source_row25 K p hv
  · exact source_row26 K p hv
  · exact source_row27 K p hv
  · exact source_row28 K p hv
  · exact source_row29 K p hv
  · exact source_row30 K p hv
  · exact source_row31 K p hv
  · exact source_row32 K p hv
  · exact source_row33 K p hv
  · exact source_row34 K p hv
  · exact source_row35 K p hv
  · exact source_row36 K p hv
  · exact source_row37 K p hv

/-- Correct pointwise orientation: the arithmetic evaluator reads forward p,
while the established structure action reads labels through p.symm. -/
theorem psdAt_eq_totalRows (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ∀ b : Fin 38, ValidLookups P33Arithmetic.blocks[b.val]! K p) :
    (P33Arithmetic.psdAt P33Arithmetic.blocks K p : ℝ) /
      (1000000000 * (P33Arithmetic.sosScale : ℝ)) =
      totalRows (p.symm • decoded K.mask K.colours) := by
  rw [psdAt_eq_sum, Int.cast_sum, Finset.sum_div, source_scale_real]
  exact Finset.sum_congr rfl (fun b _ => source_row b K p (hv b))

theorem psdAt_symm_eq_totalRows (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ∀ b : Fin 38, ValidLookups P33Arithmetic.blocks[b.val]! K p.symm) :
    (P33Arithmetic.psdAt P33Arithmetic.blocks K p.symm : ℝ) /
      (1000000000 * (P33Arithmetic.sosScale : ℝ)) =
      totalRows (p • decoded K.mask K.colours) := by
  simpa only [Equiv.symm_symm] using psdAt_eq_totalRows K p.symm hv

theorem psdOrder_eq_totalRows (K : P33Arithmetic.Class) (j : Fin 720)
    (hv : ∀ b : Fin 38, ValidLookups P33Arithmetic.blocks[b.val]! K (P33Arithmetic.order j)) :
    (P33Arithmetic.psdOrder P33Arithmetic.blocks K j : ℝ) /
      (1000000000 * (P33Arithmetic.sosScale : ℝ)) =
      totalRows ((Cover.kernelPermutation j).symm • decoded K.mask K.colours) :=
  psdAt_eq_totalRows K (Cover.kernelPermutation j) hv

/-- The indexed sum is exactly the ascending row sum used by the finite-error assembly. -/
theorem totalRows_eq_explicit (G : LabelledStructure 6) :
    totalRows G = P33Flag.row0 G +
    P33Flag.row1 G +
    P33Flag.row2 G +
    P33Flag.row3 G +
    P33Flag.row4 G +
    P33Flag.row5 G +
    P33Flag.row6 G +
    P33Flag.row7 G +
    P33Flag.row8 G +
    P33Flag.row9 G +
    P33Flag.row10 G +
    P33Flag.row11 G +
    P33Flag.row12 G +
    P33Flag.row13 G +
    P33Flag.row14 G +
    P33Flag.row15 G +
    P33Flag.row16 G +
    P33Flag.row17 G +
    P33Flag.row18 G +
    P33Flag.row19 G +
    P33Flag.row20 G +
    P33Flag.row21 G +
    P33Flag.row22 G +
    P33Flag.row23 G +
    P33Flag.row24 G +
    P33Flag.row25 G +
    P33Flag.row26 G +
    P33Flag.row27 G +
    P33Flag.row28 G +
    P33Flag.row29 G +
    P33Flag.row30 G +
    P33Flag.row31 G +
    P33Flag.row32 G +
    P33Flag.row33 G +
    P33Flag.row34 G +
    P33Flag.row35 G +
    P33Flag.row36 G +
    P33Flag.row37 G := by
  simp [totalRows, Fin.sum_univ_succ, literalRow, add_assoc]

#print axioms totalRows_eq_explicit
#print axioms source_scale
#print axioms source_scale_real
#print axioms source_row
#print axioms psdAt_eq_totalRows
#print axioms psdAt_symm_eq_totalRows
#print axioms psdOrder_eq_totalRows
end TightCycleC5.Bridge.P33PSDMatching
