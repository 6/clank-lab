import P33RowMatchingFeatures

namespace TightCycleC5.Bridge.P33RowMatching

/-- Last-match semantics of the actual three-step regularity loop. -/
theorem features_degreeIndex (ls : Array (Array Nat)) (gs : Array Nat)
    (bs : Array P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Fin 6 → Fin 6) :
    (P33Arithmetic.featuresAt ls gs bs K p).degreeIndex =
      let typ := colourAt K p 0 + 2*colourAt K p 1
      let key := P33Arithmetic.canonical K.mask K.colours [(p 0).val,(p 1).val] [(p 4).val,(p 5).val]
      if typ = bs[2]!.typeCode then 80 + P33Arithmetic.lookup bs[2]!.flags key
      else if typ = bs[1]!.typeCode then 40 + P33Arithmetic.lookup bs[1]!.flags key
      else if typ = bs[0]!.typeCode then P33Arithmetic.lookup bs[0]!.flags key
      else 120 := by
  simp [P33Arithmetic.featuresAt, colourAt, List.range']
  <;> split_ifs <;> rfl

#print axioms features_degreeIndex
end TightCycleC5.Bridge.P33RowMatching
