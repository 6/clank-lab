import KernelRowIndex
import KernelWitness28

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_28_96 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 96 * 256 + i.val))
      kernelWitness28Row96[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_96

theorem kernelBlock_28_97 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 97 * 256 + i.val))
      kernelWitness28Row97[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_97

theorem kernelBlock_28_98 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 98 * 256 + i.val))
      kernelWitness28Row98[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_98

theorem kernelBlock_28_99 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 99 * 256 + i.val))
      kernelWitness28Row99[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_99

theorem kernelBlock_28_100 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 100 * 256 + i.val))
      kernelWitness28Row100[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_100

theorem kernelBlock_28_101 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 101 * 256 + i.val))
      kernelWitness28Row101[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_101

theorem kernelBlock_28_102 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 102 * 256 + i.val))
      kernelWitness28Row102[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_102

theorem kernelBlock_28_103 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 103 * 256 + i.val))
      kernelWitness28Row103[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_103

theorem kernelBlock_28_104 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 104 * 256 + i.val))
      kernelWitness28Row104[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_104

theorem kernelBlock_28_105 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 105 * 256 + i.val))
      kernelWitness28Row105[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_105

theorem kernelBlock_28_106 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 106 * 256 + i.val))
      kernelWitness28Row106[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_106

theorem kernelBlock_28_107 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 107 * 256 + i.val))
      kernelWitness28Row107[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_107

theorem kernelBlock_28_108 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 108 * 256 + i.val))
      kernelWitness28Row108[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_108

theorem kernelBlock_28_109 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 109 * 256 + i.val))
      kernelWitness28Row109[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_109

theorem kernelBlock_28_110 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 110 * 256 + i.val))
      kernelWitness28Row110[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_110

theorem kernelBlock_28_111 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 111 * 256 + i.val))
      kernelWitness28Row111[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_111

theorem kernelBlock_28_112 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 112 * 256 + i.val))
      kernelWitness28Row112[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_112

theorem kernelBlock_28_113 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 113 * 256 + i.val))
      kernelWitness28Row113[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_113

theorem kernelBlock_28_114 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 114 * 256 + i.val))
      kernelWitness28Row114[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_114

theorem kernelBlock_28_115 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 115 * 256 + i.val))
      kernelWitness28Row115[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_115

theorem kernelBlock_28_116 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 116 * 256 + i.val))
      kernelWitness28Row116[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_116

theorem kernelBlock_28_117 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 117 * 256 + i.val))
      kernelWitness28Row117[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_117

theorem kernelBlock_28_118 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 118 * 256 + i.val))
      kernelWitness28Row118[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_118

theorem kernelBlock_28_119 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 119 * 256 + i.val))
      kernelWitness28Row119[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_119

theorem kernelBlock_28_120 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 120 * 256 + i.val))
      kernelWitness28Row120[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_120

theorem kernelBlock_28_121 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 121 * 256 + i.val))
      kernelWitness28Row121[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_121

theorem kernelBlock_28_122 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 122 * 256 + i.val))
      kernelWitness28Row122[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_122

theorem kernelBlock_28_123 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 123 * 256 + i.val))
      kernelWitness28Row123[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_123

theorem kernelBlock_28_124 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 124 * 256 + i.val))
      kernelWitness28Row124[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_124

theorem kernelBlock_28_125 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 125 * 256 + i.val))
      kernelWitness28Row125[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_125

theorem kernelBlock_28_126 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 126 * 256 + i.val))
      kernelWitness28Row126[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_126

theorem kernelBlock_28_127 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 127 * 256 + i.val))
      kernelWitness28Row127[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_127

end TightCycleC5.Bridge.Cover
