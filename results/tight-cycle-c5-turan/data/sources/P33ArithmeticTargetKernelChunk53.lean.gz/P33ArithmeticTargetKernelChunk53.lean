-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk212 :
    ∀ i : Fin (min 128 (40547 - 128 * 212)),
      targetCountsMatch (classAt (targetKernelClass ⟨212, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk212

theorem target_counts_kernel_chunk213 :
    ∀ i : Fin (min 128 (40547 - 128 * 213)),
      targetCountsMatch (classAt (targetKernelClass ⟨213, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk213

theorem target_counts_kernel_chunk214 :
    ∀ i : Fin (min 128 (40547 - 128 * 214)),
      targetCountsMatch (classAt (targetKernelClass ⟨214, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk214

theorem target_counts_kernel_chunk215 :
    ∀ i : Fin (min 128 (40547 - 128 * 215)),
      targetCountsMatch (classAt (targetKernelClass ⟨215, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk215


end TightCycleC5.Bridge.P33Arithmetic
