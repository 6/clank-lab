import KernelRowIndex
import KernelWitness13

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_13_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 64 * 256 + i.val))
      kernelWitness13Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_64

theorem kernelBlock_13_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 65 * 256 + i.val))
      kernelWitness13Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_65

theorem kernelBlock_13_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 66 * 256 + i.val))
      kernelWitness13Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_66

theorem kernelBlock_13_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 67 * 256 + i.val))
      kernelWitness13Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_67

theorem kernelBlock_13_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 68 * 256 + i.val))
      kernelWitness13Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_68

theorem kernelBlock_13_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 69 * 256 + i.val))
      kernelWitness13Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_69

theorem kernelBlock_13_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 70 * 256 + i.val))
      kernelWitness13Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_70

theorem kernelBlock_13_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 71 * 256 + i.val))
      kernelWitness13Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_71

theorem kernelBlock_13_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 72 * 256 + i.val))
      kernelWitness13Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_72

theorem kernelBlock_13_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 73 * 256 + i.val))
      kernelWitness13Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_73

theorem kernelBlock_13_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 74 * 256 + i.val))
      kernelWitness13Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_74

theorem kernelBlock_13_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 75 * 256 + i.val))
      kernelWitness13Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_75

theorem kernelBlock_13_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 76 * 256 + i.val))
      kernelWitness13Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_76

theorem kernelBlock_13_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 77 * 256 + i.val))
      kernelWitness13Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_77

theorem kernelBlock_13_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 78 * 256 + i.val))
      kernelWitness13Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_78

theorem kernelBlock_13_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 79 * 256 + i.val))
      kernelWitness13Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_79

theorem kernelBlock_13_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 80 * 256 + i.val))
      kernelWitness13Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_80

theorem kernelBlock_13_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 81 * 256 + i.val))
      kernelWitness13Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_81

theorem kernelBlock_13_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 82 * 256 + i.val))
      kernelWitness13Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_82

theorem kernelBlock_13_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 83 * 256 + i.val))
      kernelWitness13Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_83

theorem kernelBlock_13_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 84 * 256 + i.val))
      kernelWitness13Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_84

theorem kernelBlock_13_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 85 * 256 + i.val))
      kernelWitness13Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_85

theorem kernelBlock_13_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 86 * 256 + i.val))
      kernelWitness13Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_86

theorem kernelBlock_13_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 87 * 256 + i.val))
      kernelWitness13Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_87

theorem kernelBlock_13_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 88 * 256 + i.val))
      kernelWitness13Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_88

theorem kernelBlock_13_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 89 * 256 + i.val))
      kernelWitness13Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_89

theorem kernelBlock_13_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 90 * 256 + i.val))
      kernelWitness13Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_90

theorem kernelBlock_13_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 91 * 256 + i.val))
      kernelWitness13Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_91

theorem kernelBlock_13_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 92 * 256 + i.val))
      kernelWitness13Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_92

theorem kernelBlock_13_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 93 * 256 + i.val))
      kernelWitness13Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_93

theorem kernelBlock_13_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 94 * 256 + i.val))
      kernelWitness13Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_94

theorem kernelBlock_13_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (13 * 32768 + 95 * 256 + i.val))
      kernelWitness13Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_13_95

end TightCycleC5.Bridge.Cover
