import P33RowMatchingFeatures
import CertificateDescriptorsCL
import P33ArithmeticData

namespace TightCycleC5.Bridge.P33RowMatching
open Finset
set_option maxHeartbeats 2000000

/-- Flat-index interpretation used literally by clPass, before source transport. -/
def literalCL (j : Fin 12750) : CLCertificate.Descriptor :=
  let z := if j.val < 510 then j.val else j.val-510
  ⟨false, decide ((if j.val < 510 then j.val/255 else z/6120) = 1),
    BitVec.ofNat 8 (z%255+1),
    if j.val < 510 then none else some (BitVec.ofNat 3 ((z/765)%8)),
    if j.val < 510 then univ else CertificateDescriptors.colorsFromCode ((z/255)%3+1)⟩

theorem source_cl_descriptor (j : Fin 12750) : CertificateDescriptors.p33CL j = literalCL j := by
  by_cases hi : j.val < 510
  · simp [CertificateDescriptors.p33CL, CertificateDescriptors.clFromRecord,
      CertificateDescriptors.p33IndexRecord, CertificateDescriptors.p33RawRecord, literalCL,
      hi, CertificateDescriptors.colors_three]
  · have h3 : (j.val-510)/255/3 = (j.val-510)/765 := by omega
    have h24 : (j.val-510)/255/24 = (j.val-510)/6120 := by omega
    unfold CertificateDescriptors.p33CL CertificateDescriptors.p33IndexRecord
      CertificateDescriptors.p33RawRecord
    rw [if_neg hi]
    dsimp only [CertificateDescriptors.clFromRecord]
    simp only [Int.natCast_nonneg, not_false_eq_true, if_false, Int.toNat_natCast]
    simp only [literalCL, hi, ↓reduceIte, h3, h24]
    rw [if_neg (Int.not_lt.mpr (Int.natCast_nonneg _))]

theorem colorsFromCode_mem (code : Nat) (b : Bool) :
    b ∈ CertificateDescriptors.colorsFromCode code ↔ code.testBit b.toNat = true := by
  simp [CertificateDescriptors.colorsFromCode]

theorem root_edge_eq (tau : Nat) (ht : tau < 2) (e : Bool) :
    (tau == e.toNat) = true ↔ e = decide (tau = 1) := by
  interval_cases tau <;> cases e <;> decide

theorem root_edge_nat (tau : Nat) (ht : tau < 2) (e : Bool) :
    tau = e.toNat ↔ e = decide (tau = 1) := by
  simpa only [beq_iff_eq] using root_edge_eq tau ht e

theorem pattern_bit (code : Nat) (e : Fin 6 → Fin 6 → Fin 6 → Bool) (z : Fin 6) :
    (BitVec.ofNat 8 code).getLsbD (CLCertificate.pattern e 0 1 2 z) =
      code.testBit (CLCertificate.pattern e 0 1 2 z) := by
  rw [BitVec.getLsbD_ofNat]
  simp only [CLCertificate.pattern_lt, decide_true, Bool.true_and]

theorem pattern_at (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (z : Fin 6) (h0 : (0 : Fin 6) ≠ z) (h1 : (1 : Fin 6) ≠ z) (h2 : (2 : Fin 6) ≠ z) :
    4*edgeAt K p 0 1 z + 2*edgeAt K p 0 2 z + edgeAt K p 1 2 z =
      CLCertificate.pattern (fun x u v => (structureAt K p).edge {x,u,v}) 0 1 2 z := by
  simp only [edgeAt, edge_at K p 0 1 z (by decide) h0 h1,
    edge_at K p 0 2 z (by decide) h0 h2, edge_at K p 1 2 z (by decide) h1 h2,
    CLCertificate.pattern]

def clPredicate (d : CLCertificate.Descriptor) (G : LabelledStructure 6) : Prop :=
  CLCertificate.rootPass d (fun x u v => G.edge {x,u,v}) G.color 0 1 2 ∧
  CLCertificate.freePass d (fun x u v => G.edge {x,u,v}) G.color 0 1 2 3 ∧
  CLCertificate.freePass d (fun x u v => G.edge {x,u,v}) G.color 0 1 2 4 ∧
  CLCertificate.freePass d (fun x u v => G.edge {x,u,v}) G.color 0 1 2 5
instance (d : CLCertificate.Descriptor) (G : LabelledStructure 6) : Decidable (clPredicate d G) := by
  unfold clPredicate; infer_instance

theorem clPass_iff (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) (j : Fin 12750) :
    P33Arithmetic.clPass (P33Arithmetic.featuresAt P33Arithmetic.localFlags P33Arithmetic.globalFlags
      P33Arithmetic.blocks K p) j.val = true ↔
    clPredicate (CertificateDescriptors.p33CL j) (structureAt K p) := by
  rw [source_cl_descriptor]
  have hp3 := pattern_at K p 3 (by decide) (by decide) (by decide)
  have hp4 := pattern_at K p 4 (by decide) (by decide) (by decide)
  have hp5 := pattern_at K p 5 (by decide) (by decide) (by decide)
  have ht : (if j.val < 510 then j.val/255 else (j.val-510)/6120) < 2 := by
    split_ifs <;> omega
  simp only [P33Arithmetic.clPass, features_tau, features_rootColour,
    features_patterns, features_freeColours]
  simp only [edgeAt, edge_at K p 0 1 2 (by decide) (by decide) (by decide), colourAt, colour_at]
  rw [hp3, hp4, hp5]
  by_cases hi : j.val < 510
  · simp [hi, clPredicate, literalCL, CLCertificate.rootPass, CLCertificate.rootColorPass,
      CLCertificate.freePass, pattern_bit, root_edge_nat _ (by simpa [hi] using ht)]
  · simp [hi, clPredicate, literalCL, CLCertificate.rootPass, CLCertificate.rootColorPass,
      CLCertificate.freePass, pattern_bit,
      colorsFromCode_mem, CLCertificate.rootColorCode, BitVec.toNat_ofNat, root_edge_nat _ (by simpa [hi] using ht), and_assoc, and_left_comm, and_comm]
    tauto

/-- The weak CL polynomial is exactly cherry minus tetrahedron on all tuples. -/
theorem clValue_real (ls : Array (Array Nat)) (gs : Array Nat)
    (bs : Array P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) :
    ((P33Arithmetic.featuresAt ls gs bs K p).clValue : ℝ) =
      (if CLCertificate.cherry false (fun x u v => (structureAt K p).edge {x,u,v}) 0 3 4 5 then 1 else 0) -
      (if CLCertificate.tetrahedron (fun x u v => (structureAt K p).edge {x,u,v}) 0 3 4 5 then 1 else 0) := by
  rw [features_clValue]
  simp only [edgeAt, edge_at K p 0 3 4 (by decide) (by decide) (by decide),
    edge_at K p 0 3 5 (by decide) (by decide) (by decide),
    edge_at K p 0 4 5 (by decide) (by decide) (by decide),
    edge_at K p 3 4 5 (by decide) (by decide) (by decide)]
  cases hab : (structureAt K p).edge {0,3,4} <;>
    cases had : (structureAt K p).edge {0,3,5} <;>
    cases hbd : (structureAt K p).edge {0,4,5} <;>
    cases he : (structureAt K p).edge {3,4,5} <;>
    norm_num [CLCertificate.cherry, CLCertificate.tetrahedron, hab, had, hbd, he]

theorem cl_row_as_ite (d : CLCertificate.Descriptor) (G : LabelledStructure 6) :
    CLCertificate.row d G = if clPredicate d G then
      ((if CLCertificate.cherry d.strong (fun x u v => G.edge {x,u,v}) 0 3 4 5 then 1 else 0) -
        (if CLCertificate.tetrahedron (fun x u v => G.edge {x,u,v}) 0 3 4 5 then 1 else 0)) else 0 := by
  by_cases hr : CLCertificate.rootPass d (fun x u v => G.edge {x,u,v}) G.color 0 1 2 <;>
    by_cases h3 : CLCertificate.freePass d (fun x u v => G.edge {x,u,v}) G.color 0 1 2 3 <;>
    by_cases h4 : CLCertificate.freePass d (fun x u v => G.edge {x,u,v}) G.color 0 1 2 4 <;>
    by_cases h5 : CLCertificate.freePass d (fun x u v => G.edge {x,u,v}) G.color 0 1 2 5 <;>
    simp [CLCertificate.row, CLCertificate.evaluate, clPredicate, hr, h3, h4, h5]

theorem cl_row_match (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) (j : Fin 12750) :
    (P33Arithmetic.inequalityRow (P33Arithmetic.featuresAt P33Arithmetic.localFlags
      P33Arithmetic.globalFlags P33Arithmetic.blocks K p) (97+j.val) : ℝ) / 1000000000 =
      CLCertificate.row (CertificateDescriptors.p33CL j) (structureAt K p) := by
  rw [P33Arithmetic.inequalityRow, if_neg (by omega), if_neg (by omega), if_neg (by omega)]
  rw [show 97+j.val-97=j.val by omega, cl_row_as_ite, CertificateDescriptors.p33_cl_weak]
  have hc := clPass_iff K p j
  by_cases hp : P33Arithmetic.clPass (P33Arithmetic.featuresAt P33Arithmetic.localFlags
      P33Arithmetic.globalFlags P33Arithmetic.blocks K p) j.val = true
  · simp only [hp, ↓reduceIte, if_pos (hc.mp hp)]
    push_cast
    rw [clValue_real]
    ring
  · have hn : ¬clPredicate (CertificateDescriptors.p33CL j) (structureAt K p) := fun h => hp (hc.mpr h)
    simp [hp, hn]

#print axioms source_cl_descriptor
#print axioms colorsFromCode_mem
#print axioms root_edge_eq
#print axioms root_edge_nat
#print axioms pattern_bit
#print axioms pattern_at
#print axioms clPass_iff
#print axioms clValue_real
#print axioms cl_row_as_ite
#print axioms cl_row_match
end TightCycleC5.Bridge.P33RowMatching
