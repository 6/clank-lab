import Mathlib
import Statement

/-!
                                                         

For a `C₅³`-free 3-graph `H`, vertices `x`, `a` and weights `w ≥ 0`:

  `∑ c d, w c w d [xacd is a K₄³] ≤ ∑ c d, w c w d [xac, xad ∈ H] [xcd ∉ H] [acd ∉ H]`.

Inside the book of the pair `xa`, the pairs completing a `K₄³` weigh at most the pairs
missing both triples with `x` and with `a`. `book_abstract` is the graph lemma (a symmetric
relation `F` whose two-step neighbours `c, d` satisfy `R c d`); `pair_book` instantiates it.
The `C₅³` lemmas `distinct_of_mem`, `mem_perm`, `link_cancellative`, `link_cancellative_acd`
                                                                                                
-/

open Finset

namespace TightCycleC5.HelperG

open TightCycleC5

section Abstract

variable {V : Type*} [Fintype V]

/-- If `F` is symmetric, `F b c → G c`, and `F b c → F b d → R c d`, then the weighted edge
count of `F` is at most the weighted count of pairs `(c, d)` with `G c` and `R c d`. -/
theorem book_abstract (w : V → ℝ) (hw : ∀ v, 0 ≤ w v)
    (F : V → V → Prop) [DecidableRel F] (G : V → Prop) [DecidablePred G]
    (R : V → V → Prop) [DecidableRel R]
    (hF : ∀ b c, F b c → F c b) (hG : ∀ b c, F b c → G c)
    (hR : ∀ b c d, F b c → F b d → R c d) :
    ∑ b, ∑ c, (if F b c then w b * w c else 0) ≤
      ∑ c, ∑ d, (if G c ∧ R c d then w c * w d else 0) := by
  classical
  set f : V → V → ℝ := fun b c => if F b c then w b * w c else 0 with hf
  set s : V → ℝ := fun c => ∑ b, if F b c then w b else 0 with hs
  set μ : V → ℝ := fun c => ∑ d, if R c d then w d else 0 with hμ
  have hf0 : ∀ b c, 0 ≤ f b c := fun b c => by
    simp only [hf]; split_ifs
    · exact mul_nonneg (hw b) (hw c)
    · exact le_rfl
  have hs0 : ∀ c, 0 ≤ s c := fun c =>
    Finset.sum_nonneg fun b _ => by split_ifs <;> simp [hw b]
  have hμ0 : ∀ c, 0 ≤ μ c := fun c =>
    Finset.sum_nonneg fun d _ => by split_ifs <;> simp [hw d]
  have hs_ge : ∀ b c, F b c → w b ≤ s c := fun b c h => by
    simp only [hs]
    have := Finset.single_le_sum (f := fun d => if F d c then w d else 0)
      (fun d _ => by split_ifs <;> simp [hw d]) (Finset.mem_univ b)
    simpa [h] using this
  have hfsymm : ∀ b c, f b c = f c b := fun b c => by
    simp only [hf]
    by_cases h : F b c
    · simp [h, hF b c h, mul_comm]
    · have h' : ¬ F c b := fun h' => h (hF c b h')
      simp [h, h']
  -- s b ≤ μ c whenever F b c: every F-neighbour d of b has R c d
  have hs_le : ∀ b c, F b c → s b ≤ μ c := fun b c h => by
    simp only [hs, hμ]
    refine Finset.sum_le_sum fun d _ => ?_
    by_cases hd : F d b
    · simp [hd, hR b c d h (hF d b hd)]
    · simp only [hd, if_false]; split_ifs <;> simp [hw d]
  -- AM–GM: f ≤ (f s_b/s_c + f s_c/s_b)/2
  have hpt : ∀ b c, f b c ≤ (f b c * (s b / s c) + f b c * (s c / s b)) / 2 := fun b c => by
    by_cases hK : F b c
    · by_cases hz : w b * w c = 0
      · simp [hf, hK, hz]
      · have hwb : 0 < w b := lt_of_le_of_ne (hw b) (by intro h; apply hz; simp [← h])
        have hwc : 0 < w c := lt_of_le_of_ne (hw c) (by intro h; apply hz; simp [← h])
        have hsc : 0 < s c := lt_of_lt_of_le hwb (hs_ge b c hK)
        have hsb : 0 < s b := lt_of_lt_of_le hwc (hs_ge c b (hF _ _ hK))
        have h2 : 2 ≤ s b / s c + s c / s b := by
          rw [div_add_div _ _ hsc.ne' hsb.ne', le_div_iff₀ (by positivity)]
          nlinarith [sq_nonneg (s b - s c)]
        have := mul_le_mul_of_nonneg_left h2 (hf0 b c)
        linarith
    · simp [hf, hK]
  have hX : ∑ b, ∑ c, f b c * (s c / s b) = ∑ b, ∑ c, f b c * (s b / s c) := by
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun c _ => Finset.sum_congr rfl fun b _ => ?_
    rw [hfsymm]
  have step1 : ∑ b, ∑ c, f b c ≤ ∑ b, ∑ c, f b c * (s b / s c) := by
    have hsum := Finset.sum_le_sum fun b (_ : b ∈ Finset.univ) =>
      Finset.sum_le_sum fun c (_ : c ∈ Finset.univ) => hpt b c
    simp only [← Finset.sum_div, Finset.sum_add_distrib, hX] at hsum
    linarith
  have step2 : ∑ b, ∑ c, f b c * (s b / s c) ≤ ∑ c, (if G c then w c * μ c else 0) := by
    rw [Finset.sum_comm]
    refine Finset.sum_le_sum fun c _ => ?_
    calc ∑ b, f b c * (s b / s c) ≤ ∑ b, f b c * (μ c / s c) := by
          refine Finset.sum_le_sum fun b _ => ?_
          by_cases hK : F b c
          · exact mul_le_mul_of_nonneg_left
              (div_le_div_of_nonneg_right (hs_le b c hK) (hs0 c)) (hf0 b c)
          · simp [hf, hK]
      _ = w c * μ c * (s c / s c) := by
          simp only [hf, hs, Finset.sum_div, Finset.mul_sum]
          refine Finset.sum_congr rfl fun b _ => ?_
          split_ifs <;> ring
      _ ≤ if G c then w c * μ c else 0 := by
          by_cases hz : s c = 0
          · simp only [hz, div_zero, mul_zero]; split_ifs
            · exact mul_nonneg (hw c) (hμ0 c)
            · exact le_rfl
          · obtain ⟨b, hb⟩ : ∃ b, F b c := by
              by_contra hne; push Not at hne; apply hz; simp [hs, hne]
            simp only [div_self hz, mul_one, if_pos (hG b c hb)]; exact le_rfl
  calc ∑ b, ∑ c, (if F b c then w b * w c else 0) = ∑ b, ∑ c, f b c := rfl
    _ ≤ ∑ c, (if G c then w c * μ c else 0) := step1.trans step2
    _ = ∑ c, ∑ d, (if G c ∧ R c d then w c * w d else 0) := by
        refine Finset.sum_congr rfl fun c _ => ?_
        by_cases h : G c
        · simp only [h, if_true, true_and, hμ, Finset.mul_sum]
          refine Finset.sum_congr rfl fun d _ => ?_
          split_ifs <;> ring
        · simp [h]

end Abstract

section C5

variable {n : ℕ}

/-- `L a b`: the pair `ab` is in the link of `x`. -/
abbrev Lk (H : Finset (Finset (Fin n))) (x a b : Fin n) : Prop :=
  ({x, a, b} : Finset (Fin n)) ∈ H

/-- `K a b c`: `abc` is an edge and its three pairs are in the link of `x` (a `K₄³` on `xabc`). -/
abbrev K4 (H : Finset (Finset (Fin n))) (x a b c : Fin n) : Prop :=
  ({a, b, c} : Finset (Fin n)) ∈ H ∧ Lk H x a b ∧ Lk H x a c ∧ Lk H x b c

lemma distinct_of_mem {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H) {a b c : Fin n}
    (h : ({a, b, c} : Finset (Fin n)) ∈ H) : a ≠ b ∧ a ≠ c ∧ b ≠ c := by
  have h3 := hH _ h
  refine ⟨?_, ?_, ?_⟩
  · rintro rfl
    have : ({a, a, c} : Finset (Fin n)) = {a, c} := by ext; simp
    rw [this] at h3; have := Finset.card_insert_le a ({c} : Finset (Fin n)); simp at this; omega
  · rintro rfl
    have : ({a, b, a} : Finset (Fin n)) = {a, b} := by ext; simp; tauto
    rw [this] at h3; have := Finset.card_insert_le a ({b} : Finset (Fin n)); simp at this; omega
  · rintro rfl
    have : ({a, b, b} : Finset (Fin n)) = {a, b} := by ext; simp
    rw [this] at h3; have := Finset.card_insert_le a ({b} : Finset (Fin n)); simp at this; omega

lemma mem_perm {H : Finset (Finset (Fin n))} {a b c : Fin n}
    (h : ({a, b, c} : Finset (Fin n)) ∈ H) :
    ({b, a, c} : Finset (Fin n)) ∈ H ∧ ({a, c, b} : Finset (Fin n)) ∈ H := by
  have e1 : ({b, a, c} : Finset (Fin n)) = {a, b, c} := by ext; simp; tauto
  have e2 : ({a, c, b} : Finset (Fin n)) = {a, b, c} := by ext; simp; tauto
  exact ⟨e1 ▸ h, e2 ▸ h⟩

/-- (i): two `K₄³`s `xabc`, `xabd` through the pair `ab` force `cd ∉ L(x)`, else
`(c, a, b, d, x)` is a tight 5-cycle. -/
lemma link_cancellative {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H) (hfree : ¬ ContainsC5 H)
    (x a b c d : Fin n) (h1 : K4 H x a b c) (h2 : K4 H x a b d) : ¬ Lk H x c d := by
  intro hcd
  obtain ⟨habc, hxab, hxac, hxbc⟩ := h1
  obtain ⟨habd, -, hxad, hxbd⟩ := h2
  obtain ⟨hab, hac, hbc⟩ := distinct_of_mem hH habc
  obtain ⟨-, had, hbd⟩ := distinct_of_mem hH habd
  obtain ⟨hxc, hxd, hcd'⟩ := distinct_of_mem hH hcd
  obtain ⟨hxa, -, -⟩ := distinct_of_mem hH hxab
  obtain ⟨-, hxb, -⟩ := distinct_of_mem hH hxab
  apply hfree
  refine ⟨⟨![c, a, b, d, x], ?_⟩, ?_⟩
  · intro i j hij
    fin_cases i <;> fin_cases j <;> simp_all [eq_comm]
  · intro i
    fin_cases i
    · have e : ({c, a, b} : Finset (Fin n)) = {a, b, c} := by ext; simp; tauto
      simpa [e] using habc
    · simpa using habd
    · have e : ({b, d, x} : Finset (Fin n)) = {x, b, d} := by ext; simp; tauto
      simpa [e] using hxbd
    · have e : ({d, x, c} : Finset (Fin n)) = {x, c, d} := by ext; simp; tauto
      simpa [e] using hcd
    · have e : ({x, c, a} : Finset (Fin n)) = {x, a, c} := by ext; simp; tauto
      simpa [e] using hxac

/-- **CL-4**: CL-3 with the extra condition `acd ∉ H` on the cherries: if `xabc`, `xabd` are
`K₄³`s and `acd ∈ H`, then `(x, b, c, a, d)` is a tight 5-cycle. -/
lemma link_cancellative_acd {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H)
    (hfree : ¬ ContainsC5 H) (x a b c d : Fin n) (h1 : K4 H x a b c) (h2 : K4 H x a b d) :
    ({a, c, d} : Finset (Fin n)) ∉ H := by
  intro hacd
  obtain ⟨habc, hxab, hxac, hxbc⟩ := h1
  obtain ⟨habd, -, hxad, hxbd⟩ := h2
  obtain ⟨hab, hac, hbc⟩ := distinct_of_mem hH habc
  obtain ⟨-, had, hbd⟩ := distinct_of_mem hH habd
  obtain ⟨-, -, hcd⟩ := distinct_of_mem hH hacd
  obtain ⟨hxa, -, -⟩ := distinct_of_mem hH hxab
  obtain ⟨-, hxb, -⟩ := distinct_of_mem hH hxab
  obtain ⟨-, hxc, -⟩ := distinct_of_mem hH hxac
  obtain ⟨-, hxd, -⟩ := distinct_of_mem hH hxad
  apply hfree
  refine ⟨⟨![x, b, c, a, d], ?_⟩, ?_⟩
  · intro i j hij
    fin_cases i <;> fin_cases j <;> simp_all [eq_comm]
  · intro i
    fin_cases i
    · simpa using hxbc
    · have e : ({b, c, a} : Finset (Fin n)) = {a, b, c} := by ext; simp; tauto
      simpa [e] using habc
    · have e : ({c, a, d} : Finset (Fin n)) = {a, c, d} := by ext; simp; tauto
      simpa [e] using hacd
    · have e : ({a, d, x} : Finset (Fin n)) = {x, a, d} := by ext; simp; tauto
      simpa [e] using hxad
    · have e : ({d, x, b} : Finset (Fin n)) = {x, b, d} := by ext; simp; tauto
      simpa [e] using hxbd

/-- **G3, the pair-book inequality.** For a `C₅³`-free 3-graph `H`, vertices `x`, `a` and
weights `w ≥ 0`, the weighted count of ordered pairs `(c, d)` with `xacd` a `K₄³` is at most
the weighted count of ordered pairs with `xac, xad ∈ H` and `xcd, acd ∉ H` (`d = c` allowed). -/
theorem pair_book (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H) (hfree : ¬ ContainsC5 H)
    (x a : Fin n) (w : Fin n → ℝ) (hw : ∀ v, 0 ≤ w v) :
    ∑ c, ∑ d, (if K4 H x a c d then w c * w d else 0) ≤
      ∑ c, ∑ d, (if Lk H x a c ∧ Lk H x a d ∧ ¬ Lk H x c d ∧
          ({a, c, d} : Finset (Fin n)) ∉ H then w c * w d else 0) := by
  have h := book_abstract w hw (K4 H x a) (fun c => Lk H x a c)
    (fun c d => Lk H x a d ∧ ¬ Lk H x c d ∧ ({a, c, d} : Finset (Fin n)) ∉ H) ?_ ?_ ?_
  · refine h.trans (le_of_eq (Finset.sum_congr rfl fun c _ => Finset.sum_congr rfl fun d _ => ?_))
    rfl
  · rintro b c ⟨h, hab, hac, hbc⟩
    have e : ({x, c, b} : Finset (Fin n)) = {x, b, c} := by ext; simp; tauto
    exact ⟨(mem_perm h).2, hac, hab, by simpa [Lk, e] using hbc⟩
  · rintro b c ⟨-, -, hac, -⟩; exact hac
  · intro b c d h1 h2
    exact ⟨h2.2.2.1, link_cancellative hH hfree x a b c d h1 h2,
      link_cancellative_acd hH hfree x a b c d h1 h2⟩

end C5

end TightCycleC5.HelperG

#print axioms TightCycleC5.HelperG.book_abstract
#print axioms TightCycleC5.HelperG.pair_book
