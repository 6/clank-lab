import P33PSDMatchingRowsBase
import P33PSDMatchingEntries5
import P33FlagRows5
namespace TightCycleC5.Bridge.P33PSDMatching

theorem source_row5 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block5 K p) :
    (sourceContribution P33Arithmetic.block5 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row5 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block5 rfl P33PSD.q5 P33PSD.scale source_entry5
    P33Flag.basis5 P33Flag.basis5_injective rfl (fun _ => rfl) P33Flag.type5 rfl K p hv
#print axioms source_row5

theorem source_row11 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block11 K p) :
    (sourceContribution P33Arithmetic.block11 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row11 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block11 rfl P33PSD.q11 P33PSD.scale source_entry11
    P33Flag.basis11 P33Flag.basis11_injective rfl (fun _ => rfl) P33Flag.type11 rfl K p hv
#print axioms source_row11

theorem source_row17 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block17 K p) :
    (sourceContribution P33Arithmetic.block17 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row17 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block17 rfl P33PSD.q17 P33PSD.scale source_entry17
    P33Flag.basis17 P33Flag.basis17_injective rfl (fun _ => rfl) P33Flag.type17 rfl K p hv
#print axioms source_row17

theorem source_row23 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block23 K p) :
    (sourceContribution P33Arithmetic.block23 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row23 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block23 rfl P33PSD.q23 P33PSD.scale source_entry23
    P33Flag.basis23 P33Flag.basis23_injective rfl (fun _ => rfl) P33Flag.type23 rfl K p hv
#print axioms source_row23

theorem source_row29 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block29 K p) :
    (sourceContribution P33Arithmetic.block29 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row29 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block29 rfl P33PSD.q29 P33PSD.scale source_entry29
    P33Flag.basis29 P33Flag.basis29_injective rfl (fun _ => rfl) P33Flag.type29 rfl K p hv
#print axioms source_row29

theorem source_row35 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block35 K p) :
    (sourceContribution P33Arithmetic.block35 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row35 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block35 rfl P33PSD.q35 P33PSD.scale source_entry35
    P33Flag.basis35 P33Flag.basis35_injective rfl (fun _ => rfl) P33Flag.type35 rfl K p hv
#print axioms source_row35

end TightCycleC5.Bridge.P33PSDMatching
