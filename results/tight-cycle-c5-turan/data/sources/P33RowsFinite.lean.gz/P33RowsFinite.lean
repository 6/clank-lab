import P33RowsData
import P33RowsWeights
import P33RowsCodes

namespace TightCycleC5.Bridge.P33Rows
set_option maxRecDepth 10000
set_option maxHeartbeats 4000000

/-- Decode an unordered edge on four labelled positions. Repeated labels are not edges. -/
def codeEdge (raw : Nat) (x u v : Fin 4) : Bool :=
  if ({x, u, v} : Finset (Fin 4)) = {0, 1, 2} then raw.testBit 4 else
  if ({x, u, v} : Finset (Fin 4)) = {0, 1, 3} then raw.testBit 5 else
  if ({x, u, v} : Finset (Fin 4)) = {0, 2, 3} then raw.testBit 6 else
  if ({x, u, v} : Finset (Fin 4)) = {1, 2, 3} then raw.testBit 7 else false

def codeColor (raw : Nat) (i : Fin 4) : Bool := raw.testBit i.val
def localCode (raw : Nat) : Nat := canonicalLocal (codeEdge raw) (codeColor raw) 0 1 2 3
def regularCode (raw : Nat) : Nat := canonicalRegular (codeEdge raw) (codeColor raw) 0 1 2 3

/-- The decoder uses the exact low-colour/high-edge raw-code convention. -/
theorem raw4_decoded : ∀ raw : Fin 256,
    raw4 (codeEdge raw.val) (codeColor raw.val) 0 1 2 3 = raw.val := by decide +kernel

/-- The full predicates include lengths, typed roots, and root-fixed canonicality. -/
def localBasisCheck (flags : Array Nat) : Prop :=
  flags.size = 80 ∧ localColors.size = 80 ∧ ∀ i : Fin 80,
    flags[i.val]! < 256 ∧ flags[i.val]! % 2 = localColors[i.val]!.toNat ∧
      localCode flags[i.val]! = flags[i.val]!
def regularBasisCheck (flags : Array Nat) : Prop :=
  flags.size = 120 ∧ regularTypes.size = 120 ∧ ∀ i : Fin 120,
    flags[i.val]! < 256 ∧ flags[i.val]! % 4 = regularTypes[i.val]! ∧
      regularCode flags[i.val]! = flags[i.val]! ∧ regularTypes[i.val]! ∈ [0, 2, 3]
instance (flags : Array Nat) : Decidable (localBasisCheck flags) := by unfold localBasisCheck; infer_instance
instance (flags : Array Nat) : Decidable (regularBasisCheck flags) := by unfold regularBasisCheck; infer_instance

theorem local_basis_checked : localBasisCheck localFlags := by decide +kernel
theorem regular_basis_checked : regularBasisCheck regularFlags := by decide +kernel

theorem local_basis_complete : ∀ raw : Fin 256, localFlags.contains (localCode raw.val) = true := by
  decide +kernel
theorem regular_basis_complete : ∀ raw : Fin 256, raw.val % 4 ≠ 1 →
    regularFlags.contains (regularCode raw.val) = true := by decide +kernel

theorem local_descriptor_typed (i : Fin 80) :
    (localDescriptor i).flag % 2 = (localDescriptor i).rootColor.toNat :=
  (local_basis_checked.2.2 i).2.1
theorem regular_descriptor_typed (i : Fin 120) :
    (regularDescriptor i).flag % 4 = (regularDescriptor i).rootColors :=
  (regular_basis_checked.2.2 i).2.1

theorem global_basis_checked : globalFlags = #[0, 1, 3, 7, 8, 9, 11, 15] := by decide +kernel

theorem source_bases_no_duplicates : localFlags.toList.Nodup ∧ regularFlags.toList.Nodup ∧
    globalFlags.toList.Nodup := by decide +kernel

theorem global_basis_complete : ∀ e : Fin 2, ∀ outside : Fin 4,
    globalFlags.contains (8 * e.val + 2 ^ outside.val - 1) = true := by decide +kernel

theorem source_scale_pos : 0 < sourceScale := by decide +kernel

def inequalitySignCheck (weights : Array Int) : Prop :=
  weights.size = 97 ∧ ∀ i : Fin 97, 0 ≤ weights[i.val]!
instance (weights : Array Int) : Decidable (inequalitySignCheck weights) := by
  unfold inequalitySignCheck; infer_instance

theorem source_inequality_signs : inequalitySignCheck rawInequalityWeights := by decide +kernel
/-- The regularity source really is signed; no positivity premise is imposed on it. -/
theorem source_regularity_signed : rawRegularWeights.size = 120 ∧ rawRegularWeights[20]! < 0 := by
  decide +kernel

theorem inequalityWeight_nonneg (i : Fin 97) : 0 ≤ inequalityWeight i := by
  unfold inequalityWeight
  exact div_nonneg (by exact_mod_cast (source_inequality_signs.2 i)) (by positivity)
theorem localWeight_nonneg (i : Fin 80) : 0 ≤ localWeight i := inequalityWeight_nonneg _
theorem cutWeight_nonneg (i : Fin 8) : 0 ≤ cutWeight i := inequalityWeight_nonneg _
theorem densityWeight_nonneg (i : Fin 9) : 0 ≤ densityWeight i := inequalityWeight_nonneg _

/-- Each corruption is rejected by the entire predicate, not just a selected cell. -/
theorem planted_local_root_rejected : ¬localBasisCheck (localFlags.set! 0 1) := by decide +kernel
theorem planted_regular_root_rejected : ¬regularBasisCheck (regularFlags.set! 40 1) := by decide +kernel
theorem planted_negative_weight_rejected : ¬inequalitySignCheck (rawInequalityWeights.set! 0 (-1)) := by
  decide +kernel

#print axioms raw4_decoded
#print axioms local_basis_checked
#print axioms regular_basis_checked
#print axioms local_basis_complete
#print axioms regular_basis_complete
#print axioms local_descriptor_typed
#print axioms regular_descriptor_typed
#print axioms global_basis_checked
#print axioms source_bases_no_duplicates
#print axioms global_basis_complete
#print axioms source_scale_pos
#print axioms source_inequality_signs
#print axioms source_regularity_signed
#print axioms inequalityWeight_nonneg
#print axioms localWeight_nonneg
#print axioms cutWeight_nonneg
#print axioms densityWeight_nonneg
#print axioms planted_local_root_rejected
#print axioms planted_regular_root_rejected
#print axioms planted_negative_weight_rejected
end TightCycleC5.Bridge.P33Rows
