import KernelRowIndex
import KernelWitness6

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_6_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 64 * 256 + i.val))
      kernelWitness6Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_64

theorem kernelBlock_6_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 65 * 256 + i.val))
      kernelWitness6Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_65

theorem kernelBlock_6_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 66 * 256 + i.val))
      kernelWitness6Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_66

theorem kernelBlock_6_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 67 * 256 + i.val))
      kernelWitness6Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_67

theorem kernelBlock_6_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 68 * 256 + i.val))
      kernelWitness6Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_68

theorem kernelBlock_6_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 69 * 256 + i.val))
      kernelWitness6Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_69

theorem kernelBlock_6_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 70 * 256 + i.val))
      kernelWitness6Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_70

theorem kernelBlock_6_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 71 * 256 + i.val))
      kernelWitness6Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_71

theorem kernelBlock_6_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 72 * 256 + i.val))
      kernelWitness6Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_72

theorem kernelBlock_6_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 73 * 256 + i.val))
      kernelWitness6Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_73

theorem kernelBlock_6_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 74 * 256 + i.val))
      kernelWitness6Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_74

theorem kernelBlock_6_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 75 * 256 + i.val))
      kernelWitness6Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_75

theorem kernelBlock_6_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 76 * 256 + i.val))
      kernelWitness6Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_76

theorem kernelBlock_6_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 77 * 256 + i.val))
      kernelWitness6Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_77

theorem kernelBlock_6_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 78 * 256 + i.val))
      kernelWitness6Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_78

theorem kernelBlock_6_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 79 * 256 + i.val))
      kernelWitness6Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_79

theorem kernelBlock_6_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 80 * 256 + i.val))
      kernelWitness6Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_80

theorem kernelBlock_6_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 81 * 256 + i.val))
      kernelWitness6Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_81

theorem kernelBlock_6_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 82 * 256 + i.val))
      kernelWitness6Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_82

theorem kernelBlock_6_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 83 * 256 + i.val))
      kernelWitness6Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_83

theorem kernelBlock_6_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 84 * 256 + i.val))
      kernelWitness6Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_84

theorem kernelBlock_6_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 85 * 256 + i.val))
      kernelWitness6Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_85

theorem kernelBlock_6_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 86 * 256 + i.val))
      kernelWitness6Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_86

theorem kernelBlock_6_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 87 * 256 + i.val))
      kernelWitness6Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_87

theorem kernelBlock_6_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 88 * 256 + i.val))
      kernelWitness6Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_88

theorem kernelBlock_6_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 89 * 256 + i.val))
      kernelWitness6Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_89

theorem kernelBlock_6_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 90 * 256 + i.val))
      kernelWitness6Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_90

theorem kernelBlock_6_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 91 * 256 + i.val))
      kernelWitness6Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_91

theorem kernelBlock_6_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 92 * 256 + i.val))
      kernelWitness6Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_92

theorem kernelBlock_6_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 93 * 256 + i.val))
      kernelWitness6Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_93

theorem kernelBlock_6_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 94 * 256 + i.val))
      kernelWitness6Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_94

theorem kernelBlock_6_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (6 * 32768 + 95 * 256 + i.val))
      kernelWitness6Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_6_95

end TightCycleC5.Bridge.Cover
