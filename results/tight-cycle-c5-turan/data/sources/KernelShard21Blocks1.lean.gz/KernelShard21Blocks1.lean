import KernelRowIndex
import KernelWitness21

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_21_32 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 32 * 256 + i.val))
      kernelWitness21Row32[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_32

theorem kernelBlock_21_33 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 33 * 256 + i.val))
      kernelWitness21Row33[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_33

theorem kernelBlock_21_34 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 34 * 256 + i.val))
      kernelWitness21Row34[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_34

theorem kernelBlock_21_35 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 35 * 256 + i.val))
      kernelWitness21Row35[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_35

theorem kernelBlock_21_36 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 36 * 256 + i.val))
      kernelWitness21Row36[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_36

theorem kernelBlock_21_37 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 37 * 256 + i.val))
      kernelWitness21Row37[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_37

theorem kernelBlock_21_38 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 38 * 256 + i.val))
      kernelWitness21Row38[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_38

theorem kernelBlock_21_39 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 39 * 256 + i.val))
      kernelWitness21Row39[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_39

theorem kernelBlock_21_40 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 40 * 256 + i.val))
      kernelWitness21Row40[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_40

theorem kernelBlock_21_41 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 41 * 256 + i.val))
      kernelWitness21Row41[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_41

theorem kernelBlock_21_42 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 42 * 256 + i.val))
      kernelWitness21Row42[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_42

theorem kernelBlock_21_43 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 43 * 256 + i.val))
      kernelWitness21Row43[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_43

theorem kernelBlock_21_44 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 44 * 256 + i.val))
      kernelWitness21Row44[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_44

theorem kernelBlock_21_45 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 45 * 256 + i.val))
      kernelWitness21Row45[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_45

theorem kernelBlock_21_46 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 46 * 256 + i.val))
      kernelWitness21Row46[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_46

theorem kernelBlock_21_47 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 47 * 256 + i.val))
      kernelWitness21Row47[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_47

theorem kernelBlock_21_48 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 48 * 256 + i.val))
      kernelWitness21Row48[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_48

theorem kernelBlock_21_49 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 49 * 256 + i.val))
      kernelWitness21Row49[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_49

theorem kernelBlock_21_50 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 50 * 256 + i.val))
      kernelWitness21Row50[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_50

theorem kernelBlock_21_51 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 51 * 256 + i.val))
      kernelWitness21Row51[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_51

theorem kernelBlock_21_52 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 52 * 256 + i.val))
      kernelWitness21Row52[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_52

theorem kernelBlock_21_53 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 53 * 256 + i.val))
      kernelWitness21Row53[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_53

theorem kernelBlock_21_54 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 54 * 256 + i.val))
      kernelWitness21Row54[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_54

theorem kernelBlock_21_55 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 55 * 256 + i.val))
      kernelWitness21Row55[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_55

theorem kernelBlock_21_56 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 56 * 256 + i.val))
      kernelWitness21Row56[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_56

theorem kernelBlock_21_57 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 57 * 256 + i.val))
      kernelWitness21Row57[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_57

theorem kernelBlock_21_58 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 58 * 256 + i.val))
      kernelWitness21Row58[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_58

theorem kernelBlock_21_59 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 59 * 256 + i.val))
      kernelWitness21Row59[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_59

theorem kernelBlock_21_60 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 60 * 256 + i.val))
      kernelWitness21Row60[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_60

theorem kernelBlock_21_61 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 61 * 256 + i.val))
      kernelWitness21Row61[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_61

theorem kernelBlock_21_62 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 62 * 256 + i.val))
      kernelWitness21Row62[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_62

theorem kernelBlock_21_63 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 63 * 256 + i.val))
      kernelWitness21Row63[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_63

end TightCycleC5.Bridge.Cover
