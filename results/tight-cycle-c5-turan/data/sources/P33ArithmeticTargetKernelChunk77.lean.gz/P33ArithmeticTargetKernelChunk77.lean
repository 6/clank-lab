-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk308 :
    ∀ i : Fin (min 128 (40547 - 128 * 308)),
      targetCountsMatch (classAt (targetKernelClass ⟨308, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk308

theorem target_counts_kernel_chunk309 :
    ∀ i : Fin (min 128 (40547 - 128 * 309)),
      targetCountsMatch (classAt (targetKernelClass ⟨309, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk309

theorem target_counts_kernel_chunk310 :
    ∀ i : Fin (min 128 (40547 - 128 * 310)),
      targetCountsMatch (classAt (targetKernelClass ⟨310, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk310

theorem target_counts_kernel_chunk311 :
    ∀ i : Fin (min 128 (40547 - 128 * 311)),
      targetCountsMatch (classAt (targetKernelClass ⟨311, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk311


end TightCycleC5.Bridge.P33Arithmetic
