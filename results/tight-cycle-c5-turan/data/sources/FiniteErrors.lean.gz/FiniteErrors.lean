import Mathlib

/-! Explicit finite-to-asymptotic error estimates for PROOF Theorems A/B. -/
namespace TightCycleC5.Bridge

def tripleFalling (x : ℝ) : ℝ := x * (x - 1) * (x - 2)
def freeTripleFalling (x : ℝ) : ℝ := (x - 3) * (x - 4) * (x - 5)
noncomputable def tripleRatio (x : ℝ) : ℝ := tripleFalling x / freeTripleFalling x
noncomputable def tripleError (x : ℝ) : ℝ := (9 * x ^ 2 - 45 * x + 60) / freeTripleFalling x

theorem pair_denominator_pos {x : ℝ} (hx : 12 ≤ x) : 0 < (x - 4) * (x - 5) :=
  mul_pos (by linarith) (by linarith)

theorem pair_denominator_lower {x : ℝ} (hx : 12 ≤ x) :
    x ^ 2 / 4 ≤ (x - 4) * (x - 5) := by
  have h : (x / 2) * (x / 2) ≤ (x - 4) * (x - 5) := by
    gcongr <;> linarith
  nlinarith

theorem freeTripleFalling_pos {x : ℝ} (hx : 12 ≤ x) : 0 < freeTripleFalling x := by
  unfold freeTripleFalling
  exact mul_pos (mul_pos (by linarith) (by linarith)) (by linarith)

theorem freeTripleFalling_lower {x : ℝ} (hx : 12 ≤ x) :
    x ^ 3 / 8 ≤ freeTripleFalling x := by
  have h34 : 0 ≤ (x - 3) * (x - 4) := mul_nonneg (by linarith) (by linarith)
  have h : (x / 2) * (x / 2) * (x / 2) ≤ (x - 3) * (x - 4) * (x - 5) := by
    gcongr <;> linarith
  unfold freeTripleFalling
  nlinarith

theorem common_set_error_le {x : ℝ} (hx : 12 ≤ x) : 1 / (x - 5) ≤ 2 / x := by
  apply (div_le_div_iff₀ (by linarith : 0 < x - 5) (by linarith : 0 < x)).2
  linarith

theorem pair_collision_error_le {x : ℝ} (hx : 12 ≤ x) :
    (4 * x - 14) / ((x - 4) * (x - 5)) ≤ 16 / x := by
  have hd := pair_denominator_lower hx
  apply (div_le_div_iff₀ (pair_denominator_pos hx) (by linarith : 0 < x)).2
  nlinarith

theorem four_root_psd_error_le {x m : ℝ} (hx : 12 ≤ x) (hm : 0 ≤ m) :
    (4 * x - 18) * m / ((x - 4) * (x - 5)) ≤ 16 * m / x := by
  have h : (4 * x - 18) / ((x - 4) * (x - 5)) ≤ 16 / x := by
    exact le_trans (div_le_div_of_nonneg_right (by linarith) (pair_denominator_pos hx).le)
      (pair_collision_error_le hx)
  simpa only [div_mul_eq_mul_div] using mul_le_mul_of_nonneg_right h hm

theorem two_root_psd_error_le {x m : ℝ} (hx : 12 ≤ x) (hm : 0 ≤ m) :
    (4 * x - 14) * m / ((x - 2) * (x - 3)) ≤ 16 * m / x := by
  have hd : x ^ 2 / 4 ≤ (x - 2) * (x - 3) := by
    have h : (x / 2) * (x / 2) ≤ (x - 2) * (x - 3) := by
      gcongr <;> linarith
    nlinarith
  have h : (4 * x - 14) / ((x - 2) * (x - 3)) ≤ 16 / x := by
    apply (div_le_div_iff₀ (mul_pos (by linarith) (by linarith)) (by linarith : 0 < x)).2
    nlinarith
  simpa only [div_mul_eq_mul_div] using mul_le_mul_of_nonneg_right h hm

theorem local_error_le {x : ℝ} (hx : 12 ≤ x) :
    6 * (x - 3) / ((x - 4) * (x - 5)) ≤ 24 / x := by
  have hd := pair_denominator_lower hx
  apply (div_le_div_iff₀ (pair_denominator_pos hx) (by linarith : 0 < x)).2
  nlinarith

theorem triple_ratio_eq_one_add_error {x : ℝ} (hx : 12 ≤ x) :
    tripleRatio x = 1 + tripleError x := by
  have hd := ne_of_gt (freeTripleFalling_pos hx)
  unfold tripleRatio tripleError tripleFalling
  field_simp
  unfold freeTripleFalling
  ring

theorem triple_error_le {x : ℝ} (hx : 12 ≤ x) : tripleError x ≤ 72 / x := by
  have hd := freeTripleFalling_lower hx
  unfold tripleError
  apply (div_le_div_iff₀ (freeTripleFalling_pos hx) (by linarith : 0 < x)).2
  have hn : 9 * x ^ 2 - 45 * x + 60 ≤ 9 * x ^ 2 := by linarith
  have h := mul_le_mul_of_nonneg_right hn (by linarith : 0 ≤ x)
  nlinarith

theorem triple_ratio_le {x : ℝ} (hx : 12 ≤ x) : tripleRatio x ≤ 1 + 72 / x := by
  rw [triple_ratio_eq_one_add_error hx]
  linarith [triple_error_le hx]

theorem regularity_coefficient_le {x : ℝ} (hx : 12 ≤ x) :
    2 * x ^ 2 / ((x - 4) * (x - 5)) ≤ 2 + 72 / x := by
  have hd := pair_denominator_lower hx
  have hpos := pair_denominator_pos hx
  apply (div_le_iff₀ hpos).2
  have hxpos : 0 < x := by linarith
  apply (mul_le_mul_iff_left₀ hxpos).mp
  field_simp
  nlinarith

theorem regularity_error_le {x δ : ℝ} (hx : 12 ≤ x) (hδ : 0 ≤ δ) :
    (2 * δ * x ^ 2 + 4 * x - 14) / ((x - 4) * (x - 5)) ≤
      (2 + 72 / x) * δ + 16 / x := by
  have h1 := mul_le_mul_of_nonneg_right (regularity_coefficient_le hx) hδ
  have h2 := pair_collision_error_le hx
  have heq : (2 * δ * x ^ 2 + 4 * x - 14) / ((x - 4) * (x - 5)) =
      (2 * x ^ 2 / ((x - 4) * (x - 5))) * δ +
        (4 * x - 14) / ((x - 4) * (x - 5)) := by ring
  rw [heq]
  linarith

/-- c is the combined cut/flag-density mass, d the unconditional density
coefficient, e the absolute regularity mass, and s the positive scale.
The right-hand constant is the exact A from PROOF Theorem B. -/
theorem p33_coefficient_le {x c d e s : ℝ} (hx : 12 ≤ x)
    (hc : 0 ≤ c) (he : 0 ≤ e) (hs : 0 < s) :
    (tripleRatio x * c + d + (2 * x ^ 2 / ((x - 4) * (x - 5))) * e) / s ≤
      (c + d + 2 * e) / s + (72 * (c + e) / s) / x := by
  have h1 := mul_le_mul_of_nonneg_right (triple_ratio_le hx) hc
  have h2 := mul_le_mul_of_nonneg_right (regularity_coefficient_le hx) he
  apply (div_le_iff₀ hs).2
  have heq : ((c + d + 2 * e) / s + (72 * (c + e) / s) / x) * s =
      (1 + 72 / x) * c + d + (2 + 72 / x) * e := by
    have hxpos : 0 < x := by linarith
    field_simp [ne_of_gt hs, ne_of_gt hxpos]
    ring
  rw [heq]
  linarith

#print axioms pair_denominator_pos
#print axioms pair_denominator_lower
#print axioms freeTripleFalling_pos
#print axioms freeTripleFalling_lower
#print axioms common_set_error_le
#print axioms pair_collision_error_le
#print axioms four_root_psd_error_le
#print axioms two_root_psd_error_le
#print axioms local_error_le
#print axioms triple_ratio_eq_one_add_error
#print axioms triple_error_le
#print axioms triple_ratio_le
#print axioms regularity_coefficient_le
#print axioms regularity_error_le
#print axioms p33_coefficient_le
end TightCycleC5.Bridge
