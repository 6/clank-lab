import LocalCut
import PairDeletion
import PairTripleLoss

/-! PROOF §3 Lemma 5: locally maximal cut rows with their exact finite
pair/triple collision loss. No C5-freeness is needed for this lemma. -/
namespace TightCycleC5.Bridge
open Finset
variable {n : ℕ}

theorem localGain_outside_pair_nonneg (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (S : Finset (Fin n)) (hS : LocallyMaximal H S) (root : Fin 1 ↪ Fin n) :
    0 ≤ ∑ u : Outside root, ∑ v : Outside root,
      localGain H S (root 0) u.val v.val := by
  have hroot : ∀ z, z ∈ Set.range root → z = root 0 := by
    rintro z ⟨i, rfl⟩
    congr 1
    exact Subsingleton.elim _ _
  rw [sum2_outside_support root (localGain H S (root 0))
    (fun u hu v => by rw [hroot u hu]; exact localGain_root_left_zero H hH S (root 0) v)
    (fun u v hv => by rw [hroot v hv]; exact localGain_root_right_zero H hH S (root 0) u)]
  exact localGain_pair_sum_nonneg H hH S hS (root 0)

theorem localGain_outside_pair_mean_nonneg (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (S : Finset (Fin n)) (hS : LocallyMaximal H S)
    (hn : 12 ≤ n) (root : Fin 1 ↪ Fin n) :
    0 ≤ uniformMean (fun uv : Fin 2 ↪ Outside root =>
      localGain H S (root 0) (uv 0).val (uv 1).val) := by
  classical
  have hcard : Fintype.card (Outside root) = n - 1 := by
    simpa only [Fintype.card_fin] using outside_card root
  have hk : 2 ≤ Fintype.card (Outside root) := by rw [hcard]; omega
  have h := distinct_pair_mean_lower
    (fun u v : Outside root => localGain H S (root 0) u.val v.val) 0 hk
    (fun u => le_of_eq (localGain_diagonal_zero H hH S (root 0) u.val))
    (localGain_outside_pair_nonneg H hH S hS root)
  simpa only [zero_div, neg_zero] using h

/-- Lemma 5 conditioned on x: the flag can be any [0,1]-valued function
of the other ordered triple, independent of the ordered pair (u,v). -/
theorem localGain_free_mean_lower (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (S : Finset (Fin n)) (hS : LocallyMaximal H S) (hn : 12 ≤ n)
    (root : Fin 1 ↪ Fin n) (F : (Fin 3 ↪ Outside root) → ℝ)
    (hF0 : ∀ t, 0 ≤ F t) (hF1 : ∀ t, F t ≤ 1) :
    -(6 * ((n : ℝ) - 3) / (((n : ℝ) - 4) * ((n : ℝ) - 5))) ≤
      uniformMean (disjointSampleProduct
        (fun uv : Fin 2 ↪ Outside root => localGain H S (root 0) (uv 0).val (uv 1).val) F) := by
  classical
  have hcard : Fintype.card (Outside root) = n - 1 := by
    simpa only [Fintype.card_fin] using outside_card root
  have hk : 5 ≤ Fintype.card (Outside root) := by rw [hcard]; omega
  have h := pair_triple_disjoint_lower hk
    (fun uv : Fin 2 ↪ Outside root => localGain H S (root 0) (uv 0).val (uv 1).val) F
    (fun uv => localGain_abs_le H S (root 0) (uv 0).val (uv 1).val)
    (localGain_outside_pair_mean_nonneg H hH S hS hn root) hF0 hF1
  have hcardR : (Fintype.card (Outside root) : ℝ) = (n : ℝ) - 1 := by
    rw [hcard, Nat.cast_sub (by omega : 1 ≤ n)]
    norm_num
  simpa only [hcardR, sub_sub, show (1 : ℝ) + 2 = 3 by norm_num,
    show (1 : ℝ) + 3 = 4 by norm_num, show (1 : ℝ) + 4 = 5 by norm_num] using h

noncomputable def localSixRow (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (F : (root : Fin 1 ↪ Fin n) → (Fin 3 ↪ Outside root) → ℝ)
    (σ : Fin 6 ↪ Fin n) : ℝ :=
  let rf := splitSampleEquiv (r := 1) (f := 5) σ
  disjointSampleProduct
    (fun uv : Fin 2 ↪ Outside rf.1 => localGain H S (rf.1 0) (uv 0).val (uv 1).val)
    (F rf.1) rf.2

/-- Explicit label check: free labels 0,1 are u,v and 2,3,4 are a,b,d. -/
theorem localSixRow_join (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (F : (root : Fin 1 ↪ Fin n) → (Fin 3 ↪ Outside root) → ℝ)
    (root : Fin 1 ↪ Fin n) (free : Fin 5 ↪ Outside root) :
    localSixRow H S F (joinSample root free) =
      localGain H S (root 0) (free 0).val (free 1).val *
        F root ((Fin.natAddEmb 2).trans free) := by
  change (fun rf : Σ root : Fin 1 ↪ Fin n, Fin 5 ↪ Outside root =>
    disjointSampleProduct
      (fun uv : Fin 2 ↪ Outside rf.1 => localGain H S (rf.1 0) (uv 0).val (uv 1).val)
      (F rf.1) rf.2) (splitSampleEquiv (joinSample root free)) = _
  rw [splitSampleEquiv_join]
  dsimp only
  rw [disjointSampleProduct_coordinates
    (fun uv : Fin 2 ↪ Outside root => localGain H S (root 0) (uv 0).val (uv 1).val)
    (F root) free]
  rfl

/-- Full Lemma 5 for each flag indicator F(x,a,b,d). -/
theorem local_six_row_lower (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (S : Finset (Fin n)) (hS : LocallyMaximal H S) (hn : 12 ≤ n)
    (F : (root : Fin 1 ↪ Fin n) → (Fin 3 ↪ Outside root) → ℝ)
    (hF : ∀ root t, F root t = 0 ∨ F root t = 1) :
    -(6 * ((n : ℝ) - 3) / (((n : ℝ) - 4) * ((n : ℝ) - 5))) ≤
      uniformMean (localSixRow H S F) := by
  classical
  letI : Nonempty (Fin 1 ↪ Fin n) := ⟨Fin.castLEEmb (by omega : 1 ≤ n)⟩
  rw [uniformMean_joinSample (r := 1) (f := 5)]
  have he : ∀ (root : Fin 1 ↪ Fin n) (free : Fin 5 ↪ Outside root),
      localSixRow H S F (joinSample root free) =
        disjointSampleProduct
          (fun uv : Fin 2 ↪ Outside root => localGain H S (root 0) (uv 0).val (uv 1).val)
          (F root) free := by
    intro root free
    change (fun rf : Σ root : Fin 1 ↪ Fin n, Fin 5 ↪ Outside root =>
      disjointSampleProduct
        (fun uv : Fin 2 ↪ Outside rf.1 => localGain H S (rf.1 0) (uv 0).val (uv 1).val)
        (F rf.1) rf.2) (splitSampleEquiv (joinSample root free)) = _
    rw [splitSampleEquiv_join]
  simp_rw [he]
  apply root_mean_lower
  intro root
  apply localGain_free_mean_lower H hH S hS hn root (F root)
  · intro t
    rcases hF root t with h | h <;> norm_num [h]
  · intro t
    rcases hF root t with h | h <;> norm_num [h]

#print axioms localGain_outside_pair_nonneg
#print axioms localGain_outside_pair_mean_nonneg
#print axioms localGain_free_mean_lower
#print axioms localSixRow_join
#print axioms local_six_row_lower
end TightCycleC5.Bridge
