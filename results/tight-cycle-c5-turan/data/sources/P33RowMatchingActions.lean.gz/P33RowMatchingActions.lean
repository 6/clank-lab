import P33RowMatchingRows

namespace TightCycleC5.Bridge.P33RowMatching

/-- Action-oriented form: evaluate the inverse order to obtain the p-action. -/
theorem inequality_row_match_action (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hl : localQueryValid K p.symm) (hg : globalQueryValid K p.symm) (i : Fin 12847) :
    (P33Arithmetic.inequalityRow (P33Arithmetic.featuresAt P33Arithmetic.localFlags
      P33Arithmetic.globalFlags P33Arithmetic.blocks K p.symm) i.val : ℝ) / 1000000000 =
      actualInequalityRow (p • MaskEncoding.decodeStructure
        (BitVec.ofNat 20 K.mask) (BitVec.ofNat 6 K.colours)) i :=
  inequality_row_match K p.symm hl hg i

theorem regular_row_match_action (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hr : regularQueryValid K p.symm) (i : Fin 120) :
    (P33Arithmetic.regularityRow (P33Arithmetic.featuresAt P33Arithmetic.localFlags
      P33Arithmetic.globalFlags P33Arithmetic.blocks K p.symm) i.val : ℝ) / 1000000000 =
      P33Rows.sourceRegularRow i (p • MaskEncoding.decodeStructure
        (BitVec.ofNat 20 K.mask) (BitVec.ofNat 6 K.colours)) :=
  regular_row_match K p.symm i hr

#print axioms inequality_row_match_action
#print axioms regular_row_match_action
end TightCycleC5.Bridge.P33RowMatching
