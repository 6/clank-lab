import P33FlagRowsBase
import P33PSDGroup2
import P33FlagFacts2

namespace TightCycleC5.Bridge.P33Flag
open Finset Matrix

noncomputable def row2 (G : LabelledStructure 6) : ℝ :=
  pairRow P33PSD.matrix2 basis2 type2 G

theorem row2_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row2 (sampleStructure σ H S)) =
      psdTwoRootSixRow (zeroExtend P33PSD.matrix2)
        (fun root a => flagLookup basis2 (pairKey H S root a)) (pairIndicator type2 S) :=
  pair_row_eq P33PSD.matrix2 basis2 basis2_injective type2 H S

theorem row2_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -((4 * (n : ℝ) - 14) * P33PSD.bound2 / (((n : ℝ) - 4) * ((n : ℝ) - 5))) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row2 (sampleStructure σ H S)) :=
  pair_row_lower P33PSD.normalized_psd2 P33PSD.normalized_nonneg2
    P33PSD.normalized_diagonal2 hn basis2 basis2_injective type2 H S

#print axioms row2_eq_optional
#print axioms row2_lower

noncomputable def row8 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix8 basis8 type8 G

theorem row8_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row8 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix8)
        (fun root a => flagLookup basis8 (fourKey H S root a)) (fourIndicator type8 H S) :=
  four_row_eq P33PSD.matrix8 basis8 basis8_injective type8 H S

theorem row8_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound8 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row8 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd8 P33PSD.normalized_nonneg8
    P33PSD.normalized_diagonal8 hn basis8 basis8_injective type8 H S

#print axioms row8_eq_optional
#print axioms row8_lower

noncomputable def row14 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix14 basis14 type14 G

theorem row14_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row14 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix14)
        (fun root a => flagLookup basis14 (fourKey H S root a)) (fourIndicator type14 H S) :=
  four_row_eq P33PSD.matrix14 basis14 basis14_injective type14 H S

theorem row14_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound14 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row14 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd14 P33PSD.normalized_nonneg14
    P33PSD.normalized_diagonal14 hn basis14 basis14_injective type14 H S

#print axioms row14_eq_optional
#print axioms row14_lower

noncomputable def row20 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix20 basis20 type20 G

theorem row20_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row20 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix20)
        (fun root a => flagLookup basis20 (fourKey H S root a)) (fourIndicator type20 H S) :=
  four_row_eq P33PSD.matrix20 basis20 basis20_injective type20 H S

theorem row20_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound20 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row20 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd20 P33PSD.normalized_nonneg20
    P33PSD.normalized_diagonal20 hn basis20 basis20_injective type20 H S

#print axioms row20_eq_optional
#print axioms row20_lower

noncomputable def row26 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix26 basis26 type26 G

theorem row26_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row26 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix26)
        (fun root a => flagLookup basis26 (fourKey H S root a)) (fourIndicator type26 H S) :=
  four_row_eq P33PSD.matrix26 basis26 basis26_injective type26 H S

theorem row26_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound26 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row26 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd26 P33PSD.normalized_nonneg26
    P33PSD.normalized_diagonal26 hn basis26 basis26_injective type26 H S

#print axioms row26_eq_optional
#print axioms row26_lower

noncomputable def row32 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix32 basis32 type32 G

theorem row32_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row32 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix32)
        (fun root a => flagLookup basis32 (fourKey H S root a)) (fourIndicator type32 H S) :=
  four_row_eq P33PSD.matrix32 basis32 basis32_injective type32 H S

theorem row32_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound32 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row32 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd32 P33PSD.normalized_nonneg32
    P33PSD.normalized_diagonal32 hn basis32 basis32_injective type32 H S

#print axioms row32_eq_optional
#print axioms row32_lower

end TightCycleC5.Bridge.P33Flag
