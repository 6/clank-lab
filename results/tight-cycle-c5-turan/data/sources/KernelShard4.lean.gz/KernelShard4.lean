import KernelShard4Blocks0
import KernelShard4Blocks1
import KernelShard4Blocks2
import KernelShard4Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard4 : kernelShardCheck 4 kernelWitness4 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (4 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness4 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_4_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard4
end TightCycleC5.Bridge.Cover
