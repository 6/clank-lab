import KernelRowIndex
import KernelWitness4

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_4_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 64 * 256 + i.val))
      kernelWitness4Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_64

theorem kernelBlock_4_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 65 * 256 + i.val))
      kernelWitness4Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_65

theorem kernelBlock_4_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 66 * 256 + i.val))
      kernelWitness4Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_66

theorem kernelBlock_4_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 67 * 256 + i.val))
      kernelWitness4Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_67

theorem kernelBlock_4_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 68 * 256 + i.val))
      kernelWitness4Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_68

theorem kernelBlock_4_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 69 * 256 + i.val))
      kernelWitness4Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_69

theorem kernelBlock_4_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 70 * 256 + i.val))
      kernelWitness4Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_70

theorem kernelBlock_4_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 71 * 256 + i.val))
      kernelWitness4Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_71

theorem kernelBlock_4_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 72 * 256 + i.val))
      kernelWitness4Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_72

theorem kernelBlock_4_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 73 * 256 + i.val))
      kernelWitness4Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_73

theorem kernelBlock_4_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 74 * 256 + i.val))
      kernelWitness4Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_74

theorem kernelBlock_4_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 75 * 256 + i.val))
      kernelWitness4Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_75

theorem kernelBlock_4_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 76 * 256 + i.val))
      kernelWitness4Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_76

theorem kernelBlock_4_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 77 * 256 + i.val))
      kernelWitness4Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_77

theorem kernelBlock_4_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 78 * 256 + i.val))
      kernelWitness4Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_78

theorem kernelBlock_4_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 79 * 256 + i.val))
      kernelWitness4Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_79

theorem kernelBlock_4_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 80 * 256 + i.val))
      kernelWitness4Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_80

theorem kernelBlock_4_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 81 * 256 + i.val))
      kernelWitness4Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_81

theorem kernelBlock_4_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 82 * 256 + i.val))
      kernelWitness4Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_82

theorem kernelBlock_4_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 83 * 256 + i.val))
      kernelWitness4Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_83

theorem kernelBlock_4_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 84 * 256 + i.val))
      kernelWitness4Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_84

theorem kernelBlock_4_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 85 * 256 + i.val))
      kernelWitness4Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_85

theorem kernelBlock_4_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 86 * 256 + i.val))
      kernelWitness4Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_86

theorem kernelBlock_4_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 87 * 256 + i.val))
      kernelWitness4Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_87

theorem kernelBlock_4_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 88 * 256 + i.val))
      kernelWitness4Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_88

theorem kernelBlock_4_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 89 * 256 + i.val))
      kernelWitness4Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_89

theorem kernelBlock_4_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 90 * 256 + i.val))
      kernelWitness4Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_90

theorem kernelBlock_4_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 91 * 256 + i.val))
      kernelWitness4Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_91

theorem kernelBlock_4_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 92 * 256 + i.val))
      kernelWitness4Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_92

theorem kernelBlock_4_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 93 * 256 + i.val))
      kernelWitness4Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_93

theorem kernelBlock_4_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 94 * 256 + i.val))
      kernelWitness4Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_94

theorem kernelBlock_4_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 95 * 256 + i.val))
      kernelWitness4Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_95

end TightCycleC5.Bridge.Cover
