import P33FlagData
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace TightCycleC5.Bridge.P33Flag
open ColouredFlags

theorem basis3_size : basis3Data.size = 128 := by decide +kernel
theorem basis3_psd_data : ∀ i, basis3 i = P33PSD.flags3[i.val]! := by decide +kernel
theorem basis3_steps : ∀ i : Fin 127,
    basis3 i.castSucc < basis3 i.succ := by decide +kernel
theorem basis3_injective : Function.Injective basis3 :=
  (Fin.strictMono_iff_lt_succ.mpr basis3_steps).injective
theorem basis3_range : ∀ i, basis3 i < 32768 := by decide +kernel
theorem basis3_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis3 i))).toNat = type3 := by decide +kernel
#print axioms basis3_size
#print axioms basis3_psd_data
#print axioms basis3_steps
#print axioms basis3_injective
#print axioms basis3_range
#print axioms basis3_root

theorem basis9_size : basis9Data.size = 128 := by decide +kernel
theorem basis9_psd_data : ∀ i, basis9 i = P33PSD.flags9[i.val]! := by decide +kernel
theorem basis9_steps : ∀ i : Fin 127,
    basis9 i.castSucc < basis9 i.succ := by decide +kernel
theorem basis9_injective : Function.Injective basis9 :=
  (Fin.strictMono_iff_lt_succ.mpr basis9_steps).injective
theorem basis9_range : ∀ i, basis9 i < 32768 := by decide +kernel
theorem basis9_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis9 i))).toNat = type9 := by decide +kernel
#print axioms basis9_size
#print axioms basis9_psd_data
#print axioms basis9_steps
#print axioms basis9_injective
#print axioms basis9_range
#print axioms basis9_root

theorem basis15_size : basis15Data.size = 128 := by decide +kernel
theorem basis15_psd_data : ∀ i, basis15 i = P33PSD.flags15[i.val]! := by decide +kernel
theorem basis15_steps : ∀ i : Fin 127,
    basis15 i.castSucc < basis15 i.succ := by decide +kernel
theorem basis15_injective : Function.Injective basis15 :=
  (Fin.strictMono_iff_lt_succ.mpr basis15_steps).injective
theorem basis15_range : ∀ i, basis15 i < 32768 := by decide +kernel
theorem basis15_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis15 i))).toNat = type15 := by decide +kernel
#print axioms basis15_size
#print axioms basis15_psd_data
#print axioms basis15_steps
#print axioms basis15_injective
#print axioms basis15_range
#print axioms basis15_root

theorem basis21_size : basis21Data.size = 100 := by decide +kernel
theorem basis21_psd_data : ∀ i, basis21 i = P33PSD.flags21[i.val]! := by decide +kernel
theorem basis21_steps : ∀ i : Fin 99,
    basis21 i.castSucc < basis21 i.succ := by decide +kernel
theorem basis21_injective : Function.Injective basis21 :=
  (Fin.strictMono_iff_lt_succ.mpr basis21_steps).injective
theorem basis21_range : ∀ i, basis21 i < 32768 := by decide +kernel
theorem basis21_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis21 i))).toNat = type21 := by decide +kernel
#print axioms basis21_size
#print axioms basis21_psd_data
#print axioms basis21_steps
#print axioms basis21_injective
#print axioms basis21_range
#print axioms basis21_root

theorem basis27_size : basis27Data.size = 78 := by decide +kernel
theorem basis27_psd_data : ∀ i, basis27 i = P33PSD.flags27[i.val]! := by decide +kernel
theorem basis27_steps : ∀ i : Fin 77,
    basis27 i.castSucc < basis27 i.succ := by decide +kernel
theorem basis27_injective : Function.Injective basis27 :=
  (Fin.strictMono_iff_lt_succ.mpr basis27_steps).injective
theorem basis27_range : ∀ i, basis27 i < 32768 := by decide +kernel
theorem basis27_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis27 i))).toNat = type27 := by decide +kernel
#print axioms basis27_size
#print axioms basis27_psd_data
#print axioms basis27_steps
#print axioms basis27_injective
#print axioms basis27_range
#print axioms basis27_root

theorem basis33_size : basis33Data.size = 60 := by decide +kernel
theorem basis33_psd_data : ∀ i, basis33 i = P33PSD.flags33[i.val]! := by decide +kernel
theorem basis33_steps : ∀ i : Fin 59,
    basis33 i.castSucc < basis33 i.succ := by decide +kernel
theorem basis33_injective : Function.Injective basis33 :=
  (Fin.strictMono_iff_lt_succ.mpr basis33_steps).injective
theorem basis33_range : ∀ i, basis33 i < 32768 := by decide +kernel
theorem basis33_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis33 i))).toNat = type33 := by decide +kernel
#print axioms basis33_size
#print axioms basis33_psd_data
#print axioms basis33_steps
#print axioms basis33_injective
#print axioms basis33_range
#print axioms basis33_root

end TightCycleC5.Bridge.P33Flag
