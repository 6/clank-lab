import P33Rows
import CertificateDescriptorsCL
import FiniteErrors

/-! Actual coefficient-one non-PSD row bounds for Theorem B. The target
and all PSD rows remain separate; every source weight is normalized once. -/
namespace TightCycleC5.Bridge.P33NonPSDRowBounds
set_option maxRecDepth 100000
set_option maxHeartbeats 0
open Finset

noncomputable def localMass : ℝ := ∑ i : Fin 80, P33Rows.localWeight i
noncomputable def cutMass : ℝ := ∑ i : Fin 8, P33Rows.cutWeight i
noncomputable def flaggedDensityMass : ℝ := ∑ i : Fin 8, P33Rows.densityWeight i.castSucc
noncomputable def unflaggedDensityWeight : ℝ := P33Rows.densityWeight 8
noncomputable def regularMass : ℝ := ∑ i : Fin 120, |P33Rows.regularWeight i|
noncomputable def deltaConstant : ℝ :=
  cutMass + flaggedDensityMass + unflaggedDensityWeight + 2 * regularMass
noncomputable def deltaErrorConstant : ℝ := 72 * (cutMass + flaggedDensityMass + regularMass)
noncomputable def errorConstant : ℝ :=
  24 * localMass + 2 * CertificateDescriptors.p33CLMass false +
    72 * (cutMass + flaggedDensityMass) + 16 * regularMass

noncomputable def localRows (G : LabelledStructure 6) : ℝ :=
  ∑ i : Fin 80, P33Rows.localWeight i * P33Rows.sourceLocalRow i G
noncomputable def cutRows (G : LabelledStructure 6) : ℝ :=
  ∑ i : Fin 8, P33Rows.cutWeight i * P33Rows.sourceCutRow i G
noncomputable def densityRows (G : LabelledStructure 6) : ℝ :=
  ∑ i : Fin 9, P33Rows.densityWeight i * P33Rows.sourceDensityRow i G
noncomputable def flaggedDensityRows (G : LabelledStructure 6) : ℝ :=
  ∑ i : Fin 8, P33Rows.densityWeight i.castSucc * P33Rows.sourceDensityRow i.castSucc G
noncomputable def regularRows (G : LabelledStructure 6) : ℝ :=
  ∑ i : Fin 120, P33Rows.regularWeight i * P33Rows.sourceRegularRow i G
noncomputable def clRows (G : LabelledStructure 6) : ℝ :=
  ∑ i : Fin 12750, CertificateDescriptors.p33CLWeight false i *
    CLCertificate.row (CertificateDescriptors.p33CL i) G
noncomputable def rows (G : LabelledStructure 6) : ℝ :=
  localRows G + cutRows G + densityRows G + regularRows G + clRows G

theorem mass_nonneg : 0 ≤ localMass ∧ 0 ≤ cutMass ∧ 0 ≤ flaggedDensityMass ∧
    0 ≤ unflaggedDensityWeight ∧ 0 ≤ regularMass := by
  refine ⟨?_, ?_, ?_, ?_, ?_⟩
  · exact Finset.sum_nonneg (fun i _ => P33Rows.localWeight_nonneg i)
  · exact Finset.sum_nonneg (fun i _ => P33Rows.cutWeight_nonneg i)
  · exact Finset.sum_nonneg (fun i _ => P33Rows.densityWeight_nonneg i.castSucc)
  · exact P33Rows.densityWeight_nonneg 8
  · exact Finset.sum_nonneg (fun i _ => abs_nonneg (P33Rows.regularWeight i))

theorem constants_nonneg : 0 ≤ deltaConstant ∧ 0 ≤ deltaErrorConstant ∧ 0 ≤ errorConstant := by
  obtain ⟨hl,hc,hd,hu,hr⟩ := mass_nonneg
  have hcl := CertificateDescriptors.p33_cl_mass_nonneg false
  unfold deltaConstant deltaErrorConstant errorConstant
  constructor
  · linarith only [hc, hd, hu, hr]
  constructor <;> linarith only [hl, hc, hd, hu, hr, hcl]

theorem local_mean_lower {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (S : Finset (Fin n)) (hS : LocallyMaximal H S) (hn : 12 ≤ n) :
    -(24 * localMass / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => localRows (sampleStructure σ H S)) := by
  have h := P33Rows.source_weighted_local_lower H hH S hS hn
  have he := mul_le_mul_of_nonneg_left (local_error_le (x := (n : ℝ)) (by exact_mod_cast hn)) mass_nonneg.1
  change localMass * _ ≤ _ at h
  calc
    _ = -(localMass * (24 / (n : ℝ))) := by ring
    _ ≤ -(localMass * (6 * ((n : ℝ) - 3) / (((n : ℝ) - 4) * ((n : ℝ) - 5)))) := neg_le_neg he
    _ ≤ _ := by simpa only [mul_neg, localRows] using h

theorem cl_mean_lower {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (S : Finset (Fin n)) (hn : 12 ≤ n) :
    -(2 * CertificateDescriptors.p33CLMass false / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => clRows (sampleStructure σ H S)) := by
  have h := CertificateDescriptors.p33_cl_mean_lower false H hH hC hn S
  have he := mul_le_mul_of_nonneg_left (common_set_error_le (x := (n : ℝ)) (by exact_mod_cast hn))
    (CertificateDescriptors.p33_cl_mass_nonneg false)
  calc
    _ = -(CertificateDescriptors.p33CLMass false * (2 / (n : ℝ))) := by ring
    _ ≤ -(CertificateDescriptors.p33CLMass false * (1 / ((n : ℝ) - 5))) := neg_le_neg he
    _ = -CertificateDescriptors.p33CLMass false / ((n : ℝ) - 5) := by ring
    _ ≤ _ := h

/-- The ninth density row is unflagged and has no disjoint-triple error. -/
theorem unflagged_density_mean_lower {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (S : Finset (Fin n)) (hn : 12 ≤ n) (δ : ℝ)
    (hd : (P33Rows.densityBound - δ) * (n.choose 3 : ℝ) ≤ H.card) :
    -δ ≤ uniformMean (fun σ : Fin 6 ↪ Fin n => P33Rows.sourceDensityRow 8 (sampleStructure σ H S)) := by
  rw [P33Rows.source_density_ninth_exact H hH S (by omega)]
  have hc : (0 : ℝ) < (n.choose 3 : ℝ) := by exact_mod_cast Nat.choose_pos (by omega : 3 ≤ n)
  have h := (le_div_iff₀ hc).mpr hd
  linarith

theorem density_rows_split (G : LabelledStructure 6) :
    densityRows G = flaggedDensityRows G +
      unflaggedDensityWeight * P33Rows.sourceDensityRow 8 G := by
  exact Fin.sum_univ_castSucc _

theorem flagged_density_mean_lower {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (S : Finset (Fin n)) (hn : 12 ≤ n) (δ : ℝ) (hδ : 0 ≤ δ)
    (hd : (P33Rows.densityBound - δ) * (n.choose 3 : ℝ) ≤ H.card) :
    flaggedDensityMass * (-P33Rows.tripleRatio n * δ - P33Rows.tripleError n) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => flaggedDensityRows (sampleStructure σ H S)) := by
  change (∑ i : Fin 8, P33Rows.densityWeight i.castSucc) * _ ≤
    uniformMean (fun σ : Fin 6 ↪ Fin n => ∑ i : Fin 8,
      P33Rows.densityWeight i.castSucc * P33Rows.sourceDensityRow i.castSucc (sampleStructure σ H S))
  rw [P33Rows.mean_weighted, Finset.sum_mul]
  exact Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_left
    (P33Rows.source_density_lower i.castSucc H hH S hn δ hδ hd)
    (P33Rows.densityWeight_nonneg i.castSucc))

theorem density_mean_lower {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (S : Finset (Fin n)) (hn : 12 ≤ n) (δ : ℝ) (hδ : 0 ≤ δ)
    (hd : (P33Rows.densityBound - δ) * (n.choose 3 : ℝ) ≤ H.card) :
    flaggedDensityMass * (-P33Rows.tripleRatio n * δ - P33Rows.tripleError n) -
      unflaggedDensityWeight * δ ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => densityRows (sampleStructure σ H S)) := by
  have hf := flagged_density_mean_lower H hH S hn δ hδ hd
  have hu := mul_le_mul_of_nonneg_left (unflagged_density_mean_lower H hH S hn δ hd)
    mass_nonneg.2.2.2.1
  have he : uniformMean (fun σ : Fin 6 ↪ Fin n => densityRows (sampleStructure σ H S)) =
      uniformMean (fun σ : Fin 6 ↪ Fin n => flaggedDensityRows (sampleStructure σ H S)) +
      unflaggedDensityWeight * uniformMean
        (fun σ : Fin 6 ↪ Fin n => P33Rows.sourceDensityRow 8 (sampleStructure σ H S)) := by
    simp only [density_rows_split, uniformMean, Finset.sum_add_distrib, add_div,
      ← Finset.mul_sum]
    ring
  rw [he]
  linarith

/-- All signed regularity coefficients retain their signs in the row sum. -/
theorem regular_mean_lower {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (S : Finset (Fin n)) (hn : 12 ≤ n) (δ : ℝ) (hδ : 0 ≤ δ)
    (hreg : ∀ x u, (deg H x : ℝ) ≤ deg H u + δ * (n : ℝ)^2) :
    -(regularMass * ((2 + 72 / (n : ℝ)) * δ + 16 / (n : ℝ))) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => regularRows (sampleStructure σ H S)) := by
  have h := P33Rows.source_weighted_regular_abs_le H hH S hn δ hreg
  have he := mul_le_mul_of_nonneg_left (regularity_error_le (x := (n : ℝ)) (by exact_mod_cast hn) hδ)
    mass_nonneg.2.2.2.2
  have hneg := neg_abs_le (uniformMean (fun σ : Fin 6 ↪ Fin n => regularRows (sampleStructure σ H S)))
  change |uniformMean (fun σ : Fin 6 ↪ Fin n => regularRows (sampleStructure σ H S))| ≤ regularMass * _ at h
  linarith

theorem rows_mean_lower {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (S : Finset (Fin n))
    (hS : LocallyMaximal H S) (hn : 12 ≤ n) (δ : ℝ) (hδ : 0 ≤ δ)
    (hreg : ∀ x u, (deg H x : ℝ) ≤ deg H u + δ * (n : ℝ)^2)
    (hcut : (2 / 5 - δ) * (n.choose 3 : ℝ) ≤ cutCount H S)
    (hd : (P33Rows.densityBound - δ) * (n.choose 3 : ℝ) ≤ H.card) :
    -((deltaConstant + deltaErrorConstant / (n : ℝ)) * δ + errorConstant / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => rows (sampleStructure σ H S)) := by
  have hl := local_mean_lower H hH S hS hn
  have hcl := cl_mean_lower H hH hC S hn
  have hc := P33Rows.source_weighted_cut_lower H hH S hn δ hδ hcut
  have hdens := density_mean_lower H hH S hn δ hδ hd
  have hr := regular_mean_lower H hH S hn δ hδ hreg
  have hρ := triple_ratio_le (by exact_mod_cast hn : (12 : ℝ) ≤ n)
  have hη := triple_error_le (by exact_mod_cast hn : (12 : ℝ) ≤ n)
  have hmass : 0 ≤ cutMass + flaggedDensityMass := add_nonneg mass_nonneg.2.1 mass_nonneg.2.2.1
  have hρm := mul_le_mul_of_nonneg_left hρ (mul_nonneg hmass hδ)
  have hηm := mul_le_mul_of_nonneg_left hη hmass
  change (cutMass + flaggedDensityMass) * δ * P33Rows.tripleRatio n ≤
    (cutMass + flaggedDensityMass) * δ * (1 + 72 / (n : ℝ)) at hρm
  change (cutMass + flaggedDensityMass) * P33Rows.tripleError n ≤
    (cutMass + flaggedDensityMass) * (72 / (n : ℝ)) at hηm
  change cutMass * (-P33Rows.tripleRatio n * δ - P33Rows.tripleError n) ≤
    uniformMean (fun σ : Fin 6 ↪ Fin n => cutRows (sampleStructure σ H S)) at hc
  have he : uniformMean (fun σ : Fin 6 ↪ Fin n => rows (sampleStructure σ H S)) =
      uniformMean (fun σ : Fin 6 ↪ Fin n => localRows (sampleStructure σ H S)) +
      uniformMean (fun σ : Fin 6 ↪ Fin n => cutRows (sampleStructure σ H S)) +
      uniformMean (fun σ : Fin 6 ↪ Fin n => densityRows (sampleStructure σ H S)) +
      uniformMean (fun σ : Fin 6 ↪ Fin n => regularRows (sampleStructure σ H S)) +
      uniformMean (fun σ : Fin 6 ↪ Fin n => clRows (sampleStructure σ H S)) := by
    simp only [rows, uniformMean, Finset.sum_add_distrib, add_div]
  rw [he]
  unfold deltaConstant deltaErrorConstant errorConstant
  simp only [div_eq_mul_inv] at hl hcl hc hdens hr hρm hηm ⊢
  linear_combination hl + hcl + hc + hdens + hr + hρm + hηm

#print axioms mass_nonneg
#print axioms constants_nonneg
#print axioms local_mean_lower
#print axioms cl_mean_lower
#print axioms unflagged_density_mean_lower
#print axioms density_rows_split
#print axioms flagged_density_mean_lower
#print axioms density_mean_lower
#print axioms regular_mean_lower
#print axioms rows_mean_lower
end TightCycleC5.Bridge.P33NonPSDRowBounds
