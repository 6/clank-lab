import KernelRowIndex
import KernelWitness20

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_20_96 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 96 * 256 + i.val))
      kernelWitness20Row96[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_96

theorem kernelBlock_20_97 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 97 * 256 + i.val))
      kernelWitness20Row97[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_97

theorem kernelBlock_20_98 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 98 * 256 + i.val))
      kernelWitness20Row98[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_98

theorem kernelBlock_20_99 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 99 * 256 + i.val))
      kernelWitness20Row99[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_99

theorem kernelBlock_20_100 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 100 * 256 + i.val))
      kernelWitness20Row100[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_100

theorem kernelBlock_20_101 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 101 * 256 + i.val))
      kernelWitness20Row101[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_101

theorem kernelBlock_20_102 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 102 * 256 + i.val))
      kernelWitness20Row102[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_102

theorem kernelBlock_20_103 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 103 * 256 + i.val))
      kernelWitness20Row103[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_103

theorem kernelBlock_20_104 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 104 * 256 + i.val))
      kernelWitness20Row104[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_104

theorem kernelBlock_20_105 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 105 * 256 + i.val))
      kernelWitness20Row105[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_105

theorem kernelBlock_20_106 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 106 * 256 + i.val))
      kernelWitness20Row106[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_106

theorem kernelBlock_20_107 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 107 * 256 + i.val))
      kernelWitness20Row107[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_107

theorem kernelBlock_20_108 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 108 * 256 + i.val))
      kernelWitness20Row108[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_108

theorem kernelBlock_20_109 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 109 * 256 + i.val))
      kernelWitness20Row109[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_109

theorem kernelBlock_20_110 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 110 * 256 + i.val))
      kernelWitness20Row110[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_110

theorem kernelBlock_20_111 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 111 * 256 + i.val))
      kernelWitness20Row111[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_111

theorem kernelBlock_20_112 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 112 * 256 + i.val))
      kernelWitness20Row112[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_112

theorem kernelBlock_20_113 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 113 * 256 + i.val))
      kernelWitness20Row113[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_113

theorem kernelBlock_20_114 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 114 * 256 + i.val))
      kernelWitness20Row114[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_114

theorem kernelBlock_20_115 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 115 * 256 + i.val))
      kernelWitness20Row115[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_115

theorem kernelBlock_20_116 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 116 * 256 + i.val))
      kernelWitness20Row116[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_116

theorem kernelBlock_20_117 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 117 * 256 + i.val))
      kernelWitness20Row117[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_117

theorem kernelBlock_20_118 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 118 * 256 + i.val))
      kernelWitness20Row118[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_118

theorem kernelBlock_20_119 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 119 * 256 + i.val))
      kernelWitness20Row119[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_119

theorem kernelBlock_20_120 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 120 * 256 + i.val))
      kernelWitness20Row120[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_120

theorem kernelBlock_20_121 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 121 * 256 + i.val))
      kernelWitness20Row121[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_121

theorem kernelBlock_20_122 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 122 * 256 + i.val))
      kernelWitness20Row122[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_122

theorem kernelBlock_20_123 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 123 * 256 + i.val))
      kernelWitness20Row123[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_123

theorem kernelBlock_20_124 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 124 * 256 + i.val))
      kernelWitness20Row124[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_124

theorem kernelBlock_20_125 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 125 * 256 + i.val))
      kernelWitness20Row125[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_125

theorem kernelBlock_20_126 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 126 * 256 + i.val))
      kernelWitness20Row126[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_126

theorem kernelBlock_20_127 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 127 * 256 + i.val))
      kernelWitness20Row127[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_127

end TightCycleC5.Bridge.Cover
