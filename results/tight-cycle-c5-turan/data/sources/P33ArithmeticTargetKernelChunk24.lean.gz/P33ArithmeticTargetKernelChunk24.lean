-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk96 :
    ∀ i : Fin (min 128 (40547 - 128 * 96)),
      targetCountsMatch (classAt (targetKernelClass ⟨96, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk96

theorem target_counts_kernel_chunk97 :
    ∀ i : Fin (min 128 (40547 - 128 * 97)),
      targetCountsMatch (classAt (targetKernelClass ⟨97, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk97

theorem target_counts_kernel_chunk98 :
    ∀ i : Fin (min 128 (40547 - 128 * 98)),
      targetCountsMatch (classAt (targetKernelClass ⟨98, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk98

theorem target_counts_kernel_chunk99 :
    ∀ i : Fin (min 128 (40547 - 128 * 99)),
      targetCountsMatch (classAt (targetKernelClass ⟨99, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk99


end TightCycleC5.Bridge.P33Arithmetic
