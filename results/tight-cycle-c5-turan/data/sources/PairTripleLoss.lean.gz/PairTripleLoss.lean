import DisjointSampling
import TripleProducts

/-! Exact finite loss from deleting intersections between an ordered pair
and an ordered triple in a common free vertex space. -/
namespace TightCycleC5.Bridge
open Finset

theorem descFactorial_two_cast {n : ℕ} (hn : 2 ≤ n) :
    (n.descFactorial 2 : ℝ) = (n : ℝ) * ((n : ℝ) - 1) := by
  rw [Nat.descFactorial_succ, Nat.descFactorial_succ]
  simp only [Nat.descFactorial_zero, Nat.sub_zero, mul_one, Nat.cast_mul,
    Nat.cast_sub (by omega : 1 ≤ n)]
  norm_num
  ring

/-- At k vertices the exact discarded-to-retained ratio is
6(k−2)/((k−3)(k−4)). No union bound or symmetry factor is assumed. -/
theorem pair_triple_disjoint_lower {A : Type*} [Fintype A] [DecidableEq A]
    (hk : 5 ≤ Fintype.card A) (g : (Fin 2 ↪ A) → ℝ) (h : (Fin 3 ↪ A) → ℝ)
    (hg : ∀ t, |g t| ≤ 1) (hgm : 0 ≤ uniformMean g)
    (hh0 : ∀ t, 0 ≤ h t) (hh1 : ∀ t, h t ≤ 1) :
    -(6 * ((Fintype.card A : ℝ) - 2) /
      (((Fintype.card A : ℝ) - 3) * ((Fintype.card A : ℝ) - 4))) ≤
      uniformMean (disjointSampleProduct g h) := by
  classical
  let k := Fintype.card A
  letI : Nonempty (Fin 2 ↪ A) :=
    ⟨(Fin.castLEEmb (by omega : 2 ≤ k)).trans (Fintype.equivFin A).symm.toEmbedding⟩
  letI : Nonempty (Fin 3 ↪ A) :=
    ⟨(Fin.castLEEmb (by omega : 3 ≤ k)).trans (Fintype.equivFin A).symm.toEmbedding⟩
  have hl := disjointSampleProduct_lower g h hg hgm hh0 hh1
  let a : ℝ := k.descFactorial 2
  let b : ℝ := k.descFactorial 3
  let c : ℝ := (k - 2).descFactorial 3
  have ha : a = (k : ℝ) * ((k : ℝ) - 1) := descFactorial_two_cast (by omega)
  have hb : b = (k : ℝ) * ((k : ℝ) - 1) * ((k : ℝ) - 2) :=
    descFactorial_three_cast (by omega)
  have hc : c = ((k : ℝ) - 2) * ((k : ℝ) - 3) * ((k : ℝ) - 4) := by
    change ((k - 2).descFactorial 3 : ℝ) = _
    rw [descFactorial_three_cast (by omega : 3 ≤ k - 2), Nat.cast_sub (by omega : 2 ≤ k)]
    norm_num
    ring
  have hkR : (5 : ℝ) ≤ k := by exact_mod_cast hk
  have hap : 0 < a := by rw [ha]; exact mul_pos (by linarith) (by linarith)
  have hcp : 0 < c := by
    rw [hc]
    exact mul_pos (mul_pos (by linarith) (by linarith)) (by linarith)
  have h2 : (k : ℝ) - 2 ≠ 0 := by linarith
  have h3 : (k : ℝ) - 3 ≠ 0 := by linarith
  have h4 : (k : ℝ) - 4 ≠ 0 := by linarith
  have hspace : (Fintype.card ((Fin 2 ↪ A) × (Fin 3 ↪ A)) : ℝ) = a * b := by
    simp only [Fintype.card_prod, Nat.cast_mul, Fintype.card_embedding_eq,
      Fintype.card_fin, a, b, k]
  have hgood : ((disjointEmbeddingPairs A 2 3).card : ℝ) = a * c := by
    rw [disjointEmbeddingPairs_card, Nat.cast_mul]
  have hbad : (((disjointEmbeddingPairs A 2 3)ᶜ).card : ℝ) = a * b - a * c := by
    rw [Finset.card_compl, Nat.cast_sub (Finset.card_le_univ _), hspace, hgood]
  have hratio : (a * b - a * c) / (a * c) =
      6 * ((k : ℝ) - 2) / (((k : ℝ) - 3) * ((k : ℝ) - 4)) := by
    calc
      _ = (b - c) / c := by field_simp
      _ = _ := by
        rw [hb, hc]
        field_simp
        ring
  rw [hbad, hgood, neg_div, hratio] at hl
  exact hl

#print axioms descFactorial_two_cast
#print axioms pair_triple_disjoint_lower
end TightCycleC5.Bridge
