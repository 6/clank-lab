import P32Selector
import FiniteErrors

/-! The finite selector step and the quantified large-n step in PROOF
Theorem A. The positive graph-margin premise remains to be supplied by
the full exact certificate identity and its row bounds. -/
namespace TightCycleC5.Bridge
open Finset

theorem shifted_choose_margin_le {n : Nat} {ε : ℝ} (hε : 0 < ε)
    (hn : 12 ≤ n) (hlarge : 8 ≤ ε * (n : ℝ)) :
    (2 / 5 - ε) * (n.choose 3 : ℝ) ≤ (2 / 5 : ℝ) * ((n - 3).choose 3 : ℝ) := by
  have hnR : (12 : ℝ) ≤ n := by exact_mod_cast hn
  have hC := six_choose_three n
  have hCs := six_choose_three (n - 3)
  rw [Nat.cast_sub (by omega : 3 ≤ n)] at hCs
  norm_num at hCs
  have hClower := choose3_ge (by omega : 6 ≤ n)
  have hdiff : (2 / 5 : ℝ) * ((n.choose 3 : ℝ) - ((n - 3).choose 3 : ℝ)) ≤
      (3 / 5 : ℝ) * (n : ℝ) ^ 2 := by
    nlinarith
  have h8 := mul_le_mul_of_nonneg_right hlarge (sq_nonneg (n : ℝ))
  have hE := mul_le_mul_of_nonneg_left hClower hε.le
  nlinarith [sq_nonneg (n : ℝ)]

theorem maxCut_of_positive_selector {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hn : 12 ≤ n) (g : (Fin 3 ↪ Fin n) → ℝ)
    (hg : ∀ root, g root = 0 ∨ g root = 1)
    (π : (Fin 3 ↪ Fin n) → Fin n → ℝ)
    (h0 : ∀ root v, 0 ≤ π root v) (h1 : ∀ root v, π root v ≤ 1)
    (hmargin : (2 / 5 : ℝ) * selectorD g < selectorN H g π) :
    (2 / 5 : ℝ) * ((n - 3).choose 3 : ℝ) < (maxCut H : ℝ) := by
  have hD : 0 ≤ selectorD g := by
    unfold selectorD uniformMean
    apply div_nonneg
    · apply Finset.sum_nonneg
      intro root _
      rcases hg root with h | h <;> simp [h]
    · positivity
  have hbound := selectorN_le_falling H hH g hg π h0 h1
  have hfall : (0 : ℝ) < (n - 3).descFactorial 3 := by
    exact_mod_cast Nat.descFactorial_pos.mpr (by omega : 3 ≤ n - 3)
  have hDpos : 0 < selectorD g := by
    by_contra h
    have hz : selectorD g = 0 := le_antisymm (le_of_not_gt h) hD
    simp only [hz, mul_zero, zero_mul, zero_div] at hmargin hbound
    linarith
  have hmul := (le_div_iff₀ hfall).mp hbound
  have hmargin' := mul_lt_mul_of_pos_right hmargin hfall
  have hsmall : (2 / 5 : ℝ) * ((n - 3).descFactorial 3 : ℝ) < 6 * (maxCut H : ℝ) := by
    apply (mul_lt_mul_iff_right₀ hDpos).mp
    nlinarith
  have hc := six_choose_three (n - 3)
  rw [descFactorial_three_cast (by omega : 3 ≤ n - 3)] at hsmall
  nlinarith

theorem maxCut_of_positive_p32_margin {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hn : 12 ≤ n)
    (hmargin : 0 < uniformMean (fun σ : Fin 6 ↪ Fin n =>
      P32Selector.margin (sampleStructure σ H univ))) :
    (2 / 5 : ℝ) * ((n - 3).choose 3 : ℝ) < (maxCut H : ℝ) := by
  obtain ⟨j, hj⟩ := P32Selector.positive_margin_selector H univ (by omega) hmargin
  exact maxCut_of_positive_selector H hH hn
    (SelectorCertificate.rootIndicator (P32Selector.descriptor j) H)
    (SelectorCertificate.rootIndicator_zero_one _ H)
    (SelectorCertificate.probabilities (P32Selector.descriptor j) H)
    (fun _ _ => (P32Selector.probability_bounds j _).1)
    (fun _ _ => (P32Selector.probability_bounds j _).2) hj

/-- PARTIAL assembly: the exact positive-margin hypothesis is the one
remaining certificate-derived premise, not an asserted theorem here. -/
theorem p32_of_eventually_positive_margin
    (hcertificate : ∃ N : Nat, ∀ n ≥ N, ∀ H : Finset (Finset (Fin n)),
      IsThreeGraph H → ¬ ContainsC5 H →
      (4641 / 10000 : ℝ) * (n.choose 3 : ℝ) ≤ (H.card : ℝ) →
      0 < uniformMean (fun σ : Fin 6 ↪ Fin n =>
        P32Selector.margin (sampleStructure σ H univ))) : P32Statement := by
  intro ε hε
  obtain ⟨N, hN⟩ := hcertificate
  obtain ⟨M, hM⟩ := exists_nat_gt (8 / ε)
  refine ⟨max 12 (max N M), ?_⟩
  intro n hn H hH hC hdensity
  have hn12 : 12 ≤ n := le_trans (le_max_left _ _) hn
  have hnN : N ≤ n := le_trans (le_trans (le_max_left _ _) (le_max_right _ _)) hn
  have hnM : M ≤ n := le_trans (le_trans (le_max_right _ _) (le_max_right _ _)) hn
  have hMn : (M : ℝ) ≤ n := by exact_mod_cast hnM
  have hlarge : 8 ≤ ε * (n : ℝ) := by
    have h : 8 / ε < (n : ℝ) := lt_of_lt_of_le hM hMn
    have h' := (div_lt_iff₀ hε).mp h
    nlinarith
  exact le_of_lt (lt_of_le_of_lt (shifted_choose_margin_le hε hn12 hlarge)
    (maxCut_of_positive_p32_margin H hH hn12 (hN n hnN H hH hC hdensity)))

/-- The finite certificate's exact positive constant is 10^-4. This
assembly still requires its uniform graph-margin estimate. -/
theorem p32_of_uniform_margin_bound
    (hcertificate : ∃ C : ℝ, 0 ≤ C ∧ ∀ n ≥ 12, ∀ H : Finset (Finset (Fin n)),
      IsThreeGraph H → ¬ ContainsC5 H →
      (4641 / 10000 : ℝ) * (n.choose 3 : ℝ) ≤ (H.card : ℝ) →
      (1 / 10000 : ℝ) - C / (n : ℝ) ≤ uniformMean (fun σ : Fin 6 ↪ Fin n =>
        P32Selector.margin (sampleStructure σ H univ))) : P32Statement := by
  obtain ⟨C, hC0, hcert⟩ := hcertificate
  obtain ⟨M, hM⟩ := exists_nat_gt (10000 * C)
  apply p32_of_eventually_positive_margin
  refine ⟨max 12 M, ?_⟩
  intro n hn H hH hC hdensity
  have hn12 : 12 ≤ n := le_trans (le_max_left _ _) hn
  have hnM : M ≤ n := le_trans (le_max_right _ _) hn
  have hnR : (0 : ℝ) < n := by exact_mod_cast (by omega : 0 < n)
  have hMn : (M : ℝ) ≤ n := by exact_mod_cast hnM
  have herr : C / (n : ℝ) < 1 / 10000 := by
    apply (div_lt_iff₀ hnR).2
    nlinarith
  have h := hcert n hn12 H hH hC hdensity
  linarith

#print axioms shifted_choose_margin_le
#print axioms maxCut_of_positive_selector
#print axioms maxCut_of_positive_p32_margin
#print axioms p32_of_eventually_positive_margin
#print axioms p32_of_uniform_margin_bound
end TightCycleC5.Bridge
