import KernelShard3Blocks0
import KernelShard3Blocks1
import KernelShard3Blocks2
import KernelShard3Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard3 : kernelShardCheck 3 kernelWitness3 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (3 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness3 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_3_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard3
end TightCycleC5.Bridge.Cover
