import KernelRowIndex
import KernelWitness21

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_21_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 64 * 256 + i.val))
      kernelWitness21Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_64

theorem kernelBlock_21_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 65 * 256 + i.val))
      kernelWitness21Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_65

theorem kernelBlock_21_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 66 * 256 + i.val))
      kernelWitness21Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_66

theorem kernelBlock_21_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 67 * 256 + i.val))
      kernelWitness21Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_67

theorem kernelBlock_21_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 68 * 256 + i.val))
      kernelWitness21Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_68

theorem kernelBlock_21_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 69 * 256 + i.val))
      kernelWitness21Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_69

theorem kernelBlock_21_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 70 * 256 + i.val))
      kernelWitness21Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_70

theorem kernelBlock_21_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 71 * 256 + i.val))
      kernelWitness21Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_71

theorem kernelBlock_21_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 72 * 256 + i.val))
      kernelWitness21Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_72

theorem kernelBlock_21_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 73 * 256 + i.val))
      kernelWitness21Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_73

theorem kernelBlock_21_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 74 * 256 + i.val))
      kernelWitness21Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_74

theorem kernelBlock_21_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 75 * 256 + i.val))
      kernelWitness21Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_75

theorem kernelBlock_21_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 76 * 256 + i.val))
      kernelWitness21Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_76

theorem kernelBlock_21_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 77 * 256 + i.val))
      kernelWitness21Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_77

theorem kernelBlock_21_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 78 * 256 + i.val))
      kernelWitness21Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_78

theorem kernelBlock_21_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 79 * 256 + i.val))
      kernelWitness21Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_79

theorem kernelBlock_21_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 80 * 256 + i.val))
      kernelWitness21Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_80

theorem kernelBlock_21_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 81 * 256 + i.val))
      kernelWitness21Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_81

theorem kernelBlock_21_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 82 * 256 + i.val))
      kernelWitness21Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_82

theorem kernelBlock_21_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 83 * 256 + i.val))
      kernelWitness21Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_83

theorem kernelBlock_21_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 84 * 256 + i.val))
      kernelWitness21Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_84

theorem kernelBlock_21_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 85 * 256 + i.val))
      kernelWitness21Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_85

theorem kernelBlock_21_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 86 * 256 + i.val))
      kernelWitness21Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_86

theorem kernelBlock_21_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 87 * 256 + i.val))
      kernelWitness21Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_87

theorem kernelBlock_21_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 88 * 256 + i.val))
      kernelWitness21Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_88

theorem kernelBlock_21_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 89 * 256 + i.val))
      kernelWitness21Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_89

theorem kernelBlock_21_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 90 * 256 + i.val))
      kernelWitness21Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_90

theorem kernelBlock_21_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 91 * 256 + i.val))
      kernelWitness21Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_91

theorem kernelBlock_21_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 92 * 256 + i.val))
      kernelWitness21Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_92

theorem kernelBlock_21_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 93 * 256 + i.val))
      kernelWitness21Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_93

theorem kernelBlock_21_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 94 * 256 + i.val))
      kernelWitness21Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_94

theorem kernelBlock_21_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 95 * 256 + i.val))
      kernelWitness21Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_95

end TightCycleC5.Bridge.Cover
