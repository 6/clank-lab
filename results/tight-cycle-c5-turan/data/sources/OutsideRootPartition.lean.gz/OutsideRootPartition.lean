import OutsideSums

/-! Root-complement sums when the root contributions cancel in aggregate. -/
namespace TightCycleC5.Bridge
open Finset

theorem sum_outside_add_roots {R V : Type*} [Fintype R] [Fintype V]
    (root : R ↪ V) (v : V → ℝ) :
    (∑ a : Outside root, v a.val) + (∑ i : R, v (root i)) = ∑ a : V, v a := by
  classical
  rw [← Finset.sum_subtype (F := instFintypeOutside root)
    ((univ : Finset V).filter (fun a => a ∉ Set.range root)) (by intro a; simp) v]
  have hs : (∑ a ∈ (univ : Finset R).image root, v a) = ∑ i : R, v (root i) := by
    apply Finset.sum_image
    intro i _ j _ h
    exact root.injective h
  have he : (univ : Finset R).image root =
      (univ : Finset V).filter (fun a => a ∈ Set.range root) := by
    ext a
    simp
  rw [← hs, he, sum_filter, sum_filter, ← sum_add_distrib]
  apply Finset.sum_congr rfl
  intro a _
  by_cases ha : a ∈ Set.range root <;> simp [ha]

theorem sum_outside_two_cancel {V : Type*} [Fintype V]
    (root : Fin 2 ↪ V) (v : V → ℝ) (hz : v (root 0) + v (root 1) = 0) :
    (∑ a : Outside root, v a.val) = ∑ a : V, v a := by
  have h := sum_outside_add_roots root v
  rw [Fin.sum_univ_two, hz, add_zero] at h
  exact h

theorem sum2_outside_two_cancel {V : Type*} [Fintype V]
    (root : Fin 2 ↪ V) (v : V → V → ℝ)
    (hz1 : ∀ a, v (root 0) a + v (root 1) a = 0)
    (hz2 : ∀ a, v a (root 0) + v a (root 1) = 0) :
    (∑ a : Outside root, ∑ b : Outside root, v a.val b.val) =
      ∑ a : V, ∑ b : V, v a b := by
  classical
  calc
    _ = ∑ a : Outside root, ∑ b : V, v a.val b := by
      apply Finset.sum_congr rfl
      intro a _
      exact sum_outside_two_cancel root _ (hz2 a.val)
    _ = _ := by
      apply sum_outside_two_cancel root (fun a : V => ∑ b : V, v a b)
      rw [← Finset.sum_add_distrib]
      exact Finset.sum_eq_zero (fun b _ => hz1 b)

#print axioms sum_outside_add_roots
#print axioms sum_outside_two_cancel
#print axioms sum2_outside_two_cancel
end TightCycleC5.Bridge
