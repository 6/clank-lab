import KernelRowIndex
import KernelWitness10

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_10_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 64 * 256 + i.val))
      kernelWitness10Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_64

theorem kernelBlock_10_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 65 * 256 + i.val))
      kernelWitness10Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_65

theorem kernelBlock_10_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 66 * 256 + i.val))
      kernelWitness10Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_66

theorem kernelBlock_10_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 67 * 256 + i.val))
      kernelWitness10Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_67

theorem kernelBlock_10_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 68 * 256 + i.val))
      kernelWitness10Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_68

theorem kernelBlock_10_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 69 * 256 + i.val))
      kernelWitness10Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_69

theorem kernelBlock_10_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 70 * 256 + i.val))
      kernelWitness10Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_70

theorem kernelBlock_10_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 71 * 256 + i.val))
      kernelWitness10Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_71

theorem kernelBlock_10_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 72 * 256 + i.val))
      kernelWitness10Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_72

theorem kernelBlock_10_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 73 * 256 + i.val))
      kernelWitness10Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_73

theorem kernelBlock_10_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 74 * 256 + i.val))
      kernelWitness10Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_74

theorem kernelBlock_10_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 75 * 256 + i.val))
      kernelWitness10Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_75

theorem kernelBlock_10_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 76 * 256 + i.val))
      kernelWitness10Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_76

theorem kernelBlock_10_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 77 * 256 + i.val))
      kernelWitness10Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_77

theorem kernelBlock_10_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 78 * 256 + i.val))
      kernelWitness10Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_78

theorem kernelBlock_10_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 79 * 256 + i.val))
      kernelWitness10Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_79

theorem kernelBlock_10_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 80 * 256 + i.val))
      kernelWitness10Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_80

theorem kernelBlock_10_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 81 * 256 + i.val))
      kernelWitness10Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_81

theorem kernelBlock_10_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 82 * 256 + i.val))
      kernelWitness10Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_82

theorem kernelBlock_10_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 83 * 256 + i.val))
      kernelWitness10Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_83

theorem kernelBlock_10_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 84 * 256 + i.val))
      kernelWitness10Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_84

theorem kernelBlock_10_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 85 * 256 + i.val))
      kernelWitness10Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_85

theorem kernelBlock_10_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 86 * 256 + i.val))
      kernelWitness10Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_86

theorem kernelBlock_10_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 87 * 256 + i.val))
      kernelWitness10Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_87

theorem kernelBlock_10_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 88 * 256 + i.val))
      kernelWitness10Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_88

theorem kernelBlock_10_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 89 * 256 + i.val))
      kernelWitness10Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_89

theorem kernelBlock_10_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 90 * 256 + i.val))
      kernelWitness10Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_90

theorem kernelBlock_10_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 91 * 256 + i.val))
      kernelWitness10Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_91

theorem kernelBlock_10_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 92 * 256 + i.val))
      kernelWitness10Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_92

theorem kernelBlock_10_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 93 * 256 + i.val))
      kernelWitness10Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_93

theorem kernelBlock_10_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 94 * 256 + i.val))
      kernelWitness10Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_94

theorem kernelBlock_10_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 95 * 256 + i.val))
      kernelWitness10Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_95

end TightCycleC5.Bridge.Cover
