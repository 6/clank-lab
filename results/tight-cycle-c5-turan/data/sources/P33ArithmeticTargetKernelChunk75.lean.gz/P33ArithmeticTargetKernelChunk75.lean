-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk300 :
    ∀ i : Fin (min 128 (40547 - 128 * 300)),
      targetCountsMatch (classAt (targetKernelClass ⟨300, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk300

theorem target_counts_kernel_chunk301 :
    ∀ i : Fin (min 128 (40547 - 128 * 301)),
      targetCountsMatch (classAt (targetKernelClass ⟨301, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk301

theorem target_counts_kernel_chunk302 :
    ∀ i : Fin (min 128 (40547 - 128 * 302)),
      targetCountsMatch (classAt (targetKernelClass ⟨302, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk302

theorem target_counts_kernel_chunk303 :
    ∀ i : Fin (min 128 (40547 - 128 * 303)),
      targetCountsMatch (classAt (targetKernelClass ⟨303, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk303


end TightCycleC5.Bridge.P33Arithmetic
