import Statement
import Scalar

/-!
# The Mubayi–Rödl construction: `ex n ≥ L n³ − 2n²`

The iterated construction: split the vertices into a top part `A` of `a`
vertices and the rest `B`; take every triple with two vertices in `A` and
one in `B`, and recurse inside `B`.

* `extGraph` is one step: on `Fin (a + m)` (the first `a` vertices new, the
  rest a copy of `Fin m`), the triples with two new vertices and one old one,
  together with a copy of a 3-graph `H'` on the old vertices.
* `extGraph_c5free` (KLP's Example 1.2): every edge has zero or two new
  vertices, and on a tight 5-cycle that forces zero new vertices
  (`fin5_count`), so a copy would lie in the copy of `H'`.
* `extGraph_card`: `e = C(a,2)·m + e(H')`.
* `construction`: with `a = ⌈ρ n⌉`, `ρ = (3 − √3)/2`, induction on `n` and
  `lower_step` give a `C₅³`-free 3-graph on `Fin n` with at least
  `L n³ − 2n²` edges, so `ex n ≥ L n³ − 2n²` (`ex_ge`).
-/

namespace TightCycleC5

open Finset

/-- The new vertices `0, …, a − 1` of `Fin (a + m)`. -/
def newV (a m : ℕ) : Finset (Fin (a + m)) := Finset.univ.map (Fin.castAddEmb m)

/-- The old vertices `a, …, a + m − 1`, a copy of `Fin m`. -/
def oldV (a m : ℕ) : Finset (Fin (a + m)) := Finset.univ.map (Fin.natAddEmb a)

theorem mem_newV {a m : ℕ} (x : Fin (a + m)) : x ∈ newV a m ↔ (x : ℕ) < a := by
  simp only [newV, Finset.mem_map, Finset.mem_univ, true_and, Fin.coe_castAddEmb]
  constructor
  · rintro ⟨i, rfl⟩; simp
  · intro h; exact ⟨⟨x, h⟩, Fin.ext (by simp)⟩

theorem mem_oldV {a m : ℕ} (x : Fin (a + m)) : x ∈ oldV a m ↔ a ≤ (x : ℕ) := by
  simp only [oldV, Finset.mem_map, Finset.mem_univ, true_and, Fin.natAddEmb_apply]
  constructor
  · rintro ⟨i, rfl⟩; simp
  · intro h
    exact ⟨⟨x - a, by omega⟩, Fin.ext (by simp; omega)⟩

theorem card_newV (a m : ℕ) : (newV a m).card = a := by simp [newV]

theorem card_oldV (a m : ℕ) : (oldV a m).card = m := by simp [oldV]

/-- The triples with two new vertices and one old vertex. -/
def topTriples (a m : ℕ) : Finset (Finset (Fin (a + m))) :=
  (((newV a m).powersetCard 2) ×ˢ oldV a m).image (fun q => insert q.2 q.1)

/-- The copy of `H'` on the old vertices. -/
def oldPart {a m : ℕ} (H' : Finset (Finset (Fin m))) : Finset (Finset (Fin (a + m))) :=
  H'.map (Finset.mapEmbedding (Fin.natAddEmb a)).toEmbedding

/-- One step of the iterated construction. -/
def extGraph (a : ℕ) {m : ℕ} (H' : Finset (Finset (Fin m))) : Finset (Finset (Fin (a + m))) :=
  topTriples a m ∪ oldPart H'

theorem mem_topTriples {a m : ℕ} {e : Finset (Fin (a + m))} :
    e ∈ topTriples a m ↔ ∃ p z, p ⊆ newV a m ∧ p.card = 2 ∧ z ∈ oldV a m ∧ insert z p = e := by
  simp only [topTriples, Finset.mem_image, Finset.mem_product, Finset.mem_powersetCard,
    Prod.exists]
  constructor
  · rintro ⟨p, z, ⟨⟨hp, hc⟩, hz⟩, rfl⟩; exact ⟨p, z, hp, hc, hz, rfl⟩
  · rintro ⟨p, z, hp, hc, hz, rfl⟩; exact ⟨p, z, ⟨⟨hp, hc⟩, hz⟩, rfl⟩

theorem mem_oldPart {a m : ℕ} {H' : Finset (Finset (Fin m))} {e : Finset (Fin (a + m))} :
    e ∈ oldPart (a := a) H' ↔ ∃ e' ∈ H', e'.map (Fin.natAddEmb a) = e := by
  simp [oldPart]

theorem not_new_of_old {a m : ℕ} {z : Fin (a + m)} (hz : z ∈ oldV a m) : ¬ (z : ℕ) < a := by
  rw [mem_oldV] at hz; omega

/-- The new vertices of a top triple are its pair. -/
theorem filter_insert_old {a m : ℕ} {p : Finset (Fin (a + m))} {z : Fin (a + m)}
    (hp : p ⊆ newV a m) (hz : z ∈ oldV a m) :
    (insert z p).filter (fun x : Fin (a + m) => (x : ℕ) < a) = p := by
  rw [Finset.filter_insert, if_neg (not_new_of_old hz)]
  exact Finset.filter_true_of_mem fun x hx => (mem_newV x).mp (hp hx)

theorem old_of_mem_oldPart {a m : ℕ} {H' : Finset (Finset (Fin m))} {e : Finset (Fin (a + m))}
    (he : e ∈ oldPart (a := a) H') : ∀ x ∈ e, ¬ (x : ℕ) < a := by
  rw [mem_oldPart] at he
  obtain ⟨e', -, rfl⟩ := he
  intro x hx
  simp only [Finset.mem_map, Fin.natAddEmb_apply] at hx
  obtain ⟨j, -, rfl⟩ := hx
  simp

/-- Every edge of `extGraph` has two new vertices or none. -/
theorem newCount_cases {a m : ℕ} {H' : Finset (Finset (Fin m))} {e : Finset (Fin (a + m))}
    (he : e ∈ extGraph a H') :
    (e.filter (fun x : Fin (a + m) => (x : ℕ) < a)).card = 2 ∨ e ∈ oldPart (a := a) H' := by
  rcases Finset.mem_union.mp he with h | h
  · left
    obtain ⟨p, z, hp, hc, hz, rfl⟩ := mem_topTriples.mp h
    rw [filter_insert_old hp hz, hc]
  · exact Or.inr h

theorem extGraph_three {a m : ℕ} {H' : Finset (Finset (Fin m))} (hH' : IsThreeGraph H') :
    IsThreeGraph (extGraph a H') := by
  intro e he
  rcases Finset.mem_union.mp he with h | h
  · obtain ⟨p, z, hp, hc, hz, rfl⟩ := mem_topTriples.mp h
    have hzp : z ∉ p := fun hzp => not_new_of_old hz ((mem_newV z).mp (hp hzp))
    rw [Finset.card_insert_of_notMem hzp, hc]
  · obtain ⟨e', he', rfl⟩ := mem_oldPart.mp h
    rw [Finset.card_map]
    exact hH' e' he'

theorem topTriples_card (a m : ℕ) : (topTriples a m).card = a.choose 2 * m := by
  unfold topTriples
  rw [Finset.card_image_of_injOn, Finset.card_product, Finset.card_powersetCard, card_newV,
    card_oldV]
  rintro ⟨p, z⟩ hq ⟨p', z'⟩ hq' heq
  simp only [Finset.coe_product, Set.mem_prod, Finset.mem_coe, Finset.mem_powersetCard] at hq hq'
  simp only at heq
  have hp : p = p' := by
    rw [← filter_insert_old hq.1.1 hq.2, ← filter_insert_old hq'.1.1 hq'.2, heq]
  subst hp
  have hz : z ∈ insert z' p := heq ▸ Finset.mem_insert_self z p
  rcases Finset.mem_insert.mp hz with h | h
  · rw [h]
  · exact absurd ((mem_newV z).mp (hq.1.1 h)) (not_new_of_old hq.2)

theorem extGraph_card {a m : ℕ} (H' : Finset (Finset (Fin m))) :
    (extGraph a H').card = a.choose 2 * m + H'.card := by
  unfold extGraph
  rw [Finset.card_union_of_disjoint, topTriples_card]
  · simp [oldPart]
  · rw [Finset.disjoint_left]
    intro e he he'
    obtain ⟨p, z, hp, hc, hz, rfl⟩ := mem_topTriples.mp he
    obtain ⟨x, hx⟩ : p.Nonempty := Finset.card_pos.mp (by omega)
    exact old_of_mem_oldPart he' x (Finset.mem_insert_of_mem hx) ((mem_newV x).mp (hp hx))

/-- On a tight 5-cycle, if every edge has zero or two marked vertices, no
vertex is marked. -/
theorem fin5_count (c0 c1 c2 c3 c4 : ℕ) (h0 : c0 ≤ 1) (h1 : c1 ≤ 1) (h2 : c2 ≤ 1) (h3 : c3 ≤ 1)
    (h4 : c4 ≤ 1) (t0 : c0 + c1 + c2 = 2 ∨ c0 + c1 + c2 = 0)
    (t1 : c1 + c2 + c3 = 2 ∨ c1 + c2 + c3 = 0) (t2 : c2 + c3 + c4 = 2 ∨ c2 + c3 + c4 = 0)
    (t3 : c3 + c4 + c0 = 2 ∨ c3 + c4 + c0 = 0) (t4 : c4 + c0 + c1 = 2 ∨ c4 + c0 + c1 = 0) :
    c0 = 0 ∧ c1 = 0 ∧ c2 = 0 ∧ c3 = 0 ∧ c4 = 0 := by
  omega

theorem fin5_distinct : ∀ i : Fin 5, i ≠ i + 1 ∧ i ≠ i + 2 ∧ i + 1 ≠ i + 2 := by decide

/-- The number of new vertices of a triple of distinct vertices. -/
theorem card_filter_triple {n : ℕ} (P : Fin n → Prop) [DecidablePred P] {x y z : Fin n}
    (hxy : x ≠ y) (hxz : x ≠ z) (hyz : y ≠ z) :
    (({x, y, z} : Finset (Fin n)).filter P).card =
      (if P x then 1 else 0) + (if P y then 1 else 0) + (if P z then 1 else 0) := by
  rw [Finset.card_filter, Finset.sum_insert (by simp [hxy, hxz]),
    Finset.sum_insert (by simp [hyz]), Finset.sum_singleton]
  ring

/-- **KLP's Example 1.2, one step**: `extGraph a H'` is `C₅³`-free when `H'` is. -/
theorem extGraph_c5free {a m : ℕ} {H' : Finset (Finset (Fin m))} (hC : ¬ ContainsC5 H') :
    ¬ ContainsC5 (extGraph a H') := by
  rintro ⟨f, hf⟩
  set c : Fin 5 → ℕ := fun i => if ((f i : Fin (a + m)) : ℕ) < a then 1 else 0 with hc
  have hcle : ∀ i, c i ≤ 1 := fun i => by simp only [hc]; split_ifs <;> omega
  -- every edge of the cycle has two new vertices or none
  have hcnt : ∀ i : Fin 5, c i + c (i + 1) + c (i + 2) = 2 ∨ c i + c (i + 1) + c (i + 2) = 0 := by
    intro i
    obtain ⟨d1, d2, d3⟩ := fin5_distinct i
    have hcard := card_filter_triple (fun x : Fin (a + m) => (x : ℕ) < a)
      (f.injective.ne d1) (f.injective.ne d2) (f.injective.ne d3)
    rcases newCount_cases (hf i) with h | h
    · left; rw [hcard] at h; simpa only [hc] using h
    · right
      have h0 : (({f i, f (i + 1), f (i + 2)} : Finset (Fin (a + m))).filter
          (fun x : Fin (a + m) => (x : ℕ) < a)).card = 0 := by
        rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff]
        exact old_of_mem_oldPart h
      rw [hcard] at h0; simpa only [hc] using h0
  have k0 := hcnt 0
  have k1 := hcnt 1
  have k2 := hcnt 2
  have k3 := hcnt 3
  have k4 := hcnt 4
  simp only [Fin.isValue, Fin.reduceAdd] at k0 k1 k2 k3 k4
  obtain ⟨z0, z1, z2, z3, z4⟩ := fin5_count (c 0) (c 1) (c 2) (c 3) (c 4) (hcle 0) (hcle 1)
    (hcle 2) (hcle 3) (hcle 4) k0 k1 k2 k3 k4
  have hold : ∀ i, a ≤ ((f i : Fin (a + m)) : ℕ) := by
    intro i
    have hz : c i = 0 := by fin_cases i <;> assumption
    simp only [hc] at hz
    split_ifs at hz with h
    omega
  -- pull the cycle back to the old vertices
  let g : Fin 5 → Fin m := fun i => ⟨(f i : ℕ) - a, by have := (f i).2; have := hold i; omega⟩
  have hfg : ∀ i, Fin.natAddEmb a (g i) = f i := fun i => by
    apply Fin.ext; simp [g]; have := hold i; omega
  have ginj : Function.Injective g := fun i j hij => f.injective (by rw [← hfg i, ← hfg j, hij])
  apply hC
  refine ⟨⟨g, ginj⟩, fun i => ?_⟩
  have hmap : ({g i, g (i + 1), g (i + 2)} : Finset (Fin m)).map (Fin.natAddEmb a) =
      {f i, f (i + 1), f (i + 2)} := by
    simp only [Finset.map_insert, Finset.map_singleton, hfg]
  rcases newCount_cases (hf i) with h | h
  · exfalso
    obtain ⟨d1, d2, d3⟩ := fin5_distinct i
    rw [card_filter_triple (fun x : Fin (a + m) => (x : ℕ) < a) (f.injective.ne d1) (f.injective.ne d2) (f.injective.ne d3)] at h
    have := hold i; have := hold (i + 1); have := hold (i + 2)
    split_ifs at h <;> omega
  · obtain ⟨e', he', heq⟩ := mem_oldPart.mp h
    rw [← hmap] at heq
    simpa [Finset.map_inj.mp heq] using he'

/-- One step of the induction, with the vertex count `a + k`. -/
theorem construction_step {a k : ℕ} (ha1 : 1 ≤ a) (hlo : rho * ((a : ℝ) + k) ≤ a)
    (hhi : (a : ℝ) < rho * ((a : ℝ) + k) + 1) {H' : Finset (Finset (Fin k))}
    (hH' : IsThreeGraph H') (hC' : ¬ ContainsC5 H')
    (hcard' : turanL * (k : ℝ) ^ 3 - 2 * (k : ℝ) ^ 2 ≤ H'.card) :
    ∃ H : Finset (Finset (Fin (a + k))), IsThreeGraph H ∧ ¬ ContainsC5 H ∧
      turanL * ((a + k : ℕ) : ℝ) ^ 3 - 2 * ((a + k : ℕ) : ℝ) ^ 2 ≤ H.card := by
  refine ⟨extGraph a H', extGraph_three hH', extGraph_c5free hC', ?_⟩
  rw [extGraph_card]
  push_cast
  rw [Nat.cast_choose_two]
  have := lower_step (a := (a : ℝ)) (m := (k : ℝ)) (by exact_mod_cast ha1) (by positivity)
    hlo hhi
  linarith

/-- **The construction**: for every `n` a `C₅³`-free 3-graph on `Fin n` with
at least `L n³ − 2n²` edges. -/
theorem construction (n : ℕ) : ∃ H : Finset (Finset (Fin n)), IsThreeGraph H ∧
    ¬ ContainsC5 H ∧ turanL * (n : ℝ) ^ 3 - 2 * (n : ℝ) ^ 2 ≤ H.card := by
  induction n using Nat.strong_induction_on with
  | _ n ih =>
  rcases Nat.eq_zero_or_pos n with rfl | hn
  · refine ⟨∅, fun e he => absurd he (Finset.notMem_empty e), ?_, by simp⟩
    rintro ⟨f, hf⟩
    exact Finset.notMem_empty _ (hf 0)
  have hrho0 := rho_pos
  have hrho1 := rho_lt_one
  have hnR : (0 : ℝ) < n := by exact_mod_cast hn
  obtain ⟨a, ha_def⟩ : ∃ a, a = ⌈rho * n⌉₊ := ⟨_, rfl⟩
  have ha1 : 1 ≤ a := by
    rw [ha_def]
    exact Nat.one_le_iff_ne_zero.mpr
      (Nat.pos_iff_ne_zero.mp (Nat.ceil_pos.mpr (mul_pos hrho0 hnR)))
  have han : a ≤ n := by rw [ha_def]; exact Nat.ceil_le.mpr (by nlinarith)
  have hlo : rho * n ≤ a := by rw [ha_def]; exact Nat.le_ceil _
  have hhi : (a : ℝ) < rho * n + 1 := by rw [ha_def]; exact Nat.ceil_lt_add_one (by positivity)
  obtain ⟨H', hH', hC', hcard'⟩ := ih (n - a) (by omega)
  have hsum : a + (n - a) = n := by omega
  have hnR' : (n : ℝ) = (a : ℝ) + ((n - a : ℕ) : ℝ) := by
    rw [← Nat.cast_add, hsum]
  rw [hnR'] at hlo hhi
  have := construction_step ha1 hlo hhi hH' hC' hcard'
  rw [hsum] at this
  exact this

/-- Every `C₅³`-free 3-graph is a lower bound for `ex n`. -/
theorem card_le_ex {n : ℕ} {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H)
    (hC : ¬ ContainsC5 H) : H.card ≤ ex n := by
  classical
  unfold ex
  exact Finset.le_sup (f := Finset.card) (by simp [hH, hC])

/-- **The lower bound**: `ex n ≥ L n³ − 2n²`. -/
theorem ex_ge (n : ℕ) : turanL * (n : ℝ) ^ 3 - 2 * (n : ℝ) ^ 2 ≤ ex n := by
  obtain ⟨H, hH, hC, hcard⟩ := construction n
  exact hcard.trans (by exact_mod_cast card_le_ex hH hC)

end TightCycleC5
