import TripleDeletion
import LinkCancellative
import OutsideSums

/-! PROOF Lemma 1: common-subset CL rows with their finite diagonals.
The CL-3 and CL-4 inequalities are imported without changing their sources. -/

namespace TightCycleC5.Bridge

open Finset

variable {n : ℕ}

def clWeight (s : Finset (Fin n)) (a : Fin n) : ℝ := if a ∈ s then 1 else 0

def clCherry (strong : Bool) (H : Finset (Finset (Fin n))) (x a b c : Fin n) : Prop :=
  if strong then
    HelperD.Lk H x a b ∧ HelperD.Lk H x a c ∧ ¬ HelperD.Lk H x b c ∧
      ({a, b, c} : Finset (Fin n)) ∉ H
  else HelperD.Lk H x a b ∧ HelperD.Lk H x a c ∧ ¬ HelperD.Lk H x b c

instance (strong : Bool) (H : Finset (Finset (Fin n))) (x a b c : Fin n) :
    Decidable (clCherry strong H x a b c) := by
  unfold clCherry
  infer_instance

/-- This uses the same indicator weights at all three free vertices.
Strong=false is CL-3; strong=true includes CL-4's extra nonedge. -/
def clRow (strong : Bool) (H : Finset (Finset (Fin n))) (x : Fin n)
    (s : Finset (Fin n)) (a b c : Fin n) : ℝ :=
  (if clCherry strong H x a b c then clWeight s a * clWeight s b * clWeight s c else 0) -
    (if HelperD.K4 H x a b c then clWeight s a * clWeight s b * clWeight s c else 0)

theorem clRow_full_nonneg (strong : Bool) (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (x : Fin n) (s : Finset (Fin n)) :
    0 ≤ ∑ a, ∑ b, ∑ c, clRow strong H x s a b c := by
  have hw : ∀ a, 0 ≤ clWeight s a := by
    intro a
    unfold clWeight
    split_ifs <;> norm_num
  cases strong with
  | false =>
    have h := HelperD.cl3_link H hH hC x (clWeight s) hw
    simpa [clRow, clCherry, Finset.sum_sub_distrib] using sub_nonneg.mpr h
  | true =>
    have h := HelperD.cl4_link H hH hC x (clWeight s) hw
    simpa [clRow, clCherry, Finset.sum_sub_distrib] using sub_nonneg.mpr h

theorem three_graph_no_repeat {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H)
    (a b : Fin n) : ({a, b, b} : Finset (Fin n)) ∉ H := by
  intro h
  exact (HelperD.distinct_of_mem hH h).2.2 rfl

theorem three_graph_no_pair {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H)
    (a b : Fin n) : ({a, b} : Finset (Fin n)) ∉ H := by
  simpa using three_graph_no_repeat hH a b

theorem clRow_zero01 (strong : Bool) {H : Finset (Finset (Fin n))}
    (hH : IsThreeGraph H) (x : Fin n) (s : Finset (Fin n)) (a b : Fin n) :
    clRow strong H x s a a b = 0 := by
  cases strong <;>
    simp [clRow, clCherry, HelperD.K4, HelperD.Lk, three_graph_no_pair hH x a]

theorem clRow_zero02 (strong : Bool) {H : Finset (Finset (Fin n))}
    (hH : IsThreeGraph H) (x : Fin n) (s : Finset (Fin n)) (a b : Fin n) :
    clRow strong H x s a b a = 0 := by
  cases strong <;>
    simp [clRow, clCherry, HelperD.K4, HelperD.Lk, three_graph_no_pair hH x a]

theorem clRow_leaf_diagonal_le (strong : Bool) (H : Finset (Finset (Fin n)))
    (x : Fin n) (s : Finset (Fin n)) (a b : Fin n) :
    clRow strong H x s a b b ≤ 1 := by
  cases strong <;>
    simp [clRow, clCherry, HelperD.K4, HelperD.Lk, clWeight] <;>
    split_ifs <;> norm_num

theorem clRow_zero_of_not_mem01 (strong : Bool) (H : Finset (Finset (Fin n)))
    (x : Fin n) (s : Finset (Fin n)) {a : Fin n} (ha : a ∉ s) (b c : Fin n) :
    clRow strong H x s a b c = 0 := by simp [clRow, clWeight, ha]

theorem clRow_zero_of_not_mem02 (strong : Bool) (H : Finset (Finset (Fin n)))
    (x : Fin n) (s : Finset (Fin n)) (a : Fin n) {b : Fin n} (hb : b ∉ s) (c : Fin n) :
    clRow strong H x s a b c = 0 := by simp [clRow, clWeight, hb]

theorem clRow_zero_of_not_mem03 (strong : Bool) (H : Finset (Finset (Fin n)))
    (x : Fin n) (s : Finset (Fin n)) (a b : Fin n) {c : Fin n} (hc : c ∉ s) :
    clRow strong H x s a b c = 0 := by simp [clRow, clWeight, hc]

/-- The same full CL sum, now taken only over the common free vertex
space. The support condition supplies exactly the zero root weights. -/
theorem clRow_outside_nonneg {R : Type*} (root : R ↪ Fin n) (strong : Bool)
    (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H)
    (x : Fin n) (s : Finset (Fin n)) (hs : ∀ a ∈ s, a ∉ Set.range root) :
    0 ≤ ∑ a : Outside root, ∑ b : Outside root, ∑ c : Outside root,
      clRow strong H x s a.val b.val c.val := by
  have hz : ∀ a, a ∈ Set.range root → a ∉ s := fun a ha h => hs a h ha
  have he := sum3_outside_support root (clRow strong H x s)
    (fun a ha b c => clRow_zero_of_not_mem01 strong H x s (hz a ha) b c)
    (fun a b hb c => clRow_zero_of_not_mem02 strong H x s a (hz b hb) c)
    (fun a b c hc => clRow_zero_of_not_mem03 strong H x s a b (hz c hc))
  rw [he]
  exact clRow_full_nonneg strong H hH hC x s

/-- Lemma 1 conditioned on three fixed injective roots: the leaf
diagonal has not been dropped. Both CL-3 and CL-4 have the same bound. -/
theorem clRow_free_mean_lower (strong : Bool) (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (hn : 12 ≤ n)
    (root : Fin 3 ↪ Fin n) (s : Finset (Fin n)) (hs : ∀ a ∈ s, a ∉ Set.range root) :
    -(1 / ((n : ℝ) - 5)) ≤ uniformMean (fun free : Fin 3 ↪ Outside root =>
      clRow strong H (root 0) s (free 0).val (free 1).val (free 2).val) := by
  classical
  have hcard : Fintype.card (Outside root) = n - 3 := by
    simpa only [Fintype.card_fin] using outside_card root
  have hk : 3 ≤ Fintype.card (Outside root) := by rw [hcard]; omega
  have h := distinct_triple_mean_lower
    (fun a b c : Outside root => clRow strong H (root 0) s a.val b.val c.val) hk
    (fun a b => clRow_zero01 strong hH (root 0) s a.val b.val)
    (fun a b => clRow_zero02 strong hH (root 0) s a.val b.val)
    (fun a b _ => clRow_leaf_diagonal_le strong H (root 0) s a.val b.val)
    (clRow_outside_nonneg root strong H hH hC (root 0) s hs)
  have hcardR : (Fintype.card (Outside root) : ℝ) = (n : ℝ) - 3 := by
    rw [hcard, Nat.cast_sub (by omega : 3 ≤ n)]
    norm_num
  simpa only [hcardR, sub_sub, show (3 : ℝ) + 2 = 5 by norm_num] using h

/-- The labelled row of Lemma 1, sampled by an actual uniform injection
of six vertices. Common subsets and root indicators may depend on all
three ordered roots, but not on the free vertices being sampled. -/
noncomputable def clSixRow (strong : Bool) (H : Finset (Finset (Fin n)))
    (s : (Fin 3 ↪ Fin n) → Finset (Fin n)) (g : (Fin 3 ↪ Fin n) → ℝ)
    (σ : Fin 6 ↪ Fin n) : ℝ :=
  let rf := splitSampleEquiv (r := 3) (f := 3) σ
  g rf.1 * clRow strong H (rf.1 0) (s rf.1) (rf.2 0).val (rf.2 1).val (rf.2 2).val

/-- The full uniform finite CL bound from PROOF §3 Lemma 1.
No certificate row or class-cover hypothesis is used here. -/
theorem cl_six_row_lower (strong : Bool) (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (hn : 12 ≤ n)
    (s : (Fin 3 ↪ Fin n) → Finset (Fin n))
    (hs : ∀ root a, a ∈ s root → a ∉ Set.range root)
    (g : (Fin 3 ↪ Fin n) → ℝ) (hg : ∀ root, g root = 0 ∨ g root = 1) :
    -(1 / ((n : ℝ) - 5)) ≤ uniformMean (clSixRow strong H s g) := by
  classical
  letI : Nonempty (Fin 3 ↪ Fin n) := ⟨Fin.castLEEmb (by omega : 3 ≤ n)⟩
  rw [uniformMean_joinSample (r := 3) (f := 3)]
  simp only [clSixRow, splitSampleEquiv_join]
  apply root_mean_lower
  intro root
  rw [uniformMean_const_mul]
  apply root_indicator_lower _ (clRow_free_mean_lower strong H hH hC hn root (s root) (hs root))
    (hg root)
  apply neg_nonpos.mpr
  apply div_nonneg (by norm_num)
  have hnR : (12 : ℝ) ≤ n := by exact_mod_cast hn
  linarith

#print axioms clRow_full_nonneg
#print axioms three_graph_no_repeat
#print axioms three_graph_no_pair
#print axioms clRow_zero01
#print axioms clRow_zero02
#print axioms clRow_leaf_diagonal_le
#print axioms clRow_zero_of_not_mem01
#print axioms clRow_zero_of_not_mem02
#print axioms clRow_zero_of_not_mem03
#print axioms clRow_outside_nonneg
#print axioms clRow_free_mean_lower
#print axioms cl_six_row_lower

end TightCycleC5.Bridge
