import KernelShard8Blocks0
import KernelShard8Blocks1
import KernelShard8Blocks2
import KernelShard8Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard8 : kernelShardCheck 8 kernelWitness8 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (8 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness8 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_8_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard8
end TightCycleC5.Bridge.Cover
