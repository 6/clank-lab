import SixSampling
import CLRows

/-! Exact ordered-pair incidence counts underlying PROOF Lemmas 5–7. -/
namespace TightCycleC5.Bridge
open Finset

noncomputable def rootPairFiber {A : Type*} [Fintype A] [DecidableEq A]
    (x : A) (e : Finset A) : Finset (A × A) :=
  open Classical in univ.filter (fun p => ({x, p.1, p.2} : Finset A) = e)

theorem rootPairFiber_card {A : Type*} [Fintype A] [DecidableEq A]
    (x : A) (e : Finset A) (h3 : e.card = 3) :
    (rootPairFiber x e).card = if x ∈ e then 2 else 0 := by
  classical
  by_cases hx : x ∈ e
  · obtain ⟨b, c, hbc, he⟩ := card_eq_two.mp (show (e.erase x).card = 2 by
      rw [card_erase_of_mem hx, h3])
    have hbx : b ≠ x := (mem_erase.mp (show b ∈ e.erase x by rw [he]; simp)).1
    have hcx : c ≠ x := (mem_erase.mp (show c ∈ e.erase x by rw [he]; simp)).1
    have he' : e = {x, b, c} := by rw [← insert_erase hx, he]
    have hf : rootPairFiber x e = {(b, c), (c, b)} := by
      ext p
      rcases p with ⟨u, v⟩
      constructor
      · intro hp
        have hp' : ({x, u, v} : Finset A) = e := (mem_filter.mp hp).2
        have hd := card_triple_eq_three_iff.mp (show ({x, u, v} : Finset A).card = 3 by
          rw [hp', h3])
        have hu : u = b ∨ u = c := by
          have hu : u ∈ e := hp' ▸ (by simp)
          rw [he'] at hu
          simp only [mem_insert, mem_singleton] at hu
          exact hu.resolve_left hd.1.symm
        have hv : v = b ∨ v = c := by
          have hv : v ∈ e := hp' ▸ (by simp)
          rw [he'] at hv
          simp only [mem_insert, mem_singleton] at hv
          exact hv.resolve_left hd.2.1.symm
        rcases hu with rfl | rfl
        · rcases hv with rfl | rfl
          · exact False.elim (hd.2.2 rfl)
          · exact mem_insert_self _ _
        · rcases hv with rfl | rfl
          · exact mem_insert_of_mem (mem_singleton_self _)
          · exact False.elim (hd.2.2 rfl)
      · intro hp
        simp only [mem_insert, mem_singleton, Prod.mk.injEq] at hp
        rcases hp with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩
        · exact mem_filter.mpr ⟨mem_univ _, he'.symm⟩
        · apply mem_filter.mpr ⟨mem_univ _, ?_⟩
          rw [he']
          ext z
          simp only [mem_insert, mem_singleton]
          tauto
    rw [hf]
    simp [hx, hbc, hbc.symm]
  · have hf : rootPairFiber x e = ∅ := by
      apply Finset.eq_empty_iff_forall_notMem.mpr
      intro p hp
      have hp' := (mem_filter.mp hp).2
      exact hx (hp' ▸ (by simp))
    simp [hf, hx]

/-- Every three-edge containing x occurs exactly twice in the sum over
ordered pairs of its other vertices; edges avoiding x occur zero times. -/
theorem root_pair_sum {n : ℕ} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (x : Fin n) (f : Finset (Fin n) → ℝ) :
    (∑ u, ∑ v, if ({x, u, v} : Finset (Fin n)) ∈ H then f {x, u, v} else 0) =
      2 * ∑ e ∈ H.filter (fun e => x ∈ e), f e := by
  classical
  have hp : ∀ p : Fin n × Fin n,
      (if ({x, p.1, p.2} : Finset (Fin n)) ∈ H then f {x, p.1, p.2} else 0) =
      ∑ e ∈ H, if ({x, p.1, p.2} : Finset (Fin n)) = e then f e else 0 := by
    intro p
    simp [eq_comm]
  rw [← Fintype.sum_prod_type (fun p : Fin n × Fin n =>
    if ({x, p.1, p.2} : Finset (Fin n)) ∈ H then f {x, p.1, p.2} else 0)]
  simp_rw [hp]
  rw [Finset.sum_comm]
  have hf : ∀ e ∈ H,
      (∑ p : Fin n × Fin n, if ({x, p.1, p.2} : Finset (Fin n)) = e then f e else 0) =
      (if x ∈ e then 2 else 0) * f e := by
    intro e he
    have hs : (∑ p : Fin n × Fin n,
        if ({x, p.1, p.2} : Finset (Fin n)) = e then f e else 0) =
        ∑ _p ∈ rootPairFiber x e, f e := by
      simp only [rootPairFiber, Finset.sum_filter]
    rw [hs, Finset.sum_const, nsmul_eq_mul, rootPairFiber_card x e (hH e he)]
    split_ifs <;> norm_num
  rw [Finset.sum_congr rfl hf, sum_filter, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro e _
  split_ifs <;> ring

theorem root_pair_degree {n : ℕ} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (x : Fin n) :
    (∑ u, ∑ v, if ({x, u, v} : Finset (Fin n)) ∈ H then (1 : ℝ) else 0) =
      2 * (deg H x : ℝ) := by
  simpa only [Finset.sum_const, nsmul_eq_mul, mul_one, deg] using
    root_pair_sum H hH x (fun _ => (1 : ℝ))

#print axioms root_pair_degree
#print axioms rootPairFiber_card
#print axioms root_pair_sum
end TightCycleC5.Bridge
