import P33FlagEncoding
import FlagRows

/-! Literal ordered full traces, specialized to P33's exact labelled positions.
Absent basis codes give zero through the generic optional lookup theorem. -/
namespace TightCycleC5.Bridge.P33Flag
open Finset Matrix ColouredFlags

noncomputable def pairRow {d : ℕ} (Q : Matrix (Fin d) (Fin d) ℝ)
    (code : Fin d → ℕ) (typ : ℕ) (G : LabelledStructure 6) : ℝ :=
  (if pairType G = typ then 1 else 0) *
    (∑ i, ∑ j, Q i j *
      (if canonical4 (raw4 G.edge G.color pairLeft) = code i then 1 else 0) *
      (if canonical4 (raw4 G.edge G.color pairRight) = code j then 1 else 0))

noncomputable def fourRow {d : ℕ} (Q : Matrix (Fin d) (Fin d) ℝ)
    (code : Fin d → ℕ) (typ : ℕ) (G : LabelledStructure 6) : ℝ :=
  (if fourType G = typ then 1 else 0) *
    (∑ i, ∑ j, Q i j *
      (if (raw5 G.edge G.color fourLeft).toNat = code i then 1 else 0) *
      (if (raw5 G.edge G.color fourRight).toNat = code j then 1 else 0))

theorem pair_row_eq {d n : ℕ} (Q : Matrix (Fin d) (Fin d) ℝ)
    (code : Fin d → ℕ) (hinj : Function.Injective code) (typ : ℕ)
    (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => pairRow Q code typ (sampleStructure σ H S)) =
      psdTwoRootSixRow (zeroExtend Q)
        (fun root p => flagLookup code (pairKey H S root p)) (pairIndicator typ S) := by
  funext σ
  simp only [pairRow, psdTwoRootSixRow]
  rw [pairIndicator_sample typ H S σ, flag_indicator_trace Q code hinj]
  simp only [pairKey, split_pair_left, split_pair_right, raw4_sample]

theorem four_row_eq {d n : ℕ} (Q : Matrix (Fin d) (Fin d) ℝ)
    (code : Fin d → ℕ) (hinj : Function.Injective code) (typ : ℕ)
    (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => fourRow Q code typ (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend Q)
        (fun root a => flagLookup code (fourKey H S root a)) (fourIndicator typ H S) := by
  funext σ
  simp only [fourRow, psdFourRootSixRow]
  rw [fourIndicator_sample typ H S σ, flag_indicator_trace Q code hinj]
  simp only [fourKey, split_four_left, split_four_right, raw5_sample]

theorem pair_row_lower {d n : ℕ} {Q : Matrix (Fin d) (Fin d) ℝ}
    (hQ : Q.PosSemidef) {m : ℝ} (hm : 0 ≤ m) (hdiag : ∀ i, Q i i ≤ m)
    (hn : 12 ≤ n) (code : Fin d → ℕ) (hinj : Function.Injective code)
    (typ : ℕ) (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    -((4 * (n : ℝ) - 14) * m / (((n : ℝ) - 4) * ((n : ℝ) - 5))) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => pairRow Q code typ (sampleStructure σ H S)) := by
  rw [pair_row_eq Q code hinj typ H S]
  exact flag_optional_two_root_six_row_lower hQ hm hdiag hn _ _ (pairIndicator_zero_one typ S)

theorem four_row_lower {d n : ℕ} {Q : Matrix (Fin d) (Fin d) ℝ}
    (hQ : Q.PosSemidef) {m : ℝ} (hm : 0 ≤ m) (hdiag : ∀ i, Q i i ≤ m)
    (hn : 12 ≤ n) (code : Fin d → ℕ) (hinj : Function.Injective code)
    (typ : ℕ) (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    -m / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => fourRow Q code typ (sampleStructure σ H S)) := by
  rw [four_row_eq Q code hinj typ H S]
  exact flag_optional_four_root_six_row_lower hQ hm hdiag hn _ _ (fourIndicator_zero_one typ H S)

#print axioms pair_row_eq
#print axioms four_row_eq
#print axioms pair_row_lower
#print axioms four_row_lower
end TightCycleC5.Bridge.P33Flag
