import KernelShard0Blocks0
import KernelShard0Blocks1
import KernelShard0Blocks2
import KernelShard0Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard0 : kernelShardCheck 0 kernelWitness0 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (0 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness0 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_0_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard0
end TightCycleC5.Bridge.Cover
