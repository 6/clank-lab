import FiniteErrors
import BLLP

/-! Quantified final assembly in PROOF Theorem B. The normalized
certificate-derived graph bound is an explicit remaining hypothesis. -/
namespace TightCycleC5.Bridge

theorem bad_miss_of_normalized_bound {n : Nat} (hn : 12 ≤ n) {ξ : ℝ}
    (hξ : 0 < ξ) (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hbound : ((badCount H S : ℝ) - missCount H S) / (n.choose 3 : ℝ) ≤ 2 * ξ) :
    (badCount H S : ℝ) - missCount H S ≤ ξ * (n : ℝ) ^ 3 := by
  have hCpos : (0 : ℝ) < n.choose 3 := by
    exact_mod_cast Nat.choose_pos (by omega : 3 ≤ n)
  have h := (div_le_iff₀ hCpos).mp hbound
  have hc := mul_le_mul_of_nonneg_left (choose3_le n) (by positivity : 0 ≤ 2 * ξ)
  have hn0 : (0 : ℝ) ≤ n := Nat.cast_nonneg _
  nlinarith [pow_nonneg hn0 3]

/-- PARTIAL assembly. A,B,C must be actual certificate constants and
the displayed uniform graph inequality must still be proved. This
bound is not asserted for the frozen certificate here. -/
theorem p33_of_uniform_normalized_bound
    (hcertificate : ∃ A B C : ℝ, 0 ≤ A ∧ 0 ≤ B ∧ 0 ≤ C ∧ ∃ N₀ : Nat,
      ∀ n ≥ N₀, ∀ δ > (0 : ℝ),
      ∀ (H : Finset (Finset (Fin n))) (S : Finset (Fin n)),
      IsThreeGraph H → ¬ ContainsC5 H → LocallyMaximal H S →
      (∀ u v, (deg H u : ℝ) ≤ deg H v + δ * (n : ℝ) ^ 2) →
      (2 / 5 - δ) * (n.choose 3 : ℝ) ≤ (cutCount H S : ℝ) →
      (464101615 / 10 ^ 9 - δ) * (n.choose 3 : ℝ) ≤ (H.card : ℝ) →
      ((badCount H S : ℝ) - missCount H S) / (n.choose 3 : ℝ) ≤
        (A + B / (n : ℝ)) * δ + C / (n : ℝ)) : P33Statement := by
  intro ξ hξ
  obtain ⟨A, B, C, hA, hB, hC, N₀, hcert⟩ := hcertificate
  let δ : ℝ := min 1 (ξ / (A + 1))
  have hA1 : 0 < A + 1 := by linarith
  have hδ : 0 < δ := lt_min (by norm_num) (div_pos hξ hA1)
  have hδξ : (A + 1) * δ ≤ ξ := by
    have h := min_le_right (1 : ℝ) (ξ / (A + 1))
    have h' := (le_div_iff₀ hA1).mp h
    simpa [δ, mul_comm] using h'
  obtain ⟨M, hM⟩ := exists_nat_gt (max B (C / ξ))
  refine ⟨δ, hδ, max 12 (max N₀ M), ?_⟩
  intro n hn H S hH hC5 hlocal hreg hcut hdensity
  have hn12 : 12 ≤ n := le_trans (le_max_left _ _) hn
  have hnN : N₀ ≤ n := le_trans (le_trans (le_max_left _ _) (le_max_right _ _)) hn
  have hnM : M ≤ n := le_trans (le_trans (le_max_right _ _) (le_max_right _ _)) hn
  have hnR : (0 : ℝ) < n := by exact_mod_cast (by omega : 0 < n)
  have hMn : (M : ℝ) ≤ n := by exact_mod_cast hnM
  have hBn : B ≤ (n : ℝ) := le_trans (le_max_left _ _) (le_trans hM.le hMn)
  have hCn : C / ξ ≤ (n : ℝ) := le_trans (le_max_right _ _) (le_trans hM.le hMn)
  have hBratio : B / (n : ℝ) ≤ 1 := (div_le_one hnR).2 hBn
  have hCratio : C / (n : ℝ) ≤ ξ := by
    apply (div_le_iff₀ hnR).2
    have h := (div_le_iff₀ hξ).mp hCn
    nlinarith
  have hcoeff : (A + B / (n : ℝ)) * δ ≤ ξ := by
    have h := mul_le_mul_of_nonneg_right (show A + B / (n : ℝ) ≤ A + 1 by linarith) hδ.le
    linarith
  apply bad_miss_of_normalized_bound hn12 hξ H S
  have h := hcert n hnN δ hδ H S hH hC5 hlocal hreg hcut hdensity
  linarith

#print axioms bad_miss_of_normalized_bound
#print axioms p33_of_uniform_normalized_bound
end TightCycleC5.Bridge
