import P32ArithmeticCore
namespace TightCycleC5.Bridge.P32Arithmetic
set_option maxHeartbeats 0
theorem class_group52 : ∀ j : Fin 3, ClassStatement
    ⟨832 + j.val, by have := j.isLt; omega⟩ := by native_decide
#print axioms class_group52
end TightCycleC5.Bridge.P32Arithmetic
