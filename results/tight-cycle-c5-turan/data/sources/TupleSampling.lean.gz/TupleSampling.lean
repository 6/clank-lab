import InjectionSampling
import PSDCollision

/-! Exact correspondences between free injections and distinct tuple
sampling spaces. All tuples are ordered; no symmetry quotient is used. -/

namespace TightCycleC5.Bridge

open Finset

variable {A : Type*} [Fintype A] [DecidableEq A]

/-- Recover roots and free vertices from their joined labelled sample. -/
def splitSampleEquiv {r f n : ℕ} :
    (Fin (r + f) ↪ Fin n) ≃ (Σ root : Fin r ↪ Fin n, Fin f ↪ Outside root) :=
  (Equiv.embeddingCongr finSumFinEquiv.symm (Equiv.refl _)).trans splitEmbeddingEquiv

@[simp] theorem splitSampleEquiv_join {r f n : ℕ} (root : Fin r ↪ Fin n)
    (free : Fin f ↪ Outside root) : splitSampleEquiv (joinSample root free) = ⟨root, free⟩ := by
  exact splitSampleEquiv.apply_symm_apply ⟨root, free⟩

theorem joinSample_split {r f n : ℕ} (σ : Fin (r + f) ↪ Fin n) :
    joinSample (splitSampleEquiv σ).1 (splitSampleEquiv σ).2 = σ := by
  exact splitSampleEquiv.symm_apply_apply σ

/-- Distinct ordered triples from s, represented as a nested product. -/
def distinctTriples (s : Finset A) : Finset (A × A × A) :=
  (s ×ˢ (s ×ˢ s)).filter (fun t => t.1 ≠ t.2.1 ∧ t.1 ≠ t.2.2 ∧ t.2.1 ≠ t.2.2)

def embeddingPairEquiv : (Fin 2 ↪ A) ≃ ((univ : Finset A).offDiag) where
  toFun σ := ⟨(σ 0, σ 1), by
    simp only [mem_offDiag, mem_univ, true_and]
    exact σ.injective.ne (by decide)⟩
  invFun p := ⟨![p.val.1, p.val.2], by
    have hp := (mem_offDiag.mp p.property).2.2
    intro i j h
    fin_cases i <;> fin_cases j <;> simp_all⟩
  left_inv σ := by
    ext i
    fin_cases i <;> rfl
  right_inv p := by
    apply Subtype.ext
    rfl

def embeddingTripleEquiv : (Fin 3 ↪ A) ≃ distinctTriples (univ : Finset A) where
  toFun σ := ⟨(σ 0, σ 1, σ 2), by
    simp only [distinctTriples, mem_filter, mem_product, mem_univ, true_and]
    exact ⟨σ.injective.ne (by decide), σ.injective.ne (by decide), σ.injective.ne (by decide)⟩⟩
  invFun t := ⟨![t.val.1, t.val.2.1, t.val.2.2], by
    have ht := t.property
    simp only [distinctTriples, mem_filter, mem_product, mem_univ, true_and] at ht
    intro i j h
    fin_cases i <;> fin_cases j <;> simp_all⟩
  left_inv σ := by
    ext i
    fin_cases i <;> rfl
  right_inv t := by
    apply Subtype.ext
    rfl

def embeddingQuadEquiv : (Fin 4 ↪ A) ≃ disjointPairs (univ : Finset A) where
  toFun σ := ⟨((σ 0, σ 1), (σ 2, σ 3)), by
    simp only [disjointPairs, mem_filter, mem_product, mem_offDiag, mem_univ, true_and, Apart]
    exact ⟨⟨σ.injective.ne (by decide), σ.injective.ne (by decide)⟩,
      σ.injective.ne (by decide), σ.injective.ne (by decide),
      σ.injective.ne (by decide), σ.injective.ne (by decide)⟩⟩
  invFun t := ⟨![t.val.1.1, t.val.1.2, t.val.2.1, t.val.2.2], by
    have ht := t.property
    simp only [disjointPairs, mem_filter, mem_product, mem_offDiag, mem_univ, true_and, Apart] at ht
    intro i j h
    fin_cases i <;> fin_cases j <;> simp_all⟩
  left_inv σ := by
    ext i
    fin_cases i <;> rfl
  right_inv t := by
    apply Subtype.ext
    rfl

omit [Fintype A] [DecidableEq A] in
/-- Uniform subtype sampling is the corresponding finite-set average. -/
theorem uniformMean_finset (s : Finset A) (v : A → ℝ) :
    uniformMean (fun a : s => v a) = (∑ a ∈ s, v a) / (s.card : ℝ) := by
  simp only [uniformMean, Finset.sum_coe_sort, Fintype.card_coe]

omit [DecidableEq A] in
theorem pair_injection_mean (v : A → A → ℝ) :
    uniformMean (fun σ : Fin 2 ↪ A => v (σ 0) (σ 1)) =
      (∑ p ∈ (univ : Finset A).offDiag, v p.1 p.2) /
        ((univ : Finset A).offDiag.card : ℝ) := by
  have h := uniformMean_equiv_between (embeddingPairEquiv (A := A))
    (fun p => v p.val.1 p.val.2)
  exact h.trans (uniformMean_finset _ (fun p : A × A => v p.1 p.2))

theorem triple_injection_mean (v : A → A → A → ℝ) :
    uniformMean (fun σ : Fin 3 ↪ A => v (σ 0) (σ 1) (σ 2)) =
      (∑ t ∈ distinctTriples (univ : Finset A), v t.1 t.2.1 t.2.2) /
        ((distinctTriples (univ : Finset A)).card : ℝ) := by
  have h := uniformMean_equiv_between (embeddingTripleEquiv (A := A))
    (fun t => v t.val.1 t.val.2.1 t.val.2.2)
  exact h.trans (uniformMean_finset _ (fun t : A × A × A => v t.1 t.2.1 t.2.2))

theorem quad_injection_mean (v : (A × A) → (A × A) → ℝ) :
    uniformMean (fun σ : Fin 4 ↪ A => v (σ 0, σ 1) (σ 2, σ 3)) =
      (∑ t ∈ disjointPairs (univ : Finset A), v t.1 t.2) /
        ((disjointPairs (univ : Finset A)).card : ℝ) := by
  have h := uniformMean_equiv_between (embeddingQuadEquiv (A := A))
    (fun t => v t.val.1 t.val.2)
  exact h.trans (uniformMean_finset _ (fun t : (A × A) × (A × A) => v t.1 t.2))

/-- Exact ordered-triple denominator, not an asymptotic replacement. -/
theorem distinctTriples_card_real (hk : 3 ≤ Fintype.card A) :
    ((distinctTriples (univ : Finset A)).card : ℝ) =
      (Fintype.card A : ℝ) * ((Fintype.card A : ℝ) - 1) * ((Fintype.card A : ℝ) - 2) := by
  have he := Fintype.card_congr (embeddingTripleEquiv (A := A))
  simp only [Fintype.card_coe, Fintype.card_embedding_eq, Fintype.card_fin] at he
  rw [← he, Nat.descFactorial_succ, Nat.descFactorial_succ, Nat.descFactorial_succ]
  simp only [Nat.descFactorial_zero, Nat.sub_zero, mul_one, Nat.cast_mul,
    Nat.cast_sub (by omega : 2 ≤ Fintype.card A), Nat.cast_sub (by omega : 1 ≤ Fintype.card A)]
  norm_num
  ring

#print axioms uniformMean_finset
#print axioms splitSampleEquiv_join
#print axioms joinSample_split
#print axioms pair_injection_mean
#print axioms triple_injection_mean
#print axioms quad_injection_mean
#print axioms distinctTriples_card_real

end TightCycleC5.Bridge
