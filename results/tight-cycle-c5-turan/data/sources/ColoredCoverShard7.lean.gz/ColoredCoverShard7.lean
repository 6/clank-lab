import ColoredCoverSemantics

namespace TightCycleC5.Bridge.ColoredCover
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def coloredWitness224 : Array Nat := #[7244640, 7245360, 7246080, 7246800, 7247520, 7248240, 7248960, 7249680, 7250400, 7251120, 7251840, 7252560, 7253280, 7254000, 7254720, 7255440, 7256160, 7256880, 7257600, 7258320, 7259040, 7259760, 7260480, 7261200, 7261920, 7262640, 7263360, 7264080, 7264800, 7265520, 7266240, 7266960, 7267680, 7268400, 7269120, 7269840, 7270560, 7271280, 7272000, 7272720, 7273440, 7274160, 7274880, 7275600, 7276320, 7277040, 7277760, 7278480, 7279200, 7279920, 7280640, 7281360, 7282080, 7282800, 7283520, 7284240, 7284960, 7285680, 7286400, 7287120, 7287840, 7288560, 7289280, 7290000]

theorem colored_row224 : ∀ c : Fin 64,
    readRow witnessRows (224 * 64 + c.val) = coloredWitness224[c.val]! := by
  decide +kernel
#print axioms colored_row224

theorem colored_check224 : ∀ c : Fin 64,
    checkColored 224 (BitVec.ofNat 6 c.val) (coloredWitness224[c.val]!) = true := by
  decide +kernel
#print axioms colored_check224

theorem colored_family224 : ∀ c : Fin 64,
    checkColored 224 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (224 * 64 + c.val)) = true := by
  intro c
  rw [colored_row224]
  exact colored_check224 c
#print axioms colored_family224

def coloredWitness225 : Array Nat := #[7290720, 7291440, 7292160, 7292880, 7293600, 7294320, 7295040, 7295760, 7296480, 7297200, 7297920, 7298640, 7299360, 7300080, 7300800, 7301520, 7302240, 7302960, 7303680, 7304400, 7305120, 7305840, 7306560, 7307280, 7308000, 7308720, 7309440, 7310160, 7310880, 7311600, 7312320, 7313040, 7313760, 7314480, 7315200, 7315920, 7316640, 7317360, 7318080, 7318800, 7319520, 7320240, 7320960, 7321680, 7322400, 7323120, 7323840, 7324560, 7325280, 7326000, 7326720, 7327440, 7328160, 7328880, 7329600, 7330320, 7331040, 7331760, 7332480, 7333200, 7333920, 7334640, 7335360, 7336080]

theorem colored_row225 : ∀ c : Fin 64,
    readRow witnessRows (225 * 64 + c.val) = coloredWitness225[c.val]! := by
  decide +kernel
#print axioms colored_row225

theorem colored_check225 : ∀ c : Fin 64,
    checkColored 225 (BitVec.ofNat 6 c.val) (coloredWitness225[c.val]!) = true := by
  decide +kernel
#print axioms colored_check225

theorem colored_family225 : ∀ c : Fin 64,
    checkColored 225 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (225 * 64 + c.val)) = true := by
  intro c
  rw [colored_row225]
  exact colored_check225 c
#print axioms colored_family225

def coloredWitness226 : Array Nat := #[7336800, 7337520, 7338240, 7338960, 7339680, 7340400, 7341120, 7341840, 7342560, 7343280, 7344000, 7344720, 7345440, 7346160, 7346880, 7347600, 7348320, 7349040, 7349760, 7350480, 7351200, 7351920, 7352640, 7353360, 7354080, 7354800, 7355520, 7356240, 7356960, 7357680, 7358400, 7359120, 7359840, 7360560, 7361280, 7362000, 7362720, 7363440, 7364160, 7364880, 7365600, 7366320, 7367040, 7367760, 7368480, 7369200, 7369920, 7370640, 7371360, 7372080, 7372800, 7373520, 7374240, 7374960, 7375680, 7376400, 7377120, 7377840, 7378560, 7379280, 7380000, 7380720, 7381440, 7382160]

theorem colored_row226 : ∀ c : Fin 64,
    readRow witnessRows (226 * 64 + c.val) = coloredWitness226[c.val]! := by
  decide +kernel
#print axioms colored_row226

theorem colored_check226 : ∀ c : Fin 64,
    checkColored 226 (BitVec.ofNat 6 c.val) (coloredWitness226[c.val]!) = true := by
  decide +kernel
#print axioms colored_check226

theorem colored_family226 : ∀ c : Fin 64,
    checkColored 226 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (226 * 64 + c.val)) = true := by
  intro c
  rw [colored_row226]
  exact colored_check226 c
#print axioms colored_family226

def coloredWitness227 : Array Nat := #[7382880, 7383600, 7384320, 7385040, 7385760, 7386480, 7387200, 7387920, 7388640, 7389360, 7390080, 7390800, 7391520, 7392240, 7392960, 7393680, 7394400, 7395120, 7395840, 7396560, 7397280, 7398000, 7398720, 7399440, 7400160, 7400880, 7401600, 7402320, 7403040, 7403760, 7404480, 7405200, 7405920, 7406640, 7407360, 7408080, 7408800, 7409520, 7410240, 7410960, 7411680, 7412400, 7413120, 7413840, 7414560, 7415280, 7416000, 7416720, 7417440, 7418160, 7418880, 7419600, 7420320, 7421040, 7421760, 7422480, 7423200, 7423920, 7424640, 7425360, 7426080, 7426800, 7427520, 7428240]

theorem colored_row227 : ∀ c : Fin 64,
    readRow witnessRows (227 * 64 + c.val) = coloredWitness227[c.val]! := by
  decide +kernel
#print axioms colored_row227

theorem colored_check227 : ∀ c : Fin 64,
    checkColored 227 (BitVec.ofNat 6 c.val) (coloredWitness227[c.val]!) = true := by
  decide +kernel
#print axioms colored_check227

theorem colored_family227 : ∀ c : Fin 64,
    checkColored 227 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (227 * 64 + c.val)) = true := by
  intro c
  rw [colored_row227]
  exact colored_check227 c
#print axioms colored_family227

def coloredWitness228 : Array Nat := #[7428960, 7429680, 7430400, 7431120, 7431840, 7432560, 7433280, 7434000, 7434720, 7435440, 7436160, 7436880, 7437600, 7438320, 7439040, 7439760, 7440480, 7441200, 7441920, 7442640, 7443360, 7444080, 7444800, 7445520, 7446240, 7446960, 7447680, 7448400, 7449120, 7449840, 7450560, 7451280, 7452000, 7452720, 7453440, 7454160, 7454880, 7455600, 7456320, 7457040, 7457760, 7458480, 7459200, 7459920, 7460640, 7461360, 7462080, 7462800, 7463520, 7464240, 7464960, 7465680, 7466400, 7467120, 7467840, 7468560, 7469280, 7470000, 7470720, 7471440, 7472160, 7472880, 7473600, 7474320]

theorem colored_row228 : ∀ c : Fin 64,
    readRow witnessRows (228 * 64 + c.val) = coloredWitness228[c.val]! := by
  decide +kernel
#print axioms colored_row228

theorem colored_check228 : ∀ c : Fin 64,
    checkColored 228 (BitVec.ofNat 6 c.val) (coloredWitness228[c.val]!) = true := by
  decide +kernel
#print axioms colored_check228

theorem colored_family228 : ∀ c : Fin 64,
    checkColored 228 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (228 * 64 + c.val)) = true := by
  intro c
  rw [colored_row228]
  exact colored_check228 c
#print axioms colored_family228

def coloredWitness229 : Array Nat := #[7475040, 7475760, 7476480, 7477200, 7477920, 7478640, 7479360, 7480080, 7480800, 7481520, 7482240, 7482960, 7483680, 7484400, 7485120, 7485840, 7486560, 7487280, 7488000, 7488720, 7489440, 7490160, 7490880, 7491600, 7492320, 7493040, 7493760, 7494480, 7495200, 7495920, 7496640, 7497360, 7498080, 7498800, 7499520, 7500240, 7500960, 7501680, 7502400, 7503120, 7503840, 7504560, 7505280, 7506000, 7506720, 7507440, 7508160, 7508880, 7509600, 7510320, 7511040, 7511760, 7512480, 7513200, 7513920, 7514640, 7515360, 7516080, 7516800, 7517520, 7518240, 7518960, 7519680, 7520400]

theorem colored_row229 : ∀ c : Fin 64,
    readRow witnessRows (229 * 64 + c.val) = coloredWitness229[c.val]! := by
  decide +kernel
#print axioms colored_row229

theorem colored_check229 : ∀ c : Fin 64,
    checkColored 229 (BitVec.ofNat 6 c.val) (coloredWitness229[c.val]!) = true := by
  decide +kernel
#print axioms colored_check229

theorem colored_family229 : ∀ c : Fin 64,
    checkColored 229 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (229 * 64 + c.val)) = true := by
  intro c
  rw [colored_row229]
  exact colored_check229 c
#print axioms colored_family229

def coloredWitness230 : Array Nat := #[7521120, 7521840, 7522560, 7523280, 7522584, 7523304, 7524000, 7524720, 7525440, 7526160, 7526880, 7527600, 7526904, 7527624, 7528320, 7529040, 7529760, 7530480, 7531200, 7531920, 7531224, 7531944, 7532640, 7533360, 7534080, 7534800, 7535520, 7536240, 7535544, 7536264, 7536960, 7537680, 7538400, 7539120, 7539840, 7540560, 7539864, 7540584, 7541280, 7542000, 7542720, 7543440, 7544160, 7544880, 7544184, 7544904, 7545600, 7546320, 7547040, 7547760, 7548480, 7549200, 7548504, 7549224, 7549920, 7550640, 7551360, 7552080, 7552800, 7553520, 7552824, 7553544, 7554240, 7554960]

theorem colored_row230 : ∀ c : Fin 64,
    readRow witnessRows (230 * 64 + c.val) = coloredWitness230[c.val]! := by
  decide +kernel
#print axioms colored_row230

theorem colored_check230 : ∀ c : Fin 64,
    checkColored 230 (BitVec.ofNat 6 c.val) (coloredWitness230[c.val]!) = true := by
  decide +kernel
#print axioms colored_check230

theorem colored_family230 : ∀ c : Fin 64,
    checkColored 230 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (230 * 64 + c.val)) = true := by
  intro c
  rw [colored_row230]
  exact colored_check230 c
#print axioms colored_family230

def coloredWitness231 : Array Nat := #[7555680, 7556400, 7557120, 7557840, 7557144, 7557864, 7558560, 7559280, 7560000, 7560720, 7561440, 7562160, 7561464, 7562184, 7562880, 7563600, 7564320, 7565040, 7565760, 7566480, 7565784, 7566504, 7567200, 7567920, 7568640, 7569360, 7570080, 7570800, 7570104, 7570824, 7571520, 7572240, 7572960, 7573680, 7574400, 7575120, 7574424, 7575144, 7575840, 7576560, 7577280, 7578000, 7578720, 7579440, 7578744, 7579464, 7580160, 7580880, 7581600, 7582320, 7583040, 7583760, 7583064, 7583784, 7584480, 7585200, 7585920, 7586640, 7587360, 7588080, 7587384, 7588104, 7588800, 7589520]

theorem colored_row231 : ∀ c : Fin 64,
    readRow witnessRows (231 * 64 + c.val) = coloredWitness231[c.val]! := by
  decide +kernel
#print axioms colored_row231

theorem colored_check231 : ∀ c : Fin 64,
    checkColored 231 (BitVec.ofNat 6 c.val) (coloredWitness231[c.val]!) = true := by
  decide +kernel
#print axioms colored_check231

theorem colored_family231 : ∀ c : Fin 64,
    checkColored 231 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (231 * 64 + c.val)) = true := by
  intro c
  rw [colored_row231]
  exact colored_check231 c
#print axioms colored_family231

def coloredWitness232 : Array Nat := #[7590240, 7590960, 7591680, 7592400, 7593120, 7593840, 7594560, 7595280, 7596000, 7596720, 7597440, 7598160, 7598880, 7599600, 7600320, 7601040, 7601760, 7602480, 7603200, 7603920, 7604640, 7605360, 7606080, 7606800, 7607520, 7608240, 7608960, 7609680, 7610400, 7611120, 7611840, 7612560, 7613280, 7614000, 7614720, 7615440, 7616160, 7616880, 7617600, 7618320, 7619040, 7619760, 7620480, 7621200, 7621920, 7622640, 7623360, 7624080, 7624800, 7625520, 7626240, 7626960, 7627680, 7628400, 7629120, 7629840, 7630560, 7631280, 7632000, 7632720, 7633440, 7634160, 7634880, 7635600]

theorem colored_row232 : ∀ c : Fin 64,
    readRow witnessRows (232 * 64 + c.val) = coloredWitness232[c.val]! := by
  decide +kernel
#print axioms colored_row232

theorem colored_check232 : ∀ c : Fin 64,
    checkColored 232 (BitVec.ofNat 6 c.val) (coloredWitness232[c.val]!) = true := by
  decide +kernel
#print axioms colored_check232

theorem colored_family232 : ∀ c : Fin 64,
    checkColored 232 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (232 * 64 + c.val)) = true := by
  intro c
  rw [colored_row232]
  exact colored_check232 c
#print axioms colored_family232

def coloredWitness233 : Array Nat := #[7636320, 7637040, 7637760, 7638480, 7639200, 7639920, 7640640, 7641360, 7642080, 7642800, 7643520, 7644240, 7644960, 7645680, 7646400, 7647120, 7647840, 7648560, 7649280, 7650000, 7650720, 7651440, 7652160, 7652880, 7653600, 7654320, 7655040, 7655760, 7656480, 7657200, 7657920, 7658640, 7659360, 7660080, 7660800, 7661520, 7662240, 7662960, 7663680, 7664400, 7665120, 7665840, 7666560, 7667280, 7668000, 7668720, 7669440, 7670160, 7670880, 7671600, 7672320, 7673040, 7673760, 7674480, 7675200, 7675920, 7676640, 7677360, 7678080, 7678800, 7679520, 7680240, 7680960, 7681680]

theorem colored_row233 : ∀ c : Fin 64,
    readRow witnessRows (233 * 64 + c.val) = coloredWitness233[c.val]! := by
  decide +kernel
#print axioms colored_row233

theorem colored_check233 : ∀ c : Fin 64,
    checkColored 233 (BitVec.ofNat 6 c.val) (coloredWitness233[c.val]!) = true := by
  decide +kernel
#print axioms colored_check233

theorem colored_family233 : ∀ c : Fin 64,
    checkColored 233 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (233 * 64 + c.val)) = true := by
  intro c
  rw [colored_row233]
  exact colored_check233 c
#print axioms colored_family233

def coloredWitness234 : Array Nat := #[7682400, 7683120, 7683840, 7684560, 7685280, 7686000, 7686720, 7687440, 7688160, 7688880, 7689600, 7690320, 7691040, 7691760, 7692480, 7693200, 7693920, 7694640, 7695360, 7696080, 7696800, 7697520, 7698240, 7698960, 7699680, 7700400, 7701120, 7701840, 7702560, 7703280, 7704000, 7704720, 7705440, 7706160, 7706880, 7707600, 7708320, 7709040, 7709760, 7710480, 7711200, 7711920, 7712640, 7713360, 7714080, 7714800, 7715520, 7716240, 7716960, 7717680, 7718400, 7719120, 7719840, 7720560, 7721280, 7722000, 7722720, 7723440, 7724160, 7724880, 7725600, 7726320, 7727040, 7727760]

theorem colored_row234 : ∀ c : Fin 64,
    readRow witnessRows (234 * 64 + c.val) = coloredWitness234[c.val]! := by
  decide +kernel
#print axioms colored_row234

theorem colored_check234 : ∀ c : Fin 64,
    checkColored 234 (BitVec.ofNat 6 c.val) (coloredWitness234[c.val]!) = true := by
  decide +kernel
#print axioms colored_check234

theorem colored_family234 : ∀ c : Fin 64,
    checkColored 234 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (234 * 64 + c.val)) = true := by
  intro c
  rw [colored_row234]
  exact colored_check234 c
#print axioms colored_family234

def coloredWitness235 : Array Nat := #[7728480, 7729200, 7729920, 7730640, 7731360, 7732080, 7732800, 7733520, 7734240, 7734960, 7735680, 7736400, 7737120, 7737840, 7738560, 7739280, 7740000, 7740720, 7741440, 7742160, 7742880, 7743600, 7744320, 7745040, 7745760, 7746480, 7747200, 7747920, 7748640, 7749360, 7750080, 7750800, 7751520, 7752240, 7752960, 7753680, 7754400, 7755120, 7755840, 7756560, 7757280, 7758000, 7758720, 7759440, 7760160, 7760880, 7761600, 7762320, 7763040, 7763760, 7764480, 7765200, 7765920, 7766640, 7767360, 7768080, 7768800, 7769520, 7770240, 7770960, 7771680, 7772400, 7773120, 7773840]

theorem colored_row235 : ∀ c : Fin 64,
    readRow witnessRows (235 * 64 + c.val) = coloredWitness235[c.val]! := by
  decide +kernel
#print axioms colored_row235

theorem colored_check235 : ∀ c : Fin 64,
    checkColored 235 (BitVec.ofNat 6 c.val) (coloredWitness235[c.val]!) = true := by
  decide +kernel
#print axioms colored_check235

theorem colored_family235 : ∀ c : Fin 64,
    checkColored 235 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (235 * 64 + c.val)) = true := by
  intro c
  rw [colored_row235]
  exact colored_check235 c
#print axioms colored_family235

def coloredWitness236 : Array Nat := #[7774560, 7775280, 7776000, 7776720, 7776024, 7776744, 7777440, 7778160, 7778880, 7779600, 7780320, 7781040, 7780344, 7781064, 7781760, 7782480, 7783200, 7783920, 7784640, 7785360, 7784664, 7785384, 7786080, 7786800, 7787520, 7788240, 7788960, 7789680, 7788984, 7789704, 7790400, 7791120, 7791840, 7792560, 7793280, 7794000, 7793304, 7794024, 7794720, 7795440, 7796160, 7796880, 7797600, 7798320, 7797624, 7798344, 7799040, 7799760, 7800480, 7801200, 7801920, 7802640, 7801944, 7802664, 7803360, 7804080, 7804800, 7805520, 7806240, 7806960, 7806264, 7806984, 7807680, 7808400]

theorem colored_row236 : ∀ c : Fin 64,
    readRow witnessRows (236 * 64 + c.val) = coloredWitness236[c.val]! := by
  decide +kernel
#print axioms colored_row236

theorem colored_check236 : ∀ c : Fin 64,
    checkColored 236 (BitVec.ofNat 6 c.val) (coloredWitness236[c.val]!) = true := by
  decide +kernel
#print axioms colored_check236

theorem colored_family236 : ∀ c : Fin 64,
    checkColored 236 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (236 * 64 + c.val)) = true := by
  intro c
  rw [colored_row236]
  exact colored_check236 c
#print axioms colored_family236

def coloredWitness237 : Array Nat := #[7809120, 7809840, 7810560, 7811280, 7810584, 7811304, 7812000, 7812720, 7813440, 7814160, 7814880, 7815600, 7814904, 7815624, 7816320, 7817040, 7817760, 7818480, 7819200, 7819920, 7819224, 7819944, 7820640, 7821360, 7822080, 7822800, 7823520, 7824240, 7823544, 7824264, 7824960, 7825680, 7826400, 7827120, 7827840, 7828560, 7827864, 7828584, 7829280, 7830000, 7830720, 7831440, 7832160, 7832880, 7832184, 7832904, 7833600, 7834320, 7835040, 7835760, 7836480, 7837200, 7836504, 7837224, 7837920, 7838640, 7839360, 7840080, 7840800, 7841520, 7840824, 7841544, 7842240, 7842960]

theorem colored_row237 : ∀ c : Fin 64,
    readRow witnessRows (237 * 64 + c.val) = coloredWitness237[c.val]! := by
  decide +kernel
#print axioms colored_row237

theorem colored_check237 : ∀ c : Fin 64,
    checkColored 237 (BitVec.ofNat 6 c.val) (coloredWitness237[c.val]!) = true := by
  decide +kernel
#print axioms colored_check237

theorem colored_family237 : ∀ c : Fin 64,
    checkColored 237 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (237 * 64 + c.val)) = true := by
  intro c
  rw [colored_row237]
  exact colored_check237 c
#print axioms colored_family237

def coloredWitness238 : Array Nat := #[7843680, 7844400, 7845120, 7845840, 7846560, 7847280, 7848000, 7848720, 7849440, 7850160, 7850880, 7851600, 7852320, 7853040, 7853760, 7854480, 7855200, 7855920, 7856640, 7857360, 7858080, 7858800, 7859520, 7860240, 7860960, 7861680, 7862400, 7863120, 7863840, 7864560, 7865280, 7866000, 7866720, 7867440, 7868160, 7868880, 7869600, 7870320, 7871040, 7871760, 7872480, 7873200, 7873920, 7874640, 7875360, 7876080, 7876800, 7877520, 7878240, 7878960, 7879680, 7880400, 7881120, 7881840, 7882560, 7883280, 7884000, 7884720, 7885440, 7886160, 7886880, 7887600, 7888320, 7889040]

theorem colored_row238 : ∀ c : Fin 64,
    readRow witnessRows (238 * 64 + c.val) = coloredWitness238[c.val]! := by
  decide +kernel
#print axioms colored_row238

theorem colored_check238 : ∀ c : Fin 64,
    checkColored 238 (BitVec.ofNat 6 c.val) (coloredWitness238[c.val]!) = true := by
  decide +kernel
#print axioms colored_check238

theorem colored_family238 : ∀ c : Fin 64,
    checkColored 238 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (238 * 64 + c.val)) = true := by
  intro c
  rw [colored_row238]
  exact colored_check238 c
#print axioms colored_family238

def coloredWitness239 : Array Nat := #[7889760, 7890480, 7891200, 7891920, 7892640, 7893360, 7894080, 7894800, 7895520, 7896240, 7896960, 7897680, 7898400, 7899120, 7899840, 7900560, 7901280, 7902000, 7902720, 7903440, 7904160, 7904880, 7905600, 7906320, 7907040, 7907760, 7908480, 7909200, 7909920, 7910640, 7911360, 7912080, 7912800, 7913520, 7914240, 7914960, 7915680, 7916400, 7917120, 7917840, 7918560, 7919280, 7920000, 7920720, 7921440, 7922160, 7922880, 7923600, 7924320, 7925040, 7925760, 7926480, 7927200, 7927920, 7928640, 7929360, 7930080, 7930800, 7931520, 7932240, 7932960, 7933680, 7934400, 7935120]

theorem colored_row239 : ∀ c : Fin 64,
    readRow witnessRows (239 * 64 + c.val) = coloredWitness239[c.val]! := by
  decide +kernel
#print axioms colored_row239

theorem colored_check239 : ∀ c : Fin 64,
    checkColored 239 (BitVec.ofNat 6 c.val) (coloredWitness239[c.val]!) = true := by
  decide +kernel
#print axioms colored_check239

theorem colored_family239 : ∀ c : Fin 64,
    checkColored 239 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (239 * 64 + c.val)) = true := by
  intro c
  rw [colored_row239]
  exact colored_check239 c
#print axioms colored_family239

def coloredWitness240 : Array Nat := #[7935840, 7936560, 7937280, 7938000, 7937304, 7938024, 7938720, 7939440, 7940160, 7940880, 7941600, 7942320, 7941624, 7942344, 7943040, 7943760, 7944480, 7945200, 7945920, 7946640, 7945944, 7946664, 7947360, 7948080, 7948800, 7949520, 7950240, 7950960, 7950264, 7950984, 7951680, 7952400, 7953120, 7953840, 7954560, 7955280, 7954584, 7955304, 7956000, 7956720, 7957440, 7958160, 7958880, 7959600, 7958904, 7959624, 7960320, 7961040, 7961760, 7962480, 7963200, 7963920, 7963224, 7963944, 7964640, 7965360, 7966080, 7966800, 7967520, 7968240, 7967544, 7968264, 7968960, 7969680]

theorem colored_row240 : ∀ c : Fin 64,
    readRow witnessRows (240 * 64 + c.val) = coloredWitness240[c.val]! := by
  decide +kernel
#print axioms colored_row240

theorem colored_check240 : ∀ c : Fin 64,
    checkColored 240 (BitVec.ofNat 6 c.val) (coloredWitness240[c.val]!) = true := by
  decide +kernel
#print axioms colored_check240

theorem colored_family240 : ∀ c : Fin 64,
    checkColored 240 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (240 * 64 + c.val)) = true := by
  intro c
  rw [colored_row240]
  exact colored_check240 c
#print axioms colored_family240

def coloredWitness241 : Array Nat := #[7970400, 7971120, 7971840, 7972560, 7971864, 7972584, 7973280, 7974000, 7974720, 7975440, 7976160, 7976880, 7976184, 7976904, 7977600, 7978320, 7979040, 7979760, 7980480, 7981200, 7980504, 7981224, 7981920, 7982640, 7983360, 7984080, 7984800, 7985520, 7984824, 7985544, 7986240, 7986960, 7987680, 7988400, 7989120, 7989840, 7989144, 7989864, 7990560, 7991280, 7992000, 7992720, 7993440, 7994160, 7993464, 7994184, 7994880, 7995600, 7996320, 7997040, 7997760, 7998480, 7997784, 7998504, 7999200, 7999920, 8000640, 8001360, 8002080, 8002800, 8002104, 8002824, 8003520, 8004240]

theorem colored_row241 : ∀ c : Fin 64,
    readRow witnessRows (241 * 64 + c.val) = coloredWitness241[c.val]! := by
  decide +kernel
#print axioms colored_row241

theorem colored_check241 : ∀ c : Fin 64,
    checkColored 241 (BitVec.ofNat 6 c.val) (coloredWitness241[c.val]!) = true := by
  decide +kernel
#print axioms colored_check241

theorem colored_family241 : ∀ c : Fin 64,
    checkColored 241 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (241 * 64 + c.val)) = true := by
  intro c
  rw [colored_row241]
  exact colored_check241 c
#print axioms colored_family241

def coloredWitness242 : Array Nat := #[8004960, 8005680, 8006400, 8007120, 8006424, 8007144, 8007840, 8008560, 8006070, 8009280, 8007510, 8010000, 8007534, 8010024, 8008950, 8010720, 8011440, 8012160, 8012880, 8013600, 8012904, 8013624, 8014320, 8015040, 8012550, 8015760, 8013990, 8016480, 8014014, 8016504, 8015430, 8017200, 8017920, 8018640, 8019360, 8020080, 8019384, 8020104, 8020800, 8021520, 8019030, 8022240, 8020470, 8022960, 8020494, 8022984, 8021910, 8023680, 8024400, 8025120, 8025840, 8026560, 8025864, 8026584, 8027280, 8028000, 8025510, 8028720, 8026950, 8029440, 8026974, 8029464, 8028390, 8030160]

theorem colored_row242 : ∀ c : Fin 64,
    readRow witnessRows (242 * 64 + c.val) = coloredWitness242[c.val]! := by
  decide +kernel
#print axioms colored_row242

theorem colored_check242 : ∀ c : Fin 64,
    checkColored 242 (BitVec.ofNat 6 c.val) (coloredWitness242[c.val]!) = true := by
  decide +kernel
#print axioms colored_check242

theorem colored_family242 : ∀ c : Fin 64,
    checkColored 242 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (242 * 64 + c.val)) = true := by
  intro c
  rw [colored_row242]
  exact colored_check242 c
#print axioms colored_family242

def coloredWitness243 : Array Nat := #[8030880, 8031600, 8032320, 8033040, 8033760, 8034480, 8035200, 8035920, 8036640, 8037360, 8038080, 8038800, 8039520, 8040240, 8040960, 8041680, 8042400, 8043120, 8043840, 8044560, 8045280, 8046000, 8046720, 8047440, 8048160, 8048880, 8049600, 8050320, 8051040, 8051760, 8052480, 8053200, 8053920, 8054640, 8055360, 8056080, 8056800, 8057520, 8058240, 8058960, 8059680, 8060400, 8061120, 8061840, 8062560, 8063280, 8064000, 8064720, 8065440, 8066160, 8066880, 8067600, 8068320, 8069040, 8069760, 8070480, 8071200, 8071920, 8072640, 8073360, 8074080, 8074800, 8075520, 8076240]

theorem colored_row243 : ∀ c : Fin 64,
    readRow witnessRows (243 * 64 + c.val) = coloredWitness243[c.val]! := by
  decide +kernel
#print axioms colored_row243

theorem colored_check243 : ∀ c : Fin 64,
    checkColored 243 (BitVec.ofNat 6 c.val) (coloredWitness243[c.val]!) = true := by
  decide +kernel
#print axioms colored_check243

theorem colored_family243 : ∀ c : Fin 64,
    checkColored 243 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (243 * 64 + c.val)) = true := by
  intro c
  rw [colored_row243]
  exact colored_check243 c
#print axioms colored_family243

def coloredWitness244 : Array Nat := #[8076960, 8077680, 8078400, 8079120, 8079840, 8080560, 8081280, 8082000, 8082720, 8083440, 8084160, 8084880, 8085600, 8086320, 8087040, 8087760, 8088480, 8089200, 8089920, 8090640, 8091360, 8092080, 8092800, 8093520, 8094240, 8094960, 8095680, 8096400, 8097120, 8097840, 8098560, 8099280, 8100000, 8100720, 8101440, 8102160, 8102880, 8103600, 8104320, 8105040, 8105760, 8106480, 8107200, 8107920, 8108640, 8109360, 8110080, 8110800, 8111520, 8112240, 8112960, 8113680, 8114400, 8115120, 8115840, 8116560, 8117280, 8118000, 8118720, 8119440, 8120160, 8120880, 8121600, 8122320]

theorem colored_row244 : ∀ c : Fin 64,
    readRow witnessRows (244 * 64 + c.val) = coloredWitness244[c.val]! := by
  decide +kernel
#print axioms colored_row244

theorem colored_check244 : ∀ c : Fin 64,
    checkColored 244 (BitVec.ofNat 6 c.val) (coloredWitness244[c.val]!) = true := by
  decide +kernel
#print axioms colored_check244

theorem colored_family244 : ∀ c : Fin 64,
    checkColored 244 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (244 * 64 + c.val)) = true := by
  intro c
  rw [colored_row244]
  exact colored_check244 c
#print axioms colored_family244

def coloredWitness245 : Array Nat := #[8123040, 8123760, 8124480, 8125200, 8125920, 8126640, 8127360, 8128080, 8128800, 8129520, 8130240, 8130960, 8131680, 8132400, 8133120, 8133840, 8134560, 8135280, 8136000, 8136720, 8137440, 8138160, 8138880, 8139600, 8140320, 8141040, 8141760, 8142480, 8143200, 8143920, 8144640, 8145360, 8146080, 8146800, 8147520, 8148240, 8148960, 8149680, 8150400, 8151120, 8151840, 8152560, 8153280, 8154000, 8154720, 8155440, 8156160, 8156880, 8157600, 8158320, 8159040, 8159760, 8160480, 8161200, 8161920, 8162640, 8163360, 8164080, 8164800, 8165520, 8166240, 8166960, 8167680, 8168400]

theorem colored_row245 : ∀ c : Fin 64,
    readRow witnessRows (245 * 64 + c.val) = coloredWitness245[c.val]! := by
  decide +kernel
#print axioms colored_row245

theorem colored_check245 : ∀ c : Fin 64,
    checkColored 245 (BitVec.ofNat 6 c.val) (coloredWitness245[c.val]!) = true := by
  decide +kernel
#print axioms colored_check245

theorem colored_family245 : ∀ c : Fin 64,
    checkColored 245 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (245 * 64 + c.val)) = true := by
  intro c
  rw [colored_row245]
  exact colored_check245 c
#print axioms colored_family245

def coloredWitness246 : Array Nat := #[8169120, 8169840, 8170560, 8171280, 8172000, 8172720, 8173440, 8174160, 8174880, 8175600, 8176320, 8177040, 8177760, 8178480, 8179200, 8179920, 8180640, 8181360, 8182080, 8182800, 8183520, 8184240, 8184960, 8185680, 8186400, 8187120, 8187840, 8188560, 8189280, 8190000, 8190720, 8191440, 8192160, 8192880, 8193600, 8194320, 8195040, 8195760, 8196480, 8197200, 8197920, 8198640, 8199360, 8200080, 8200800, 8201520, 8202240, 8202960, 8203680, 8204400, 8205120, 8205840, 8206560, 8207280, 8208000, 8208720, 8209440, 8210160, 8210880, 8211600, 8212320, 8213040, 8213760, 8214480]

theorem colored_row246 : ∀ c : Fin 64,
    readRow witnessRows (246 * 64 + c.val) = coloredWitness246[c.val]! := by
  decide +kernel
#print axioms colored_row246

theorem colored_check246 : ∀ c : Fin 64,
    checkColored 246 (BitVec.ofNat 6 c.val) (coloredWitness246[c.val]!) = true := by
  decide +kernel
#print axioms colored_check246

theorem colored_family246 : ∀ c : Fin 64,
    checkColored 246 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (246 * 64 + c.val)) = true := by
  intro c
  rw [colored_row246]
  exact colored_check246 c
#print axioms colored_family246

def coloredWitness247 : Array Nat := #[8215200, 8215920, 8216640, 8217360, 8216664, 8217384, 8218080, 8218800, 8219520, 8220240, 8220960, 8221680, 8220984, 8221704, 8222400, 8223120, 8223840, 8224560, 8225280, 8226000, 8225304, 8226024, 8226720, 8227440, 8228160, 8228880, 8229600, 8230320, 8229624, 8230344, 8231040, 8231760, 8232480, 8233200, 8233920, 8234640, 8233944, 8234664, 8235360, 8236080, 8236800, 8237520, 8238240, 8238960, 8238264, 8238984, 8239680, 8240400, 8241120, 8241840, 8242560, 8243280, 8242584, 8243304, 8244000, 8244720, 8245440, 8246160, 8246880, 8247600, 8246904, 8247624, 8248320, 8249040]

theorem colored_row247 : ∀ c : Fin 64,
    readRow witnessRows (247 * 64 + c.val) = coloredWitness247[c.val]! := by
  decide +kernel
#print axioms colored_row247

theorem colored_check247 : ∀ c : Fin 64,
    checkColored 247 (BitVec.ofNat 6 c.val) (coloredWitness247[c.val]!) = true := by
  decide +kernel
#print axioms colored_check247

theorem colored_family247 : ∀ c : Fin 64,
    checkColored 247 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (247 * 64 + c.val)) = true := by
  intro c
  rw [colored_row247]
  exact colored_check247 c
#print axioms colored_family247

def coloredWitness248 : Array Nat := #[8249760, 8250480, 8251200, 8251920, 8251224, 8251944, 8252640, 8253360, 8254080, 8254800, 8255520, 8256240, 8255544, 8256264, 8256960, 8257680, 8258400, 8259120, 8259840, 8260560, 8259864, 8260584, 8261280, 8262000, 8262720, 8263440, 8264160, 8264880, 8264184, 8264904, 8265600, 8266320, 8267040, 8267760, 8268480, 8269200, 8268504, 8269224, 8269920, 8270640, 8271360, 8272080, 8272800, 8273520, 8272824, 8273544, 8274240, 8274960, 8275680, 8276400, 8277120, 8277840, 8277144, 8277864, 8278560, 8279280, 8280000, 8280720, 8281440, 8282160, 8281464, 8282184, 8282880, 8283600]

theorem colored_row248 : ∀ c : Fin 64,
    readRow witnessRows (248 * 64 + c.val) = coloredWitness248[c.val]! := by
  decide +kernel
#print axioms colored_row248

theorem colored_check248 : ∀ c : Fin 64,
    checkColored 248 (BitVec.ofNat 6 c.val) (coloredWitness248[c.val]!) = true := by
  decide +kernel
#print axioms colored_check248

theorem colored_family248 : ∀ c : Fin 64,
    checkColored 248 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (248 * 64 + c.val)) = true := by
  intro c
  rw [colored_row248]
  exact colored_check248 c
#print axioms colored_family248

def coloredWitness249 : Array Nat := #[8284320, 8285040, 8285760, 8286480, 8287200, 8287920, 8288640, 8289360, 8290080, 8290800, 8291520, 8292240, 8292960, 8293680, 8294400, 8295120, 8295840, 8296560, 8297280, 8298000, 8298720, 8299440, 8300160, 8300880, 8301600, 8302320, 8303040, 8303760, 8304480, 8305200, 8305920, 8306640, 8307360, 8308080, 8308800, 8309520, 8310240, 8310960, 8311680, 8312400, 8313120, 8313840, 8314560, 8315280, 8316000, 8316720, 8317440, 8318160, 8318880, 8319600, 8320320, 8321040, 8321760, 8322480, 8323200, 8323920, 8324640, 8325360, 8326080, 8326800, 8327520, 8328240, 8328960, 8329680]

theorem colored_row249 : ∀ c : Fin 64,
    readRow witnessRows (249 * 64 + c.val) = coloredWitness249[c.val]! := by
  decide +kernel
#print axioms colored_row249

theorem colored_check249 : ∀ c : Fin 64,
    checkColored 249 (BitVec.ofNat 6 c.val) (coloredWitness249[c.val]!) = true := by
  decide +kernel
#print axioms colored_check249

theorem colored_family249 : ∀ c : Fin 64,
    checkColored 249 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (249 * 64 + c.val)) = true := by
  intro c
  rw [colored_row249]
  exact colored_check249 c
#print axioms colored_family249

def coloredWitness250 : Array Nat := #[8330400, 8331120, 8331840, 8332560, 8333280, 8334000, 8334720, 8335440, 8336160, 8336880, 8337600, 8338320, 8339040, 8339760, 8340480, 8341200, 8341920, 8342640, 8343360, 8344080, 8344800, 8345520, 8346240, 8346960, 8347680, 8348400, 8349120, 8349840, 8350560, 8351280, 8352000, 8352720, 8353440, 8354160, 8354880, 8355600, 8356320, 8357040, 8357760, 8358480, 8359200, 8359920, 8360640, 8361360, 8362080, 8362800, 8363520, 8364240, 8364960, 8365680, 8366400, 8367120, 8367840, 8368560, 8369280, 8370000, 8370720, 8371440, 8372160, 8372880, 8373600, 8374320, 8375040, 8375760]

theorem colored_row250 : ∀ c : Fin 64,
    readRow witnessRows (250 * 64 + c.val) = coloredWitness250[c.val]! := by
  decide +kernel
#print axioms colored_row250

theorem colored_check250 : ∀ c : Fin 64,
    checkColored 250 (BitVec.ofNat 6 c.val) (coloredWitness250[c.val]!) = true := by
  decide +kernel
#print axioms colored_check250

theorem colored_family250 : ∀ c : Fin 64,
    checkColored 250 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (250 * 64 + c.val)) = true := by
  intro c
  rw [colored_row250]
  exact colored_check250 c
#print axioms colored_family250

def coloredWitness251 : Array Nat := #[8376480, 8377200, 8377920, 8378640, 8379360, 8380080, 8380800, 8381520, 8382240, 8382960, 8383680, 8384400, 8385120, 8385840, 8386560, 8387280, 8388000, 8388720, 8389440, 8390160, 8390880, 8391600, 8392320, 8393040, 8393760, 8394480, 8395200, 8395920, 8396640, 8397360, 8398080, 8398800, 8399520, 8400240, 8400960, 8401680, 8402400, 8403120, 8403840, 8404560, 8405280, 8406000, 8406720, 8407440, 8408160, 8408880, 8409600, 8410320, 8411040, 8411760, 8412480, 8413200, 8413920, 8414640, 8415360, 8416080, 8416800, 8417520, 8418240, 8418960, 8419680, 8420400, 8421120, 8421840]

theorem colored_row251 : ∀ c : Fin 64,
    readRow witnessRows (251 * 64 + c.val) = coloredWitness251[c.val]! := by
  decide +kernel
#print axioms colored_row251

theorem colored_check251 : ∀ c : Fin 64,
    checkColored 251 (BitVec.ofNat 6 c.val) (coloredWitness251[c.val]!) = true := by
  decide +kernel
#print axioms colored_check251

theorem colored_family251 : ∀ c : Fin 64,
    checkColored 251 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (251 * 64 + c.val)) = true := by
  intro c
  rw [colored_row251]
  exact colored_check251 c
#print axioms colored_family251

def coloredWitness252 : Array Nat := #[8422560, 8423280, 8424000, 8424720, 8425440, 8426160, 8426880, 8427600, 8428320, 8429040, 8429760, 8430480, 8431200, 8431920, 8432640, 8433360, 8434080, 8434800, 8435520, 8436240, 8436960, 8437680, 8438400, 8439120, 8439840, 8440560, 8441280, 8442000, 8442720, 8443440, 8444160, 8444880, 8445600, 8446320, 8447040, 8447760, 8448480, 8449200, 8449920, 8450640, 8451360, 8452080, 8452800, 8453520, 8454240, 8454960, 8455680, 8456400, 8457120, 8457840, 8458560, 8459280, 8460000, 8460720, 8461440, 8462160, 8462880, 8463600, 8464320, 8465040, 8465760, 8466480, 8467200, 8467920]

theorem colored_row252 : ∀ c : Fin 64,
    readRow witnessRows (252 * 64 + c.val) = coloredWitness252[c.val]! := by
  decide +kernel
#print axioms colored_row252

theorem colored_check252 : ∀ c : Fin 64,
    checkColored 252 (BitVec.ofNat 6 c.val) (coloredWitness252[c.val]!) = true := by
  decide +kernel
#print axioms colored_check252

theorem colored_family252 : ∀ c : Fin 64,
    checkColored 252 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (252 * 64 + c.val)) = true := by
  intro c
  rw [colored_row252]
  exact colored_check252 c
#print axioms colored_family252

def coloredWitness253 : Array Nat := #[8468640, 8469360, 8470080, 8470800, 8471520, 8472240, 8472960, 8473680, 8474400, 8475120, 8475840, 8476560, 8477280, 8478000, 8478720, 8479440, 8480160, 8480880, 8481600, 8482320, 8483040, 8483760, 8484480, 8485200, 8485920, 8486640, 8487360, 8488080, 8488800, 8489520, 8490240, 8490960, 8491680, 8492400, 8493120, 8493840, 8494560, 8495280, 8496000, 8496720, 8497440, 8498160, 8498880, 8499600, 8500320, 8501040, 8501760, 8502480, 8503200, 8503920, 8504640, 8505360, 8506080, 8506800, 8507520, 8508240, 8508960, 8509680, 8510400, 8511120, 8511840, 8512560, 8513280, 8514000]

theorem colored_row253 : ∀ c : Fin 64,
    readRow witnessRows (253 * 64 + c.val) = coloredWitness253[c.val]! := by
  decide +kernel
#print axioms colored_row253

theorem colored_check253 : ∀ c : Fin 64,
    checkColored 253 (BitVec.ofNat 6 c.val) (coloredWitness253[c.val]!) = true := by
  decide +kernel
#print axioms colored_check253

theorem colored_family253 : ∀ c : Fin 64,
    checkColored 253 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (253 * 64 + c.val)) = true := by
  intro c
  rw [colored_row253]
  exact colored_check253 c
#print axioms colored_family253

def coloredWitness254 : Array Nat := #[8514720, 8515440, 8516160, 8516880, 8517600, 8518320, 8519040, 8519760, 8520480, 8521200, 8521920, 8522640, 8523360, 8524080, 8524800, 8525520, 8526240, 8526960, 8527680, 8528400, 8529120, 8529840, 8530560, 8531280, 8532000, 8532720, 8533440, 8534160, 8534880, 8535600, 8536320, 8537040, 8537760, 8538480, 8539200, 8539920, 8540640, 8541360, 8542080, 8542800, 8543520, 8544240, 8544960, 8545680, 8546400, 8547120, 8547840, 8548560, 8549280, 8550000, 8550720, 8551440, 8552160, 8552880, 8553600, 8554320, 8555040, 8555760, 8556480, 8557200, 8557920, 8558640, 8559360, 8560080]

theorem colored_row254 : ∀ c : Fin 64,
    readRow witnessRows (254 * 64 + c.val) = coloredWitness254[c.val]! := by
  decide +kernel
#print axioms colored_row254

theorem colored_check254 : ∀ c : Fin 64,
    checkColored 254 (BitVec.ofNat 6 c.val) (coloredWitness254[c.val]!) = true := by
  decide +kernel
#print axioms colored_check254

theorem colored_family254 : ∀ c : Fin 64,
    checkColored 254 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (254 * 64 + c.val)) = true := by
  intro c
  rw [colored_row254]
  exact colored_check254 c
#print axioms colored_family254

def coloredWitness255 : Array Nat := #[8560800, 8561520, 8562240, 8562960, 8562264, 8562984, 8563680, 8564400, 8565120, 8565840, 8566560, 8567280, 8566584, 8567304, 8568000, 8568720, 8569440, 8570160, 8570880, 8571600, 8570904, 8571624, 8572320, 8573040, 8573760, 8574480, 8575200, 8575920, 8575224, 8575944, 8576640, 8577360, 8578080, 8578800, 8579520, 8580240, 8579544, 8580264, 8580960, 8581680, 8582400, 8583120, 8583840, 8584560, 8583864, 8584584, 8585280, 8586000, 8586720, 8587440, 8588160, 8588880, 8588184, 8588904, 8589600, 8590320, 8591040, 8591760, 8592480, 8593200, 8592504, 8593224, 8593920, 8594640]

theorem colored_row255 : ∀ c : Fin 64,
    readRow witnessRows (255 * 64 + c.val) = coloredWitness255[c.val]! := by
  decide +kernel
#print axioms colored_row255

theorem colored_check255 : ∀ c : Fin 64,
    checkColored 255 (BitVec.ofNat 6 c.val) (coloredWitness255[c.val]!) = true := by
  decide +kernel
#print axioms colored_check255

theorem colored_family255 : ∀ c : Fin 64,
    checkColored 255 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (255 * 64 + c.val)) = true := by
  intro c
  rw [colored_row255]
  exact colored_check255 c
#print axioms colored_family255

end TightCycleC5.Bridge.ColoredCover
