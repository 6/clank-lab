import P33ArithmeticEncoding

/-! Explicit forward evaluation is inverse relabelling in the accepted
LabelledStructure action. This convention is accounted for before taking
any original row mean. -/
namespace TightCycleC5.Bridge.P33Arithmetic

/-- The actual six-vertex structure represented by the literal bits. -/
def decodedClass (K : Class) : LabelledStructure 6 :=
  MaskEncoding.decodeStructure (BitVec.ofNat 20 K.mask) (BitVec.ofNat 6 K.colours)

/-- A forward lookup is an inverse action, including the colour convention. -/
theorem colour_eq_inverse_relabel (K : Class) (p : Equiv.Perm (Fin 6)) (v : Fin 6) :
    colour K.colours (p v).val = ((p.symm • decodedClass K).color v).toNat := by
  change colour K.colours (p v).val = ((decodedClass K).color (p v)).toNat
  exact colour_eq_decoded K.mask K.colours (p v)

/-- Triple edges agree pointwise at every distinct queried triple. -/
theorem edge_eq_inverse_relabel (K : Class) (p : Equiv.Perm (Fin 6))
    (a b c : Fin 6) (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c) :
    edge K.mask (p a).val (p b).val (p c).val =
      ((p.symm • decodedClass K).edge {a,b,c}).toNat := by
  change edge K.mask (p a).val (p b).val (p c).val =
    ((decodedClass K).edge (({a,b,c} : Finset (Fin 6)).map p.toEmbedding)).toNat
  simpa [Finset.map_insert, Finset.map_singleton, decodedClass] using
    edge_eq_decoded K.mask K.colours (p a) (p b) (p c)
      (p.injective.ne hab) (p.injective.ne hac) (p.injective.ne hbc)

/-- Inversion is a bijection, so the original row mean has the same value. -/
theorem inverse_relabel_mean (K : Class) (row : LabelledStructure 6 → ℝ) :
    uniformMean (fun j : Fin 720 =>
      row ((Cover.kernelPermutation j).symm • decodedClass K)) =
    uniformMean (fun j : Fin 720 =>
      row (Cover.kernelPermutation j • decodedClass K)) := by
  calc
    _ = uniformMean (fun p : Equiv.Perm (Fin 6) =>
        row (p.symm • decodedClass K)) :=
      Cover.PermutationEnumeration.uniformMean_kernelPermutation
        (fun p => row (p.symm • decodedClass K))
    _ = uniformMean (fun p : Equiv.Perm (Fin 6) =>
        row (p • decodedClass K)) :=
      uniformMean_equiv (Equiv.inv (Equiv.Perm (Fin 6)))
        (fun p => row (p • decodedClass K))
    _ = _ := (Cover.PermutationEnumeration.uniformMean_kernelPermutation
      (fun p => row (p • decodedClass K))).symm

#print axioms colour_eq_inverse_relabel
#print axioms edge_eq_inverse_relabel
#print axioms inverse_relabel_mean
end TightCycleC5.Bridge.P33Arithmetic
