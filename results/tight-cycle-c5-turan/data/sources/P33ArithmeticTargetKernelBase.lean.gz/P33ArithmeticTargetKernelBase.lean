import P33ArithmeticTargetCore

/-! Literal target equality without the native all-class theorem. -/
namespace TightCycleC5.Bridge.P33Arithmetic
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def targetCountsMatch (K : Class) : Prop :=
  targetNumerator K = (badCount (classGraph K) (classCut K) : Int) -
    (missCount (classGraph K) (classCut K) : Int)

instance (K : Class) : Decidable (targetCountsMatch K) := by
  unfold targetCountsMatch
  infer_instance

def targetKernelClass (b : Fin 317) (i : Fin (min 128 (40547 - 128 * b.val))) :
    Fin 40547 := ⟨128 * b.val + i.val, by have hi := i.isLt; omega⟩

theorem targetKernelClass_val (b : Fin 317) (i : Fin (min 128 (40547 - 128 * b.val))) :
    (targetKernelClass b i).val = 128 * b.val + i.val := rfl

theorem target_numerator_corruption_rejected :
    targetNumerator (classAt ⟨20273, by decide⟩) + 1 ≠
      (badCount (classGraph (classAt ⟨20273, by decide⟩))
        (classCut (classAt ⟨20273, by decide⟩)) : Int) -
      (missCount (classGraph (classAt ⟨20273, by decide⟩))
        (classCut (classAt ⟨20273, by decide⟩)) : Int) := by
  decide +kernel

#print axioms targetKernelClass_val
#print axioms target_numerator_corruption_rejected
end TightCycleC5.Bridge.P33Arithmetic
