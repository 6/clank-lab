-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk116 :
    ∀ i : Fin (min 128 (40547 - 128 * 116)),
      targetCountsMatch (classAt (targetKernelClass ⟨116, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk116

theorem target_counts_kernel_chunk117 :
    ∀ i : Fin (min 128 (40547 - 128 * 117)),
      targetCountsMatch (classAt (targetKernelClass ⟨117, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk117

theorem target_counts_kernel_chunk118 :
    ∀ i : Fin (min 128 (40547 - 128 * 118)),
      targetCountsMatch (classAt (targetKernelClass ⟨118, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk118

theorem target_counts_kernel_chunk119 :
    ∀ i : Fin (min 128 (40547 - 128 * 119)),
      targetCountsMatch (classAt (targetKernelClass ⟨119, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk119


end TightCycleC5.Bridge.P33Arithmetic
