import P32PSDGram1Rows0
import P32PSDGram1Rows1
import P32PSDGram1Rows2
import P32PSDGram1Rows3
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace TightCycleC5.Bridge.P32PSD.Kernel
theorem gram1 : q1 = u1 * u1.transpose := by
  ext i j
  fin_cases i
  · exact gram1_row0 j
  · exact gram1_row1 j
  · exact gram1_row2 j
  · exact gram1_row3 j
  · exact gram1_row4 j
  · exact gram1_row5 j
  · exact gram1_row6 j
  · exact gram1_row7 j
  · exact gram1_row8 j
  · exact gram1_row9 j
  · exact gram1_row10 j
  · exact gram1_row11 j
  · exact gram1_row12 j
  · exact gram1_row13 j
  · exact gram1_row14 j
  · exact gram1_row15 j
  · exact gram1_row16 j
  · exact gram1_row17 j
  · exact gram1_row18 j
  · exact gram1_row19 j
  · exact gram1_row20 j
  · exact gram1_row21 j
  · exact gram1_row22 j
  · exact gram1_row23 j
  · exact gram1_row24 j
  · exact gram1_row25 j
  · exact gram1_row26 j
  · exact gram1_row27 j
  · exact gram1_row28 j
  · exact gram1_row29 j
  · exact gram1_row30 j
  · exact gram1_row31 j
  · exact gram1_row32 j
  · exact gram1_row33 j
  · exact gram1_row34 j
  · exact gram1_row35 j
  · exact gram1_row36 j
  · exact gram1_row37 j
  · exact gram1_row38 j
  · exact gram1_row39 j
  · exact gram1_row40 j
  · exact gram1_row41 j
  · exact gram1_row42 j
  · exact gram1_row43 j
  · exact gram1_row44 j
  · exact gram1_row45 j
  · exact gram1_row46 j
  · exact gram1_row47 j
  · exact gram1_row48 j
  · exact gram1_row49 j
  · exact gram1_row50 j
  · exact gram1_row51 j
  · exact gram1_row52 j
  · exact gram1_row53 j
  · exact gram1_row54 j
  · exact gram1_row55 j
  · exact gram1_row56 j
  · exact gram1_row57 j
  · exact gram1_row58 j
  · exact gram1_row59 j
  · exact gram1_row60 j
  · exact gram1_row61 j
  · exact gram1_row62 j
  · exact gram1_row63 j
theorem diagonal1 : ∀ i, q1 i i ≤ m1 := by decide +kernel
#print axioms gram1
#print axioms diagonal1
end TightCycleC5.Bridge.P32PSD.Kernel
