import P33FlagRowsBase
import P33PSDGroup3
import P33FlagFacts3

namespace TightCycleC5.Bridge.P33Flag
open Finset Matrix

noncomputable def row3 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix3 basis3 type3 G

theorem row3_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row3 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix3)
        (fun root a => flagLookup basis3 (fourKey H S root a)) (fourIndicator type3 H S) :=
  four_row_eq P33PSD.matrix3 basis3 basis3_injective type3 H S

theorem row3_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound3 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row3 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd3 P33PSD.normalized_nonneg3
    P33PSD.normalized_diagonal3 hn basis3 basis3_injective type3 H S

#print axioms row3_eq_optional
#print axioms row3_lower

noncomputable def row9 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix9 basis9 type9 G

theorem row9_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row9 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix9)
        (fun root a => flagLookup basis9 (fourKey H S root a)) (fourIndicator type9 H S) :=
  four_row_eq P33PSD.matrix9 basis9 basis9_injective type9 H S

theorem row9_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound9 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row9 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd9 P33PSD.normalized_nonneg9
    P33PSD.normalized_diagonal9 hn basis9 basis9_injective type9 H S

#print axioms row9_eq_optional
#print axioms row9_lower

noncomputable def row15 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix15 basis15 type15 G

theorem row15_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row15 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix15)
        (fun root a => flagLookup basis15 (fourKey H S root a)) (fourIndicator type15 H S) :=
  four_row_eq P33PSD.matrix15 basis15 basis15_injective type15 H S

theorem row15_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound15 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row15 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd15 P33PSD.normalized_nonneg15
    P33PSD.normalized_diagonal15 hn basis15 basis15_injective type15 H S

#print axioms row15_eq_optional
#print axioms row15_lower

noncomputable def row21 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix21 basis21 type21 G

theorem row21_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row21 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix21)
        (fun root a => flagLookup basis21 (fourKey H S root a)) (fourIndicator type21 H S) :=
  four_row_eq P33PSD.matrix21 basis21 basis21_injective type21 H S

theorem row21_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound21 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row21 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd21 P33PSD.normalized_nonneg21
    P33PSD.normalized_diagonal21 hn basis21 basis21_injective type21 H S

#print axioms row21_eq_optional
#print axioms row21_lower

noncomputable def row27 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix27 basis27 type27 G

theorem row27_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row27 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix27)
        (fun root a => flagLookup basis27 (fourKey H S root a)) (fourIndicator type27 H S) :=
  four_row_eq P33PSD.matrix27 basis27 basis27_injective type27 H S

theorem row27_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound27 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row27 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd27 P33PSD.normalized_nonneg27
    P33PSD.normalized_diagonal27 hn basis27 basis27_injective type27 H S

#print axioms row27_eq_optional
#print axioms row27_lower

noncomputable def row33 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix33 basis33 type33 G

theorem row33_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row33 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix33)
        (fun root a => flagLookup basis33 (fourKey H S root a)) (fourIndicator type33 H S) :=
  four_row_eq P33PSD.matrix33 basis33 basis33_injective type33 H S

theorem row33_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound33 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row33 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd33 P33PSD.normalized_nonneg33
    P33PSD.normalized_diagonal33 hn basis33 basis33_injective type33 H S

#print axioms row33_eq_optional
#print axioms row33_lower

end TightCycleC5.Bridge.P33Flag
