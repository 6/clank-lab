import KernelRowIndex
import KernelWitness1

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_1_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 64 * 256 + i.val))
      kernelWitness1Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_64

theorem kernelBlock_1_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 65 * 256 + i.val))
      kernelWitness1Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_65

theorem kernelBlock_1_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 66 * 256 + i.val))
      kernelWitness1Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_66

theorem kernelBlock_1_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 67 * 256 + i.val))
      kernelWitness1Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_67

theorem kernelBlock_1_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 68 * 256 + i.val))
      kernelWitness1Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_68

theorem kernelBlock_1_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 69 * 256 + i.val))
      kernelWitness1Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_69

theorem kernelBlock_1_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 70 * 256 + i.val))
      kernelWitness1Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_70

theorem kernelBlock_1_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 71 * 256 + i.val))
      kernelWitness1Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_71

theorem kernelBlock_1_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 72 * 256 + i.val))
      kernelWitness1Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_72

theorem kernelBlock_1_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 73 * 256 + i.val))
      kernelWitness1Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_73

theorem kernelBlock_1_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 74 * 256 + i.val))
      kernelWitness1Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_74

theorem kernelBlock_1_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 75 * 256 + i.val))
      kernelWitness1Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_75

theorem kernelBlock_1_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 76 * 256 + i.val))
      kernelWitness1Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_76

theorem kernelBlock_1_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 77 * 256 + i.val))
      kernelWitness1Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_77

theorem kernelBlock_1_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 78 * 256 + i.val))
      kernelWitness1Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_78

theorem kernelBlock_1_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 79 * 256 + i.val))
      kernelWitness1Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_79

theorem kernelBlock_1_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 80 * 256 + i.val))
      kernelWitness1Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_80

theorem kernelBlock_1_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 81 * 256 + i.val))
      kernelWitness1Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_81

theorem kernelBlock_1_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 82 * 256 + i.val))
      kernelWitness1Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_82

theorem kernelBlock_1_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 83 * 256 + i.val))
      kernelWitness1Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_83

theorem kernelBlock_1_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 84 * 256 + i.val))
      kernelWitness1Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_84

theorem kernelBlock_1_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 85 * 256 + i.val))
      kernelWitness1Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_85

theorem kernelBlock_1_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 86 * 256 + i.val))
      kernelWitness1Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_86

theorem kernelBlock_1_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 87 * 256 + i.val))
      kernelWitness1Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_87

theorem kernelBlock_1_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 88 * 256 + i.val))
      kernelWitness1Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_88

theorem kernelBlock_1_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 89 * 256 + i.val))
      kernelWitness1Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_89

theorem kernelBlock_1_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 90 * 256 + i.val))
      kernelWitness1Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_90

theorem kernelBlock_1_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 91 * 256 + i.val))
      kernelWitness1Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_91

theorem kernelBlock_1_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 92 * 256 + i.val))
      kernelWitness1Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_92

theorem kernelBlock_1_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 93 * 256 + i.val))
      kernelWitness1Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_93

theorem kernelBlock_1_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 94 * 256 + i.val))
      kernelWitness1Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_94

theorem kernelBlock_1_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 95 * 256 + i.val))
      kernelWitness1Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_95

end TightCycleC5.Bridge.Cover
