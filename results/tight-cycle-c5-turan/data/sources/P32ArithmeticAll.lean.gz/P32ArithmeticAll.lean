import P32ArithmeticGroup00
import P32ArithmeticGroup01
import P32ArithmeticGroup02
import P32ArithmeticGroup03
import P32ArithmeticGroup04
import P32ArithmeticGroup05
import P32ArithmeticGroup06
import P32ArithmeticGroup07
import P32ArithmeticGroup08
import P32ArithmeticGroup09
import P32ArithmeticGroup10
import P32ArithmeticGroup11
import P32ArithmeticGroup12
import P32ArithmeticGroup13
import P32ArithmeticGroup14
import P32ArithmeticGroup15
import P32ArithmeticGroup16
import P32ArithmeticGroup17
import P32ArithmeticGroup18
import P32ArithmeticGroup19
import P32ArithmeticGroup20
import P32ArithmeticGroup21
import P32ArithmeticGroup22
import P32ArithmeticGroup23
import P32ArithmeticGroup24
import P32ArithmeticGroup25
import P32ArithmeticGroup26
import P32ArithmeticGroup27
import P32ArithmeticGroup28
import P32ArithmeticGroup29
import P32ArithmeticGroup30
import P32ArithmeticGroup31
import P32ArithmeticGroup32
import P32ArithmeticGroup33
import P32ArithmeticGroup34
import P32ArithmeticGroup35
import P32ArithmeticGroup36
import P32ArithmeticGroup37
import P32ArithmeticGroup38
import P32ArithmeticGroup39
import P32ArithmeticGroup40
import P32ArithmeticGroup41
import P32ArithmeticGroup42
import P32ArithmeticGroup43
import P32ArithmeticGroup44
import P32ArithmeticGroup45
import P32ArithmeticGroup46
import P32ArithmeticGroup47
import P32ArithmeticGroup48
import P32ArithmeticGroup49
import P32ArithmeticGroup50
import P32ArithmeticGroup51
import P32ArithmeticGroup52
import P32ArithmeticSemantics

namespace TightCycleC5.Bridge.P32Arithmetic
open Finset
set_option maxHeartbeats 0

/-- Every pinned class, every genuine permutation; all lookups, signed
coefficient/slack identities and nonnegative slack are checked. -/
theorem all_classes : ∀ i : Fin 835, ClassStatement i := by
  intro i
  have groups : ∀ (b : Fin 53) (r : Fin 16) (h : b.val*16+r.val < 835),
      ClassStatement ⟨b.val*16+r.val, h⟩ := by
    intro b
    fin_cases b
    · intro r h; exact class_group00 r
    · intro r h; exact class_group01 r
    · intro r h; exact class_group02 r
    · intro r h; exact class_group03 r
    · intro r h; exact class_group04 r
    · intro r h; exact class_group05 r
    · intro r h; exact class_group06 r
    · intro r h; exact class_group07 r
    · intro r h; exact class_group08 r
    · intro r h; exact class_group09 r
    · intro r h; exact class_group10 r
    · intro r h; exact class_group11 r
    · intro r h; exact class_group12 r
    · intro r h; exact class_group13 r
    · intro r h; exact class_group14 r
    · intro r h; exact class_group15 r
    · intro r h; exact class_group16 r
    · intro r h; exact class_group17 r
    · intro r h; exact class_group18 r
    · intro r h; exact class_group19 r
    · intro r h; exact class_group20 r
    · intro r h; exact class_group21 r
    · intro r h; exact class_group22 r
    · intro r h; exact class_group23 r
    · intro r h; exact class_group24 r
    · intro r h; exact class_group25 r
    · intro r h; exact class_group26 r
    · intro r h; exact class_group27 r
    · intro r h; exact class_group28 r
    · intro r h; exact class_group29 r
    · intro r h; exact class_group30 r
    · intro r h; exact class_group31 r
    · intro r h; exact class_group32 r
    · intro r h; exact class_group33 r
    · intro r h; exact class_group34 r
    · intro r h; exact class_group35 r
    · intro r h; exact class_group36 r
    · intro r h; exact class_group37 r
    · intro r h; exact class_group38 r
    · intro r h; exact class_group39 r
    · intro r h; exact class_group40 r
    · intro r h; exact class_group41 r
    · intro r h; exact class_group42 r
    · intro r h; exact class_group43 r
    · intro r h; exact class_group44 r
    · intro r h; exact class_group45 r
    · intro r h; exact class_group46 r
    · intro r h; exact class_group47 r
    · intro r h; exact class_group48 r
    · intro r h; exact class_group49 r
    · intro r h; exact class_group50 r
    · intro r h; exact class_group51 r
    · intro r h
      change 52*16+r.val < 835 at h
      have hr : r.val < 3 := by omega
      exact class_group52 ⟨r.val, hr⟩
  let b : Fin 53 := ⟨i.val / 16, by have := i.isLt; omega⟩
  let r : Fin 16 := ⟨i.val % 16, Nat.mod_lt _ (by decide)⟩
  have he : b.val*16+r.val = i.val := by dsimp [b, r]; omega
  have hl : b.val*16+r.val < 835 := by rw [he]; exact i.isLt
  have hi : (⟨b.val*16+r.val, hl⟩ : Fin 835) = i := Fin.ext he
  simpa only [hi] using groups b r hl

/-- Every actual permutation has successful combined flag lookup. -/
theorem class_psd_lookup_valid (i : Fin 835) (p : Equiv.Perm (Fin 6)) :
    (psdNumerator (features (p • classStructure i))).isSome = true := by
  obtain ⟨j, rfl⟩ := Cover.PermutationEnumeration.kernelPermutation_bijective.2 p
  exact lookups_succeed_of_check i (all_classes i) j

theorem cover_class_psd_lookup_valid (i : Fin 835) (p : Equiv.Perm (Fin 6)) :
    (psdNumerator (features (p • MaskEncoding.decodeStructure
      (Cover.representative i) 0))).isSome = true := by
  simpa only [classStructure_eq_representative] using class_psd_lookup_valid i p

theorem class_mean_identity (i : Fin 835) :
    uniformMean (fun p : Equiv.Perm (Fin 6) => literalRow (p • classStructure i)) =
      1/10000 + (slacks.get i : ℝ) / (720 * (scale : ℝ)) :=
  class_mean_identity_of_check i (all_classes i)

theorem class_mean_lower (i : Fin 835) :
    (1 : ℝ)/10000 ≤
      uniformMean (fun p : Equiv.Perm (Fin 6) => literalRow (p • classStructure i)) :=
  class_mean_lower_of_check i (all_classes i)

theorem class_margin_bound (i : Fin 835) :
    (1 : ℝ)/10000 +
      uniformMean (fun p : Equiv.Perm (Fin 6) => clContribution (p • classStructure i)) +
      uniformMean (fun p : Equiv.Perm (Fin 6) => bookContribution (p • classStructure i)) +
      uniformMean (fun p : Equiv.Perm (Fin 6) => densityContribution (p • classStructure i)) +
      uniformMean (fun p : Equiv.Perm (Fin 6) => psdContribution (p • classStructure i)) ≤
      uniformMean (fun p : Equiv.Perm (Fin 6) => selectorMargin (p • classStructure i)) :=
  class_margin_bound_of_check i (all_classes i)

theorem cover_class_margin_bound (i : Fin 835) :
    let G := MaskEncoding.decodeStructure (Cover.representative i) 0
    (1 : ℝ)/10000 +
      uniformMean (fun p : Equiv.Perm (Fin 6) => clContribution (p • G)) +
      uniformMean (fun p : Equiv.Perm (Fin 6) => bookContribution (p • G)) +
      uniformMean (fun p : Equiv.Perm (Fin 6) => densityContribution (p • G)) +
      uniformMean (fun p : Equiv.Perm (Fin 6) => psdContribution (p • G)) ≤
      uniformMean (fun p : Equiv.Perm (Fin 6) => selectorMargin (p • G)) := by
  simpa only [classStructure_eq_representative] using class_margin_bound i

theorem rejects_changed_coefficient :
    ¬ (∑ j : Fin 720, ((classValues 0).get j).left) = coefficients.get 0 + 1 :=
  rejects_changed_coefficient_of_check 0 (all_classes 0)

theorem rejects_changed_slack :
    ¬ (∑ j : Fin 720, (((classValues 0).get j).left - ((classValues 0).get j).right)) =
      720*margin + slacks.get 0 + 1 :=
  rejects_changed_slack_of_check 0 (all_classes 0)

#print axioms all_classes
#print axioms class_psd_lookup_valid
#print axioms cover_class_psd_lookup_valid
#print axioms class_mean_identity
#print axioms class_mean_lower
#print axioms class_margin_bound
#print axioms cover_class_margin_bound
#print axioms rejects_changed_coefficient
#print axioms rejects_changed_slack
end TightCycleC5.Bridge.P32Arithmetic
