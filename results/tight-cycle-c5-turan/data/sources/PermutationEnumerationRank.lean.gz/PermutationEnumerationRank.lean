import KernelCoverSemantics

/-! The table's Lehmer rank is a checked left inverse, not an assumed
completeness theorem for Lehmer codes. All finite checks use the kernel.
Regenerate with python3 PermutationEnumerationGenerate.py. -/
namespace TightCycleC5.Bridge.Cover.PermutationEnumeration

set_option maxRecDepth 100000
set_option maxHeartbeats 0

/-- Number of later smaller values, weighted in lexicographic factorial order. -/
def lehmerRank (p : Equiv.Perm (Fin 6)) : ℕ :=
  (List.ofFn fun i : Fin 6 =>
    ((List.finRange 6).filter fun j => i < j ∧ p j < p i).length *
      Nat.factorial (5 - i.val)).sum

theorem rank_block0 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (0 * 16 + j.val))) =
      0 * 16 + j.val := by
  decide +kernel
#print axioms rank_block0

theorem rank_block1 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (1 * 16 + j.val))) =
      1 * 16 + j.val := by
  decide +kernel
#print axioms rank_block1

theorem rank_block2 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (2 * 16 + j.val))) =
      2 * 16 + j.val := by
  decide +kernel
#print axioms rank_block2

theorem rank_block3 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (3 * 16 + j.val))) =
      3 * 16 + j.val := by
  decide +kernel
#print axioms rank_block3

theorem rank_block4 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (4 * 16 + j.val))) =
      4 * 16 + j.val := by
  decide +kernel
#print axioms rank_block4

theorem rank_block5 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (5 * 16 + j.val))) =
      5 * 16 + j.val := by
  decide +kernel
#print axioms rank_block5

theorem rank_block6 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (6 * 16 + j.val))) =
      6 * 16 + j.val := by
  decide +kernel
#print axioms rank_block6

theorem rank_block7 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (7 * 16 + j.val))) =
      7 * 16 + j.val := by
  decide +kernel
#print axioms rank_block7

theorem rank_block8 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (8 * 16 + j.val))) =
      8 * 16 + j.val := by
  decide +kernel
#print axioms rank_block8

theorem rank_block9 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (9 * 16 + j.val))) =
      9 * 16 + j.val := by
  decide +kernel
#print axioms rank_block9

theorem rank_block10 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (10 * 16 + j.val))) =
      10 * 16 + j.val := by
  decide +kernel
#print axioms rank_block10

theorem rank_block11 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (11 * 16 + j.val))) =
      11 * 16 + j.val := by
  decide +kernel
#print axioms rank_block11

theorem rank_block12 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (12 * 16 + j.val))) =
      12 * 16 + j.val := by
  decide +kernel
#print axioms rank_block12

theorem rank_block13 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (13 * 16 + j.val))) =
      13 * 16 + j.val := by
  decide +kernel
#print axioms rank_block13

theorem rank_block14 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (14 * 16 + j.val))) =
      14 * 16 + j.val := by
  decide +kernel
#print axioms rank_block14

theorem rank_block15 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (15 * 16 + j.val))) =
      15 * 16 + j.val := by
  decide +kernel
#print axioms rank_block15

theorem rank_block16 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (16 * 16 + j.val))) =
      16 * 16 + j.val := by
  decide +kernel
#print axioms rank_block16

theorem rank_block17 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (17 * 16 + j.val))) =
      17 * 16 + j.val := by
  decide +kernel
#print axioms rank_block17

theorem rank_block18 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (18 * 16 + j.val))) =
      18 * 16 + j.val := by
  decide +kernel
#print axioms rank_block18

theorem rank_block19 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (19 * 16 + j.val))) =
      19 * 16 + j.val := by
  decide +kernel
#print axioms rank_block19

theorem rank_block20 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (20 * 16 + j.val))) =
      20 * 16 + j.val := by
  decide +kernel
#print axioms rank_block20

theorem rank_block21 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (21 * 16 + j.val))) =
      21 * 16 + j.val := by
  decide +kernel
#print axioms rank_block21

theorem rank_block22 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (22 * 16 + j.val))) =
      22 * 16 + j.val := by
  decide +kernel
#print axioms rank_block22

theorem rank_block23 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (23 * 16 + j.val))) =
      23 * 16 + j.val := by
  decide +kernel
#print axioms rank_block23

theorem rank_block24 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (24 * 16 + j.val))) =
      24 * 16 + j.val := by
  decide +kernel
#print axioms rank_block24

theorem rank_block25 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (25 * 16 + j.val))) =
      25 * 16 + j.val := by
  decide +kernel
#print axioms rank_block25

theorem rank_block26 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (26 * 16 + j.val))) =
      26 * 16 + j.val := by
  decide +kernel
#print axioms rank_block26

theorem rank_block27 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (27 * 16 + j.val))) =
      27 * 16 + j.val := by
  decide +kernel
#print axioms rank_block27

theorem rank_block28 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (28 * 16 + j.val))) =
      28 * 16 + j.val := by
  decide +kernel
#print axioms rank_block28

theorem rank_block29 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (29 * 16 + j.val))) =
      29 * 16 + j.val := by
  decide +kernel
#print axioms rank_block29

theorem rank_block30 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (30 * 16 + j.val))) =
      30 * 16 + j.val := by
  decide +kernel
#print axioms rank_block30

theorem rank_block31 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (31 * 16 + j.val))) =
      31 * 16 + j.val := by
  decide +kernel
#print axioms rank_block31

theorem rank_block32 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (32 * 16 + j.val))) =
      32 * 16 + j.val := by
  decide +kernel
#print axioms rank_block32

theorem rank_block33 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (33 * 16 + j.val))) =
      33 * 16 + j.val := by
  decide +kernel
#print axioms rank_block33

theorem rank_block34 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (34 * 16 + j.val))) =
      34 * 16 + j.val := by
  decide +kernel
#print axioms rank_block34

theorem rank_block35 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (35 * 16 + j.val))) =
      35 * 16 + j.val := by
  decide +kernel
#print axioms rank_block35

theorem rank_block36 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (36 * 16 + j.val))) =
      36 * 16 + j.val := by
  decide +kernel
#print axioms rank_block36

theorem rank_block37 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (37 * 16 + j.val))) =
      37 * 16 + j.val := by
  decide +kernel
#print axioms rank_block37

theorem rank_block38 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (38 * 16 + j.val))) =
      38 * 16 + j.val := by
  decide +kernel
#print axioms rank_block38

theorem rank_block39 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (39 * 16 + j.val))) =
      39 * 16 + j.val := by
  decide +kernel
#print axioms rank_block39

theorem rank_block40 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (40 * 16 + j.val))) =
      40 * 16 + j.val := by
  decide +kernel
#print axioms rank_block40

theorem rank_block41 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (41 * 16 + j.val))) =
      41 * 16 + j.val := by
  decide +kernel
#print axioms rank_block41

theorem rank_block42 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (42 * 16 + j.val))) =
      42 * 16 + j.val := by
  decide +kernel
#print axioms rank_block42

theorem rank_block43 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (43 * 16 + j.val))) =
      43 * 16 + j.val := by
  decide +kernel
#print axioms rank_block43

theorem rank_block44 : ∀ j : Fin 16,
    lehmerRank (kernelPermutation (Fin.ofNat 720 (44 * 16 + j.val))) =
      44 * 16 + j.val := by
  decide +kernel
#print axioms rank_block44

/-- Checked left inverse on all 720 literal entries. -/
theorem rank_kernelPermutation (j : Fin 720) :
    lehmerRank (kernelPermutation j) = j.val := by
  have blocks : ∀ (b : Fin 45) (c : Fin 16),
      lehmerRank (kernelPermutation (Fin.ofNat 720 (b.val * 16 + c.val))) =
        b.val * 16 + c.val := by
    intro b
    fin_cases b
    · exact rank_block0
    · exact rank_block1
    · exact rank_block2
    · exact rank_block3
    · exact rank_block4
    · exact rank_block5
    · exact rank_block6
    · exact rank_block7
    · exact rank_block8
    · exact rank_block9
    · exact rank_block10
    · exact rank_block11
    · exact rank_block12
    · exact rank_block13
    · exact rank_block14
    · exact rank_block15
    · exact rank_block16
    · exact rank_block17
    · exact rank_block18
    · exact rank_block19
    · exact rank_block20
    · exact rank_block21
    · exact rank_block22
    · exact rank_block23
    · exact rank_block24
    · exact rank_block25
    · exact rank_block26
    · exact rank_block27
    · exact rank_block28
    · exact rank_block29
    · exact rank_block30
    · exact rank_block31
    · exact rank_block32
    · exact rank_block33
    · exact rank_block34
    · exact rank_block35
    · exact rank_block36
    · exact rank_block37
    · exact rank_block38
    · exact rank_block39
    · exact rank_block40
    · exact rank_block41
    · exact rank_block42
    · exact rank_block43
    · exact rank_block44
  let b : Fin 45 := ⟨j.val / 16, by have := j.isLt; omega⟩
  let c : Fin 16 := ⟨j.val % 16, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 16 + c.val = j.val := by dsimp [b, c]; omega
  have hj : Fin.ofNat 720 (b.val * 16 + c.val) = j := by
    ext
    change (b.val * 16 + c.val) % 720 = j.val
    rw [he, Nat.mod_eq_of_lt j.isLt]
  have h := blocks b c
  rw [hj, he] at h
  exact h
#print axioms rank_kernelPermutation

end TightCycleC5.Bridge.Cover.PermutationEnumeration
