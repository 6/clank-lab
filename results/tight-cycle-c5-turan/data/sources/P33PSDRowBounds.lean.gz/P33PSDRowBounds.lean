import P33FlagRows
import FiniteErrors

/-! Explicit finite loss for the sum of all 38 actual P33 PSD rows.
The source matrices already include the single SOS normalization. -/
namespace TightCycleC5.Bridge.P33PSDRowBounds
set_option maxRecDepth 100000
open Finset

noncomputable def errorConstant : ℝ :=
  16 * (P33PSD.bound0 + P33PSD.bound1 + P33PSD.bound2) +
    2 * (P33PSD.bound3 + P33PSD.bound4 + P33PSD.bound5 + P33PSD.bound6 + P33PSD.bound7 + P33PSD.bound8 + P33PSD.bound9 + P33PSD.bound10 + P33PSD.bound11 + P33PSD.bound12 + P33PSD.bound13 + P33PSD.bound14 + P33PSD.bound15 + P33PSD.bound16 + P33PSD.bound17 + P33PSD.bound18 + P33PSD.bound19 + P33PSD.bound20 + P33PSD.bound21 + P33PSD.bound22 + P33PSD.bound23 + P33PSD.bound24 + P33PSD.bound25 + P33PSD.bound26 + P33PSD.bound27 + P33PSD.bound28 + P33PSD.bound29 + P33PSD.bound30 + P33PSD.bound31 + P33PSD.bound32 + P33PSD.bound33 + P33PSD.bound34 + P33PSD.bound35 + P33PSD.bound36 + P33PSD.bound37)

noncomputable def rows (G : LabelledStructure 6) : ℝ :=
  P33Flag.row0 G +
    P33Flag.row1 G +
    P33Flag.row2 G +
    P33Flag.row3 G +
    P33Flag.row4 G +
    P33Flag.row5 G +
    P33Flag.row6 G +
    P33Flag.row7 G +
    P33Flag.row8 G +
    P33Flag.row9 G +
    P33Flag.row10 G +
    P33Flag.row11 G +
    P33Flag.row12 G +
    P33Flag.row13 G +
    P33Flag.row14 G +
    P33Flag.row15 G +
    P33Flag.row16 G +
    P33Flag.row17 G +
    P33Flag.row18 G +
    P33Flag.row19 G +
    P33Flag.row20 G +
    P33Flag.row21 G +
    P33Flag.row22 G +
    P33Flag.row23 G +
    P33Flag.row24 G +
    P33Flag.row25 G +
    P33Flag.row26 G +
    P33Flag.row27 G +
    P33Flag.row28 G +
    P33Flag.row29 G +
    P33Flag.row30 G +
    P33Flag.row31 G +
    P33Flag.row32 G +
    P33Flag.row33 G +
    P33Flag.row34 G +
    P33Flag.row35 G +
    P33Flag.row36 G +
    P33Flag.row37 G

theorem error_constant_nonneg : 0 ≤ errorConstant := by
  have h0 := P33PSD.normalized_nonneg0
  have h1 := P33PSD.normalized_nonneg1
  have h2 := P33PSD.normalized_nonneg2
  have h3 := P33PSD.normalized_nonneg3
  have h4 := P33PSD.normalized_nonneg4
  have h5 := P33PSD.normalized_nonneg5
  have h6 := P33PSD.normalized_nonneg6
  have h7 := P33PSD.normalized_nonneg7
  have h8 := P33PSD.normalized_nonneg8
  have h9 := P33PSD.normalized_nonneg9
  have h10 := P33PSD.normalized_nonneg10
  have h11 := P33PSD.normalized_nonneg11
  have h12 := P33PSD.normalized_nonneg12
  have h13 := P33PSD.normalized_nonneg13
  have h14 := P33PSD.normalized_nonneg14
  have h15 := P33PSD.normalized_nonneg15
  have h16 := P33PSD.normalized_nonneg16
  have h17 := P33PSD.normalized_nonneg17
  have h18 := P33PSD.normalized_nonneg18
  have h19 := P33PSD.normalized_nonneg19
  have h20 := P33PSD.normalized_nonneg20
  have h21 := P33PSD.normalized_nonneg21
  have h22 := P33PSD.normalized_nonneg22
  have h23 := P33PSD.normalized_nonneg23
  have h24 := P33PSD.normalized_nonneg24
  have h25 := P33PSD.normalized_nonneg25
  have h26 := P33PSD.normalized_nonneg26
  have h27 := P33PSD.normalized_nonneg27
  have h28 := P33PSD.normalized_nonneg28
  have h29 := P33PSD.normalized_nonneg29
  have h30 := P33PSD.normalized_nonneg30
  have h31 := P33PSD.normalized_nonneg31
  have h32 := P33PSD.normalized_nonneg32
  have h33 := P33PSD.normalized_nonneg33
  have h34 := P33PSD.normalized_nonneg34
  have h35 := P33PSD.normalized_nonneg35
  have h36 := P33PSD.normalized_nonneg36
  have h37 := P33PSD.normalized_nonneg37
  unfold errorConstant
  positivity

theorem rows_mean_lower {n : Nat} (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (hn : 12 ≤ n) :
    -(errorConstant / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => rows (sampleStructure σ H S)) := by
  have hnR : (12 : ℝ) ≤ n := by exact_mod_cast hn
  have hr0 := P33Flag.row0_lower H S hn
  have he0 : (4 * (n : ℝ) - 14) * P33PSD.bound0 /
      (((n : ℝ) - 4) * ((n : ℝ) - 5)) ≤ 16 * P33PSD.bound0 / (n : ℝ) := by
    calc
      _ = ((4 * (n : ℝ) - 14) / (((n : ℝ) - 4) * ((n : ℝ) - 5))) * P33PSD.bound0 := by ring
      _ ≤ (16 / (n : ℝ)) * P33PSD.bound0 :=
        mul_le_mul_of_nonneg_right (pair_collision_error_le hnR) P33PSD.normalized_nonneg0
      _ = _ := by ring
  have h0 : -(16 * P33PSD.bound0 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row0 (sampleStructure σ H S)) := by linarith
  have hr1 := P33Flag.row1_lower H S hn
  have he1 : (4 * (n : ℝ) - 14) * P33PSD.bound1 /
      (((n : ℝ) - 4) * ((n : ℝ) - 5)) ≤ 16 * P33PSD.bound1 / (n : ℝ) := by
    calc
      _ = ((4 * (n : ℝ) - 14) / (((n : ℝ) - 4) * ((n : ℝ) - 5))) * P33PSD.bound1 := by ring
      _ ≤ (16 / (n : ℝ)) * P33PSD.bound1 :=
        mul_le_mul_of_nonneg_right (pair_collision_error_le hnR) P33PSD.normalized_nonneg1
      _ = _ := by ring
  have h1 : -(16 * P33PSD.bound1 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row1 (sampleStructure σ H S)) := by linarith
  have hr2 := P33Flag.row2_lower H S hn
  have he2 : (4 * (n : ℝ) - 14) * P33PSD.bound2 /
      (((n : ℝ) - 4) * ((n : ℝ) - 5)) ≤ 16 * P33PSD.bound2 / (n : ℝ) := by
    calc
      _ = ((4 * (n : ℝ) - 14) / (((n : ℝ) - 4) * ((n : ℝ) - 5))) * P33PSD.bound2 := by ring
      _ ≤ (16 / (n : ℝ)) * P33PSD.bound2 :=
        mul_le_mul_of_nonneg_right (pair_collision_error_le hnR) P33PSD.normalized_nonneg2
      _ = _ := by ring
  have h2 : -(16 * P33PSD.bound2 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row2 (sampleStructure σ H S)) := by linarith
  have hr3 := P33Flag.row3_lower H S hn
  rw [neg_div] at hr3
  have he3 : P33PSD.bound3 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound3 / (n : ℝ) := by
    calc
      _ = P33PSD.bound3 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound3 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg3
      _ = _ := by ring
  have h3 : -(2 * P33PSD.bound3 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row3 (sampleStructure σ H S)) := by linarith
  have hr4 := P33Flag.row4_lower H S hn
  rw [neg_div] at hr4
  have he4 : P33PSD.bound4 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound4 / (n : ℝ) := by
    calc
      _ = P33PSD.bound4 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound4 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg4
      _ = _ := by ring
  have h4 : -(2 * P33PSD.bound4 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row4 (sampleStructure σ H S)) := by linarith
  have hr5 := P33Flag.row5_lower H S hn
  rw [neg_div] at hr5
  have he5 : P33PSD.bound5 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound5 / (n : ℝ) := by
    calc
      _ = P33PSD.bound5 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound5 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg5
      _ = _ := by ring
  have h5 : -(2 * P33PSD.bound5 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row5 (sampleStructure σ H S)) := by linarith
  have hr6 := P33Flag.row6_lower H S hn
  rw [neg_div] at hr6
  have he6 : P33PSD.bound6 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound6 / (n : ℝ) := by
    calc
      _ = P33PSD.bound6 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound6 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg6
      _ = _ := by ring
  have h6 : -(2 * P33PSD.bound6 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row6 (sampleStructure σ H S)) := by linarith
  have hr7 := P33Flag.row7_lower H S hn
  rw [neg_div] at hr7
  have he7 : P33PSD.bound7 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound7 / (n : ℝ) := by
    calc
      _ = P33PSD.bound7 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound7 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg7
      _ = _ := by ring
  have h7 : -(2 * P33PSD.bound7 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row7 (sampleStructure σ H S)) := by linarith
  have hr8 := P33Flag.row8_lower H S hn
  rw [neg_div] at hr8
  have he8 : P33PSD.bound8 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound8 / (n : ℝ) := by
    calc
      _ = P33PSD.bound8 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound8 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg8
      _ = _ := by ring
  have h8 : -(2 * P33PSD.bound8 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row8 (sampleStructure σ H S)) := by linarith
  have hr9 := P33Flag.row9_lower H S hn
  rw [neg_div] at hr9
  have he9 : P33PSD.bound9 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound9 / (n : ℝ) := by
    calc
      _ = P33PSD.bound9 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound9 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg9
      _ = _ := by ring
  have h9 : -(2 * P33PSD.bound9 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row9 (sampleStructure σ H S)) := by linarith
  have hr10 := P33Flag.row10_lower H S hn
  rw [neg_div] at hr10
  have he10 : P33PSD.bound10 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound10 / (n : ℝ) := by
    calc
      _ = P33PSD.bound10 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound10 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg10
      _ = _ := by ring
  have h10 : -(2 * P33PSD.bound10 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row10 (sampleStructure σ H S)) := by linarith
  have hr11 := P33Flag.row11_lower H S hn
  rw [neg_div] at hr11
  have he11 : P33PSD.bound11 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound11 / (n : ℝ) := by
    calc
      _ = P33PSD.bound11 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound11 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg11
      _ = _ := by ring
  have h11 : -(2 * P33PSD.bound11 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row11 (sampleStructure σ H S)) := by linarith
  have hr12 := P33Flag.row12_lower H S hn
  rw [neg_div] at hr12
  have he12 : P33PSD.bound12 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound12 / (n : ℝ) := by
    calc
      _ = P33PSD.bound12 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound12 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg12
      _ = _ := by ring
  have h12 : -(2 * P33PSD.bound12 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row12 (sampleStructure σ H S)) := by linarith
  have hr13 := P33Flag.row13_lower H S hn
  rw [neg_div] at hr13
  have he13 : P33PSD.bound13 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound13 / (n : ℝ) := by
    calc
      _ = P33PSD.bound13 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound13 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg13
      _ = _ := by ring
  have h13 : -(2 * P33PSD.bound13 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row13 (sampleStructure σ H S)) := by linarith
  have hr14 := P33Flag.row14_lower H S hn
  rw [neg_div] at hr14
  have he14 : P33PSD.bound14 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound14 / (n : ℝ) := by
    calc
      _ = P33PSD.bound14 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound14 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg14
      _ = _ := by ring
  have h14 : -(2 * P33PSD.bound14 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row14 (sampleStructure σ H S)) := by linarith
  have hr15 := P33Flag.row15_lower H S hn
  rw [neg_div] at hr15
  have he15 : P33PSD.bound15 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound15 / (n : ℝ) := by
    calc
      _ = P33PSD.bound15 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound15 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg15
      _ = _ := by ring
  have h15 : -(2 * P33PSD.bound15 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row15 (sampleStructure σ H S)) := by linarith
  have hr16 := P33Flag.row16_lower H S hn
  rw [neg_div] at hr16
  have he16 : P33PSD.bound16 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound16 / (n : ℝ) := by
    calc
      _ = P33PSD.bound16 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound16 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg16
      _ = _ := by ring
  have h16 : -(2 * P33PSD.bound16 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row16 (sampleStructure σ H S)) := by linarith
  have hr17 := P33Flag.row17_lower H S hn
  rw [neg_div] at hr17
  have he17 : P33PSD.bound17 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound17 / (n : ℝ) := by
    calc
      _ = P33PSD.bound17 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound17 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg17
      _ = _ := by ring
  have h17 : -(2 * P33PSD.bound17 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row17 (sampleStructure σ H S)) := by linarith
  have hr18 := P33Flag.row18_lower H S hn
  rw [neg_div] at hr18
  have he18 : P33PSD.bound18 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound18 / (n : ℝ) := by
    calc
      _ = P33PSD.bound18 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound18 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg18
      _ = _ := by ring
  have h18 : -(2 * P33PSD.bound18 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row18 (sampleStructure σ H S)) := by linarith
  have hr19 := P33Flag.row19_lower H S hn
  rw [neg_div] at hr19
  have he19 : P33PSD.bound19 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound19 / (n : ℝ) := by
    calc
      _ = P33PSD.bound19 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound19 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg19
      _ = _ := by ring
  have h19 : -(2 * P33PSD.bound19 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row19 (sampleStructure σ H S)) := by linarith
  have hr20 := P33Flag.row20_lower H S hn
  rw [neg_div] at hr20
  have he20 : P33PSD.bound20 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound20 / (n : ℝ) := by
    calc
      _ = P33PSD.bound20 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound20 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg20
      _ = _ := by ring
  have h20 : -(2 * P33PSD.bound20 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row20 (sampleStructure σ H S)) := by linarith
  have hr21 := P33Flag.row21_lower H S hn
  rw [neg_div] at hr21
  have he21 : P33PSD.bound21 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound21 / (n : ℝ) := by
    calc
      _ = P33PSD.bound21 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound21 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg21
      _ = _ := by ring
  have h21 : -(2 * P33PSD.bound21 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row21 (sampleStructure σ H S)) := by linarith
  have hr22 := P33Flag.row22_lower H S hn
  rw [neg_div] at hr22
  have he22 : P33PSD.bound22 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound22 / (n : ℝ) := by
    calc
      _ = P33PSD.bound22 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound22 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg22
      _ = _ := by ring
  have h22 : -(2 * P33PSD.bound22 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row22 (sampleStructure σ H S)) := by linarith
  have hr23 := P33Flag.row23_lower H S hn
  rw [neg_div] at hr23
  have he23 : P33PSD.bound23 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound23 / (n : ℝ) := by
    calc
      _ = P33PSD.bound23 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound23 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg23
      _ = _ := by ring
  have h23 : -(2 * P33PSD.bound23 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row23 (sampleStructure σ H S)) := by linarith
  have hr24 := P33Flag.row24_lower H S hn
  rw [neg_div] at hr24
  have he24 : P33PSD.bound24 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound24 / (n : ℝ) := by
    calc
      _ = P33PSD.bound24 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound24 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg24
      _ = _ := by ring
  have h24 : -(2 * P33PSD.bound24 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row24 (sampleStructure σ H S)) := by linarith
  have hr25 := P33Flag.row25_lower H S hn
  rw [neg_div] at hr25
  have he25 : P33PSD.bound25 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound25 / (n : ℝ) := by
    calc
      _ = P33PSD.bound25 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound25 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg25
      _ = _ := by ring
  have h25 : -(2 * P33PSD.bound25 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row25 (sampleStructure σ H S)) := by linarith
  have hr26 := P33Flag.row26_lower H S hn
  rw [neg_div] at hr26
  have he26 : P33PSD.bound26 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound26 / (n : ℝ) := by
    calc
      _ = P33PSD.bound26 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound26 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg26
      _ = _ := by ring
  have h26 : -(2 * P33PSD.bound26 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row26 (sampleStructure σ H S)) := by linarith
  have hr27 := P33Flag.row27_lower H S hn
  rw [neg_div] at hr27
  have he27 : P33PSD.bound27 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound27 / (n : ℝ) := by
    calc
      _ = P33PSD.bound27 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound27 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg27
      _ = _ := by ring
  have h27 : -(2 * P33PSD.bound27 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row27 (sampleStructure σ H S)) := by linarith
  have hr28 := P33Flag.row28_lower H S hn
  rw [neg_div] at hr28
  have he28 : P33PSD.bound28 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound28 / (n : ℝ) := by
    calc
      _ = P33PSD.bound28 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound28 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg28
      _ = _ := by ring
  have h28 : -(2 * P33PSD.bound28 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row28 (sampleStructure σ H S)) := by linarith
  have hr29 := P33Flag.row29_lower H S hn
  rw [neg_div] at hr29
  have he29 : P33PSD.bound29 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound29 / (n : ℝ) := by
    calc
      _ = P33PSD.bound29 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound29 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg29
      _ = _ := by ring
  have h29 : -(2 * P33PSD.bound29 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row29 (sampleStructure σ H S)) := by linarith
  have hr30 := P33Flag.row30_lower H S hn
  rw [neg_div] at hr30
  have he30 : P33PSD.bound30 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound30 / (n : ℝ) := by
    calc
      _ = P33PSD.bound30 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound30 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg30
      _ = _ := by ring
  have h30 : -(2 * P33PSD.bound30 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row30 (sampleStructure σ H S)) := by linarith
  have hr31 := P33Flag.row31_lower H S hn
  rw [neg_div] at hr31
  have he31 : P33PSD.bound31 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound31 / (n : ℝ) := by
    calc
      _ = P33PSD.bound31 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound31 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg31
      _ = _ := by ring
  have h31 : -(2 * P33PSD.bound31 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row31 (sampleStructure σ H S)) := by linarith
  have hr32 := P33Flag.row32_lower H S hn
  rw [neg_div] at hr32
  have he32 : P33PSD.bound32 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound32 / (n : ℝ) := by
    calc
      _ = P33PSD.bound32 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound32 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg32
      _ = _ := by ring
  have h32 : -(2 * P33PSD.bound32 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row32 (sampleStructure σ H S)) := by linarith
  have hr33 := P33Flag.row33_lower H S hn
  rw [neg_div] at hr33
  have he33 : P33PSD.bound33 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound33 / (n : ℝ) := by
    calc
      _ = P33PSD.bound33 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound33 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg33
      _ = _ := by ring
  have h33 : -(2 * P33PSD.bound33 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row33 (sampleStructure σ H S)) := by linarith
  have hr34 := P33Flag.row34_lower H S hn
  rw [neg_div] at hr34
  have he34 : P33PSD.bound34 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound34 / (n : ℝ) := by
    calc
      _ = P33PSD.bound34 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound34 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg34
      _ = _ := by ring
  have h34 : -(2 * P33PSD.bound34 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row34 (sampleStructure σ H S)) := by linarith
  have hr35 := P33Flag.row35_lower H S hn
  rw [neg_div] at hr35
  have he35 : P33PSD.bound35 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound35 / (n : ℝ) := by
    calc
      _ = P33PSD.bound35 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound35 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg35
      _ = _ := by ring
  have h35 : -(2 * P33PSD.bound35 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row35 (sampleStructure σ H S)) := by linarith
  have hr36 := P33Flag.row36_lower H S hn
  rw [neg_div] at hr36
  have he36 : P33PSD.bound36 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound36 / (n : ℝ) := by
    calc
      _ = P33PSD.bound36 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound36 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg36
      _ = _ := by ring
  have h36 : -(2 * P33PSD.bound36 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row36 (sampleStructure σ H S)) := by linarith
  have hr37 := P33Flag.row37_lower H S hn
  rw [neg_div] at hr37
  have he37 : P33PSD.bound37 / ((n : ℝ) - 5) ≤ 2 * P33PSD.bound37 / (n : ℝ) := by
    calc
      _ = P33PSD.bound37 * (1 / ((n : ℝ) - 5)) := by ring
      _ ≤ P33PSD.bound37 * (2 / (n : ℝ)) :=
        mul_le_mul_of_nonneg_left (common_set_error_le hnR) P33PSD.normalized_nonneg37
      _ = _ := by ring
  have h37 : -(2 * P33PSD.bound37 / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => P33Flag.row37 (sampleStructure σ H S)) := by linarith
  simp only [rows, uniformMean, Finset.sum_add_distrib, add_div] at *
  unfold errorConstant
  simp only [mul_add, add_div]
  linarith only [h0, h1, h2, h3, h4, h5, h6, h7, h8, h9, h10, h11, h12, h13, h14, h15, h16, h17, h18, h19, h20, h21, h22, h23, h24, h25, h26, h27, h28, h29, h30, h31, h32, h33, h34, h35, h36, h37]

#print axioms error_constant_nonneg
#print axioms rows_mean_lower
end TightCycleC5.Bridge.P33PSDRowBounds
