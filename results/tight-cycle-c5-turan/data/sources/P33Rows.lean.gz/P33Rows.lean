import P33RowsFinite
import P33RowsGlobal

namespace TightCycleC5.Bridge.P33Rows
open Finset

/-- Literal source rows, with their source ordering and fixed label positions. -/
def sourceLocalRow (i : Fin 80) := localRow (localDescriptor i)
def sourceRegularRow (i : Fin 120) := regularRow (regularDescriptor i)
noncomputable def sourceCutRow (i : Fin 8) := cutRow (cutDescriptor i)
noncomputable def sourceDensityRow (i : Fin 9) := densityRow (densityDescriptor i)

theorem source_local_flag {V : Type*} (i : Fin 80) (e : EdgeFn V) (c : ColorFn V)
    (x a b d : V) : localFlag (localDescriptor i) e c x a b d =
      if canonicalLocal e c x a b d = localFlags[i.val]! then 1 else 0 :=
  localFlag_of_typed _ (local_descriptor_typed i) e c x a b d

theorem source_regular_flag {V : Type*} (i : Fin 120) (e : EdgeFn V) (c : ColorFn V)
    (x u b d : V) : regularFlag (regularDescriptor i) e c x u b d =
      if canonicalRegular e c x u b d = regularFlags[i.val]! then 1 else 0 :=
  regularFlag_of_typed _ (regular_descriptor_typed i) e c x u b d

theorem source_local_lower {n : Nat} (i : Fin 80) (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (S : Finset (Fin n)) (hS : LocallyMaximal H S) (hn : 12 ≤ n) :
    -(6 * ((n : ℝ) - 3) / (((n : ℝ) - 4) * ((n : ℝ) - 5))) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => sourceLocalRow i (sampleStructure σ H S)) :=
  localRow_mean_lower _ H hH S hS hn

theorem source_regular_abs_le {n : Nat} (i : Fin 120) (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (S : Finset (Fin n)) (hn : 12 ≤ n) (δ : ℝ)
    (hreg : ∀ x u, (deg H x : ℝ) ≤ deg H u + δ * (n : ℝ) ^ 2) :
    |uniformMean (fun σ : Fin 6 ↪ Fin n => sourceRegularRow i (sampleStructure σ H S))| ≤
      (2 * δ * (n : ℝ) ^ 2 + 4 * (n : ℝ) - 14) / (((n : ℝ) - 4) * ((n : ℝ) - 5)) :=
  regularRow_mean_abs_le _ H hH S hn δ hreg

theorem source_cut_lower {n : Nat} (i : Fin 8) (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (S : Finset (Fin n)) (hn : 12 ≤ n) (δ : ℝ) (hδ : 0 ≤ δ)
    (hcut : (2 / 5 - δ) * (n.choose 3 : ℝ) ≤ cutCount H S) :
    -tripleRatio n * δ - tripleError n ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => sourceCutRow i (sampleStructure σ H S)) :=
  cutRow_mean_lower _ H hH S hn δ hδ hcut

theorem source_density_lower {n : Nat} (i : Fin 9) (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (S : Finset (Fin n)) (hn : 12 ≤ n) (δ : ℝ) (hδ : 0 ≤ δ)
    (hdensity : (densityBound - δ) * (n.choose 3 : ℝ) ≤ H.card) :
    -tripleRatio n * δ - tripleError n ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => sourceDensityRow i (sampleStructure σ H S)) :=
  densityRow_mean_lower _ H hH S hn δ hδ hdensity

theorem source_density_ninth_exact {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (S : Finset (Fin n)) (hn : 6 ≤ n) :
    uniformMean (fun σ : Fin 6 ↪ Fin n => sourceDensityRow 8 (sampleStructure σ H S)) =
      (H.card : ℝ) / (n.choose 3 : ℝ) - densityBound :=
  densityRow_none_mean H hH S hn

theorem source_weighted_local_lower {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (S : Finset (Fin n)) (hS : LocallyMaximal H S) (hn : 12 ≤ n) :
    (∑ i : Fin 80, localWeight i) *
      -(6 * ((n : ℝ) - 3) / (((n : ℝ) - 4) * ((n : ℝ) - 5))) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => ∑ i : Fin 80,
        localWeight i * sourceLocalRow i (sampleStructure σ H S)) :=
  weighted_localRow_mean_lower localDescriptor localWeight localWeight_nonneg H hH S hS hn

/-- Regularity weights are arbitrary signed source coefficients. -/
theorem source_weighted_regular_abs_le {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (S : Finset (Fin n)) (hn : 12 ≤ n) (δ : ℝ)
    (hreg : ∀ x u, (deg H x : ℝ) ≤ deg H u + δ * (n : ℝ) ^ 2) :
    |uniformMean (fun σ : Fin 6 ↪ Fin n => ∑ i : Fin 120,
      regularWeight i * sourceRegularRow i (sampleStructure σ H S))| ≤
      (∑ i : Fin 120, |regularWeight i|) *
        ((2 * δ * (n : ℝ) ^ 2 + 4 * (n : ℝ) - 14) / (((n : ℝ) - 4) * ((n : ℝ) - 5))) :=
  weighted_regularRow_mean_abs_le regularDescriptor regularWeight H hH S hn δ hreg

theorem source_weighted_cut_lower {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (S : Finset (Fin n)) (hn : 12 ≤ n) (δ : ℝ) (hδ : 0 ≤ δ)
    (hcut : (2 / 5 - δ) * (n.choose 3 : ℝ) ≤ cutCount H S) :
    (∑ i : Fin 8, cutWeight i) * (-tripleRatio n * δ - tripleError n) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => ∑ i : Fin 8,
        cutWeight i * sourceCutRow i (sampleStructure σ H S)) := by
  rw [mean_weighted, Finset.sum_mul]
  exact Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_left
    (source_cut_lower i H hH S hn δ hδ hcut) (cutWeight_nonneg i))

theorem source_weighted_density_lower {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (S : Finset (Fin n)) (hn : 12 ≤ n) (δ : ℝ) (hδ : 0 ≤ δ)
    (hdensity : (densityBound - δ) * (n.choose 3 : ℝ) ≤ H.card) :
    (∑ i : Fin 9, densityWeight i) * (-tripleRatio n * δ - tripleError n) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => ∑ i : Fin 9,
        densityWeight i * sourceDensityRow i (sampleStructure σ H S)) := by
  rw [mean_weighted, Finset.sum_mul]
  exact Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_left
    (source_density_lower i H hH S hn δ hδ hdensity) (densityWeight_nonneg i))

/-- A common model witnesses that the exact finite hypotheses can hold together. -/
theorem hypotheses_control :
    IsThreeGraph (∅ : Finset (Finset (Fin 12))) ∧
    LocallyMaximal (∅ : Finset (Finset (Fin 12))) ∅ ∧
    (∀ x u : Fin 12, (deg ∅ x : ℝ) ≤ deg ∅ u + (1 : ℝ) * (12 : ℝ)^2) ∧
    (2 / 5 - (1 : ℝ)) * (12 : ℕ).choose 3 ≤
      cutCount (∅ : Finset (Finset (Fin 12))) ∅ ∧
    (densityBound - (1 : ℝ)) * (12 : ℕ).choose 3 ≤
      ((∅ : Finset (Finset (Fin 12))).card : ℝ) := by
  norm_num [IsThreeGraph, LocallyMaximal, cutCount, deg, densityBound]

#print axioms hypotheses_control
#print axioms source_local_flag
#print axioms source_regular_flag
#print axioms source_local_lower
#print axioms source_regular_abs_le
#print axioms source_cut_lower
#print axioms source_density_lower
#print axioms source_density_ninth_exact
#print axioms source_weighted_local_lower
#print axioms source_weighted_regular_abs_le
#print axioms source_weighted_cut_lower
#print axioms source_weighted_density_lower
end TightCycleC5.Bridge.P33Rows
