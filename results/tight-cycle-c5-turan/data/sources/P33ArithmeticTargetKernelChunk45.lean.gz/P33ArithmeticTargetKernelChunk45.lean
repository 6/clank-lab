-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk180 :
    ∀ i : Fin (min 128 (40547 - 128 * 180)),
      targetCountsMatch (classAt (targetKernelClass ⟨180, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk180

theorem target_counts_kernel_chunk181 :
    ∀ i : Fin (min 128 (40547 - 128 * 181)),
      targetCountsMatch (classAt (targetKernelClass ⟨181, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk181

theorem target_counts_kernel_chunk182 :
    ∀ i : Fin (min 128 (40547 - 128 * 182)),
      targetCountsMatch (classAt (targetKernelClass ⟨182, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk182

theorem target_counts_kernel_chunk183 :
    ∀ i : Fin (min 128 (40547 - 128 * 183)),
      targetCountsMatch (classAt (targetKernelClass ⟨183, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk183


end TightCycleC5.Bridge.P33Arithmetic
