import P33Rows
import CertificateDescriptorsCL

namespace TightCycleC5.Bridge.P33RowMatching
open Finset

/-- Actual source rows, with the exact arithmetic flat index partition. -/
noncomputable def actualInequalityRow (G : LabelledStructure 6) (i : Fin 12847) : ℝ :=
  if h : i.val < 80 then P33Rows.sourceLocalRow ⟨i.val,h⟩ G
  else if h : i.val < 88 then P33Rows.sourceCutRow ⟨i.val-80,by omega⟩ G
  else if h : i.val < 97 then P33Rows.sourceDensityRow ⟨i.val-88,by omega⟩ G
  else CLCertificate.row (CertificateDescriptors.p33CL ⟨i.val-97,by omega⟩) G

/-- Source multiplier corresponding to the same flat row partition. -/
noncomputable def actualInequalityWeight (i : Fin 12847) : ℝ :=
  if h : i.val < 97 then P33Rows.inequalityWeight ⟨i.val,h⟩
  else CertificateDescriptors.p33CLWeight false ⟨i.val-97,by omega⟩

/-- Signed non-PSD source contribution. Every weight is raw/sourceScale once.
The target and PSD terms are intentionally separate mathematical objects. -/
noncomputable def actualNonPSD (G : LabelledStructure 6) : ℝ :=
  (∑ i : Fin 80, P33Rows.localWeight i * P33Rows.sourceLocalRow i G) +
  (∑ i : Fin 8, P33Rows.cutWeight i * P33Rows.sourceCutRow i G) +
  (∑ i : Fin 9, P33Rows.densityWeight i * P33Rows.sourceDensityRow i G) +
  (∑ j : Fin 12750, CertificateDescriptors.p33CLWeight false j *
    CLCertificate.row (CertificateDescriptors.p33CL j) G) +
  (∑ r : Fin 120, P33Rows.regularWeight r * P33Rows.sourceRegularRow r G)

end TightCycleC5.Bridge.P33RowMatching
