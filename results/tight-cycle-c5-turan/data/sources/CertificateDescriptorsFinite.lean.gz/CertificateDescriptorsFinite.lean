import CertificateDescriptorsSigned
import Mathlib

/-! Kernel checks of signed inputs and exact finite descriptor indexing. -/
namespace TightCycleC5.Bridge.CertificateDescriptors

set_option maxRecDepth 100000
set_option maxHeartbeats 4000000

def nonnegativeInput (ys : Array Int) (size : Nat) : Prop :=
  ys.size = size ∧ ∀ i : Fin size, 0 ≤ ys[i.val]!

theorem nonnegativeInput_of_blocks (blocks : Array (Array Int)) (size count : Nat)
    (hc : blocks.size = count) (hs : (blocks.map Array.size).sum = size)
    (h : ∀ b : Fin count, (blocks[b.val]!).all (fun z => decide (0 ≤ z)) = true) :
    nonnegativeInput blocks.flatten size := by
  refine ⟨by simpa only [Array.size_flatten] using hs, fun i => ?_⟩
  have hi : i.val < blocks.flatten.size := by simpa only [Array.size_flatten, hs] using i.isLt
  rw [getElem!_pos blocks.flatten i.val hi]
  obtain ⟨xs, hb, hz⟩ := Array.mem_flatten.mp (Array.mem_of_getElem (rfl : blocks.flatten[i.val] = _))
  obtain ⟨b, hb', rfl⟩ := Array.mem_iff_getElem.mp hb
  have hbcount : b < count := by omega
  have hh := Array.all_eq_true_iff_forall_mem.mp (h ⟨b, hbcount⟩)
  have hxs : blocks[b]! = blocks[b] := getElem!_pos blocks b hb'
  simp only [hxs] at hh
  exact decide_eq_true_eq.mp (hh _ hz)

theorem p32_signed_checked : nonnegativeInput p32YData 9511 :=
  nonnegativeInput_of_blocks _ _ 75 (by decide +kernel) (by decide +kernel) p32_blocks_nonneg
theorem p33a_signed_checked : nonnegativeInput p33aYData 12847 :=
  nonnegativeInput_of_blocks _ _ 101 (by decide +kernel) (by decide +kernel) p33a_blocks_nonneg
theorem p33b_signed_checked : nonnegativeInput p33bYData 12847 :=
  nonnegativeInput_of_blocks _ _ 101 (by decide +kernel) (by decide +kernel) p33b_blocks_nonneg

theorem p32_scales_positive : 0 < p32ProbabilityScale ∧ 0 < p32WeightScale ∧
    0 < p32FactorScale ∧ 0 < p32Scale := by decide +kernel

theorem p33_scales_positive : 0 < p33aScale ∧ 0 < p33bScale ∧
    0 < p33aClassDenominator ∧ 0 < p33bClassDenominator := by decide +kernel

theorem rejects_negative_of_size (ys : Array Int) (size : Nat)
    (hs : ys.size = size) (hp : 0 < size) :
    ¬ nonnegativeInput (ys.set! 0 (-1)) size := by
  intro h
  have hz := h.2 ⟨0, hp⟩
  have hi : 0 < ys.size := by omega
  change 0 ≤ (ys.set! 0 (-1))[0]! at hz
  rw [Array.getElem!_set!_self ys 0 (-1) hi] at hz
  norm_num at hz

theorem p32_rejects_negative :
    ¬ nonnegativeInput (p32YData.set! 0 (-1)) 9511 :=
  rejects_negative_of_size _ _ p32_signed_checked.1 (by decide)
theorem p33a_rejects_negative :
    ¬ nonnegativeInput (p33aYData.set! 0 (-1)) 12847 :=
  rejects_negative_of_size _ _ p33a_signed_checked.1 (by decide)
theorem p33b_rejects_negative :
    ¬ nonnegativeInput (p33bYData.set! 0 (-1)) 12847 :=
  rejects_negative_of_size _ _ p33b_signed_checked.1 (by decide)

/-- The exact flat-index decoding checked against the frozen CL records. -/
def p33RawRecord (j : Nat) : CLRecord :=
  if j < 510 then ⟨j, j / 255, -1, 3, j % 255 + 1⟩
  else
    let v := j - 510
    let combo := v / 255
    ⟨j, combo / 24, ((combo / 3) % 8 : Nat), combo % 3 + 1, v % 255 + 1⟩

def p33IndexRecord (j : Fin 12750) : CLRecord := p33RawRecord j.val

theorem p33_records_dimension : p33CLRecords.size = 12750 := by
  rw [p33CLRecords, Array.size_flatten]
  decide +kernel

theorem p33_record_blocks_dimensions (b : Fin 100) :
    (p33CLRecordBlocks[b.val]!).size = min 128 (12750 - 128 * b.val) := by
  fin_cases b <;> decide +kernel

theorem p33_record_blocks_checked (b : Fin 100) : ∀ r : Fin 128,
    128 * b.val + r.val < 12750 →
    (p33CLRecordBlocks[b.val]!)[r.val]! = p33RawRecord (128 * b.val + r.val) := by
  fin_cases b <;> decide +kernel

theorem p33_records_exact (j : Fin 12750) :
    p33CLRecordAt j = p33IndexRecord j := by
  have hb : j.val / 128 < 100 := by omega
  have hr : j.val % 128 < 128 := Nat.mod_lt _ (by decide)
  have he : 128 * (j.val / 128) + j.val % 128 = j.val := by omega
  have h := p33_record_blocks_checked ⟨j.val / 128, hb⟩ ⟨j.val % 128, hr⟩ (by simpa only [he] using j.isLt)
  simpa only [he, p33CLRecordAt, p33IndexRecord] using h

theorem p33_record_bounds : ∀ j : Fin 12750,
    (p33IndexRecord j).serial = j.val ∧ (p33IndexRecord j).tau < 2 ∧
    ((p33IndexRecord j).rootColor = -1 ∨
      0 ≤ (p33IndexRecord j).rootColor ∧ (p33IndexRecord j).rootColor < 8) ∧
    1 ≤ (p33IndexRecord j).colors ∧ (p33IndexRecord j).colors ≤ 3 ∧
    1 ≤ (p33IndexRecord j).mask ∧ (p33IndexRecord j).mask ≤ 255 := by
  intro j
  unfold p33IndexRecord p33RawRecord
  split_ifs with h <;> dsimp
  · have := Nat.mod_lt j.val (by decide : 0 < 255)
    omega
  · have := Nat.mod_lt (j.val - 510) (by decide : 0 < 255)
    have := Nat.mod_lt ((j.val - 510) / 255) (by decide : 0 < 3)
    have := Nat.mod_lt ((j.val - 510) / 255 / 3) (by decide : 0 < 8)
    omega

/-- The frozen singleton/pairs interleaving, followed by full32. -/
def bookMaskEnumeration : List Nat :=
  ((List.range 32).flatMap fun a =>
    (2 ^ a) :: (((List.range 32).filter fun b => a < b).map fun b => 2 ^ a + 2 ^ b)) ++
      [2 ^ 32 - 1]

theorem book_masks_exact : bookMasksData.toList = bookMaskEnumeration := by decide +kernel
theorem book_enumeration_length : bookMaskEnumeration.length = 529 := by decide +kernel
theorem book_masks_dimension : bookMasksData.size = 529 := by decide +kernel

def bookMask (r : Fin 529) : Nat := bookMasksData[r.val]!
def bookIndicator (r : Fin 529) (p : Fin 32) : Int :=
  if (BitVec.ofNat 32 (bookMask r)).getLsbD p.val then 1 else 0

theorem book_masks_fit : ∀ r : Fin 529, bookMask r < 2 ^ 32 := by decide +kernel

theorem book_masks_weights_checked (r : Fin 529) :
    bookMask r < 2 ^ 32 ∧ ∀ p : Fin 32, bookIndicator r p = 0 ∨ bookIndicator r p = 1 := by
  refine ⟨book_masks_fit r, fun p => ?_⟩
  unfold bookIndicator
  split_ifs <;> simp

#print axioms nonnegativeInput_of_blocks
#print axioms p32_signed_checked
#print axioms p33a_signed_checked
#print axioms p33b_signed_checked
#print axioms p32_scales_positive
#print axioms p33_scales_positive
#print axioms rejects_negative_of_size
#print axioms p32_rejects_negative
#print axioms p33a_rejects_negative
#print axioms p33b_rejects_negative
#print axioms p33_records_dimension
#print axioms p33_record_blocks_dimensions
#print axioms p33_record_blocks_checked
#print axioms p33_records_exact
#print axioms p33_record_bounds
#print axioms book_masks_exact
#print axioms book_enumeration_length
#print axioms book_masks_dimension
#print axioms book_masks_fit
#print axioms book_masks_weights_checked
end TightCycleC5.Bridge.CertificateDescriptors
