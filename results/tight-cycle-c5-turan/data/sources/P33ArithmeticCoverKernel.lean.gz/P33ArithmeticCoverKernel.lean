import P33ArithmeticCoverKernelChunk0
import P33ArithmeticCoverKernelChunk1
import P33ArithmeticCoverKernelChunk2
import P33ArithmeticCoverKernelChunk3
import P33ArithmeticCoverKernelChunk4
import P33ArithmeticCoverKernelChunk5
import P33ArithmeticCoverKernelChunk6
import P33ArithmeticCoverKernelChunk7
import P33ArithmeticCoverKernelChunk8
import P33ArithmeticCoverKernelChunk9
import P33ArithmeticCoverKernelChunk10
import P33ArithmeticCoverKernelChunk11
import P33ArithmeticCoverKernelChunk12
import P33ArithmeticCoverKernelChunk13
import P33ArithmeticCoverKernelChunk14
import P33ArithmeticCoverKernelChunk15
import P33ArithmeticCoverKernelChunk16
import P33ArithmeticCoverKernelChunk17
import P33ArithmeticCoverKernelChunk18
import P33ArithmeticCoverKernelChunk19
import P33ArithmeticCoverKernelChunk20
import P33ArithmeticCoverKernelChunk21
import P33ArithmeticCoverKernelChunk22
import P33ArithmeticCoverKernelChunk23
import P33ArithmeticCoverKernelChunk24
import P33ArithmeticCoverKernelChunk25
import P33ArithmeticCoverKernelChunk26
import P33ArithmeticCoverKernelChunk27
import P33ArithmeticCoverKernelChunk28
import P33ArithmeticCoverKernelChunk29
import P33ArithmeticCoverKernelChunk30
import P33ArithmeticCoverKernelChunk31
import P33ArithmeticCoverKernelChunk32
import P33ArithmeticCoverKernelChunk33
import P33ArithmeticCoverKernelChunk34
import P33ArithmeticCoverKernelChunk35
import P33ArithmeticCoverKernelChunk36
import P33ArithmeticCoverKernelChunk37
import P33ArithmeticCoverKernelChunk38
import P33ArithmeticCoverKernelChunk39
import P33ArithmeticCoverKernelChunk40
import P33ArithmeticCoverKernelChunk41
import P33ArithmeticCoverKernelChunk42
import P33ArithmeticCoverKernelChunk43
import P33ArithmeticCoverKernelChunk44
import P33ArithmeticCoverKernelChunk45
import P33ArithmeticCoverKernelChunk46
import P33ArithmeticCoverKernelChunk47
import P33ArithmeticCoverKernelChunk48
import P33ArithmeticCoverKernelChunk49
import P33ArithmeticCoverKernelChunk50
import P33ArithmeticCoverKernelChunk51
import P33ArithmeticCoverKernelChunk52
import P33ArithmeticCoverKernelChunk53
import P33ArithmeticCoverKernelChunk54
import P33ArithmeticCoverKernelChunk55
import P33ArithmeticCoverKernelChunk56
import P33ArithmeticCoverKernelChunk57
import P33ArithmeticCoverKernelChunk58
import P33ArithmeticCoverKernelChunk59
import P33ArithmeticCoverKernelChunk60
import P33ArithmeticCoverKernelChunk61
import P33ArithmeticCoverKernelChunk62
import P33ArithmeticCoverKernelChunk63
import P33ArithmeticCoverKernelChunk64
import P33ArithmeticCoverKernelChunk65
import P33ArithmeticCoverKernelChunk66
import P33ArithmeticCoverKernelChunk67
import P33ArithmeticCoverKernelChunk68
import P33ArithmeticCoverKernelChunk69
import P33ArithmeticCoverKernelChunk70
import P33ArithmeticCoverKernelChunk71
import P33ArithmeticCoverKernelChunk72
import P33ArithmeticCoverKernelChunk73
import P33ArithmeticCoverKernelChunk74
import P33ArithmeticCoverKernelChunk75
import P33ArithmeticCoverKernelChunk76
import P33ArithmeticCoverKernelChunk77
import P33ArithmeticCoverKernelChunk78
import P33ArithmeticCoverKernelChunk79

/-! Every genuine class index lies in its checked kernel chunk. -/
namespace TightCycleC5.Bridge.P33Arithmetic
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem all_class_bits_kernel_chunks (b : Fin 80) :
    ∀ i : Fin (min 512 (40547 - 512 * b.val)),
      classBitsAligned (coverKernelClass b i) := by
  fin_cases b
  · exact class_alignment_kernel_chunk0
  · exact class_alignment_kernel_chunk1
  · exact class_alignment_kernel_chunk2
  · exact class_alignment_kernel_chunk3
  · exact class_alignment_kernel_chunk4
  · exact class_alignment_kernel_chunk5
  · exact class_alignment_kernel_chunk6
  · exact class_alignment_kernel_chunk7
  · exact class_alignment_kernel_chunk8
  · exact class_alignment_kernel_chunk9
  · exact class_alignment_kernel_chunk10
  · exact class_alignment_kernel_chunk11
  · exact class_alignment_kernel_chunk12
  · exact class_alignment_kernel_chunk13
  · exact class_alignment_kernel_chunk14
  · exact class_alignment_kernel_chunk15
  · exact class_alignment_kernel_chunk16
  · exact class_alignment_kernel_chunk17
  · exact class_alignment_kernel_chunk18
  · exact class_alignment_kernel_chunk19
  · exact class_alignment_kernel_chunk20
  · exact class_alignment_kernel_chunk21
  · exact class_alignment_kernel_chunk22
  · exact class_alignment_kernel_chunk23
  · exact class_alignment_kernel_chunk24
  · exact class_alignment_kernel_chunk25
  · exact class_alignment_kernel_chunk26
  · exact class_alignment_kernel_chunk27
  · exact class_alignment_kernel_chunk28
  · exact class_alignment_kernel_chunk29
  · exact class_alignment_kernel_chunk30
  · exact class_alignment_kernel_chunk31
  · exact class_alignment_kernel_chunk32
  · exact class_alignment_kernel_chunk33
  · exact class_alignment_kernel_chunk34
  · exact class_alignment_kernel_chunk35
  · exact class_alignment_kernel_chunk36
  · exact class_alignment_kernel_chunk37
  · exact class_alignment_kernel_chunk38
  · exact class_alignment_kernel_chunk39
  · exact class_alignment_kernel_chunk40
  · exact class_alignment_kernel_chunk41
  · exact class_alignment_kernel_chunk42
  · exact class_alignment_kernel_chunk43
  · exact class_alignment_kernel_chunk44
  · exact class_alignment_kernel_chunk45
  · exact class_alignment_kernel_chunk46
  · exact class_alignment_kernel_chunk47
  · exact class_alignment_kernel_chunk48
  · exact class_alignment_kernel_chunk49
  · exact class_alignment_kernel_chunk50
  · exact class_alignment_kernel_chunk51
  · exact class_alignment_kernel_chunk52
  · exact class_alignment_kernel_chunk53
  · exact class_alignment_kernel_chunk54
  · exact class_alignment_kernel_chunk55
  · exact class_alignment_kernel_chunk56
  · exact class_alignment_kernel_chunk57
  · exact class_alignment_kernel_chunk58
  · exact class_alignment_kernel_chunk59
  · exact class_alignment_kernel_chunk60
  · exact class_alignment_kernel_chunk61
  · exact class_alignment_kernel_chunk62
  · exact class_alignment_kernel_chunk63
  · exact class_alignment_kernel_chunk64
  · exact class_alignment_kernel_chunk65
  · exact class_alignment_kernel_chunk66
  · exact class_alignment_kernel_chunk67
  · exact class_alignment_kernel_chunk68
  · exact class_alignment_kernel_chunk69
  · exact class_alignment_kernel_chunk70
  · exact class_alignment_kernel_chunk71
  · exact class_alignment_kernel_chunk72
  · exact class_alignment_kernel_chunk73
  · exact class_alignment_kernel_chunk74
  · exact class_alignment_kernel_chunk75
  · exact class_alignment_kernel_chunk76
  · exact class_alignment_kernel_chunk77
  · exact class_alignment_kernel_chunk78
  · exact class_alignment_kernel_chunk79

theorem all_class_bits_kernel_match (k : Fin 40547) : classBitsAligned k := by
  have hb : k.val / 512 < 80 := by omega
  let b : Fin 80 := ⟨k.val / 512, hb⟩
  have hi : k.val % 512 < min 512 (40547 - 512 * b.val) := by
    dsimp [b]
    omega
  let i : Fin (min 512 (40547 - 512 * b.val)) := ⟨k.val % 512, hi⟩
  have hk : coverKernelClass b i = k := by
    apply Fin.ext
    dsimp [coverKernelClass, b, i]
    omega
  rw [← hk]
  exact all_class_bits_kernel_chunks b i

#print axioms all_class_bits_kernel_chunks
#print axioms all_class_bits_kernel_match
end TightCycleC5.Bridge.P33Arithmetic
