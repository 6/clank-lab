-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticCoefficients
import P33ArithmeticClasses
import P33ArithmeticBlocks0
import P33ArithmeticBlocks1
import P33ArithmeticBlocks2
import P33ArithmeticBlocks3

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

def blocks : Array Block := #[block0, block1, block2, block3, block4, block5, block6, block7, block8, block9, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31, block32, block33, block34, block35, block36, block37]
end TightCycleC5.Bridge.P33Arithmetic
