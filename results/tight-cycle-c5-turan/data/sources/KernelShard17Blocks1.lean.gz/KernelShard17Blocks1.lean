import KernelRowIndex
import KernelWitness17

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_17_32 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 32 * 256 + i.val))
      kernelWitness17Row32[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_32

theorem kernelBlock_17_33 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 33 * 256 + i.val))
      kernelWitness17Row33[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_33

theorem kernelBlock_17_34 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 34 * 256 + i.val))
      kernelWitness17Row34[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_34

theorem kernelBlock_17_35 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 35 * 256 + i.val))
      kernelWitness17Row35[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_35

theorem kernelBlock_17_36 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 36 * 256 + i.val))
      kernelWitness17Row36[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_36

theorem kernelBlock_17_37 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 37 * 256 + i.val))
      kernelWitness17Row37[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_37

theorem kernelBlock_17_38 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 38 * 256 + i.val))
      kernelWitness17Row38[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_38

theorem kernelBlock_17_39 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 39 * 256 + i.val))
      kernelWitness17Row39[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_39

theorem kernelBlock_17_40 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 40 * 256 + i.val))
      kernelWitness17Row40[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_40

theorem kernelBlock_17_41 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 41 * 256 + i.val))
      kernelWitness17Row41[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_41

theorem kernelBlock_17_42 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 42 * 256 + i.val))
      kernelWitness17Row42[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_42

theorem kernelBlock_17_43 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 43 * 256 + i.val))
      kernelWitness17Row43[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_43

theorem kernelBlock_17_44 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 44 * 256 + i.val))
      kernelWitness17Row44[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_44

theorem kernelBlock_17_45 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 45 * 256 + i.val))
      kernelWitness17Row45[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_45

theorem kernelBlock_17_46 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 46 * 256 + i.val))
      kernelWitness17Row46[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_46

theorem kernelBlock_17_47 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 47 * 256 + i.val))
      kernelWitness17Row47[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_47

theorem kernelBlock_17_48 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 48 * 256 + i.val))
      kernelWitness17Row48[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_48

theorem kernelBlock_17_49 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 49 * 256 + i.val))
      kernelWitness17Row49[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_49

theorem kernelBlock_17_50 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 50 * 256 + i.val))
      kernelWitness17Row50[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_50

theorem kernelBlock_17_51 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 51 * 256 + i.val))
      kernelWitness17Row51[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_51

theorem kernelBlock_17_52 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 52 * 256 + i.val))
      kernelWitness17Row52[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_52

theorem kernelBlock_17_53 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 53 * 256 + i.val))
      kernelWitness17Row53[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_53

theorem kernelBlock_17_54 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 54 * 256 + i.val))
      kernelWitness17Row54[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_54

theorem kernelBlock_17_55 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 55 * 256 + i.val))
      kernelWitness17Row55[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_55

theorem kernelBlock_17_56 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 56 * 256 + i.val))
      kernelWitness17Row56[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_56

theorem kernelBlock_17_57 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 57 * 256 + i.val))
      kernelWitness17Row57[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_57

theorem kernelBlock_17_58 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 58 * 256 + i.val))
      kernelWitness17Row58[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_58

theorem kernelBlock_17_59 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 59 * 256 + i.val))
      kernelWitness17Row59[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_59

theorem kernelBlock_17_60 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 60 * 256 + i.val))
      kernelWitness17Row60[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_60

theorem kernelBlock_17_61 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 61 * 256 + i.val))
      kernelWitness17Row61[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_61

theorem kernelBlock_17_62 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 62 * 256 + i.val))
      kernelWitness17Row62[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_62

theorem kernelBlock_17_63 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 63 * 256 + i.val))
      kernelWitness17Row63[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_63

end TightCycleC5.Bridge.Cover
