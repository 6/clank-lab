-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk128 :
    ∀ i : Fin (min 128 (40547 - 128 * 128)),
      targetCountsMatch (classAt (targetKernelClass ⟨128, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk128

theorem target_counts_kernel_chunk129 :
    ∀ i : Fin (min 128 (40547 - 128 * 129)),
      targetCountsMatch (classAt (targetKernelClass ⟨129, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk129

theorem target_counts_kernel_chunk130 :
    ∀ i : Fin (min 128 (40547 - 128 * 130)),
      targetCountsMatch (classAt (targetKernelClass ⟨130, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk130

theorem target_counts_kernel_chunk131 :
    ∀ i : Fin (min 128 (40547 - 128 * 131)),
      targetCountsMatch (classAt (targetKernelClass ⟨131, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk131


end TightCycleC5.Bridge.P33Arithmetic
