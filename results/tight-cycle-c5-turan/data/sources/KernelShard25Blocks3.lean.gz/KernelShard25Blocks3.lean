import KernelRowIndex
import KernelWitness25

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_25_96 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 96 * 256 + i.val))
      kernelWitness25Row96[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_96

theorem kernelBlock_25_97 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 97 * 256 + i.val))
      kernelWitness25Row97[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_97

theorem kernelBlock_25_98 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 98 * 256 + i.val))
      kernelWitness25Row98[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_98

theorem kernelBlock_25_99 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 99 * 256 + i.val))
      kernelWitness25Row99[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_99

theorem kernelBlock_25_100 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 100 * 256 + i.val))
      kernelWitness25Row100[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_100

theorem kernelBlock_25_101 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 101 * 256 + i.val))
      kernelWitness25Row101[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_101

theorem kernelBlock_25_102 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 102 * 256 + i.val))
      kernelWitness25Row102[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_102

theorem kernelBlock_25_103 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 103 * 256 + i.val))
      kernelWitness25Row103[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_103

theorem kernelBlock_25_104 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 104 * 256 + i.val))
      kernelWitness25Row104[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_104

theorem kernelBlock_25_105 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 105 * 256 + i.val))
      kernelWitness25Row105[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_105

theorem kernelBlock_25_106 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 106 * 256 + i.val))
      kernelWitness25Row106[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_106

theorem kernelBlock_25_107 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 107 * 256 + i.val))
      kernelWitness25Row107[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_107

theorem kernelBlock_25_108 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 108 * 256 + i.val))
      kernelWitness25Row108[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_108

theorem kernelBlock_25_109 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 109 * 256 + i.val))
      kernelWitness25Row109[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_109

theorem kernelBlock_25_110 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 110 * 256 + i.val))
      kernelWitness25Row110[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_110

theorem kernelBlock_25_111 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 111 * 256 + i.val))
      kernelWitness25Row111[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_111

theorem kernelBlock_25_112 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 112 * 256 + i.val))
      kernelWitness25Row112[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_112

theorem kernelBlock_25_113 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 113 * 256 + i.val))
      kernelWitness25Row113[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_113

theorem kernelBlock_25_114 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 114 * 256 + i.val))
      kernelWitness25Row114[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_114

theorem kernelBlock_25_115 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 115 * 256 + i.val))
      kernelWitness25Row115[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_115

theorem kernelBlock_25_116 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 116 * 256 + i.val))
      kernelWitness25Row116[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_116

theorem kernelBlock_25_117 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 117 * 256 + i.val))
      kernelWitness25Row117[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_117

theorem kernelBlock_25_118 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 118 * 256 + i.val))
      kernelWitness25Row118[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_118

theorem kernelBlock_25_119 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 119 * 256 + i.val))
      kernelWitness25Row119[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_119

theorem kernelBlock_25_120 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 120 * 256 + i.val))
      kernelWitness25Row120[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_120

theorem kernelBlock_25_121 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 121 * 256 + i.val))
      kernelWitness25Row121[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_121

theorem kernelBlock_25_122 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 122 * 256 + i.val))
      kernelWitness25Row122[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_122

theorem kernelBlock_25_123 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 123 * 256 + i.val))
      kernelWitness25Row123[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_123

theorem kernelBlock_25_124 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 124 * 256 + i.val))
      kernelWitness25Row124[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_124

theorem kernelBlock_25_125 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 125 * 256 + i.val))
      kernelWitness25Row125[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_125

theorem kernelBlock_25_126 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 126 * 256 + i.val))
      kernelWitness25Row126[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_126

theorem kernelBlock_25_127 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 127 * 256 + i.val))
      kernelWitness25Row127[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_127

end TightCycleC5.Bridge.Cover
