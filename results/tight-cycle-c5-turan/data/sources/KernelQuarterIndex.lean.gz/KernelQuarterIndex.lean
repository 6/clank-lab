import KernelRowIndex

/-! A faithful partition of a 256-mask obligation into four bounded pieces. -/
namespace TightCycleC5.Bridge.Cover

theorem kernelBlockFromQuarters (P : Nat → Prop)
    (h : ∀ b : Fin 4, ∀ c : Fin 64, P (b.val * 64 + c.val)) :
    ∀ i : Fin 256, P i.val := by
  intro i
  let b : Fin 4 := ⟨i.val / 64, by have := i.isLt; omega⟩
  let c : Fin 64 := ⟨i.val % 64, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 64 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [he] using h b c

#print axioms kernelBlockFromQuarters
end TightCycleC5.Bridge.Cover
