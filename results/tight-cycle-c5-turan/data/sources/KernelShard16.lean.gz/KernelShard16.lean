import KernelShard16Blocks0
import KernelShard16Blocks1
import KernelShard16Blocks2
import KernelShard16Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard16 : kernelShardCheck 16 kernelWitness16 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (16 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness16 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_16_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard16
end TightCycleC5.Bridge.Cover
