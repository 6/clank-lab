import P33ArithmeticData

/-! Exact finite arithmetic on quoted source data. This layer is explicitly
partial until literal-predicate and actual-permutation transport are proved. -/
namespace TightCycleC5.Bridge.P33Arithmetic
open Finset

set_option maxRecDepth 100000
set_option maxHeartbeats 0

def sparseValue {n : Nat} (support : Array (Fin n × Int))
    (row : Fin n → Int) : Int :=
  ∑ t : Fin support.size, (support[t.val]'t.isLt).2 * row (support[t.val]'t.isLt).1

def sparseCoefficient {n : Nat} (support : Array (Fin n × Int)) (i : Fin n) : Int :=
  ∑ t : Fin support.size, if (support[t.val]'t.isLt).1 = i then (support[t.val]'t.isLt).2 else 0

/-- Sparse optimization preserves the full signed finite row sum. -/
theorem sparseValue_eq_full {n : Nat} (support : Array (Fin n × Int))
    (row : Fin n → Int) :
    sparseValue support row = ∑ i : Fin n, sparseCoefficient support i * row i :=
  (sparse_sum_eq (fun t : Fin support.size => (support[t.val]'t.isLt).1)
    (fun t : Fin support.size => (support[t.val]'t.isLt).2) row).symm

/-- Bounds checked at the actual queries, before any default array value
could conceal a missing flag or an out-of-range encoded structure. -/
def lookupsValid (K : Class) (j : Fin 720) : Bool := Id.run do
  let p := fun i : Fin 6 => (order j i).val
  let c := colour K.colours (p 0)
  if c ≥ localFlags.size then return false
  let lc := canonical K.mask K.colours [p 0] [p 3,p 4,p 5]
  if lookup localFlags[c]! lc ≥ localFlags[c]!.size then return false
  let gc := canonical K.mask K.colours [] [p 3,p 4,p 5]
  if lookup globalFlags gc ≥ globalFlags.size then return false
  for bi in [:blocks.size] do
    let b := blocks[bi]!
    let root := (List.range b.roots).map fun v => p (Fin.ofNat 6 v)
    if encoded K.mask K.colours root = b.typeCode then
      let a := if b.roots = 2 then canonical K.mask K.colours root [p 2,p 3]
        else encoded K.mask K.colours (root ++ [p 4])
      let z := if b.roots = 2 then canonical K.mask K.colours root [p 4,p 5]
        else encoded K.mask K.colours (root ++ [p 5])
      if lookup b.flags a ≥ b.flags.size || lookup b.flags z ≥ b.flags.size then return false
  let f := features localFlags globalFlags blocks K j
  if f.localIndex ≥ 80 || f.globalIndex ≥ 8 || f.degreeIndex > 120 then return false
  if f.tau ≥ 2 || f.rootColour ≥ 8 then return false
  if !(f.patterns.all (· < 8)) || !(f.freeColours.all (· < 2)) then return false
  return true

def nuisanceInteger (K : Class) (j : Fin 720) : Int :=
  let f := features localFlags globalFlags blocks K j
  psdOrder blocks K j +
    sparseValue inequalitySupport (fun i => inequalityRow f i.val) +
    sparseValue regularitySupport (fun i => regularityRow f i.val)

/-- Family tags: PSD, regularity, local, cut, density, CL. This is used
only to certify that the timing unit actually exercises every family. -/
def familyContribution (K : Class) (j : Fin 720) (family : Fin 6) : Int :=
  let f := features localFlags globalFlags blocks K j
  if family.val = 0 then psdOrder blocks K j
  else if family.val = 1 then
    sparseValue regularitySupport (fun i => regularityRow f i.val)
  else sparseValue inequalitySupport (fun i =>
    let tag := if i.val < 80 then 2 else if i.val < 88 then 3
      else if i.val < 97 then 4 else 5
    if tag = family.val then inequalityRow f i.val else 0)

def unitExercisesAllFamilies : Bool :=
  (List.finRange 6).all fun family => unitIndices.any fun k =>
    (List.finRange 720).any fun j => familyContribution (classAt k) j family != 0

def integerTotal (K : Class) : Int :=
  sosScale * 36000000000 * targetNumerator K +
    ∑ j : Fin 720, nuisanceInteger K j

/-- This is only a finite predicate until its separate semantic adapter
identifies the literal rows and transports to actual kernelPermutation. -/
def classCheck (K : Class) : Bool :=
  decide (K.mask < 2^20 ∧ K.colours < 64) &&
  decide (K.quotedTarget = targetNumerator K * 9000000000) &&
  (List.finRange 720).all (lookupsValid K) && decide (integerTotal K ≤ 0)

def dataWellFormed : Bool :=
  decide (0 < sosScale) && decide (blocks.size = 38) &&
  decide (denseInequalities.size = 12847) && decide (denseRegularity.size = 120) &&
  denseInequalities.all (· ≥ 0) &&
  decide (localFlags.size = 2 ∧ globalFlags.size = 8) &&
  localFlags.all (fun flags => flags.size == 40) &&
  blocks.all (fun b =>
    decide ((b.n = 4 ∧ b.roots = 2) ∨ (b.n = 5 ∧ b.roots = 4)) &&
    decide (0 < b.flags.size) &&
    b.terms.all (fun t => decide (0 ≤ t.weight) &&
      (if t.matrix.isEmpty then t.vector.size == b.flags.size
       else t.matrix.size == b.flags.size &&
         t.matrix.all (fun row => row.size == b.flags.size))))

def unitCheck : Bool := dataWellFormed && unitIndices.all (fun k => classCheck (classAt k))

/-- The integer is converted to a rational, with exactly one SOS scale. -/
def rationalClassValue (K : Class) : ℚ :=
  (targetNumerator K : ℚ) / 20 +
    ((∑ j : Fin 720, (nuisanceInteger K j : ℚ)) / 720) * 720 /
      720000000000 / (sosScale : ℚ)

/-- The rational expression above is precisely the signed integer total
cleared by U and the positive SOS scale. Semantic row equality is separate. -/
theorem rationalClassValue_eq_integerTotal (K : Class) (hs : sosScale ≠ 0) :
    rationalClassValue K = (integerTotal K : ℚ) / (720000000000 * (sosScale : ℚ)) := by
  have hs' : (sosScale : ℚ) ≠ 0 := Int.cast_ne_zero.mpr hs
  simp only [rationalClassValue, integerTotal, Int.cast_add, Int.cast_mul,
    Int.cast_ofNat, Int.cast_sum]
  field_simp
  <;> ring

/-- Extract the signed integer inequality from the finite checker itself. -/
theorem classCheck_integer_nonpos (K : Class) (h : classCheck K = true) :
    integerTotal K ≤ 0 := by
  simp only [classCheck, Bool.and_eq_true, decide_eq_true_eq] at h
  tauto

/-- The checked integer inequality is transported faithfully to rationals.
The positive-scale hypothesis is discharged by the separate exact data check. -/
theorem classCheck_rational_nonpos (K : Class) (hs : 0 < sosScale)
    (h : classCheck K = true) : rationalClassValue K ≤ 0 := by
  rw [rationalClassValue_eq_integerTotal K (ne_of_gt hs)]
  exact (int_total_nonpos_iff (integerTotal K) sosScale 720000000000 hs
    (by decide)).2 (classCheck_integer_nonpos K h)

/-- Faithful rational-to-real conversion of this explicitly partial layer. -/
theorem classCheck_real_nonpos (K : Class) (hs : 0 < sosScale)
    (h : classCheck K = true) : (rationalClassValue K : ℝ) ≤ 0 :=
  (rat_real_nonpos_iff _).2 (classCheck_rational_nonpos K hs h)

#print axioms sparseValue_eq_full
#print axioms rationalClassValue_eq_integerTotal
#print axioms classCheck_integer_nonpos
#print axioms classCheck_rational_nonpos
#print axioms classCheck_real_nonpos
end TightCycleC5.Bridge.P33Arithmetic
