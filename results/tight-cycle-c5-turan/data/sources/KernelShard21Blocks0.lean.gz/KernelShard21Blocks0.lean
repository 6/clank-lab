import KernelRowIndex
import KernelWitness21

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_21_0 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 0 * 256 + i.val))
      kernelWitness21Row0[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_0

theorem kernelBlock_21_1 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 1 * 256 + i.val))
      kernelWitness21Row1[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_1

theorem kernelBlock_21_2 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 2 * 256 + i.val))
      kernelWitness21Row2[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_2

theorem kernelBlock_21_3 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 3 * 256 + i.val))
      kernelWitness21Row3[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_3

theorem kernelBlock_21_4 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 4 * 256 + i.val))
      kernelWitness21Row4[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_4

theorem kernelBlock_21_5 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 5 * 256 + i.val))
      kernelWitness21Row5[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_5

theorem kernelBlock_21_6 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 6 * 256 + i.val))
      kernelWitness21Row6[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_6

theorem kernelBlock_21_7 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 7 * 256 + i.val))
      kernelWitness21Row7[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_7

theorem kernelBlock_21_8 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 8 * 256 + i.val))
      kernelWitness21Row8[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_8

theorem kernelBlock_21_9 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 9 * 256 + i.val))
      kernelWitness21Row9[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_9

theorem kernelBlock_21_10 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 10 * 256 + i.val))
      kernelWitness21Row10[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_10

theorem kernelBlock_21_11 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 11 * 256 + i.val))
      kernelWitness21Row11[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_11

theorem kernelBlock_21_12 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 12 * 256 + i.val))
      kernelWitness21Row12[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_12

theorem kernelBlock_21_13 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 13 * 256 + i.val))
      kernelWitness21Row13[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_13

theorem kernelBlock_21_14 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 14 * 256 + i.val))
      kernelWitness21Row14[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_14

theorem kernelBlock_21_15 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 15 * 256 + i.val))
      kernelWitness21Row15[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_15

theorem kernelBlock_21_16 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 16 * 256 + i.val))
      kernelWitness21Row16[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_16

theorem kernelBlock_21_17 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 17 * 256 + i.val))
      kernelWitness21Row17[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_17

theorem kernelBlock_21_18 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 18 * 256 + i.val))
      kernelWitness21Row18[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_18

theorem kernelBlock_21_19 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 19 * 256 + i.val))
      kernelWitness21Row19[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_19

theorem kernelBlock_21_20 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 20 * 256 + i.val))
      kernelWitness21Row20[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_20

theorem kernelBlock_21_21 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 21 * 256 + i.val))
      kernelWitness21Row21[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_21

theorem kernelBlock_21_22 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 22 * 256 + i.val))
      kernelWitness21Row22[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_22

theorem kernelBlock_21_23 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 23 * 256 + i.val))
      kernelWitness21Row23[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_23

theorem kernelBlock_21_24 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 24 * 256 + i.val))
      kernelWitness21Row24[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_24

theorem kernelBlock_21_25 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 25 * 256 + i.val))
      kernelWitness21Row25[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_25

theorem kernelBlock_21_26 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 26 * 256 + i.val))
      kernelWitness21Row26[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_26

theorem kernelBlock_21_27 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 27 * 256 + i.val))
      kernelWitness21Row27[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_27

theorem kernelBlock_21_28 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 28 * 256 + i.val))
      kernelWitness21Row28[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_28

theorem kernelBlock_21_29 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 29 * 256 + i.val))
      kernelWitness21Row29[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_29

theorem kernelBlock_21_30 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 30 * 256 + i.val))
      kernelWitness21Row30[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_30

theorem kernelBlock_21_31 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (21 * 32768 + 31 * 256 + i.val))
      kernelWitness21Row31[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_21_31

end TightCycleC5.Bridge.Cover
