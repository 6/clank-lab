import ColoredCoverSemantics

namespace TightCycleC5.Bridge.ColoredCover
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def coloredWitness256 : Array Nat := #[8595360, 8596080, 8596800, 8597520, 8596824, 8597544, 8598240, 8598960, 8599680, 8600400, 8601120, 8601840, 8601144, 8601864, 8602560, 8603280, 8604000, 8604720, 8605440, 8606160, 8605464, 8606184, 8606880, 8607600, 8608320, 8609040, 8609760, 8610480, 8609784, 8610504, 8611200, 8611920, 8612640, 8613360, 8614080, 8614800, 8614104, 8614824, 8615520, 8616240, 8616960, 8617680, 8618400, 8619120, 8618424, 8619144, 8619840, 8620560, 8621280, 8622000, 8622720, 8623440, 8622744, 8623464, 8624160, 8624880, 8625600, 8626320, 8627040, 8627760, 8627064, 8627784, 8628480, 8629200]

theorem colored_row256 : ∀ c : Fin 64,
    readRow witnessRows (256 * 64 + c.val) = coloredWitness256[c.val]! := by
  decide +kernel
#print axioms colored_row256

theorem colored_check256 : ∀ c : Fin 64,
    checkColored 256 (BitVec.ofNat 6 c.val) (coloredWitness256[c.val]!) = true := by
  decide +kernel
#print axioms colored_check256

theorem colored_family256 : ∀ c : Fin 64,
    checkColored 256 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (256 * 64 + c.val)) = true := by
  intro c
  rw [colored_row256]
  exact colored_check256 c
#print axioms colored_family256

def coloredWitness257 : Array Nat := #[8629920, 8630640, 8631360, 8632080, 8632800, 8633520, 8634240, 8634960, 8635680, 8636400, 8637120, 8637840, 8638560, 8639280, 8640000, 8640720, 8641440, 8642160, 8642880, 8643600, 8644320, 8645040, 8645760, 8646480, 8647200, 8647920, 8648640, 8649360, 8650080, 8650800, 8651520, 8652240, 8652960, 8653680, 8654400, 8655120, 8655840, 8656560, 8657280, 8658000, 8658720, 8659440, 8660160, 8660880, 8661600, 8662320, 8663040, 8663760, 8664480, 8665200, 8665920, 8666640, 8667360, 8668080, 8668800, 8669520, 8670240, 8670960, 8671680, 8672400, 8673120, 8673840, 8674560, 8675280]

theorem colored_row257 : ∀ c : Fin 64,
    readRow witnessRows (257 * 64 + c.val) = coloredWitness257[c.val]! := by
  decide +kernel
#print axioms colored_row257

theorem colored_check257 : ∀ c : Fin 64,
    checkColored 257 (BitVec.ofNat 6 c.val) (coloredWitness257[c.val]!) = true := by
  decide +kernel
#print axioms colored_check257

theorem colored_family257 : ∀ c : Fin 64,
    checkColored 257 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (257 * 64 + c.val)) = true := by
  intro c
  rw [colored_row257]
  exact colored_check257 c
#print axioms colored_family257

def coloredWitness258 : Array Nat := #[8676000, 8676720, 8677440, 8678160, 8678880, 8679600, 8680320, 8681040, 8681760, 8682480, 8683200, 8683920, 8684640, 8685360, 8686080, 8686800, 8687520, 8688240, 8688960, 8689680, 8690400, 8691120, 8691840, 8692560, 8693280, 8694000, 8694720, 8695440, 8696160, 8696880, 8697600, 8698320, 8699040, 8699760, 8700480, 8701200, 8701920, 8702640, 8703360, 8704080, 8704800, 8705520, 8706240, 8706960, 8707680, 8708400, 8709120, 8709840, 8710560, 8711280, 8712000, 8712720, 8713440, 8714160, 8714880, 8715600, 8716320, 8717040, 8717760, 8718480, 8719200, 8719920, 8720640, 8721360]

theorem colored_row258 : ∀ c : Fin 64,
    readRow witnessRows (258 * 64 + c.val) = coloredWitness258[c.val]! := by
  decide +kernel
#print axioms colored_row258

theorem colored_check258 : ∀ c : Fin 64,
    checkColored 258 (BitVec.ofNat 6 c.val) (coloredWitness258[c.val]!) = true := by
  decide +kernel
#print axioms colored_check258

theorem colored_family258 : ∀ c : Fin 64,
    checkColored 258 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (258 * 64 + c.val)) = true := by
  intro c
  rw [colored_row258]
  exact colored_check258 c
#print axioms colored_family258

def coloredWitness259 : Array Nat := #[8722080, 8722800, 8723520, 8724240, 8724960, 8725680, 8726400, 8727120, 8727840, 8728560, 8729280, 8730000, 8730720, 8731440, 8732160, 8732880, 8733600, 8734320, 8735040, 8735760, 8736480, 8737200, 8737920, 8738640, 8739360, 8740080, 8740800, 8741520, 8742240, 8742960, 8743680, 8744400, 8745120, 8745840, 8746560, 8747280, 8748000, 8748720, 8749440, 8750160, 8750880, 8751600, 8752320, 8753040, 8753760, 8754480, 8755200, 8755920, 8756640, 8757360, 8758080, 8758800, 8759520, 8760240, 8760960, 8761680, 8762400, 8763120, 8763840, 8764560, 8765280, 8766000, 8766720, 8767440]

theorem colored_row259 : ∀ c : Fin 64,
    readRow witnessRows (259 * 64 + c.val) = coloredWitness259[c.val]! := by
  decide +kernel
#print axioms colored_row259

theorem colored_check259 : ∀ c : Fin 64,
    checkColored 259 (BitVec.ofNat 6 c.val) (coloredWitness259[c.val]!) = true := by
  decide +kernel
#print axioms colored_check259

theorem colored_family259 : ∀ c : Fin 64,
    checkColored 259 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (259 * 64 + c.val)) = true := by
  intro c
  rw [colored_row259]
  exact colored_check259 c
#print axioms colored_family259

def coloredWitness260 : Array Nat := #[8768160, 8768880, 8769600, 8770320, 8771040, 8771760, 8772480, 8773200, 8773920, 8774640, 8775360, 8776080, 8776800, 8777520, 8778240, 8778960, 8779680, 8780400, 8781120, 8781840, 8782560, 8783280, 8784000, 8784720, 8785440, 8786160, 8786880, 8787600, 8788320, 8789040, 8789760, 8790480, 8791200, 8791920, 8792640, 8793360, 8794080, 8794800, 8795520, 8796240, 8796960, 8797680, 8798400, 8799120, 8799840, 8800560, 8801280, 8802000, 8802720, 8803440, 8804160, 8804880, 8805600, 8806320, 8807040, 8807760, 8808480, 8809200, 8809920, 8810640, 8811360, 8812080, 8812800, 8813520]

theorem colored_row260 : ∀ c : Fin 64,
    readRow witnessRows (260 * 64 + c.val) = coloredWitness260[c.val]! := by
  decide +kernel
#print axioms colored_row260

theorem colored_check260 : ∀ c : Fin 64,
    checkColored 260 (BitVec.ofNat 6 c.val) (coloredWitness260[c.val]!) = true := by
  decide +kernel
#print axioms colored_check260

theorem colored_family260 : ∀ c : Fin 64,
    checkColored 260 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (260 * 64 + c.val)) = true := by
  intro c
  rw [colored_row260]
  exact colored_check260 c
#print axioms colored_family260

def coloredWitness261 : Array Nat := #[8814240, 8814960, 8815680, 8816400, 8817120, 8817840, 8818560, 8819280, 8820000, 8820720, 8821440, 8822160, 8822880, 8823600, 8824320, 8825040, 8825760, 8826480, 8827200, 8827920, 8828640, 8829360, 8830080, 8830800, 8831520, 8832240, 8832960, 8833680, 8834400, 8835120, 8835840, 8836560, 8837280, 8838000, 8838720, 8839440, 8840160, 8840880, 8841600, 8842320, 8843040, 8843760, 8844480, 8845200, 8845920, 8846640, 8847360, 8848080, 8848800, 8849520, 8850240, 8850960, 8851680, 8852400, 8853120, 8853840, 8854560, 8855280, 8856000, 8856720, 8857440, 8858160, 8858880, 8859600]

theorem colored_row261 : ∀ c : Fin 64,
    readRow witnessRows (261 * 64 + c.val) = coloredWitness261[c.val]! := by
  decide +kernel
#print axioms colored_row261

theorem colored_check261 : ∀ c : Fin 64,
    checkColored 261 (BitVec.ofNat 6 c.val) (coloredWitness261[c.val]!) = true := by
  decide +kernel
#print axioms colored_check261

theorem colored_family261 : ∀ c : Fin 64,
    checkColored 261 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (261 * 64 + c.val)) = true := by
  intro c
  rw [colored_row261]
  exact colored_check261 c
#print axioms colored_family261

def coloredWitness262 : Array Nat := #[8860320, 8861040, 8861760, 8862480, 8863200, 8863920, 8864640, 8865360, 8866080, 8866800, 8867520, 8868240, 8868960, 8869680, 8870400, 8871120, 8871840, 8872560, 8873280, 8874000, 8874720, 8875440, 8876160, 8876880, 8877600, 8878320, 8879040, 8879760, 8880480, 8881200, 8881920, 8882640, 8883360, 8884080, 8884800, 8885520, 8886240, 8886960, 8887680, 8888400, 8889120, 8889840, 8890560, 8891280, 8892000, 8892720, 8893440, 8894160, 8894880, 8895600, 8896320, 8897040, 8897760, 8898480, 8899200, 8899920, 8900640, 8901360, 8902080, 8902800, 8903520, 8904240, 8904960, 8905680]

theorem colored_row262 : ∀ c : Fin 64,
    readRow witnessRows (262 * 64 + c.val) = coloredWitness262[c.val]! := by
  decide +kernel
#print axioms colored_row262

theorem colored_check262 : ∀ c : Fin 64,
    checkColored 262 (BitVec.ofNat 6 c.val) (coloredWitness262[c.val]!) = true := by
  decide +kernel
#print axioms colored_check262

theorem colored_family262 : ∀ c : Fin 64,
    checkColored 262 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (262 * 64 + c.val)) = true := by
  intro c
  rw [colored_row262]
  exact colored_check262 c
#print axioms colored_family262

def coloredWitness263 : Array Nat := #[8906400, 8907120, 8907840, 8908560, 8907864, 8908584, 8909280, 8910000, 8910720, 8911440, 8912160, 8912880, 8912184, 8912904, 8913600, 8914320, 8915040, 8915760, 8916480, 8917200, 8916504, 8917224, 8917920, 8918640, 8919360, 8920080, 8920800, 8921520, 8920824, 8921544, 8922240, 8922960, 8923680, 8924400, 8925120, 8925840, 8925144, 8925864, 8926560, 8927280, 8928000, 8928720, 8929440, 8930160, 8929464, 8930184, 8930880, 8931600, 8932320, 8933040, 8933760, 8934480, 8933784, 8934504, 8935200, 8935920, 8936640, 8937360, 8938080, 8938800, 8938104, 8938824, 8939520, 8940240]

theorem colored_row263 : ∀ c : Fin 64,
    readRow witnessRows (263 * 64 + c.val) = coloredWitness263[c.val]! := by
  decide +kernel
#print axioms colored_row263

theorem colored_check263 : ∀ c : Fin 64,
    checkColored 263 (BitVec.ofNat 6 c.val) (coloredWitness263[c.val]!) = true := by
  decide +kernel
#print axioms colored_check263

theorem colored_family263 : ∀ c : Fin 64,
    checkColored 263 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (263 * 64 + c.val)) = true := by
  intro c
  rw [colored_row263]
  exact colored_check263 c
#print axioms colored_family263

def coloredWitness264 : Array Nat := #[8940960, 8941680, 8942400, 8943120, 8942424, 8943144, 8943840, 8944560, 8945280, 8946000, 8946720, 8947440, 8946744, 8947464, 8948160, 8948880, 8949600, 8950320, 8951040, 8951760, 8951064, 8951784, 8952480, 8953200, 8953920, 8954640, 8955360, 8956080, 8955384, 8956104, 8956800, 8957520, 8958240, 8958960, 8959680, 8960400, 8959704, 8960424, 8961120, 8961840, 8962560, 8963280, 8964000, 8964720, 8964024, 8964744, 8965440, 8966160, 8966880, 8967600, 8968320, 8969040, 8968344, 8969064, 8969760, 8970480, 8971200, 8971920, 8972640, 8973360, 8972664, 8973384, 8974080, 8974800]

theorem colored_row264 : ∀ c : Fin 64,
    readRow witnessRows (264 * 64 + c.val) = coloredWitness264[c.val]! := by
  decide +kernel
#print axioms colored_row264

theorem colored_check264 : ∀ c : Fin 64,
    checkColored 264 (BitVec.ofNat 6 c.val) (coloredWitness264[c.val]!) = true := by
  decide +kernel
#print axioms colored_check264

theorem colored_family264 : ∀ c : Fin 64,
    checkColored 264 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (264 * 64 + c.val)) = true := by
  intro c
  rw [colored_row264]
  exact colored_check264 c
#print axioms colored_family264

def coloredWitness265 : Array Nat := #[8975520, 8976240, 8976960, 8977680, 8976984, 8977704, 8978400, 8979120, 8979840, 8980560, 8981280, 8982000, 8981304, 8982024, 8982720, 8983440, 8984160, 8984880, 8985600, 8986320, 8985624, 8986344, 8987040, 8987760, 8988480, 8989200, 8989920, 8990640, 8989944, 8990664, 8991360, 8992080, 8992800, 8993520, 8994240, 8994960, 8994264, 8994984, 8995680, 8996400, 8997120, 8997840, 8998560, 8999280, 8998584, 8999304, 9000000, 9000720, 9001440, 9002160, 9002880, 9003600, 9002904, 9003624, 9004320, 9005040, 9005760, 9006480, 9007200, 9007920, 9007224, 9007944, 9008640, 9009360]

theorem colored_row265 : ∀ c : Fin 64,
    readRow witnessRows (265 * 64 + c.val) = coloredWitness265[c.val]! := by
  decide +kernel
#print axioms colored_row265

theorem colored_check265 : ∀ c : Fin 64,
    checkColored 265 (BitVec.ofNat 6 c.val) (coloredWitness265[c.val]!) = true := by
  decide +kernel
#print axioms colored_check265

theorem colored_family265 : ∀ c : Fin 64,
    checkColored 265 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (265 * 64 + c.val)) = true := by
  intro c
  rw [colored_row265]
  exact colored_check265 c
#print axioms colored_family265

def coloredWitness266 : Array Nat := #[9010080, 9010800, 9011520, 9012240, 9011544, 9012264, 9012960, 9013680, 9014400, 9015120, 9015840, 9016560, 9015864, 9016584, 9017280, 9018000, 9018720, 9019440, 9020160, 9020880, 9020184, 9020904, 9021600, 9022320, 9023040, 9023760, 9024480, 9025200, 9024504, 9025224, 9025920, 9026640, 9027360, 9028080, 9028800, 9029520, 9028824, 9029544, 9030240, 9030960, 9031680, 9032400, 9033120, 9033840, 9033144, 9033864, 9034560, 9035280, 9036000, 9036720, 9037440, 9038160, 9037464, 9038184, 9038880, 9039600, 9040320, 9041040, 9041760, 9042480, 9041784, 9042504, 9043200, 9043920]

theorem colored_row266 : ∀ c : Fin 64,
    readRow witnessRows (266 * 64 + c.val) = coloredWitness266[c.val]! := by
  decide +kernel
#print axioms colored_row266

theorem colored_check266 : ∀ c : Fin 64,
    checkColored 266 (BitVec.ofNat 6 c.val) (coloredWitness266[c.val]!) = true := by
  decide +kernel
#print axioms colored_check266

theorem colored_family266 : ∀ c : Fin 64,
    checkColored 266 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (266 * 64 + c.val)) = true := by
  intro c
  rw [colored_row266]
  exact colored_check266 c
#print axioms colored_family266

def coloredWitness267 : Array Nat := #[9044640, 9045360, 9045501, 9046080, 9045621, 9046104, 9046800, 9047520, 9048240, 9048960, 9049101, 9049680, 9049221, 9049704, 9050400, 9051120, 9048242, 9048962, 9049103, 9049682, 9049223, 9049706, 9050402, 9051122, 9051840, 9052560, 9052701, 9053280, 9052821, 9053304, 9054000, 9054720, 9045993, 9046941, 9046299, 9047661, 9046419, 9047781, 9048153, 9055440, 9049593, 9050541, 9049899, 9051261, 9050019, 9051381, 9051753, 9056160, 9049595, 9050543, 9049901, 9051263, 9050021, 9051383, 9051755, 9056162, 9053193, 9054141, 9053499, 9054861, 9053619, 9054981, 9055353, 9056880]

theorem colored_row267 : ∀ c : Fin 64,
    readRow witnessRows (267 * 64 + c.val) = coloredWitness267[c.val]! := by
  decide +kernel
#print axioms colored_row267

theorem colored_check267 : ∀ c : Fin 64,
    checkColored 267 (BitVec.ofNat 6 c.val) (coloredWitness267[c.val]!) = true := by
  decide +kernel
#print axioms colored_check267

theorem colored_family267 : ∀ c : Fin 64,
    checkColored 267 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (267 * 64 + c.val)) = true := by
  intro c
  rw [colored_row267]
  exact colored_check267 c
#print axioms colored_family267

def coloredWitness268 : Array Nat := #[9057600, 9058320, 9059040, 9059760, 9059064, 9059784, 9060480, 9061200, 9061920, 9062640, 9063360, 9064080, 9063384, 9064104, 9064800, 9065520, 9061922, 9062642, 9063362, 9064082, 9063386, 9064106, 9064802, 9065522, 9066240, 9066960, 9067680, 9068400, 9067704, 9068424, 9069120, 9069840, 9070560, 9071280, 9072000, 9072720, 9072024, 9072744, 9073440, 9074160, 9074880, 9075600, 9076320, 9077040, 9076344, 9077064, 9077760, 9078480, 9074882, 9075602, 9076322, 9077042, 9076346, 9077066, 9077762, 9078482, 9079200, 9079920, 9080640, 9081360, 9080664, 9081384, 9082080, 9082800]

theorem colored_row268 : ∀ c : Fin 64,
    readRow witnessRows (268 * 64 + c.val) = coloredWitness268[c.val]! := by
  decide +kernel
#print axioms colored_row268

theorem colored_check268 : ∀ c : Fin 64,
    checkColored 268 (BitVec.ofNat 6 c.val) (coloredWitness268[c.val]!) = true := by
  decide +kernel
#print axioms colored_check268

theorem colored_family268 : ∀ c : Fin 64,
    checkColored 268 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (268 * 64 + c.val)) = true := by
  intro c
  rw [colored_row268]
  exact colored_check268 c
#print axioms colored_family268

def coloredWitness269 : Array Nat := #[9083520, 9084240, 9084381, 9084960, 9085680, 9086400, 9087120, 9087840, 9088560, 9089280, 9089421, 9090000, 9090720, 9091440, 9092160, 9092880, 9093600, 9094320, 9094461, 9095040, 9095760, 9096480, 9097200, 9097920, 9098640, 9099360, 9099501, 9100080, 9100800, 9101520, 9102240, 9102960, 9085821, 9087261, 9086541, 9087981, 9103680, 9104400, 9104541, 9105120, 9090861, 9092301, 9091581, 9093021, 9105840, 9106560, 9106701, 9107280, 9095901, 9097341, 9096621, 9098061, 9108000, 9108720, 9108861, 9109440, 9100941, 9102381, 9101661, 9103101, 9110160, 9110880, 9111021, 9111600]

theorem colored_row269 : ∀ c : Fin 64,
    readRow witnessRows (269 * 64 + c.val) = coloredWitness269[c.val]! := by
  decide +kernel
#print axioms colored_row269

theorem colored_check269 : ∀ c : Fin 64,
    checkColored 269 (BitVec.ofNat 6 c.val) (coloredWitness269[c.val]!) = true := by
  decide +kernel
#print axioms colored_check269

theorem colored_family269 : ∀ c : Fin 64,
    checkColored 269 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (269 * 64 + c.val)) = true := by
  intro c
  rw [colored_row269]
  exact colored_check269 c
#print axioms colored_family269

def coloredWitness270 : Array Nat := #[9112320, 9113040, 9113760, 9114480, 9115200, 9115920, 9116640, 9117360, 9118080, 9118800, 9119520, 9120240, 9120960, 9121680, 9122400, 9123120, 9123840, 9124560, 9125280, 9126000, 9126720, 9127440, 9128160, 9128880, 9129600, 9130320, 9131040, 9131760, 9132480, 9133200, 9133920, 9134640, 9135360, 9136080, 9136800, 9137520, 9138240, 9138960, 9139680, 9140400, 9141120, 9141840, 9142560, 9143280, 9144000, 9144720, 9145440, 9146160, 9146880, 9147600, 9148320, 9149040, 9149760, 9150480, 9151200, 9151920, 9152640, 9153360, 9154080, 9154800, 9155520, 9156240, 9156960, 9157680]

theorem colored_row270 : ∀ c : Fin 64,
    readRow witnessRows (270 * 64 + c.val) = coloredWitness270[c.val]! := by
  decide +kernel
#print axioms colored_row270

theorem colored_check270 : ∀ c : Fin 64,
    checkColored 270 (BitVec.ofNat 6 c.val) (coloredWitness270[c.val]!) = true := by
  decide +kernel
#print axioms colored_check270

theorem colored_family270 : ∀ c : Fin 64,
    checkColored 270 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (270 * 64 + c.val)) = true := by
  intro c
  rw [colored_row270]
  exact colored_check270 c
#print axioms colored_family270

def coloredWitness271 : Array Nat := #[9158400, 9159120, 9159261, 9159840, 9160560, 9161280, 9162000, 9162720, 9163440, 9164160, 9164301, 9164880, 9165600, 9166320, 9167040, 9167760, 9163442, 9164162, 9164303, 9164882, 9165602, 9166322, 9167042, 9167762, 9168480, 9169200, 9169341, 9169920, 9170640, 9171360, 9172080, 9172800, 9160701, 9162141, 9161421, 9162861, 9173520, 9174240, 9174381, 9174960, 9165741, 9167181, 9166461, 9167901, 9175680, 9176400, 9176541, 9177120, 9165743, 9167183, 9166463, 9167903, 9175682, 9176402, 9176543, 9177122, 9170781, 9172221, 9171501, 9172941, 9177840, 9178560, 9178701, 9179280]

theorem colored_row271 : ∀ c : Fin 64,
    readRow witnessRows (271 * 64 + c.val) = coloredWitness271[c.val]! := by
  decide +kernel
#print axioms colored_row271

theorem colored_check271 : ∀ c : Fin 64,
    checkColored 271 (BitVec.ofNat 6 c.val) (coloredWitness271[c.val]!) = true := by
  decide +kernel
#print axioms colored_check271

theorem colored_family271 : ∀ c : Fin 64,
    checkColored 271 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (271 * 64 + c.val)) = true := by
  intro c
  rw [colored_row271]
  exact colored_check271 c
#print axioms colored_family271

def coloredWitness272 : Array Nat := #[9180000, 9180720, 9181440, 9182160, 9182880, 9183600, 9184320, 9185040, 9185760, 9186480, 9187200, 9187920, 9188640, 9189360, 9190080, 9190800, 9185762, 9186482, 9187202, 9187922, 9188642, 9189362, 9190082, 9190802, 9191520, 9192240, 9192960, 9193680, 9194400, 9195120, 9195840, 9196560, 9197280, 9198000, 9198720, 9199440, 9200160, 9200880, 9201600, 9202320, 9203040, 9203760, 9204480, 9205200, 9205920, 9206640, 9207360, 9208080, 9203042, 9203762, 9204482, 9205202, 9205922, 9206642, 9207362, 9208082, 9208800, 9209520, 9210240, 9210960, 9211680, 9212400, 9213120, 9213840]

theorem colored_row272 : ∀ c : Fin 64,
    readRow witnessRows (272 * 64 + c.val) = coloredWitness272[c.val]! := by
  decide +kernel
#print axioms colored_row272

theorem colored_check272 : ∀ c : Fin 64,
    checkColored 272 (BitVec.ofNat 6 c.val) (coloredWitness272[c.val]!) = true := by
  decide +kernel
#print axioms colored_check272

theorem colored_family272 : ∀ c : Fin 64,
    checkColored 272 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (272 * 64 + c.val)) = true := by
  intro c
  rw [colored_row272]
  exact colored_check272 c
#print axioms colored_family272

def coloredWitness273 : Array Nat := #[9214560, 9215280, 9215421, 9216000, 9216720, 9217440, 9218160, 9218880, 9219600, 9220320, 9220461, 9221040, 9221760, 9222480, 9223200, 9223920, 9219602, 9220322, 9220463, 9221042, 9221762, 9222482, 9223202, 9223922, 9224640, 9225360, 9225501, 9226080, 9226800, 9227520, 9228240, 9228960, 9216861, 9218301, 9217581, 9219021, 9229680, 9230400, 9230541, 9231120, 9221901, 9223341, 9222621, 9224061, 9231840, 9232560, 9232701, 9233280, 9221903, 9223343, 9222623, 9224063, 9231842, 9232562, 9232703, 9233282, 9226941, 9228381, 9227661, 9229101, 9234000, 9234720, 9234861, 9235440]

theorem colored_row273 : ∀ c : Fin 64,
    readRow witnessRows (273 * 64 + c.val) = coloredWitness273[c.val]! := by
  decide +kernel
#print axioms colored_row273

theorem colored_check273 : ∀ c : Fin 64,
    checkColored 273 (BitVec.ofNat 6 c.val) (coloredWitness273[c.val]!) = true := by
  decide +kernel
#print axioms colored_check273

theorem colored_family273 : ∀ c : Fin 64,
    checkColored 273 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (273 * 64 + c.val)) = true := by
  intro c
  rw [colored_row273]
  exact colored_check273 c
#print axioms colored_family273

def coloredWitness274 : Array Nat := #[9236160, 9236880, 9237021, 9237600, 9238320, 9239040, 9239760, 9240480, 9241200, 9241920, 9242061, 9242640, 9243360, 9244080, 9244800, 9245520, 9246240, 9246960, 9247101, 9247680, 9248400, 9249120, 9249840, 9250560, 9251280, 9252000, 9252141, 9252720, 9253440, 9254160, 9254880, 9255600, 9238461, 9239901, 9239181, 9240621, 9256320, 9257040, 9257181, 9257760, 9243501, 9244941, 9244221, 9245661, 9258480, 9259200, 9259341, 9259920, 9248541, 9249981, 9249261, 9250701, 9260640, 9261360, 9261501, 9262080, 9253581, 9255021, 9254301, 9255741, 9262800, 9263520, 9263661, 9264240]

theorem colored_row274 : ∀ c : Fin 64,
    readRow witnessRows (274 * 64 + c.val) = coloredWitness274[c.val]! := by
  decide +kernel
#print axioms colored_row274

theorem colored_check274 : ∀ c : Fin 64,
    checkColored 274 (BitVec.ofNat 6 c.val) (coloredWitness274[c.val]!) = true := by
  decide +kernel
#print axioms colored_check274

theorem colored_family274 : ∀ c : Fin 64,
    checkColored 274 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (274 * 64 + c.val)) = true := by
  intro c
  rw [colored_row274]
  exact colored_check274 c
#print axioms colored_family274

def coloredWitness275 : Array Nat := #[9264960, 9265680, 9265821, 9266400, 9267120, 9267840, 9268560, 9269280, 9270000, 9270720, 9270861, 9271440, 9272160, 9272880, 9273600, 9274320, 9270002, 9270722, 9270863, 9271442, 9272162, 9272882, 9273602, 9274322, 9275040, 9275760, 9275901, 9276480, 9277200, 9277920, 9278640, 9279360, 9267261, 9268701, 9267981, 9269421, 9280080, 9280800, 9280941, 9281520, 9272301, 9273741, 9273021, 9274461, 9282240, 9282960, 9283101, 9283680, 9272303, 9273743, 9273023, 9274463, 9282242, 9282962, 9283103, 9283682, 9277341, 9278781, 9278061, 9279501, 9284400, 9285120, 9285261, 9285840]

theorem colored_row275 : ∀ c : Fin 64,
    readRow witnessRows (275 * 64 + c.val) = coloredWitness275[c.val]! := by
  decide +kernel
#print axioms colored_row275

theorem colored_check275 : ∀ c : Fin 64,
    checkColored 275 (BitVec.ofNat 6 c.val) (coloredWitness275[c.val]!) = true := by
  decide +kernel
#print axioms colored_check275

theorem colored_family275 : ∀ c : Fin 64,
    checkColored 275 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (275 * 64 + c.val)) = true := by
  intro c
  rw [colored_row275]
  exact colored_check275 c
#print axioms colored_family275

def coloredWitness276 : Array Nat := #[9286560, 9287280, 9288000, 9288720, 9288024, 9288744, 9289440, 9290160, 9290880, 9291600, 9292320, 9293040, 9292344, 9293064, 9293760, 9294480, 9295200, 9295920, 9296640, 9297360, 9296664, 9297384, 9298080, 9298800, 9299520, 9300240, 9300960, 9301680, 9300984, 9301704, 9302400, 9303120, 9303840, 9304560, 9305280, 9306000, 9305304, 9306024, 9306720, 9307440, 9308160, 9308880, 9309600, 9310320, 9309624, 9310344, 9311040, 9311760, 9312480, 9313200, 9313920, 9314640, 9313944, 9314664, 9315360, 9316080, 9316800, 9317520, 9318240, 9318960, 9318264, 9318984, 9319680, 9320400]

theorem colored_row276 : ∀ c : Fin 64,
    readRow witnessRows (276 * 64 + c.val) = coloredWitness276[c.val]! := by
  decide +kernel
#print axioms colored_row276

theorem colored_check276 : ∀ c : Fin 64,
    checkColored 276 (BitVec.ofNat 6 c.val) (coloredWitness276[c.val]!) = true := by
  decide +kernel
#print axioms colored_check276

theorem colored_family276 : ∀ c : Fin 64,
    checkColored 276 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (276 * 64 + c.val)) = true := by
  intro c
  rw [colored_row276]
  exact colored_check276 c
#print axioms colored_family276

def coloredWitness277 : Array Nat := #[9321120, 9321840, 9322560, 9323280, 9322584, 9323304, 9324000, 9324720, 9325440, 9326160, 9326880, 9327600, 9326904, 9327624, 9328320, 9329040, 9329760, 9330480, 9331200, 9331920, 9331224, 9331944, 9332640, 9333360, 9334080, 9334800, 9335520, 9336240, 9335544, 9336264, 9336960, 9337680, 9338400, 9339120, 9339840, 9340560, 9339864, 9340584, 9341280, 9342000, 9342720, 9343440, 9344160, 9344880, 9344184, 9344904, 9345600, 9346320, 9347040, 9347760, 9348480, 9349200, 9348504, 9349224, 9349920, 9350640, 9351360, 9352080, 9352800, 9353520, 9352824, 9353544, 9354240, 9354960]

theorem colored_row277 : ∀ c : Fin 64,
    readRow witnessRows (277 * 64 + c.val) = coloredWitness277[c.val]! := by
  decide +kernel
#print axioms colored_row277

theorem colored_check277 : ∀ c : Fin 64,
    checkColored 277 (BitVec.ofNat 6 c.val) (coloredWitness277[c.val]!) = true := by
  decide +kernel
#print axioms colored_check277

theorem colored_family277 : ∀ c : Fin 64,
    checkColored 277 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (277 * 64 + c.val)) = true := by
  intro c
  rw [colored_row277]
  exact colored_check277 c
#print axioms colored_family277

def coloredWitness278 : Array Nat := #[9355680, 9356400, 9357120, 9357840, 9357146, 9357866, 9358560, 9359280, 9360000, 9360720, 9361440, 9362160, 9362880, 9363600, 9364320, 9365040, 9360026, 9360746, 9362906, 9363626, 9361466, 9362186, 9364346, 9365066, 9365760, 9366480, 9367200, 9367920, 9367226, 9367946, 9368640, 9369360, 9370080, 9370800, 9371520, 9372240, 9371546, 9372266, 9372960, 9373680, 9374400, 9375120, 9375840, 9376560, 9377280, 9378000, 9378720, 9379440, 9374426, 9375146, 9377306, 9378026, 9375866, 9376586, 9378746, 9379466, 9380160, 9380880, 9381600, 9382320, 9381626, 9382346, 9383040, 9383760]

theorem colored_row278 : ∀ c : Fin 64,
    readRow witnessRows (278 * 64 + c.val) = coloredWitness278[c.val]! := by
  decide +kernel
#print axioms colored_row278

theorem colored_check278 : ∀ c : Fin 64,
    checkColored 278 (BitVec.ofNat 6 c.val) (coloredWitness278[c.val]!) = true := by
  decide +kernel
#print axioms colored_check278

theorem colored_family278 : ∀ c : Fin 64,
    checkColored 278 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (278 * 64 + c.val)) = true := by
  intro c
  rw [colored_row278]
  exact colored_check278 c
#print axioms colored_family278

def coloredWitness279 : Array Nat := #[9384480, 9385200, 9385920, 9386640, 9385946, 9386666, 9387360, 9388080, 9388800, 9389520, 9390240, 9390960, 9391680, 9392400, 9393120, 9393840, 9388826, 9389546, 9391706, 9392426, 9390266, 9390986, 9393146, 9393866, 9394560, 9395280, 9396000, 9396720, 9396026, 9396746, 9397440, 9398160, 9398880, 9399600, 9400320, 9401040, 9400346, 9401066, 9401760, 9402480, 9403200, 9403920, 9404640, 9405360, 9406080, 9406800, 9407520, 9408240, 9403226, 9403946, 9406106, 9406826, 9404666, 9405386, 9407546, 9408266, 9408960, 9409680, 9410400, 9411120, 9410426, 9411146, 9411840, 9412560]

theorem colored_row279 : ∀ c : Fin 64,
    readRow witnessRows (279 * 64 + c.val) = coloredWitness279[c.val]! := by
  decide +kernel
#print axioms colored_row279

theorem colored_check279 : ∀ c : Fin 64,
    checkColored 279 (BitVec.ofNat 6 c.val) (coloredWitness279[c.val]!) = true := by
  decide +kernel
#print axioms colored_check279

theorem colored_family279 : ∀ c : Fin 64,
    checkColored 279 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (279 * 64 + c.val)) = true := by
  intro c
  rw [colored_row279]
  exact colored_check279 c
#print axioms colored_family279

def coloredWitness280 : Array Nat := #[9413280, 9414000, 9414720, 9415440, 9416160, 9416880, 9417600, 9418320, 9419040, 9419760, 9420480, 9421200, 9421920, 9422640, 9423360, 9424080, 9424800, 9425520, 9426240, 9426960, 9427680, 9428400, 9429120, 9429840, 9430560, 9431280, 9432000, 9432720, 9433440, 9434160, 9434880, 9435600, 9436320, 9437040, 9437760, 9438480, 9439200, 9439920, 9440640, 9441360, 9442080, 9442800, 9443520, 9444240, 9444960, 9445680, 9446400, 9447120, 9447840, 9448560, 9449280, 9450000, 9450720, 9451440, 9452160, 9452880, 9453600, 9454320, 9455040, 9455760, 9456480, 9457200, 9457920, 9458640]

theorem colored_row280 : ∀ c : Fin 64,
    readRow witnessRows (280 * 64 + c.val) = coloredWitness280[c.val]! := by
  decide +kernel
#print axioms colored_row280

theorem colored_check280 : ∀ c : Fin 64,
    checkColored 280 (BitVec.ofNat 6 c.val) (coloredWitness280[c.val]!) = true := by
  decide +kernel
#print axioms colored_check280

theorem colored_family280 : ∀ c : Fin 64,
    checkColored 280 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (280 * 64 + c.val)) = true := by
  intro c
  rw [colored_row280]
  exact colored_check280 c
#print axioms colored_family280

def coloredWitness281 : Array Nat := #[9459360, 9460080, 9460800, 9461520, 9462240, 9462960, 9463680, 9464400, 9465120, 9465840, 9466560, 9467280, 9468000, 9468720, 9469440, 9470160, 9470880, 9471600, 9472320, 9473040, 9473760, 9474480, 9475200, 9475920, 9476640, 9477360, 9478080, 9478800, 9479520, 9480240, 9480960, 9481680, 9482400, 9483120, 9483840, 9484560, 9485280, 9486000, 9486720, 9487440, 9488160, 9488880, 9489600, 9490320, 9491040, 9491760, 9492480, 9493200, 9493920, 9494640, 9495360, 9496080, 9496800, 9497520, 9498240, 9498960, 9499680, 9500400, 9501120, 9501840, 9502560, 9503280, 9504000, 9504720]

theorem colored_row281 : ∀ c : Fin 64,
    readRow witnessRows (281 * 64 + c.val) = coloredWitness281[c.val]! := by
  decide +kernel
#print axioms colored_row281

theorem colored_check281 : ∀ c : Fin 64,
    checkColored 281 (BitVec.ofNat 6 c.val) (coloredWitness281[c.val]!) = true := by
  decide +kernel
#print axioms colored_check281

theorem colored_family281 : ∀ c : Fin 64,
    checkColored 281 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (281 * 64 + c.val)) = true := by
  intro c
  rw [colored_row281]
  exact colored_check281 c
#print axioms colored_family281

def coloredWitness282 : Array Nat := #[9505440, 9506160, 9506880, 9507600, 9508320, 9509040, 9509760, 9510480, 9511200, 9511920, 9512640, 9513360, 9514080, 9514800, 9515520, 9516240, 9516960, 9517680, 9518400, 9519120, 9519840, 9520560, 9521280, 9522000, 9522720, 9523440, 9524160, 9524880, 9525600, 9526320, 9527040, 9527760, 9528480, 9529200, 9529920, 9530640, 9531360, 9532080, 9532800, 9533520, 9534240, 9534960, 9535680, 9536400, 9537120, 9537840, 9538560, 9539280, 9540000, 9540720, 9541440, 9542160, 9542880, 9543600, 9544320, 9545040, 9545760, 9546480, 9547200, 9547920, 9548640, 9549360, 9550080, 9550800]

theorem colored_row282 : ∀ c : Fin 64,
    readRow witnessRows (282 * 64 + c.val) = coloredWitness282[c.val]! := by
  decide +kernel
#print axioms colored_row282

theorem colored_check282 : ∀ c : Fin 64,
    checkColored 282 (BitVec.ofNat 6 c.val) (coloredWitness282[c.val]!) = true := by
  decide +kernel
#print axioms colored_check282

theorem colored_family282 : ∀ c : Fin 64,
    checkColored 282 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (282 * 64 + c.val)) = true := by
  intro c
  rw [colored_row282]
  exact colored_check282 c
#print axioms colored_family282

def coloredWitness283 : Array Nat := #[9551520, 9552240, 9552960, 9553680, 9554400, 9555120, 9555840, 9556560, 9557280, 9558000, 9558720, 9559440, 9560160, 9560880, 9561600, 9562320, 9563040, 9563760, 9564480, 9565200, 9565920, 9566640, 9567360, 9568080, 9568800, 9569520, 9570240, 9570960, 9571680, 9572400, 9573120, 9573840, 9574560, 9575280, 9576000, 9576720, 9577440, 9578160, 9578880, 9579600, 9580320, 9581040, 9581760, 9582480, 9583200, 9583920, 9584640, 9585360, 9586080, 9586800, 9587520, 9588240, 9588960, 9589680, 9590400, 9591120, 9591840, 9592560, 9593280, 9594000, 9594720, 9595440, 9596160, 9596880]

theorem colored_row283 : ∀ c : Fin 64,
    readRow witnessRows (283 * 64 + c.val) = coloredWitness283[c.val]! := by
  decide +kernel
#print axioms colored_row283

theorem colored_check283 : ∀ c : Fin 64,
    checkColored 283 (BitVec.ofNat 6 c.val) (coloredWitness283[c.val]!) = true := by
  decide +kernel
#print axioms colored_check283

theorem colored_family283 : ∀ c : Fin 64,
    checkColored 283 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (283 * 64 + c.val)) = true := by
  intro c
  rw [colored_row283]
  exact colored_check283 c
#print axioms colored_family283

def coloredWitness284 : Array Nat := #[9597600, 9598320, 9599040, 9599760, 9600480, 9601200, 9601920, 9602640, 9603360, 9604080, 9604800, 9605520, 9606240, 9606960, 9607680, 9608400, 9609120, 9609840, 9610560, 9611280, 9612000, 9612720, 9613440, 9614160, 9614880, 9615600, 9616320, 9617040, 9617760, 9618480, 9619200, 9619920, 9620640, 9621360, 9622080, 9622800, 9623520, 9624240, 9624960, 9625680, 9626400, 9627120, 9627840, 9628560, 9629280, 9630000, 9630720, 9631440, 9632160, 9632880, 9633600, 9634320, 9635040, 9635760, 9636480, 9637200, 9637920, 9638640, 9639360, 9640080, 9640800, 9641520, 9642240, 9642960]

theorem colored_row284 : ∀ c : Fin 64,
    readRow witnessRows (284 * 64 + c.val) = coloredWitness284[c.val]! := by
  decide +kernel
#print axioms colored_row284

theorem colored_check284 : ∀ c : Fin 64,
    checkColored 284 (BitVec.ofNat 6 c.val) (coloredWitness284[c.val]!) = true := by
  decide +kernel
#print axioms colored_check284

theorem colored_family284 : ∀ c : Fin 64,
    checkColored 284 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (284 * 64 + c.val)) = true := by
  intro c
  rw [colored_row284]
  exact colored_check284 c
#print axioms colored_family284

def coloredWitness285 : Array Nat := #[9643680, 9644400, 9645120, 9645840, 9646560, 9647280, 9648000, 9648720, 9649440, 9650160, 9650880, 9651600, 9652320, 9653040, 9653760, 9654480, 9655200, 9655920, 9656640, 9657360, 9658080, 9658800, 9659520, 9660240, 9660960, 9661680, 9662400, 9663120, 9663840, 9664560, 9665280, 9666000, 9666720, 9667440, 9668160, 9668880, 9669600, 9670320, 9671040, 9671760, 9672480, 9673200, 9673920, 9674640, 9675360, 9676080, 9676800, 9677520, 9678240, 9678960, 9679680, 9680400, 9681120, 9681840, 9682560, 9683280, 9684000, 9684720, 9685440, 9686160, 9686880, 9687600, 9688320, 9689040]

theorem colored_row285 : ∀ c : Fin 64,
    readRow witnessRows (285 * 64 + c.val) = coloredWitness285[c.val]! := by
  decide +kernel
#print axioms colored_row285

theorem colored_check285 : ∀ c : Fin 64,
    checkColored 285 (BitVec.ofNat 6 c.val) (coloredWitness285[c.val]!) = true := by
  decide +kernel
#print axioms colored_check285

theorem colored_family285 : ∀ c : Fin 64,
    checkColored 285 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (285 * 64 + c.val)) = true := by
  intro c
  rw [colored_row285]
  exact colored_check285 c
#print axioms colored_family285

def coloredWitness286 : Array Nat := #[9689760, 9690480, 9691200, 9691920, 9692640, 9693360, 9694080, 9694800, 9695520, 9696240, 9696960, 9697680, 9698400, 9699120, 9699840, 9700560, 9701280, 9702000, 9702720, 9703440, 9704160, 9704880, 9705600, 9706320, 9707040, 9707760, 9708480, 9709200, 9709920, 9710640, 9711360, 9712080, 9712800, 9713520, 9714240, 9714960, 9715680, 9716400, 9717120, 9717840, 9718560, 9719280, 9720000, 9720720, 9721440, 9722160, 9722880, 9723600, 9724320, 9725040, 9725760, 9726480, 9727200, 9727920, 9728640, 9729360, 9730080, 9730800, 9731520, 9732240, 9732960, 9733680, 9734400, 9735120]

theorem colored_row286 : ∀ c : Fin 64,
    readRow witnessRows (286 * 64 + c.val) = coloredWitness286[c.val]! := by
  decide +kernel
#print axioms colored_row286

theorem colored_check286 : ∀ c : Fin 64,
    checkColored 286 (BitVec.ofNat 6 c.val) (coloredWitness286[c.val]!) = true := by
  decide +kernel
#print axioms colored_check286

theorem colored_family286 : ∀ c : Fin 64,
    checkColored 286 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (286 * 64 + c.val)) = true := by
  intro c
  rw [colored_row286]
  exact colored_check286 c
#print axioms colored_family286

def coloredWitness287 : Array Nat := #[9735840, 9736560, 9737280, 9738000, 9738720, 9739440, 9740160, 9740880, 9741600, 9742320, 9743040, 9743760, 9744480, 9745200, 9745920, 9746640, 9747360, 9748080, 9748800, 9749520, 9750240, 9750960, 9751680, 9752400, 9753120, 9753840, 9754560, 9755280, 9756000, 9756720, 9757440, 9758160, 9758880, 9759600, 9760320, 9761040, 9761760, 9762480, 9763200, 9763920, 9764640, 9765360, 9766080, 9766800, 9767520, 9768240, 9768960, 9769680, 9770400, 9771120, 9771840, 9772560, 9773280, 9774000, 9774720, 9775440, 9776160, 9776880, 9777600, 9778320, 9779040, 9779760, 9780480, 9781200]

theorem colored_row287 : ∀ c : Fin 64,
    readRow witnessRows (287 * 64 + c.val) = coloredWitness287[c.val]! := by
  decide +kernel
#print axioms colored_row287

theorem colored_check287 : ∀ c : Fin 64,
    checkColored 287 (BitVec.ofNat 6 c.val) (coloredWitness287[c.val]!) = true := by
  decide +kernel
#print axioms colored_check287

theorem colored_family287 : ∀ c : Fin 64,
    checkColored 287 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (287 * 64 + c.val)) = true := by
  intro c
  rw [colored_row287]
  exact colored_check287 c
#print axioms colored_family287

end TightCycleC5.Bridge.ColoredCover
