import SubsetSampling

/-! Exact sums over injections into a root complement. -/
namespace TightCycleC5.Bridge
open Finset

noncomputable def outsideEmbeddingEquiv {R V : Type*} [Fintype V] {k : ℕ}
    (root : R ↪ V) : (Fin k ↪ Outside root) ≃
      {σ : Fin k ↪ V // ∀ i, σ i ∉ Set.range root} where
  toFun free := ⟨free.trans ⟨Subtype.val, Subtype.val_injective⟩, fun i => (free i).property⟩
  invFun σ := ⟨fun i => ⟨σ.val i, σ.property i⟩,
    fun _ _ h => σ.val.injective (congrArg Subtype.val h)⟩
  left_inv _ := rfl
  right_inv _ := rfl

theorem sum_complement_embedding {R V : Type*} [Fintype R] [Fintype V] [DecidableEq V] {k : ℕ}
    (root : R ↪ V) (v : (Fin k ↪ V) → ℝ) :
    (∑ free : Fin k ↪ Outside root, v (free.trans ⟨Subtype.val, Subtype.val_injective⟩)) =
      ∑ σ : Fin k ↪ V, if ∀ i, σ i ∉ Set.range root then v σ else 0 := by
  classical
  have h := Equiv.sum_comp (outsideEmbeddingEquiv (k := k) root)
    (fun σ => v σ.val)
  change (∑ free : Fin k ↪ Outside root, v (free.trans ⟨Subtype.val, Subtype.val_injective⟩)) = _ at h
  rw [h]
  exact (Finset.sum_subtype ((univ : Finset (Fin k ↪ V)).filter
    (fun σ => ∀ i, σ i ∉ Set.range root)) (by intro σ; simp) v).symm.trans
    (Finset.sum_filter _ _)

/-- A finite root set, without choosing an ordering for later set sums. -/
noncomputable def rootSet {R V : Type*} [Fintype R] [DecidableEq V] (root : R ↪ V) : Finset V :=
  univ.map root

theorem disjoint_embeddingSet_rootSet {R V : Type*} [Fintype R] [DecidableEq V]
    {k : ℕ} (root : R ↪ V) (σ : Fin k ↪ V) :
    Disjoint (embeddingSet σ) (rootSet root) ↔ ∀ i, σ i ∉ Set.range root := by
  classical
  simp only [Finset.disjoint_left, embeddingSet, rootSet, mem_map, mem_univ,
    true_and, Set.mem_range]
  constructor
  · intro h i hi
    obtain ⟨j, hj⟩ := hi
    exact h ⟨i, rfl⟩ ⟨j, hj⟩
  · intro h a ⟨i, hi⟩ ⟨j, hj⟩
    exact h i ⟨j, hj.trans hi.symm⟩

/-- The ordered free-triple sum equals six times the sum over three-sets
avoiding all roots, with completely arbitrary real set weights. -/
theorem free_triple_set_sum {R V : Type*} [Fintype R] [Fintype V] [DecidableEq V]
    (root : R ↪ V) (w : Finset V → ℝ) :
    (∑ free : Fin 3 ↪ Outside root,
      w (embeddingSet (free.trans ⟨Subtype.val, Subtype.val_injective⟩))) =
      6 * ∑ e ∈ (univ : Finset V).powersetCard 3,
        if Disjoint e (rootSet root) then w e else 0 := by
  classical
  rw [sum_complement_embedding root (fun σ : Fin 3 ↪ V => w (embeddingSet σ))]
  have hp : ∀ σ : Fin 3 ↪ V,
      (if ∀ i, σ i ∉ Set.range root then w (embeddingSet σ) else 0) =
      (fun e => if Disjoint e (rootSet root) then w e else 0) (embeddingSet σ) := by
    intro σ
    simp only [disjoint_embeddingSet_rootSet]
  calc
    _ = ∑ σ : Fin 3 ↪ V,
        (fun e => if Disjoint e (rootSet root) then w e else 0) (embeddingSet σ) :=
      Finset.sum_congr rfl (fun σ _ => hp σ)
    _ = _ := by
      rw [embeddingSet_sum 3 (fun e : Finset V => if Disjoint e (rootSet root) then w e else 0)]
      norm_num

#print axioms sum_complement_embedding
#print axioms disjoint_embeddingSet_rootSet
#print axioms free_triple_set_sum
end TightCycleC5.Bridge
