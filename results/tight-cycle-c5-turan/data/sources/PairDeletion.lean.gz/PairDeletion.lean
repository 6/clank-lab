import TripleDeletion

/-! Exact diagonal deletion for the pair-book rows. -/
namespace TightCycleC5.Bridge
open Finset
variable {A : Type*} [Fintype A] [DecidableEq A]

theorem pair_diagonal_identity (v : A → A → ℝ) :
    (∑ a, ∑ b, v a b) =
      (∑ p ∈ (univ : Finset A).offDiag, v p.1 p.2) + ∑ a, v a a := by
  have hp : ∀ a b, v a b = (if a ≠ b then v a b else 0) +
      (if b = a then v a a else 0) := by
    intro a b
    by_cases h : a = b <;> simp [h, Ne.symm]
  have hs := Finset.sum_congr (s₁ := (univ : Finset A)) rfl (fun a _ =>
    Finset.sum_congr (s₁ := (univ : Finset A)) rfl (fun b _ => hp a b))
  simpa only [sum_add_distrib, offDiag_eq_filter, sum_filter, sum_product,
    Finset.sum_ite_eq', mem_univ, if_true] using hs

theorem distinct_pair_sum_lower (v : A → A → ℝ) (B : ℝ)
    (hdiag : ∀ a, v a a ≤ B) (hfull : 0 ≤ ∑ a, ∑ b, v a b) :
    -((Fintype.card A : ℝ) * B) ≤ ∑ p ∈ (univ : Finset A).offDiag, v p.1 p.2 := by
  have hloss : (∑ a, v a a) ≤ (Fintype.card A : ℝ) * B := by
    calc
      _ ≤ ∑ _a : A, B := sum_le_sum fun a _ => hdiag a
      _ = _ := by simp
  rw [pair_diagonal_identity v] at hfull
  linarith

theorem distinct_pair_mean_lower (v : A → A → ℝ) (B : ℝ)
    (hk : 2 ≤ Fintype.card A) (hdiag : ∀ a, v a a ≤ B)
    (hfull : 0 ≤ ∑ a, ∑ b, v a b) :
    -(B / ((Fintype.card A : ℝ) - 1)) ≤
      uniformMean (fun σ : Fin 2 ↪ A => v (σ 0) (σ 1)) := by
  rw [pair_injection_mean, offDiag_card_real, card_univ]
  have hkR : (2 : ℝ) ≤ Fintype.card A := by exact_mod_cast hk
  have hd : 0 < (Fintype.card A : ℝ) * ((Fintype.card A : ℝ) - 1) :=
    mul_pos (by linarith) (by linarith)
  apply (le_div_iff₀ hd).mpr
  calc
    _ = -((Fintype.card A : ℝ) * B) := by
      have h1 : (Fintype.card A : ℝ) - 1 ≠ 0 := by linarith
      field_simp
    _ ≤ _ := distinct_pair_sum_lower v B hdiag hfull

#print axioms pair_diagonal_identity
#print axioms distinct_pair_sum_lower
#print axioms distinct_pair_mean_lower
end TightCycleC5.Bridge
