import FamilyData

/-! A complete CL-3 family timing unit. This is an exact-data computation,
not a proof of the uniform graph-to-row or class-cover bridge. -/

namespace TightCycleC5.Bridge.Family

def orders : Array (Array Nat) :=
  ((List.range 6).permutations.map List.toArray).toArray

def tripleIndex (a b c : Nat) : Nat :=
  let lo := min a (min b c)
  let hi := max a (max b c)
  let mid := a + b + c - lo - hi
  20 - (6 - lo).choose 3 + ((5 - lo).choose 2 - (6 - mid).choose 2) + hi - mid - 1

def edge (mask : Nat) (p : Array Nat) (a b c : Nat) : Nat :=
  if mask.testBit (tripleIndex p[a]! p[b]! p[c]!) then 1 else 0

def zeta (ys : Array Int) (tau seen : Nat) : Int :=
  (List.range 255).foldl (fun acc i =>
    if (i + 1) &&& seen == seen then acc + ys[tau * 255 + i]! else acc) 0

def zetas (ys : Array Int) : Array Int :=
  (Array.range 512).map (fun i => zeta ys (i / 256) (i % 256))

def rowValue (table : Array Int) (mask : Nat) (p : Array Nat) : Int :=
  let e := edge mask p
  let pat := fun z => 4 * e 0 1 z + 2 * e 0 2 z + e 1 2 z
  let seen := (1 <<< pat 3) ||| (1 <<< pat 4) ||| (1 <<< pat 5)
  let cherry : Int := (e 0 3 4 : Int) * e 0 3 5 * (1 - (e 0 4 5 : Int))
  let k4 : Int := (e 0 3 4 : Int) * e 0 3 5 * e 0 4 5 * e 3 4 5
  table[256 * e 0 1 2 + seen]! * (cherry - k4)

def familyCheckData (ys : Array Int) (ks : Array Nat) (sums : Array Int) : Bool := Id.run do
  if ys.size != 510 || ks.size != 835 || sums.size != 835 then
    return false
  if orders.size != 720 || !ys.all (fun y => y >= 0) then return false
  let table := zetas ys
  for i in [:ks.size] do
    let actual := orders.foldl (fun acc p => acc + rowValue table ks[i]! p) 0
    if actual != sums[i]! then return false
  return true

def familyCheck : Bool := familyCheckData multipliers classes expected

set_option maxHeartbeats 0 in
theorem cl3_family_exact : familyCheck = true := by native_decide

#print axioms cl3_family_exact

theorem rejects_negative_multiplier :
    familyCheckData (multipliers.set! 0 (-1)) classes expected = false := by native_decide

theorem rejects_changed_sum :
    familyCheckData multipliers classes (expected.set! 0 (expected[0]! + 1)) = false := by
  native_decide

#print axioms rejects_negative_multiplier
#print axioms rejects_changed_sum

end TightCycleC5.Bridge.Family
