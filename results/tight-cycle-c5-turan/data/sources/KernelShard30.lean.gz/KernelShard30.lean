import KernelShard30Blocks0
import KernelShard30Blocks1
import KernelShard30Blocks2
import KernelShard30Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard30 : kernelShardCheck 30 kernelWitness30 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (30 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness30 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_30_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard30
end TightCycleC5.Bridge.Cover
