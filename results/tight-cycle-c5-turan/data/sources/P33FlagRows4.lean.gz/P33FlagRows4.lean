import P33FlagRowsBase
import P33PSDGroup4
import P33FlagFacts4

namespace TightCycleC5.Bridge.P33Flag
open Finset Matrix

noncomputable def row4 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix4 basis4 type4 G

theorem row4_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row4 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix4)
        (fun root a => flagLookup basis4 (fourKey H S root a)) (fourIndicator type4 H S) :=
  four_row_eq P33PSD.matrix4 basis4 basis4_injective type4 H S

theorem row4_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound4 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row4 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd4 P33PSD.normalized_nonneg4
    P33PSD.normalized_diagonal4 hn basis4 basis4_injective type4 H S

#print axioms row4_eq_optional
#print axioms row4_lower

noncomputable def row10 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix10 basis10 type10 G

theorem row10_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row10 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix10)
        (fun root a => flagLookup basis10 (fourKey H S root a)) (fourIndicator type10 H S) :=
  four_row_eq P33PSD.matrix10 basis10 basis10_injective type10 H S

theorem row10_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound10 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row10 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd10 P33PSD.normalized_nonneg10
    P33PSD.normalized_diagonal10 hn basis10 basis10_injective type10 H S

#print axioms row10_eq_optional
#print axioms row10_lower

noncomputable def row16 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix16 basis16 type16 G

theorem row16_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row16 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix16)
        (fun root a => flagLookup basis16 (fourKey H S root a)) (fourIndicator type16 H S) :=
  four_row_eq P33PSD.matrix16 basis16 basis16_injective type16 H S

theorem row16_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound16 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row16 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd16 P33PSD.normalized_nonneg16
    P33PSD.normalized_diagonal16 hn basis16 basis16_injective type16 H S

#print axioms row16_eq_optional
#print axioms row16_lower

noncomputable def row22 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix22 basis22 type22 G

theorem row22_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row22 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix22)
        (fun root a => flagLookup basis22 (fourKey H S root a)) (fourIndicator type22 H S) :=
  four_row_eq P33PSD.matrix22 basis22 basis22_injective type22 H S

theorem row22_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound22 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row22 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd22 P33PSD.normalized_nonneg22
    P33PSD.normalized_diagonal22 hn basis22 basis22_injective type22 H S

#print axioms row22_eq_optional
#print axioms row22_lower

noncomputable def row28 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix28 basis28 type28 G

theorem row28_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row28 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix28)
        (fun root a => flagLookup basis28 (fourKey H S root a)) (fourIndicator type28 H S) :=
  four_row_eq P33PSD.matrix28 basis28 basis28_injective type28 H S

theorem row28_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound28 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row28 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd28 P33PSD.normalized_nonneg28
    P33PSD.normalized_diagonal28 hn basis28 basis28_injective type28 H S

#print axioms row28_eq_optional
#print axioms row28_lower

noncomputable def row34 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix34 basis34 type34 G

theorem row34_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row34 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix34)
        (fun root a => flagLookup basis34 (fourKey H S root a)) (fourIndicator type34 H S) :=
  four_row_eq P33PSD.matrix34 basis34 basis34_injective type34 H S

theorem row34_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound34 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row34 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd34 P33PSD.normalized_nonneg34
    P33PSD.normalized_diagonal34 hn basis34 basis34_injective type34 H S

#print axioms row34_eq_optional
#print axioms row34_lower

end TightCycleC5.Bridge.P33Flag
