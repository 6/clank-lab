import P33RowMatchingRows
import P33RowMatchingWeightAll
import P33RowMatchingSums
import P33RowMatchingAlgebra
import P33ArithmeticUnit

namespace TightCycleC5.Bridge.P33RowMatching
open Finset

/-- Exactly the signed non-PSD part of the accepted integer evaluator. -/
def nonPSDIntegerAt (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) : Int :=
  let f := P33Arithmetic.featuresAt P33Arithmetic.localFlags P33Arithmetic.globalFlags P33Arithmetic.blocks K p
  P33Arithmetic.sparseValue P33Arithmetic.inequalitySupport (fun i => P33Arithmetic.inequalityRow f i.val) +
  P33Arithmetic.sparseValue P33Arithmetic.regularitySupport (fun i => P33Arithmetic.regularityRow f i.val)

/-- Every raw multiplier is divided by the common SOS scale once. The only
native dependencies are the two accepted sparse-to-dense coefficient checks. -/
theorem normalized_nonPSD_match (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hl : localQueryValid K p) (hg : globalQueryValid K p) (hr : regularQueryValid K p) :
    (nonPSDIntegerAt K p : ℝ) / 1000000000 / (P33Arithmetic.sosScale : ℝ) =
      actualNonPSD (structureAt K p) := by
  unfold nonPSDIntegerAt
  rw [Int.cast_add,add_div,add_div]
  rw [sparse_normalized_eq _ _ _ _ (inequality_row_match K p hl hg),
    sparse_normalized_eq _ _ _ _ (fun i => regular_row_match K p i hr)]
  simp_rw [P33Arithmetic.sparse_inequalities_match,P33Arithmetic.sparse_regularity_match,
    inequality_weight_match,regular_weight_match]
  exact (actualNonPSD_eq_flat (structureAt K p)).symm

#print axioms normalized_nonPSD_match
end TightCycleC5.Bridge.P33RowMatching
