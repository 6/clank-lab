import KernelRowIndex
import KernelWitness5

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_5_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 64 * 256 + i.val))
      kernelWitness5Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_64

theorem kernelBlock_5_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 65 * 256 + i.val))
      kernelWitness5Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_65

theorem kernelBlock_5_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 66 * 256 + i.val))
      kernelWitness5Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_66

theorem kernelBlock_5_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 67 * 256 + i.val))
      kernelWitness5Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_67

theorem kernelBlock_5_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 68 * 256 + i.val))
      kernelWitness5Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_68

theorem kernelBlock_5_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 69 * 256 + i.val))
      kernelWitness5Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_69

theorem kernelBlock_5_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 70 * 256 + i.val))
      kernelWitness5Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_70

theorem kernelBlock_5_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 71 * 256 + i.val))
      kernelWitness5Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_71

theorem kernelBlock_5_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 72 * 256 + i.val))
      kernelWitness5Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_72

theorem kernelBlock_5_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 73 * 256 + i.val))
      kernelWitness5Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_73

theorem kernelBlock_5_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 74 * 256 + i.val))
      kernelWitness5Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_74

theorem kernelBlock_5_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 75 * 256 + i.val))
      kernelWitness5Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_75

theorem kernelBlock_5_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 76 * 256 + i.val))
      kernelWitness5Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_76

theorem kernelBlock_5_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 77 * 256 + i.val))
      kernelWitness5Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_77

theorem kernelBlock_5_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 78 * 256 + i.val))
      kernelWitness5Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_78

theorem kernelBlock_5_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 79 * 256 + i.val))
      kernelWitness5Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_79

theorem kernelBlock_5_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 80 * 256 + i.val))
      kernelWitness5Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_80

theorem kernelBlock_5_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 81 * 256 + i.val))
      kernelWitness5Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_81

theorem kernelBlock_5_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 82 * 256 + i.val))
      kernelWitness5Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_82

theorem kernelBlock_5_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 83 * 256 + i.val))
      kernelWitness5Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_83

theorem kernelBlock_5_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 84 * 256 + i.val))
      kernelWitness5Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_84

theorem kernelBlock_5_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 85 * 256 + i.val))
      kernelWitness5Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_85

theorem kernelBlock_5_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 86 * 256 + i.val))
      kernelWitness5Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_86

theorem kernelBlock_5_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 87 * 256 + i.val))
      kernelWitness5Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_87

theorem kernelBlock_5_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 88 * 256 + i.val))
      kernelWitness5Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_88

theorem kernelBlock_5_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 89 * 256 + i.val))
      kernelWitness5Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_89

theorem kernelBlock_5_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 90 * 256 + i.val))
      kernelWitness5Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_90

theorem kernelBlock_5_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 91 * 256 + i.val))
      kernelWitness5Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_91

theorem kernelBlock_5_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 92 * 256 + i.val))
      kernelWitness5Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_92

theorem kernelBlock_5_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 93 * 256 + i.val))
      kernelWitness5Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_93

theorem kernelBlock_5_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 94 * 256 + i.val))
      kernelWitness5Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_94

theorem kernelBlock_5_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 95 * 256 + i.val))
      kernelWitness5Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_95

end TightCycleC5.Bridge.Cover
