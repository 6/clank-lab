import M4
import Scalar

/-!
# M4 implies the upper bound `e(H) ≤ α n³ / 6`

                                                                        
`LagrBound n` says that every `C₅³`-free 3-graph on `Fin n` has
`lagr H w ≤ L (Σ w)³` for all nonnegative weights `w`, with `L = α / 6`.
It is proved for every `n` by strong induction, given `M4Statement`:

1. A weighting with a zero coordinate is a weighting of a smaller vertex
   set: restrict `H` to the support and relabel it to `Fin k`
   (`pullback`, `lagr_pullback`, `lagr_le_of_zero`).
2. A maximiser `w*` of `lagr H` on the simplex exists (compactness).
3. If `w*` has a zero coordinate, step 1 applies. If two vertices lie in no
   common edge, moving all weight of one onto the other does not decrease
   `lagr H` for one of the two directions (`merge`, the Frankl–Rödl step), and
   gives a maximiser with a zero coordinate.
4. Otherwise `H` covers pairs and `w*` is an interior maximiser: M4 gives a
   cut `A` with `lagr H w* ≤ x² y / 2 + lagr H[Aᶜ] w*`, `x = w*(A)`,
   `y = w*(Aᶜ)`; step 1 bounds the last term by `L y³`, and `scalar_step`
   gives `x² y / 2 + L y³ ≤ L (x + y)³ = L`.

At the all-ones weighting, `lagr H 1 = e(H)` and `Σ 1 = n`, so
`m4_implies_bound` follows.
-/

namespace TightCycleC5

open Finset

/-! ### Basic facts about the Lagrangian -/

theorem three_le_of_mem {n : ℕ} {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H)
    {e : Finset (Fin n)} (he : e ∈ H) : 3 ≤ n := by
  have := e.card_le_univ
  simpa [hH e he] using this

theorem lagr_smul {n : ℕ} {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H) (c : ℝ)
    (w : Fin n → ℝ) : lagr H (c • w) = c ^ 3 * lagr H w := by
  unfold lagr
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun e he => ?_
  simp only [Pi.smul_apply, smul_eq_mul]
  rw [Finset.prod_mul_distrib, Finset.prod_const, hH e he]

theorem continuous_lagr {n : ℕ} (H : Finset (Finset (Fin n))) : Continuous (lagr H) := by
  show Continuous fun w : Fin n → ℝ => ∑ e ∈ H, ∏ v ∈ e, w v
  exact continuous_finsetSum _ fun e _ => continuous_finsetProd _ fun v _ => continuous_apply v

theorem lagr_empty {n : ℕ} (w : Fin n → ℝ) : lagr (∅ : Finset (Finset (Fin n))) w = 0 := by
  simp [lagr]

/-! ### Restriction to an embedded vertex set -/

/-- The pull-back of `H` along an embedding `φ : Fin m ↪ Fin n`: the edges of
`H` inside the range of `φ`, relabelled. -/
def pullback {m n : ℕ} (φ : Fin m ↪ Fin n) (H : Finset (Finset (Fin n))) :
    Finset (Finset (Fin m)) :=
  Finset.univ.filter (fun e => e.map φ ∈ H)

theorem pullback_three {m n : ℕ} (φ : Fin m ↪ Fin n) {H : Finset (Finset (Fin n))}
    (hH : IsThreeGraph H) : IsThreeGraph (pullback φ H) := by
  intro e he
  simp only [pullback, mem_filter, mem_univ, true_and] at he
  rw [← Finset.card_map φ]
  exact hH _ he

theorem pullback_c5free {m n : ℕ} (φ : Fin m ↪ Fin n) {H : Finset (Finset (Fin n))}
    (hC : ¬ ContainsC5 H) : ¬ ContainsC5 (pullback φ H) := by
  rintro ⟨f, hf⟩
  apply hC
  refine ⟨f.trans φ, fun i => ?_⟩
  have := hf i
  simp only [pullback, mem_filter, mem_univ, true_and] at this
  simpa [Finset.map_insert, Finset.map_singleton] using this

/-- Restricting to the range of `φ` does not change the Lagrangian of a
weighting that vanishes off that range. -/
theorem lagr_pullback {m n : ℕ} (φ : Fin m ↪ Fin n) (H : Finset (Finset (Fin n)))
    (w : Fin n → ℝ) (hw : ∀ v, v ∉ Set.range φ → w v = 0) :
    lagr (pullback φ H) (w ∘ φ) = lagr H w := by
  unfold lagr
  have h1 : ∑ e ∈ pullback φ H, ∏ v ∈ e, (w ∘ φ) v =
      ∑ e ∈ (pullback φ H).map (Finset.mapEmbedding φ).toEmbedding, ∏ v ∈ e, w v := by
    rw [Finset.sum_map]
    refine Finset.sum_congr rfl fun e _ => ?_
    simp [Finset.prod_map]
  rw [h1]
  apply Finset.sum_subset
  · intro e he
    simp only [Finset.mem_map, pullback, mem_filter, mem_univ, true_and,
      RelEmbedding.coe_toEmbedding, Finset.mapEmbedding_apply] at he
    obtain ⟨a, ha, rfl⟩ := he
    exact ha
  · intro e he hne
    by_contra hprod
    apply hne
    have hall : e ⊆ Finset.univ.map φ := by
      intro v hv
      by_contra hv'
      apply hprod
      apply Finset.prod_eq_zero hv
      apply hw
      rintro ⟨j, rfl⟩
      exact hv' (Finset.mem_map_of_mem φ (Finset.mem_univ j))
    obtain ⟨u, -, rfl⟩ := Finset.subset_map_iff.mp hall
    simp only [Finset.mem_map, pullback, mem_filter, mem_univ, true_and,
      RelEmbedding.coe_toEmbedding, Finset.mapEmbedding_apply]
    exact ⟨u, he, rfl⟩

/-- The bound for all weightings on `Fin n`. -/
def LagrBound (n : ℕ) : Prop :=
  ∀ H : Finset (Finset (Fin n)), IsThreeGraph H → ¬ ContainsC5 H →
    ∀ w : Fin n → ℝ, (∀ v, 0 ≤ w v) → lagr H w ≤ turanL * (∑ v, w v) ^ 3

/-- **Step 1.** A weighting with a zero coordinate lives on fewer vertices. -/
theorem lagr_le_of_zero {n : ℕ} (ih : ∀ m < n, LagrBound m) {H : Finset (Finset (Fin n))}
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (w : Fin n → ℝ) (hw : ∀ v, 0 ≤ w v)
    (hz : ∃ v, w v = 0) : lagr H w ≤ turanL * (∑ v, w v) ^ 3 := by
  obtain ⟨v₀, hv₀⟩ := hz
  set S : Finset (Fin n) := Finset.univ.filter (fun v => w v ≠ 0) with hS
  have hcard : S.card < n := by
    have : S.card < (Finset.univ : Finset (Fin n)).card := by
      apply Finset.card_lt_card
      refine ⟨Finset.subset_univ _, fun h => ?_⟩
      have := h (Finset.mem_univ v₀)
      simp [hS, hv₀] at this
    simpa using this
  set φ : Fin S.card ↪ Fin n := (S.orderEmbOfFin rfl).toEmbedding with hφ
  have hrange : Set.range φ = S := by
    rw [hφ, RelEmbedding.coe_toEmbedding, Finset.range_orderEmbOfFin]
  have hwφ : ∀ v, v ∉ Set.range φ → w v = 0 := by
    intro v hv
    rw [hrange] at hv
    simpa [hS] using hv
  have hsum : ∑ j, (w ∘ φ) j = ∑ v, w v := by
    have hmap : (Finset.univ : Finset (Fin S.card)).map φ = S := by
      apply Finset.coe_injective
      rw [Finset.coe_map, Finset.coe_univ, Set.image_univ, hrange]
    calc ∑ j, (w ∘ φ) j = ∑ v ∈ (Finset.univ : Finset (Fin S.card)).map φ, w v := by
          rw [Finset.sum_map]; rfl
      _ = ∑ v ∈ S, w v := by rw [hmap]
      _ = ∑ v, w v := by rw [hS, Finset.sum_filter_ne_zero]
  rw [← lagr_pullback φ H w hwφ, ← hsum]
  exact ih S.card hcard (pullback φ H) (pullback_three φ hH) (pullback_c5free φ hC) (w ∘ φ)
    (fun j => hw (φ j))

/-! ### The Frankl–Rödl merging step -/

/-- Moving the weight of `v` onto `u`. -/
def moveWeight {n : ℕ} (w : Fin n → ℝ) (u v : Fin n) : Fin n → ℝ :=
  fun x => w x + (if x = u then w v else 0) - (if x = v then w v else 0)

theorem moveWeight_u {n : ℕ} (w : Fin n → ℝ) {u v : Fin n} (huv : u ≠ v) :
    moveWeight w u v u = w u + w v := by
  simp [moveWeight, huv]

theorem moveWeight_v {n : ℕ} (w : Fin n → ℝ) {u v : Fin n} (huv : u ≠ v) :
    moveWeight w u v v = 0 := by
  simp [moveWeight, huv.symm]

theorem moveWeight_other {n : ℕ} (w : Fin n → ℝ) {u v x : Fin n} (hu : x ≠ u) (hv : x ≠ v) :
    moveWeight w u v x = w x := by
  simp [moveWeight, hu, hv]

theorem moveWeight_sum {n : ℕ} (w : Fin n → ℝ) (u v : Fin n) :
    ∑ x, moveWeight w u v x = ∑ x, w x := by
  simp only [moveWeight, Finset.sum_sub_distrib, Finset.sum_add_distrib, Finset.sum_ite_eq',
    Finset.mem_univ, if_true]
  ring

theorem moveWeight_nonneg {n : ℕ} (w : Fin n → ℝ) (hw : ∀ x, 0 ≤ w x) {u v : Fin n}
    (huv : u ≠ v) : ∀ x, 0 ≤ moveWeight w u v x := by
  intro x
  by_cases hxu : x = u
  · subst hxu; rw [moveWeight_u w huv]; linarith [hw x, hw v]
  by_cases hxv : x = v
  · subst hxv; rw [moveWeight_v w huv]
  rw [moveWeight_other w hxu hxv]; exact hw x

/-- The product over an edge containing `u` but not `v` after moving `v`'s
weight onto `u`. -/
theorem prod_moveWeight_of_mem {n : ℕ} (w : Fin n → ℝ) {u v : Fin n} (huv : u ≠ v)
    {e : Finset (Fin n)} (hu : u ∈ e) (hv : v ∉ e) :
    ∏ x ∈ e, moveWeight w u v x = (w u + w v) * ∏ x ∈ e.erase u, w x := by
  rw [← Finset.mul_prod_erase e _ hu, moveWeight_u w huv]
  congr 1
  refine Finset.prod_congr rfl fun x hx => ?_
  have hxu : x ≠ u := Finset.ne_of_mem_erase hx
  have hxv : x ≠ v := fun h => hv (h ▸ Finset.mem_of_mem_erase hx)
  exact moveWeight_other w hxu hxv

theorem prod_moveWeight_of_not_mem {n : ℕ} (w : Fin n → ℝ) {u v : Fin n}
    {e : Finset (Fin n)} (hu : u ∉ e) (hv : v ∉ e) :
    ∏ x ∈ e, moveWeight w u v x = ∏ x ∈ e, w x := by
  refine Finset.prod_congr rfl fun x hx => ?_
  exact moveWeight_other w (fun h => hu (h ▸ hx)) (fun h => hv (h ▸ hx))

theorem prod_moveWeight_zero {n : ℕ} (w : Fin n → ℝ) {u v : Fin n} (huv : u ≠ v)
    {e : Finset (Fin n)} (hv : v ∈ e) : ∏ x ∈ e, moveWeight w u v x = 0 :=
  Finset.prod_eq_zero hv (moveWeight_v w huv)

/-- The edge identity: on an edge not containing both `u` and `v`,
`(w u + w v) Π w = w u · Π w₁ + w v · Π w₂`, where `w₁` moves `v`'s weight
onto `u` and `w₂` moves `u`'s weight onto `v`. -/
theorem edge_identity {n : ℕ} (w : Fin n → ℝ) {u v : Fin n} (huv : u ≠ v)
    {e : Finset (Fin n)} (he : ¬ (u ∈ e ∧ v ∈ e)) :
    (w u + w v) * ∏ x ∈ e, w x =
      w u * ∏ x ∈ e, moveWeight w u v x + w v * ∏ x ∈ e, moveWeight w v u x := by
  by_cases hu : u ∈ e
  · have hv : v ∉ e := fun hv => he ⟨hu, hv⟩
    rw [prod_moveWeight_of_mem w huv hu hv, prod_moveWeight_zero w huv.symm hu,
      ← Finset.mul_prod_erase e _ hu]
    ring
  · by_cases hv : v ∈ e
    · rw [prod_moveWeight_zero w huv hv, prod_moveWeight_of_mem w huv.symm hv hu,
        ← Finset.mul_prod_erase e _ hv]
      ring
    · rw [prod_moveWeight_of_not_mem w hu hv, prod_moveWeight_of_not_mem w hv hu]
      ring

/-- **The Frankl–Rödl step.** If `u ≠ v` lie in no common edge, some
weighting with a zero coordinate and the same total has Lagrangian at least
`lagr H w`. -/
theorem merge {n : ℕ} {H : Finset (Finset (Fin n))} (w : Fin n → ℝ) (hw : ∀ x, 0 ≤ w x)
    {u v : Fin n} (huv : u ≠ v) (hnc : ∀ e ∈ H, ¬ (u ∈ e ∧ v ∈ e)) :
    ∃ w' : Fin n → ℝ, (∀ x, 0 ≤ w' x) ∧ ∑ x, w' x = ∑ x, w x ∧ (∃ x, w' x = 0) ∧
      lagr H w ≤ lagr H w' := by
  have hid : (w u + w v) * lagr H w =
      w u * lagr H (moveWeight w u v) + w v * lagr H (moveWeight w v u) := by
    unfold lagr
    rw [Finset.mul_sum, Finset.mul_sum, Finset.mul_sum, ← Finset.sum_add_distrib]
    exact Finset.sum_congr rfl fun e he => edge_identity w huv (hnc e he)
  by_cases h0 : w u + w v = 0
  · refine ⟨w, hw, rfl, ⟨u, ?_⟩, le_rfl⟩
    linarith [hw u, hw v]
  have hpos : 0 < w u + w v := lt_of_le_of_ne (add_nonneg (hw u) (hw v)) (Ne.symm h0)
  by_cases hcmp : lagr H (moveWeight w v u) ≤ lagr H (moveWeight w u v)
  · refine ⟨moveWeight w u v, moveWeight_nonneg w hw huv, moveWeight_sum w u v,
      ⟨v, moveWeight_v w huv⟩, ?_⟩
    have : (w u + w v) * lagr H w ≤ (w u + w v) * lagr H (moveWeight w u v) := by
      rw [hid]; nlinarith [hw u, hw v]
    exact le_of_mul_le_mul_left this hpos
  · push Not at hcmp
    refine ⟨moveWeight w v u, moveWeight_nonneg w hw huv.symm, moveWeight_sum w v u,
      ⟨u, moveWeight_v w huv.symm⟩, ?_⟩
    have : (w u + w v) * lagr H w ≤ (w u + w v) * lagr H (moveWeight w v u) := by
      rw [hid]; nlinarith [hw u, hw v]
    exact le_of_mul_le_mul_left this hpos

/-! ### The cut step -/

/-- The Lagrangian of `H[Aᶜ]` is the Lagrangian of `H` at the weighting that
vanishes on `A`. -/
theorem lagr_filter_compl {n : ℕ} (H : Finset (Finset (Fin n))) (w : Fin n → ℝ)
    (A : Finset (Fin n)) :
    lagr (H.filter (fun e => e ⊆ Aᶜ)) w = lagr H (fun v => if v ∈ Aᶜ then w v else 0) := by
  unfold lagr
  rw [← Finset.sum_filter_add_sum_filter_not H (fun e => e ⊆ Aᶜ)]
  have h0 : ∑ e ∈ H.filter (fun e => ¬ e ⊆ Aᶜ),
      ∏ v ∈ e, (if v ∈ Aᶜ then w v else 0) = 0 := by
    refine Finset.sum_eq_zero fun e he => ?_
    rw [Finset.mem_filter, Finset.not_subset] at he
    obtain ⟨-, x, hx, hxA⟩ := he
    exact Finset.prod_eq_zero hx (if_neg hxA)
  rw [h0, add_zero]
  refine Finset.sum_congr rfl fun e he => ?_
  rw [Finset.mem_filter] at he
  exact Finset.prod_congr rfl fun x hx => (if_pos (he.2 hx)).symm

/-! ### The induction -/

/-- **`LagrBound n` for every `n`, given M4.** -/
theorem lagrBound_of_m4 (h : M4Statement) (n : ℕ) : LagrBound n := by
  induction n using Nat.strong_induction_on with
  | _ n ih =>
  intro H hH hC
  by_cases hHe : H = ∅
  · intro w hw
    subst hHe
    rw [lagr_empty]
    exact mul_nonneg turanL_nonneg (pow_nonneg (Finset.sum_nonneg fun v _ => hw v) 3)
  obtain ⟨e₀, he₀⟩ := Finset.nonempty_iff_ne_empty.mpr hHe
  have hn3 : 3 ≤ n := three_le_of_mem hH he₀
  have hred := fun w hw hz => lagr_le_of_zero ih hH hC w hw hz
  -- the bound on the simplex
  have hsimp : ∀ w ∈ simplex n, lagr H w ≤ turanL := by
    intro w0 hw0
    have hcpt : IsCompact (simplex n) := isCompact_stdSimplex ℝ (Fin n)
    obtain ⟨ws, hws, hmax⟩ :=
      hcpt.exists_isMaxOn ⟨w0, hw0⟩ (continuous_lagr H).continuousOn
    have hmax' : ∀ w' ∈ simplex n, lagr H w' ≤ lagr H ws := fun w' hw' => hmax hw'
    suffices lagr H ws ≤ turanL from (hmax' w0 hw0).trans this
    by_cases hz : ∃ v, ws v = 0
    · have := hred ws hws.1 hz
      rwa [hws.2, one_pow, mul_one] at this
    push Not at hz
    have hpos : ∀ v, 0 < ws v := fun v => lt_of_le_of_ne (hws.1 v) (hz v).symm
    by_cases hcov : CoversPairs H
    · obtain ⟨A, hA, hAc, hcut⟩ :=
        h n H (by omega) hH hC hcov ws hws hpos hmax'
      set wB : Fin n → ℝ := fun v => if v ∈ Aᶜ then ws v else 0 with hwB
      have hwB0 : ∀ v, 0 ≤ wB v := fun v => by
        simp only [hwB]; split_ifs
        · exact hws.1 v
        · exact le_rfl
      obtain ⟨a, ha⟩ := hA
      have hzB : ∃ v, wB v = 0 := ⟨a, by simp [hwB, ha]⟩
      have hB := hred wB hwB0 hzB
      have hsumB : ∑ v, wB v = ∑ v ∈ Aᶜ, ws v := by
        simp only [hwB]
        rw [← Finset.sum_filter, Finset.filter_mem_eq_inter, Finset.univ_inter]
      rw [hsumB, ← lagr_filter_compl] at hB
      have hxy : ∑ v ∈ A, ws v + ∑ v ∈ Aᶜ, ws v = 1 := by
        rw [Finset.sum_add_sum_compl, hws.2]
      have hx : 0 ≤ ∑ v ∈ A, ws v := Finset.sum_nonneg fun v _ => hws.1 v
      have hy : 0 ≤ ∑ v ∈ Aᶜ, ws v := Finset.sum_nonneg fun v _ => hws.1 v
      have hsc := scalar_step hx hy
      rw [hxy, one_pow, mul_one] at hsc
      linarith
    · unfold CoversPairs at hcov
      push Not at hcov
      obtain ⟨u, v, huv, hnc⟩ := hcov
      obtain ⟨w', hw'0, hsum', hz', hle⟩ :=
        merge (H := H) ws hws.1 huv (fun e he ⟨hu, hv⟩ => hnc e he hu hv)
      have := hred w' hw'0 hz'
      rw [hsum', hws.2, one_pow, mul_one] at this
      linarith
  -- the general bound, by scaling
  intro w hw
  by_cases hz : ∃ v, w v = 0
  · exact hred w hw hz
  push Not at hz
  set t := ∑ v, w v with ht_def
  have ht : 0 < t := by
    have : (Finset.univ : Finset (Fin n)).Nonempty := ⟨⟨0, by omega⟩, Finset.mem_univ _⟩
    exact Finset.sum_pos (fun v _ => lt_of_le_of_ne (hw v) (hz v).symm) this
  have hw1 : t⁻¹ • w ∈ simplex n := by
    refine ⟨fun v => ?_, ?_⟩
    · simp only [Pi.smul_apply, smul_eq_mul]
      exact mul_nonneg (inv_nonneg.mpr ht.le) (hw v)
    · simp only [Pi.smul_apply, smul_eq_mul]
      rw [← Finset.mul_sum, ← ht_def, inv_mul_cancel₀ ht.ne']
  have := hsimp _ hw1
  rw [lagr_smul hH] at this
  have ht3 : 0 < t ^ 3 := pow_pos ht 3
  rw [inv_pow] at this
  have := mul_le_mul_of_nonneg_left this ht3.le
  rw [← mul_assoc, mul_inv_cancel₀ ht3.ne', one_mul] at this
  linarith

/-- **The reduction**: M4 bounds every `C₅³`-free 3-graph by `α n³ / 6`. -/
theorem m4_implies_bound (h : M4Statement) (n : ℕ) (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) :
    (H.card : ℝ) ≤ (2 * Real.sqrt 3 - 3) * (n : ℝ) ^ 3 / 6 := by
  have := lagrBound_of_m4 h n H hH hC (fun _ => 1) (fun _ => zero_le_one)
  have hl : lagr H (fun _ => (1 : ℝ)) = H.card := by
    simp [lagr]
  rw [hl] at this
  simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, mul_one]
    at this
  unfold turanL at this
  linarith

end TightCycleC5
