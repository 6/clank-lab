import P33PSDData

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33PSD

theorem terms1_psd : ∀ k, (intMatrixReal (terms1 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector1x0
  · exact int_outer_posSemidef vector1x1
  · exact int_outer_posSemidef vector1x2
  · exact int_outer_posSemidef vector1x3
  · exact int_outer_posSemidef vector1x4
  · exact int_outer_posSemidef vector1x5
  · exact int_outer_posSemidef vector1x6
  · exact int_outer_posSemidef vector1x7
  · exact int_outer_posSemidef vector1x8
  · exact int_outer_posSemidef vector1x9
  · exact int_outer_posSemidef vector1x10
  · exact int_outer_posSemidef vector1x11
  · exact int_outer_posSemidef vector1x12
  · exact int_outer_posSemidef vector1x13
theorem terms1_diagonal : ∀ k i, terms1 k i i ≤ (diagBounds1 k : ℤ) := by
  decide +kernel
theorem psd1 : (intMatrixReal q1).PosSemidef :=
  integer_sos_posSemidef weights1 terms1 terms1_psd
theorem diagonal1 : ∀ i, q1 i i ≤ (m1 : ℤ) :=
  integer_sos_diagonal weights1 diagBounds1 terms1 terms1_diagonal
theorem normalized_psd1 : matrix1.PosSemidef :=
  scale_int_posSemidef q1 scale psd1
theorem normalized_diagonal1 : ∀ i, matrix1 i i ≤ bound1 :=
  scale_int_diagonal q1 scale m1 diagonal1
theorem normalized_nonneg1 : 0 ≤ bound1 :=
  scale_int_bound_nonneg scale m1 (Nat.cast_nonneg _)

#print axioms psd1
#print axioms diagonal1
#print axioms normalized_psd1
#print axioms normalized_diagonal1
#print axioms normalized_nonneg1
#print axioms terms1_psd
#print axioms terms1_diagonal

theorem terms7_psd : ∀ k, (intMatrixReal (terms7 k)).PosSemidef := by
  intro k
  fin_cases k
theorem terms7_diagonal : ∀ k i, terms7 k i i ≤ (diagBounds7 k : ℤ) := by
  decide +kernel
theorem psd7 : (intMatrixReal q7).PosSemidef :=
  integer_sos_posSemidef weights7 terms7 terms7_psd
theorem diagonal7 : ∀ i, q7 i i ≤ (m7 : ℤ) :=
  integer_sos_diagonal weights7 diagBounds7 terms7 terms7_diagonal
theorem normalized_psd7 : matrix7.PosSemidef :=
  scale_int_posSemidef q7 scale psd7
theorem normalized_diagonal7 : ∀ i, matrix7 i i ≤ bound7 :=
  scale_int_diagonal q7 scale m7 diagonal7
theorem normalized_nonneg7 : 0 ≤ bound7 :=
  scale_int_bound_nonneg scale m7 (Nat.cast_nonneg _)

#print axioms psd7
#print axioms diagonal7
#print axioms normalized_psd7
#print axioms normalized_diagonal7
#print axioms normalized_nonneg7
#print axioms terms7_psd
#print axioms terms7_diagonal

theorem terms13_psd : ∀ k, (intMatrixReal (terms13 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector13x0
  · exact int_outer_posSemidef vector13x1
  · exact int_outer_posSemidef vector13x2
  · exact int_outer_posSemidef vector13x3
  · exact int_outer_posSemidef vector13x4
  · exact int_outer_posSemidef vector13x5
  · exact int_outer_posSemidef vector13x6
  · exact int_outer_posSemidef vector13x7
  · exact int_outer_posSemidef vector13x8
  · exact int_outer_posSemidef vector13x9
  · exact int_outer_posSemidef vector13x10
  · exact int_outer_posSemidef vector13x11
  · exact int_outer_posSemidef vector13x12
theorem terms13_diagonal : ∀ k i, terms13 k i i ≤ (diagBounds13 k : ℤ) := by
  decide +kernel
theorem psd13 : (intMatrixReal q13).PosSemidef :=
  integer_sos_posSemidef weights13 terms13 terms13_psd
theorem diagonal13 : ∀ i, q13 i i ≤ (m13 : ℤ) :=
  integer_sos_diagonal weights13 diagBounds13 terms13 terms13_diagonal
theorem normalized_psd13 : matrix13.PosSemidef :=
  scale_int_posSemidef q13 scale psd13
theorem normalized_diagonal13 : ∀ i, matrix13 i i ≤ bound13 :=
  scale_int_diagonal q13 scale m13 diagonal13
theorem normalized_nonneg13 : 0 ≤ bound13 :=
  scale_int_bound_nonneg scale m13 (Nat.cast_nonneg _)

#print axioms psd13
#print axioms diagonal13
#print axioms normalized_psd13
#print axioms normalized_diagonal13
#print axioms normalized_nonneg13
#print axioms terms13_psd
#print axioms terms13_diagonal

theorem terms19_psd : ∀ k, (intMatrixReal (terms19 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector19x0
  · exact int_outer_posSemidef vector19x1
  · exact int_outer_posSemidef vector19x2
  · exact int_outer_posSemidef vector19x3
  · exact int_outer_posSemidef vector19x4
  · exact int_outer_posSemidef vector19x5
  · exact int_outer_posSemidef vector19x6
  · exact int_outer_posSemidef vector19x7
  · exact int_outer_posSemidef vector19x8
  · exact int_outer_posSemidef vector19x9
  · exact int_outer_posSemidef vector19x10
  · exact int_outer_posSemidef vector19x11
  · exact int_outer_posSemidef vector19x12
  · exact int_outer_posSemidef vector19x13
theorem terms19_diagonal : ∀ k i, terms19 k i i ≤ (diagBounds19 k : ℤ) := by
  decide +kernel
theorem psd19 : (intMatrixReal q19).PosSemidef :=
  integer_sos_posSemidef weights19 terms19 terms19_psd
theorem diagonal19 : ∀ i, q19 i i ≤ (m19 : ℤ) :=
  integer_sos_diagonal weights19 diagBounds19 terms19 terms19_diagonal
theorem normalized_psd19 : matrix19.PosSemidef :=
  scale_int_posSemidef q19 scale psd19
theorem normalized_diagonal19 : ∀ i, matrix19 i i ≤ bound19 :=
  scale_int_diagonal q19 scale m19 diagonal19
theorem normalized_nonneg19 : 0 ≤ bound19 :=
  scale_int_bound_nonneg scale m19 (Nat.cast_nonneg _)

#print axioms psd19
#print axioms diagonal19
#print axioms normalized_psd19
#print axioms normalized_diagonal19
#print axioms normalized_nonneg19
#print axioms terms19_psd
#print axioms terms19_diagonal

theorem terms25_psd : ∀ k, (intMatrixReal (terms25 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector25x0
  · exact int_outer_posSemidef vector25x1
  · exact int_outer_posSemidef vector25x2
  · exact int_outer_posSemidef vector25x3
  · exact int_outer_posSemidef vector25x4
  · exact int_outer_posSemidef vector25x5
  · exact int_outer_posSemidef vector25x6
  · exact int_outer_posSemidef vector25x7
  · exact int_outer_posSemidef vector25x8
theorem terms25_diagonal : ∀ k i, terms25 k i i ≤ (diagBounds25 k : ℤ) := by
  decide +kernel
theorem psd25 : (intMatrixReal q25).PosSemidef :=
  integer_sos_posSemidef weights25 terms25 terms25_psd
theorem diagonal25 : ∀ i, q25 i i ≤ (m25 : ℤ) :=
  integer_sos_diagonal weights25 diagBounds25 terms25 terms25_diagonal
theorem normalized_psd25 : matrix25.PosSemidef :=
  scale_int_posSemidef q25 scale psd25
theorem normalized_diagonal25 : ∀ i, matrix25 i i ≤ bound25 :=
  scale_int_diagonal q25 scale m25 diagonal25
theorem normalized_nonneg25 : 0 ≤ bound25 :=
  scale_int_bound_nonneg scale m25 (Nat.cast_nonneg _)

#print axioms psd25
#print axioms diagonal25
#print axioms normalized_psd25
#print axioms normalized_diagonal25
#print axioms normalized_nonneg25
#print axioms terms25_psd
#print axioms terms25_diagonal

theorem terms31_psd : ∀ k, (intMatrixReal (terms31 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector31x0
  · exact int_outer_posSemidef vector31x1
  · exact int_outer_posSemidef vector31x2
  · exact int_outer_posSemidef vector31x3
  · exact int_outer_posSemidef vector31x4
  · exact int_outer_posSemidef vector31x5
theorem terms31_diagonal : ∀ k i, terms31 k i i ≤ (diagBounds31 k : ℤ) := by
  decide +kernel
theorem psd31 : (intMatrixReal q31).PosSemidef :=
  integer_sos_posSemidef weights31 terms31 terms31_psd
theorem diagonal31 : ∀ i, q31 i i ≤ (m31 : ℤ) :=
  integer_sos_diagonal weights31 diagBounds31 terms31 terms31_diagonal
theorem normalized_psd31 : matrix31.PosSemidef :=
  scale_int_posSemidef q31 scale psd31
theorem normalized_diagonal31 : ∀ i, matrix31 i i ≤ bound31 :=
  scale_int_diagonal q31 scale m31 diagonal31
theorem normalized_nonneg31 : 0 ≤ bound31 :=
  scale_int_bound_nonneg scale m31 (Nat.cast_nonneg _)

#print axioms psd31
#print axioms diagonal31
#print axioms normalized_psd31
#print axioms normalized_diagonal31
#print axioms normalized_nonneg31
#print axioms terms31_psd
#print axioms terms31_diagonal

theorem terms37_psd : ∀ k, (intMatrixReal (terms37 k)).PosSemidef := by
  intro k
  fin_cases k
theorem terms37_diagonal : ∀ k i, terms37 k i i ≤ (diagBounds37 k : ℤ) := by
  decide +kernel
theorem psd37 : (intMatrixReal q37).PosSemidef :=
  integer_sos_posSemidef weights37 terms37 terms37_psd
theorem diagonal37 : ∀ i, q37 i i ≤ (m37 : ℤ) :=
  integer_sos_diagonal weights37 diagBounds37 terms37 terms37_diagonal
theorem normalized_psd37 : matrix37.PosSemidef :=
  scale_int_posSemidef q37 scale psd37
theorem normalized_diagonal37 : ∀ i, matrix37 i i ≤ bound37 :=
  scale_int_diagonal q37 scale m37 diagonal37
theorem normalized_nonneg37 : 0 ≤ bound37 :=
  scale_int_bound_nonneg scale m37 (Nat.cast_nonneg _)

#print axioms psd37
#print axioms diagonal37
#print axioms normalized_psd37
#print axioms normalized_diagonal37
#print axioms normalized_nonneg37
#print axioms terms37_psd
#print axioms terms37_diagonal

end TightCycleC5.Bridge.P33PSD
