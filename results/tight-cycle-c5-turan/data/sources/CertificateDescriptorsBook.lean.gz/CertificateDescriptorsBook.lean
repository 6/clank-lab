import CertificateDescriptorsCL
import PairBookCertificate

/-! The exact 16 x 529 P32 indicator-book descriptors and multiplier slice. -/
namespace TightCycleC5.Bridge.CertificateDescriptors
open Finset

def bookRoot (i : Fin 8464) : Fin 16 := ⟨i.val / 529, by omega⟩
def bookRestriction (i : Fin 8464) : Fin 529 := ⟨i.val % 529, Nat.mod_lt _ (by decide)⟩
def bookFlatIndex (k : Fin 16) (r : Fin 529) : Fin 8464 :=
  ⟨529 * k.val + r.val, by omega⟩
def bookMaskBits (r : Fin 529) : BitVec 32 := BitVec.ofNat 32 (bookMask r)

theorem book_flat_root (k : Fin 16) (r : Fin 529) : bookRoot (bookFlatIndex k r) = k := by
  apply Fin.ext
  simp only [bookRoot, bookFlatIndex]
  omega

theorem book_flat_restriction (k : Fin 16) (r : Fin 529) :
    bookRestriction (bookFlatIndex k r) = r := by
  apply Fin.ext
  simp only [bookRestriction, bookFlatIndex]
  omega

theorem book_mask_exact (r : Fin 529) : (bookMaskBits r).toNat = bookMask r := by
  exact Nat.mod_eq_of_lt (book_masks_weights_checked r).1

def p32BookDescriptor (i : Fin 8464) : PairBookCertificate.Descriptor :=
  PairBookCertificate.indicatorDescriptor (bookRoot i) (bookMaskBits (bookRestriction i))

/-- The descriptor uses exactly the quoted, kernel-checked Int indicators. -/
theorem p32_book_weight_quote (i : Fin 8464) (p : Fin 32) :
    (p32BookDescriptor i).weight p = (bookIndicator (bookRestriction i) p : ℝ) := by
  simp only [p32BookDescriptor, PairBookCertificate.indicatorDescriptor,
    bookIndicator, bookMaskBits]
  split_ifs <;> norm_num

theorem p32_book_weight_zero_one (i : Fin 8464) (p : Fin 32) :
    (p32BookDescriptor i).weight p = 0 ∨ (p32BookDescriptor i).weight p = 1 := by
  rw [p32_book_weight_quote]
  rcases (book_masks_weights_checked (bookRestriction i)).2 p with h | h <;> simp [h]

def p32BookSourceIndex (i : Fin 8464) : Fin 9511 := ⟨1020 + i.val, by omega⟩

theorem p32_book_source_index (i : Fin 8464) :
    (p32BookSourceIndex i).val = 1020 + 529 * (bookRoot i).val + (bookRestriction i).val := by
  simp only [p32BookSourceIndex, bookRoot, bookRestriction]
  omega

theorem p32_book_source_pair (k : Fin 16) (r : Fin 529) :
    (p32BookSourceIndex (bookFlatIndex k r)).val = 1020 + 529 * k.val + r.val := by
  simp only [p32BookSourceIndex, bookFlatIndex]
  omega

noncomputable def p32BookWeight (i : Fin 8464) : ℝ := p32Weight (p32BookSourceIndex i)
noncomputable def p32BookMass : ℝ := ∑ i : Fin 8464, p32BookWeight i

theorem p32_book_weight_nonneg (i : Fin 8464) : 0 ≤ p32BookWeight i := p32_weight_nonneg _
theorem p32_book_mass_nonneg : 0 ≤ p32BookMass :=
  Finset.sum_nonneg (fun i _ => p32_book_weight_nonneg i)

theorem p32_book_row_mean_lower {n : Nat} (i : Fin 8464) (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (hn : 12 ≤ n) (S : Finset (Fin n)) :
    -(1 / ((n : ℝ) - 5)) ≤ uniformMean (fun σ : Fin 6 ↪ Fin n =>
      PairBookCertificate.row (p32BookDescriptor i) (sampleStructure σ H S)) :=
  PairBookCertificate.indicator_row_mean_lower (bookRoot i) (bookMaskBits (bookRestriction i))
    H hH hC hn S

/-- Exact source coefficients preserve the sum-mass lower bound for all 8464 rows. -/
theorem p32_book_mean_lower {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (hn : 12 ≤ n) (S : Finset (Fin n)) :
    -p32BookMass / ((n : ℝ) - 5) ≤ uniformMean (fun σ : Fin 6 ↪ Fin n =>
      ∑ i : Fin 8464, p32BookWeight i * PairBookCertificate.row
        (p32BookDescriptor i) (sampleStructure σ H S)) := by
  have he : uniformMean (fun σ : Fin 6 ↪ Fin n => ∑ i : Fin 8464,
      p32BookWeight i * PairBookCertificate.row (p32BookDescriptor i) (sampleStructure σ H S)) =
      ∑ i : Fin 8464, p32BookWeight i * uniformMean (fun σ : Fin 6 ↪ Fin n =>
        PairBookCertificate.row (p32BookDescriptor i) (sampleStructure σ H S)) := by
    unfold uniformMean
    rw [Finset.sum_comm, Finset.sum_div]
    apply Finset.sum_congr rfl
    intro i _
    rw [← Finset.mul_sum]
    ring
  rw [he]
  change -(∑ i : Fin 8464, p32BookWeight i) / ((n : ℝ) - 5) ≤ _
  calc
    _ = ∑ i : Fin 8464, p32BookWeight i * (-(1 / ((n : ℝ) - 5))) := by
      rw [← Finset.sum_mul]
      ring
    _ ≤ _ := Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_left
      (p32_book_row_mean_lower i H hH hC hn S) (p32_book_weight_nonneg i))

#print axioms book_flat_root
#print axioms book_flat_restriction
#print axioms book_mask_exact
#print axioms p32_book_weight_quote
#print axioms p32_book_weight_zero_one
#print axioms p32_book_source_index
#print axioms p32_book_source_pair
#print axioms p32_book_weight_nonneg
#print axioms p32_book_mass_nonneg
#print axioms p32_book_row_mean_lower
#print axioms p32_book_mean_lower
end TightCycleC5.Bridge.CertificateDescriptors
