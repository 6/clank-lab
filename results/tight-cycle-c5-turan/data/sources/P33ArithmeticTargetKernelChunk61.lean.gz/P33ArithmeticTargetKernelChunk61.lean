-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk244 :
    ∀ i : Fin (min 128 (40547 - 128 * 244)),
      targetCountsMatch (classAt (targetKernelClass ⟨244, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk244

theorem target_counts_kernel_chunk245 :
    ∀ i : Fin (min 128 (40547 - 128 * 245)),
      targetCountsMatch (classAt (targetKernelClass ⟨245, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk245

theorem target_counts_kernel_chunk246 :
    ∀ i : Fin (min 128 (40547 - 128 * 246)),
      targetCountsMatch (classAt (targetKernelClass ⟨246, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk246

theorem target_counts_kernel_chunk247 :
    ∀ i : Fin (min 128 (40547 - 128 * 247)),
      targetCountsMatch (classAt (targetKernelClass ⟨247, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk247


end TightCycleC5.Bridge.P33Arithmetic
