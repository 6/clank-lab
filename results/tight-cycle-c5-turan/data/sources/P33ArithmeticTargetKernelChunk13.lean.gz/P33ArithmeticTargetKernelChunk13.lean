-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk52 :
    ∀ i : Fin (min 128 (40547 - 128 * 52)),
      targetCountsMatch (classAt (targetKernelClass ⟨52, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk52

theorem target_counts_kernel_chunk53 :
    ∀ i : Fin (min 128 (40547 - 128 * 53)),
      targetCountsMatch (classAt (targetKernelClass ⟨53, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk53

theorem target_counts_kernel_chunk54 :
    ∀ i : Fin (min 128 (40547 - 128 * 54)),
      targetCountsMatch (classAt (targetKernelClass ⟨54, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk54

theorem target_counts_kernel_chunk55 :
    ∀ i : Fin (min 128 (40547 - 128 * 55)),
      targetCountsMatch (classAt (targetKernelClass ⟨55, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk55


end TightCycleC5.Bridge.P33Arithmetic
