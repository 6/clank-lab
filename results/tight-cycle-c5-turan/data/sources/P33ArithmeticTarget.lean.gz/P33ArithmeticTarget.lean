import P33ArithmeticTargetKernel

/-! Original target API, now derived from complete kernel checks. -/
namespace TightCycleC5.Bridge.P33Arithmetic
set_option maxRecDepth 100000
set_option maxHeartbeats 0

/-- All genuine finite class targets are checked against the original
count definitions, rather than a quotation of the target column. -/
theorem all_class_target_counts_match : ∀ k : Fin 40547,
    targetNumerator (classAt k) =
      (badCount (classGraph (classAt k)) (classCut (classAt k)) : Int) -
      (missCount (classGraph (classAt k)) (classCut (classAt k)) : Int) := by
  intro k
  exact all_class_target_counts_kernel k

theorem target_normalized (k : Fin 40547) :
    (targetNumerator (classAt k) : ℝ) / 20 = countedTarget (classAt k) := by
  rw [all_class_target_counts_match]
  simp only [Int.cast_sub, Int.cast_natCast, countedTarget]

theorem target_literal (k : Fin 40547) :
    (targetNumerator (classAt k) : ℝ) / 20 = literalTarget (decodedClass (classAt k)) := by
  rw [literalTarget_decoded, target_normalized]


#print axioms all_class_target_counts_match
#print axioms target_normalized
#print axioms target_literal
end TightCycleC5.Bridge.P33Arithmetic
