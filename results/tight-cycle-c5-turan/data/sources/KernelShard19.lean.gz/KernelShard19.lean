import KernelShard19Blocks0
import KernelShard19Blocks1
import KernelShard19Blocks2
import KernelShard19Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard19 : kernelShardCheck 19 kernelWitness19 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (19 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness19 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_19_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard19
end TightCycleC5.Bridge.Cover
