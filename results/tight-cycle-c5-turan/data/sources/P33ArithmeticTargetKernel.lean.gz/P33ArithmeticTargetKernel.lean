import P33ArithmeticTargetKernelChunk0
import P33ArithmeticTargetKernelChunk1
import P33ArithmeticTargetKernelChunk2
import P33ArithmeticTargetKernelChunk3
import P33ArithmeticTargetKernelChunk4
import P33ArithmeticTargetKernelChunk5
import P33ArithmeticTargetKernelChunk6
import P33ArithmeticTargetKernelChunk7
import P33ArithmeticTargetKernelChunk8
import P33ArithmeticTargetKernelChunk9
import P33ArithmeticTargetKernelChunk10
import P33ArithmeticTargetKernelChunk11
import P33ArithmeticTargetKernelChunk12
import P33ArithmeticTargetKernelChunk13
import P33ArithmeticTargetKernelChunk14
import P33ArithmeticTargetKernelChunk15
import P33ArithmeticTargetKernelChunk16
import P33ArithmeticTargetKernelChunk17
import P33ArithmeticTargetKernelChunk18
import P33ArithmeticTargetKernelChunk19
import P33ArithmeticTargetKernelChunk20
import P33ArithmeticTargetKernelChunk21
import P33ArithmeticTargetKernelChunk22
import P33ArithmeticTargetKernelChunk23
import P33ArithmeticTargetKernelChunk24
import P33ArithmeticTargetKernelChunk25
import P33ArithmeticTargetKernelChunk26
import P33ArithmeticTargetKernelChunk27
import P33ArithmeticTargetKernelChunk28
import P33ArithmeticTargetKernelChunk29
import P33ArithmeticTargetKernelChunk30
import P33ArithmeticTargetKernelChunk31
import P33ArithmeticTargetKernelChunk32
import P33ArithmeticTargetKernelChunk33
import P33ArithmeticTargetKernelChunk34
import P33ArithmeticTargetKernelChunk35
import P33ArithmeticTargetKernelChunk36
import P33ArithmeticTargetKernelChunk37
import P33ArithmeticTargetKernelChunk38
import P33ArithmeticTargetKernelChunk39
import P33ArithmeticTargetKernelChunk40
import P33ArithmeticTargetKernelChunk41
import P33ArithmeticTargetKernelChunk42
import P33ArithmeticTargetKernelChunk43
import P33ArithmeticTargetKernelChunk44
import P33ArithmeticTargetKernelChunk45
import P33ArithmeticTargetKernelChunk46
import P33ArithmeticTargetKernelChunk47
import P33ArithmeticTargetKernelChunk48
import P33ArithmeticTargetKernelChunk49
import P33ArithmeticTargetKernelChunk50
import P33ArithmeticTargetKernelChunk51
import P33ArithmeticTargetKernelChunk52
import P33ArithmeticTargetKernelChunk53
import P33ArithmeticTargetKernelChunk54
import P33ArithmeticTargetKernelChunk55
import P33ArithmeticTargetKernelChunk56
import P33ArithmeticTargetKernelChunk57
import P33ArithmeticTargetKernelChunk58
import P33ArithmeticTargetKernelChunk59
import P33ArithmeticTargetKernelChunk60
import P33ArithmeticTargetKernelChunk61
import P33ArithmeticTargetKernelChunk62
import P33ArithmeticTargetKernelChunk63
import P33ArithmeticTargetKernelChunk64
import P33ArithmeticTargetKernelChunk65
import P33ArithmeticTargetKernelChunk66
import P33ArithmeticTargetKernelChunk67
import P33ArithmeticTargetKernelChunk68
import P33ArithmeticTargetKernelChunk69
import P33ArithmeticTargetKernelChunk70
import P33ArithmeticTargetKernelChunk71
import P33ArithmeticTargetKernelChunk72
import P33ArithmeticTargetKernelChunk73
import P33ArithmeticTargetKernelChunk74
import P33ArithmeticTargetKernelChunk75
import P33ArithmeticTargetKernelChunk76
import P33ArithmeticTargetKernelChunk77
import P33ArithmeticTargetKernelChunk78
import P33ArithmeticTargetKernelChunk79

/-! All actual finite classes are covered by the kernel target chunks. -/
namespace TightCycleC5.Bridge.P33Arithmetic
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem all_target_counts_kernel_chunks (b : Fin 317) :
    ∀ i : Fin (min 128 (40547 - 128 * b.val)),
      targetCountsMatch (classAt (targetKernelClass b i)) := by
  fin_cases b
  · exact target_counts_kernel_chunk0
  · exact target_counts_kernel_chunk1
  · exact target_counts_kernel_chunk2
  · exact target_counts_kernel_chunk3
  · exact target_counts_kernel_chunk4
  · exact target_counts_kernel_chunk5
  · exact target_counts_kernel_chunk6
  · exact target_counts_kernel_chunk7
  · exact target_counts_kernel_chunk8
  · exact target_counts_kernel_chunk9
  · exact target_counts_kernel_chunk10
  · exact target_counts_kernel_chunk11
  · exact target_counts_kernel_chunk12
  · exact target_counts_kernel_chunk13
  · exact target_counts_kernel_chunk14
  · exact target_counts_kernel_chunk15
  · exact target_counts_kernel_chunk16
  · exact target_counts_kernel_chunk17
  · exact target_counts_kernel_chunk18
  · exact target_counts_kernel_chunk19
  · exact target_counts_kernel_chunk20
  · exact target_counts_kernel_chunk21
  · exact target_counts_kernel_chunk22
  · exact target_counts_kernel_chunk23
  · exact target_counts_kernel_chunk24
  · exact target_counts_kernel_chunk25
  · exact target_counts_kernel_chunk26
  · exact target_counts_kernel_chunk27
  · exact target_counts_kernel_chunk28
  · exact target_counts_kernel_chunk29
  · exact target_counts_kernel_chunk30
  · exact target_counts_kernel_chunk31
  · exact target_counts_kernel_chunk32
  · exact target_counts_kernel_chunk33
  · exact target_counts_kernel_chunk34
  · exact target_counts_kernel_chunk35
  · exact target_counts_kernel_chunk36
  · exact target_counts_kernel_chunk37
  · exact target_counts_kernel_chunk38
  · exact target_counts_kernel_chunk39
  · exact target_counts_kernel_chunk40
  · exact target_counts_kernel_chunk41
  · exact target_counts_kernel_chunk42
  · exact target_counts_kernel_chunk43
  · exact target_counts_kernel_chunk44
  · exact target_counts_kernel_chunk45
  · exact target_counts_kernel_chunk46
  · exact target_counts_kernel_chunk47
  · exact target_counts_kernel_chunk48
  · exact target_counts_kernel_chunk49
  · exact target_counts_kernel_chunk50
  · exact target_counts_kernel_chunk51
  · exact target_counts_kernel_chunk52
  · exact target_counts_kernel_chunk53
  · exact target_counts_kernel_chunk54
  · exact target_counts_kernel_chunk55
  · exact target_counts_kernel_chunk56
  · exact target_counts_kernel_chunk57
  · exact target_counts_kernel_chunk58
  · exact target_counts_kernel_chunk59
  · exact target_counts_kernel_chunk60
  · exact target_counts_kernel_chunk61
  · exact target_counts_kernel_chunk62
  · exact target_counts_kernel_chunk63
  · exact target_counts_kernel_chunk64
  · exact target_counts_kernel_chunk65
  · exact target_counts_kernel_chunk66
  · exact target_counts_kernel_chunk67
  · exact target_counts_kernel_chunk68
  · exact target_counts_kernel_chunk69
  · exact target_counts_kernel_chunk70
  · exact target_counts_kernel_chunk71
  · exact target_counts_kernel_chunk72
  · exact target_counts_kernel_chunk73
  · exact target_counts_kernel_chunk74
  · exact target_counts_kernel_chunk75
  · exact target_counts_kernel_chunk76
  · exact target_counts_kernel_chunk77
  · exact target_counts_kernel_chunk78
  · exact target_counts_kernel_chunk79
  · exact target_counts_kernel_chunk80
  · exact target_counts_kernel_chunk81
  · exact target_counts_kernel_chunk82
  · exact target_counts_kernel_chunk83
  · exact target_counts_kernel_chunk84
  · exact target_counts_kernel_chunk85
  · exact target_counts_kernel_chunk86
  · exact target_counts_kernel_chunk87
  · exact target_counts_kernel_chunk88
  · exact target_counts_kernel_chunk89
  · exact target_counts_kernel_chunk90
  · exact target_counts_kernel_chunk91
  · exact target_counts_kernel_chunk92
  · exact target_counts_kernel_chunk93
  · exact target_counts_kernel_chunk94
  · exact target_counts_kernel_chunk95
  · exact target_counts_kernel_chunk96
  · exact target_counts_kernel_chunk97
  · exact target_counts_kernel_chunk98
  · exact target_counts_kernel_chunk99
  · exact target_counts_kernel_chunk100
  · exact target_counts_kernel_chunk101
  · exact target_counts_kernel_chunk102
  · exact target_counts_kernel_chunk103
  · exact target_counts_kernel_chunk104
  · exact target_counts_kernel_chunk105
  · exact target_counts_kernel_chunk106
  · exact target_counts_kernel_chunk107
  · exact target_counts_kernel_chunk108
  · exact target_counts_kernel_chunk109
  · exact target_counts_kernel_chunk110
  · exact target_counts_kernel_chunk111
  · exact target_counts_kernel_chunk112
  · exact target_counts_kernel_chunk113
  · exact target_counts_kernel_chunk114
  · exact target_counts_kernel_chunk115
  · exact target_counts_kernel_chunk116
  · exact target_counts_kernel_chunk117
  · exact target_counts_kernel_chunk118
  · exact target_counts_kernel_chunk119
  · exact target_counts_kernel_chunk120
  · exact target_counts_kernel_chunk121
  · exact target_counts_kernel_chunk122
  · exact target_counts_kernel_chunk123
  · exact target_counts_kernel_chunk124
  · exact target_counts_kernel_chunk125
  · exact target_counts_kernel_chunk126
  · exact target_counts_kernel_chunk127
  · exact target_counts_kernel_chunk128
  · exact target_counts_kernel_chunk129
  · exact target_counts_kernel_chunk130
  · exact target_counts_kernel_chunk131
  · exact target_counts_kernel_chunk132
  · exact target_counts_kernel_chunk133
  · exact target_counts_kernel_chunk134
  · exact target_counts_kernel_chunk135
  · exact target_counts_kernel_chunk136
  · exact target_counts_kernel_chunk137
  · exact target_counts_kernel_chunk138
  · exact target_counts_kernel_chunk139
  · exact target_counts_kernel_chunk140
  · exact target_counts_kernel_chunk141
  · exact target_counts_kernel_chunk142
  · exact target_counts_kernel_chunk143
  · exact target_counts_kernel_chunk144
  · exact target_counts_kernel_chunk145
  · exact target_counts_kernel_chunk146
  · exact target_counts_kernel_chunk147
  · exact target_counts_kernel_chunk148
  · exact target_counts_kernel_chunk149
  · exact target_counts_kernel_chunk150
  · exact target_counts_kernel_chunk151
  · exact target_counts_kernel_chunk152
  · exact target_counts_kernel_chunk153
  · exact target_counts_kernel_chunk154
  · exact target_counts_kernel_chunk155
  · exact target_counts_kernel_chunk156
  · exact target_counts_kernel_chunk157
  · exact target_counts_kernel_chunk158
  · exact target_counts_kernel_chunk159
  · exact target_counts_kernel_chunk160
  · exact target_counts_kernel_chunk161
  · exact target_counts_kernel_chunk162
  · exact target_counts_kernel_chunk163
  · exact target_counts_kernel_chunk164
  · exact target_counts_kernel_chunk165
  · exact target_counts_kernel_chunk166
  · exact target_counts_kernel_chunk167
  · exact target_counts_kernel_chunk168
  · exact target_counts_kernel_chunk169
  · exact target_counts_kernel_chunk170
  · exact target_counts_kernel_chunk171
  · exact target_counts_kernel_chunk172
  · exact target_counts_kernel_chunk173
  · exact target_counts_kernel_chunk174
  · exact target_counts_kernel_chunk175
  · exact target_counts_kernel_chunk176
  · exact target_counts_kernel_chunk177
  · exact target_counts_kernel_chunk178
  · exact target_counts_kernel_chunk179
  · exact target_counts_kernel_chunk180
  · exact target_counts_kernel_chunk181
  · exact target_counts_kernel_chunk182
  · exact target_counts_kernel_chunk183
  · exact target_counts_kernel_chunk184
  · exact target_counts_kernel_chunk185
  · exact target_counts_kernel_chunk186
  · exact target_counts_kernel_chunk187
  · exact target_counts_kernel_chunk188
  · exact target_counts_kernel_chunk189
  · exact target_counts_kernel_chunk190
  · exact target_counts_kernel_chunk191
  · exact target_counts_kernel_chunk192
  · exact target_counts_kernel_chunk193
  · exact target_counts_kernel_chunk194
  · exact target_counts_kernel_chunk195
  · exact target_counts_kernel_chunk196
  · exact target_counts_kernel_chunk197
  · exact target_counts_kernel_chunk198
  · exact target_counts_kernel_chunk199
  · exact target_counts_kernel_chunk200
  · exact target_counts_kernel_chunk201
  · exact target_counts_kernel_chunk202
  · exact target_counts_kernel_chunk203
  · exact target_counts_kernel_chunk204
  · exact target_counts_kernel_chunk205
  · exact target_counts_kernel_chunk206
  · exact target_counts_kernel_chunk207
  · exact target_counts_kernel_chunk208
  · exact target_counts_kernel_chunk209
  · exact target_counts_kernel_chunk210
  · exact target_counts_kernel_chunk211
  · exact target_counts_kernel_chunk212
  · exact target_counts_kernel_chunk213
  · exact target_counts_kernel_chunk214
  · exact target_counts_kernel_chunk215
  · exact target_counts_kernel_chunk216
  · exact target_counts_kernel_chunk217
  · exact target_counts_kernel_chunk218
  · exact target_counts_kernel_chunk219
  · exact target_counts_kernel_chunk220
  · exact target_counts_kernel_chunk221
  · exact target_counts_kernel_chunk222
  · exact target_counts_kernel_chunk223
  · exact target_counts_kernel_chunk224
  · exact target_counts_kernel_chunk225
  · exact target_counts_kernel_chunk226
  · exact target_counts_kernel_chunk227
  · exact target_counts_kernel_chunk228
  · exact target_counts_kernel_chunk229
  · exact target_counts_kernel_chunk230
  · exact target_counts_kernel_chunk231
  · exact target_counts_kernel_chunk232
  · exact target_counts_kernel_chunk233
  · exact target_counts_kernel_chunk234
  · exact target_counts_kernel_chunk235
  · exact target_counts_kernel_chunk236
  · exact target_counts_kernel_chunk237
  · exact target_counts_kernel_chunk238
  · exact target_counts_kernel_chunk239
  · exact target_counts_kernel_chunk240
  · exact target_counts_kernel_chunk241
  · exact target_counts_kernel_chunk242
  · exact target_counts_kernel_chunk243
  · exact target_counts_kernel_chunk244
  · exact target_counts_kernel_chunk245
  · exact target_counts_kernel_chunk246
  · exact target_counts_kernel_chunk247
  · exact target_counts_kernel_chunk248
  · exact target_counts_kernel_chunk249
  · exact target_counts_kernel_chunk250
  · exact target_counts_kernel_chunk251
  · exact target_counts_kernel_chunk252
  · exact target_counts_kernel_chunk253
  · exact target_counts_kernel_chunk254
  · exact target_counts_kernel_chunk255
  · exact target_counts_kernel_chunk256
  · exact target_counts_kernel_chunk257
  · exact target_counts_kernel_chunk258
  · exact target_counts_kernel_chunk259
  · exact target_counts_kernel_chunk260
  · exact target_counts_kernel_chunk261
  · exact target_counts_kernel_chunk262
  · exact target_counts_kernel_chunk263
  · exact target_counts_kernel_chunk264
  · exact target_counts_kernel_chunk265
  · exact target_counts_kernel_chunk266
  · exact target_counts_kernel_chunk267
  · exact target_counts_kernel_chunk268
  · exact target_counts_kernel_chunk269
  · exact target_counts_kernel_chunk270
  · exact target_counts_kernel_chunk271
  · exact target_counts_kernel_chunk272
  · exact target_counts_kernel_chunk273
  · exact target_counts_kernel_chunk274
  · exact target_counts_kernel_chunk275
  · exact target_counts_kernel_chunk276
  · exact target_counts_kernel_chunk277
  · exact target_counts_kernel_chunk278
  · exact target_counts_kernel_chunk279
  · exact target_counts_kernel_chunk280
  · exact target_counts_kernel_chunk281
  · exact target_counts_kernel_chunk282
  · exact target_counts_kernel_chunk283
  · exact target_counts_kernel_chunk284
  · exact target_counts_kernel_chunk285
  · exact target_counts_kernel_chunk286
  · exact target_counts_kernel_chunk287
  · exact target_counts_kernel_chunk288
  · exact target_counts_kernel_chunk289
  · exact target_counts_kernel_chunk290
  · exact target_counts_kernel_chunk291
  · exact target_counts_kernel_chunk292
  · exact target_counts_kernel_chunk293
  · exact target_counts_kernel_chunk294
  · exact target_counts_kernel_chunk295
  · exact target_counts_kernel_chunk296
  · exact target_counts_kernel_chunk297
  · exact target_counts_kernel_chunk298
  · exact target_counts_kernel_chunk299
  · exact target_counts_kernel_chunk300
  · exact target_counts_kernel_chunk301
  · exact target_counts_kernel_chunk302
  · exact target_counts_kernel_chunk303
  · exact target_counts_kernel_chunk304
  · exact target_counts_kernel_chunk305
  · exact target_counts_kernel_chunk306
  · exact target_counts_kernel_chunk307
  · exact target_counts_kernel_chunk308
  · exact target_counts_kernel_chunk309
  · exact target_counts_kernel_chunk310
  · exact target_counts_kernel_chunk311
  · exact target_counts_kernel_chunk312
  · exact target_counts_kernel_chunk313
  · exact target_counts_kernel_chunk314
  · exact target_counts_kernel_chunk315
  · exact target_counts_kernel_chunk316

theorem all_class_target_counts_kernel (k : Fin 40547) : targetCountsMatch (classAt k) := by
  have hb : k.val / 128 < 317 := by omega
  let b : Fin 317 := ⟨k.val / 128, hb⟩
  have hi : k.val % 128 < min 128 (40547 - 128 * b.val) := by
    dsimp [b]
    omega
  let i : Fin (min 128 (40547 - 128 * b.val)) := ⟨k.val % 128, hi⟩
  have hk : targetKernelClass b i = k := by
    apply Fin.ext
    dsimp [targetKernelClass, b, i]
    omega
  rw [← hk]
  exact all_target_counts_kernel_chunks b i

#print axioms all_target_counts_kernel_chunks
#print axioms all_class_target_counts_kernel
end TightCycleC5.Bridge.P33Arithmetic
