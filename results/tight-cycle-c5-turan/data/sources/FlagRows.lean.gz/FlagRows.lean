import FlagPSD
import PSDRows

/-! The original six-injection bounds now permit missing (zero) flags. -/
namespace TightCycleC5.Bridge
open Finset Matrix
variable {n : ℕ} {I : Type*} [Fintype I] [DecidableEq I]

theorem flag_optional_four_root_six_row_lower {Q : Matrix I I ℝ}
    (hQ : Q.PosSemidef) {m : ℝ} (hm : 0 ≤ m) (hdiag : ∀ i, Q i i ≤ m)
    (hn : 12 ≤ n)
    (flag : (root : Fin 4 ↪ Fin n) → Outside root → Option I)
    (g : (Fin 4 ↪ Fin n) → ℝ) (hg : ∀ root, g root = 0 ∨ g root = 1) :
    -m / ((n : ℝ) - 5) ≤
      uniformMean (psdFourRootSixRow (zeroExtend Q) flag g) := by
  exact psd_four_root_six_row_lower (zeroExtend_posSemidef hQ) hm
    (zeroExtend_diagonal_le Q hm hdiag) hn flag g hg

theorem flag_optional_two_root_six_row_lower {Q : Matrix I I ℝ}
    (hQ : Q.PosSemidef) {m : ℝ} (hm : 0 ≤ m) (hdiag : ∀ i, Q i i ≤ m)
    (hn : 12 ≤ n)
    (flag : (root : Fin 2 ↪ Fin n) → Outside root × Outside root → Option I)
    (g : (Fin 2 ↪ Fin n) → ℝ) (hg : ∀ root, g root = 0 ∨ g root = 1) :
    -((4 * (n : ℝ) - 14) * m / (((n : ℝ) - 4) * ((n : ℝ) - 5))) ≤
      uniformMean (psdTwoRootSixRow (zeroExtend Q) flag g) := by
  exact psd_two_root_six_row_lower (zeroExtend_posSemidef hQ) hm
    (zeroExtend_diagonal_le Q hm hdiag) hn flag g hg

/-- Literal four-root indicator-vector row, with keys allowed outside the basis. -/
noncomputable def flagIndicatorFourRootSixRow {k : ℕ}
    (Q : Matrix (Fin k) (Fin k) ℝ) (code : Fin k → ℕ)
    (key : (root : Fin 4 ↪ Fin n) → Outside root → ℕ)
    (g : (Fin 4 ↪ Fin n) → ℝ) (σ : Fin 6 ↪ Fin n) : ℝ :=
  let rf := splitSampleEquiv (r := 4) (f := 2) σ
  g rf.1 * (∑ i, ∑ j, Q i j *
    (if key rf.1 (rf.2 0) = code i then 1 else 0) *
    (if key rf.1 (rf.2 1) = code j then 1 else 0))

/-- Literal two-root indicator-vector row on ordered free pairs. -/
noncomputable def flagIndicatorTwoRootSixRow {k : ℕ}
    (Q : Matrix (Fin k) (Fin k) ℝ) (code : Fin k → ℕ)
    (key : (root : Fin 2 ↪ Fin n) → Outside root × Outside root → ℕ)
    (g : (Fin 2 ↪ Fin n) → ℝ) (σ : Fin 6 ↪ Fin n) : ℝ :=
  let rf := splitSampleEquiv (r := 2) (f := 4) σ
  g rf.1 * (∑ i, ∑ j, Q i j *
    (if key rf.1 (rf.2 0, rf.2 1) = code i then 1 else 0) *
    (if key rf.1 (rf.2 2, rf.2 3) = code j then 1 else 0))

theorem flag_indicator_four_root_row_eq {k : ℕ}
    (Q : Matrix (Fin k) (Fin k) ℝ) (code : Fin k → ℕ)
    (hinj : Function.Injective code)
    (key : (root : Fin 4 ↪ Fin n) → Outside root → ℕ)
    (g : (Fin 4 ↪ Fin n) → ℝ) :
    flagIndicatorFourRootSixRow Q code key g =
      psdFourRootSixRow (zeroExtend Q) (fun root a => flagLookup code (key root a)) g := by
  funext σ
  simp only [flagIndicatorFourRootSixRow, psdFourRootSixRow,
    flag_indicator_trace Q code hinj]

theorem flag_indicator_two_root_row_eq {k : ℕ}
    (Q : Matrix (Fin k) (Fin k) ℝ) (code : Fin k → ℕ)
    (hinj : Function.Injective code)
    (key : (root : Fin 2 ↪ Fin n) → Outside root × Outside root → ℕ)
    (g : (Fin 2 ↪ Fin n) → ℝ) :
    flagIndicatorTwoRootSixRow Q code key g =
      psdTwoRootSixRow (zeroExtend Q) (fun root a => flagLookup code (key root a)) g := by
  funext σ
  simp only [flagIndicatorTwoRootSixRow, psdTwoRootSixRow,
    flag_indicator_trace Q code hinj]

theorem flag_indicator_four_root_six_row_lower {k : ℕ}
    {Q : Matrix (Fin k) (Fin k) ℝ} (hQ : Q.PosSemidef)
    {m : ℝ} (hm : 0 ≤ m) (hdiag : ∀ i, Q i i ≤ m) (hn : 12 ≤ n)
    (code : Fin k → ℕ) (hinj : Function.Injective code)
    (key : (root : Fin 4 ↪ Fin n) → Outside root → ℕ)
    (g : (Fin 4 ↪ Fin n) → ℝ) (hg : ∀ root, g root = 0 ∨ g root = 1) :
    -m / ((n : ℝ) - 5) ≤
      uniformMean (flagIndicatorFourRootSixRow Q code key g) := by
  rw [flag_indicator_four_root_row_eq Q code hinj]
  exact flag_optional_four_root_six_row_lower hQ hm hdiag hn _ g hg

theorem flag_indicator_two_root_six_row_lower {k : ℕ}
    {Q : Matrix (Fin k) (Fin k) ℝ} (hQ : Q.PosSemidef)
    {m : ℝ} (hm : 0 ≤ m) (hdiag : ∀ i, Q i i ≤ m) (hn : 12 ≤ n)
    (code : Fin k → ℕ) (hinj : Function.Injective code)
    (key : (root : Fin 2 ↪ Fin n) → Outside root × Outside root → ℕ)
    (g : (Fin 2 ↪ Fin n) → ℝ) (hg : ∀ root, g root = 0 ∨ g root = 1) :
    -((4 * (n : ℝ) - 14) * m / (((n : ℝ) - 4) * ((n : ℝ) - 5))) ≤
      uniformMean (flagIndicatorTwoRootSixRow Q code key g) := by
  rw [flag_indicator_two_root_row_eq Q code hinj]
  exact flag_optional_two_root_six_row_lower hQ hm hdiag hn _ g hg

#print axioms flag_indicator_four_root_row_eq
#print axioms flag_indicator_two_root_row_eq
#print axioms flag_indicator_four_root_six_row_lower
#print axioms flag_indicator_two_root_six_row_lower
#print axioms flag_optional_four_root_six_row_lower
#print axioms flag_optional_two_root_six_row_lower
end TightCycleC5.Bridge
