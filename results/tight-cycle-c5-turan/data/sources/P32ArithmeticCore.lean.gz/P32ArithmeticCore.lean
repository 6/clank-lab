import P32ArithmeticData

/-! Literal signed P32 arithmetic on actual labelled structures. No zeta
transforms, grouped coefficient tables, or stored product tables are used. -/
namespace TightCycleC5.Bridge.P32Arithmetic
open Finset
set_option maxRecDepth 100000
set_option maxHeartbeats 0

/-- All quotation shape/bounds and signs; vector types additionally enforce
bounds at every data access. Imported Q arrays have their sizes checked too. -/
def QuotationValid : Prop :=
  0 < probScale ∧ 0 < weightScale ∧ 0 < factorScale ∧ 0 < scale ∧
  margin * 10000 = scale ∧
  classes.toArray = Family.classes ∧
  (∀ i : Fin 835, classes.get i < 2^20 ∧ 0 ≤ slacks.get i) ∧
  (∀ i : Fin 9511, 0 ≤ multipliers.get i) ∧
  (∀ i : Fin 9, 0 ≤ (selectors.get i).weight ∧
    ∀ j : Fin 8, 0 ≤ (selectors.get i).pi.get j ∧
      (selectors.get i).pi.get j ≤ probScale) ∧
  (∑ i : Fin 9, (selectors.get i).weight) = weightScale ∧
  (∀ i : Fin 25, ∀ j : Fin 32,
    0 ≤ (cuts.get i).beta.get j ∧ (cuts.get i).beta.get j ≤ probScale) ∧
  selectorScale * (5 * probScale^3 * weightScale) = scale ∧
  clScale * weightScale = scale ∧
  bookScale * (weightScale * probScale^2) = scale ∧
  densityScale * (10000 * weightScale) = scale ∧
  psdScale * factorScale^2 = scale ∧
  P32PSD.factorScale = factorScale ∧
  (P32PSD.q0Data.size = 64 ∧ ∀ r ∈ P32PSD.q0Data.toList, r.size = 64) ∧
  (P32PSD.q1Data.size = 64 ∧ ∀ r ∈ P32PSD.q1Data.toList, r.size = 64) ∧
  (P32PSD.q2Data.size = 50 ∧ ∀ r ∈ P32PSD.q2Data.toList, r.size = 50) ∧
  (P32PSD.q3Data.size = 39 ∧ ∀ r ∈ P32PSD.q3Data.toList, r.size = 39) ∧
  (P32PSD.q4Data.size = 30 ∧ ∀ r ∈ P32PSD.q4Data.toList, r.size = 30) ∧
  (P32PSD.q5Data.size = 12 ∧ ∀ r ∈ P32PSD.q5Data.toList, r.size = 12)

instance : Decidable QuotationValid := by unfold QuotationValid; infer_instance

theorem quotation_valid : QuotationValid := by native_decide
#print axioms quotation_valid

def bit (b : Bool) : ℤ := b.toNat

def pattern5 (e : Fin 6 → Fin 6 → Fin 6 → Bool) (z : Fin 6) : Fin 32 :=
  ⟨16 * (e 0 1 z).toNat + 8 * (e 0 2 z).toNat + 4 * (e 1 2 z).toNat +
    2 * (e 3 1 z).toNat + (e 3 2 z).toNat, by
      have := Bool.toNat_le (e 0 1 z); have := Bool.toNat_le (e 0 2 z)
      have := Bool.toNat_le (e 1 2 z); have := Bool.toNat_le (e 3 1 z)
      have := Bool.toNat_le (e 3 2 z); omega⟩

def flag4 (e : Fin 6 → Fin 6 → Fin 6 → Bool) (z : Fin 6) : Fin 64 :=
  ⟨(e 0 1 z).toNat + 2 * (e 0 2 z).toNat + 4 * (e 0 3 z).toNat +
    8 * (e 1 2 z).toNat + 16 * (e 1 3 z).toNat + 32 * (e 2 3 z).toNat, by
      have := Bool.toNat_le (e 0 1 z); have := Bool.toNat_le (e 0 2 z)
      have := Bool.toNat_le (e 0 3 z); have := Bool.toNat_le (e 1 2 z)
      have := Bool.toNat_le (e 1 3 z); have := Bool.toNat_le (e 2 3 z); omega⟩

def flag2 (e : Fin 6 → Fin 6 → Fin 6 → Bool) (a b : Fin 6) : Fin 64 :=
  ⟨4 * ((e 0 1 a).toNat + (e 0 1 b).toNat) + 2 * (e 0 a b).toNat +
    (e 1 a b).toNat, by
      have := Bool.toNat_le (e 0 1 a); have := Bool.toNat_le (e 0 1 b)
      have := Bool.toNat_le (e 0 a b); have := Bool.toNat_le (e 1 a b); omega⟩

structure Features where
  tau : Bool
  target : ℤ
  patterns : Vector (Fin 8) 3
  bookRoot : Fin 16
  bookA : Fin 32
  bookB : Fin 32
  root4 : Fin 16
  fourA : Fin 64
  fourB : Fin 64
  twoA : Fin 64
  twoB : Fin 64
  cl3 : ℤ
  cl4 : ℤ

/-- Exactly the root/flag predicates of frozen PROOF §3a, evaluated on the
actual edge function; colours are unused by this uncoloured certificate. -/
def features (G : LabelledStructure 6) : Features := Id.run do
  let e := fun a b c : Fin 6 => G.edge {a,b,c}
  let pat := fun z => (⟨CLCertificate.pattern e 0 1 2 z,
    CLCertificate.pattern_lt e 0 1 2 z⟩ : Fin 8)
  let tau := e 0 1 2
  let t := bit (e 3 4 5)
  let ch := bit (e 0 3 4) * bit (e 0 3 5) * (1 - bit (e 0 4 5))
  let k4 := bit (e 0 3 4) * bit (e 0 3 5) * bit (e 0 4 5) * t
  return {
    tau := tau, target := t, patterns := ⟨#[pat 3, pat 4, pat 5], by rfl⟩
    bookRoot := ⟨8 * tau.toNat + (pat 3).val, by
      have := Bool.toNat_le tau; have := (pat 3).isLt; omega⟩
    bookA := pattern5 e 4, bookB := pattern5 e 5
    root4 := ⟨(e 0 1 2).toNat + 2*(e 0 1 3).toNat +
      4*(e 0 2 3).toNat + 8*(e 1 2 3).toNat, by
        have := Bool.toNat_le (e 0 1 2); have := Bool.toNat_le (e 0 1 3)
        have := Bool.toNat_le (e 0 2 3); have := Bool.toNat_le (e 1 2 3); omega⟩
    fourA := flag4 e 4, fourB := flag4 e 5
    twoA := flag2 e 2 3, twoB := flag2 e 4 5
    cl3 := ch - k4, cl4 := ch * (1-t) - k4 }

def bookRestrictionList : List ℕ :=
  (List.range 32).flatMap (fun a =>
    [2^a] ++ (List.range (31-a)).map (fun b => 2^a + 2^(a+1+b))) ++ [2^32-1]

theorem bookRestrictionList_length : bookRestrictionList.length = 529 := by decide +kernel
#print axioms bookRestrictionList_length

def bookRestrictions : Vector ℕ 529 :=
  ⟨bookRestrictionList.toArray, by simpa using bookRestrictionList_length⟩

def bookRestriction (i : Fin 529) : ℕ := bookRestrictions.get i

/-- Literal common-subset membership, individually for every restriction. -/
def clPass (f : Features) (i : Fin 510) : Bool :=
  (f.tau.toNat == i.val / 255) &&
    f.patterns.toArray.all (fun p => (i.val % 255 + 1).testBit p.val)

def clNumerator (f : Features) : ℤ :=
  (∑ i : Fin 510, if clPass f i then multipliers.get ⟨i.val, by omega⟩ * f.cl3 else 0) +
  (∑ i : Fin 510, if clPass f i then multipliers.get ⟨510+i.val, by have := i.isLt; omega⟩ * f.cl4 else 0)

/-- All 8464 indicator-book rows are individual singleton/pair/all predicates.
The outer root test only avoids evaluating rows whose root indicator is zero. -/
def indicatorBookNumerator (f : Features) : ℤ :=
  ∑ k : Fin 16, if f.bookRoot = k then
    ∑ r : Fin 529, if (bookRestriction r).testBit f.bookA.val &&
      (bookRestriction r).testBit f.bookB.val then
      multipliers.get ⟨1020 + k.val * 529 + r.val, by
        have := k.isLt; have := r.isLt; omega⟩ * f.cl4
    else 0
  else 0

def weightedBookNumerator (f : Features) : ℤ :=
  ∑ i : Fin 25, if (cuts.get i).root = f.bookRoot then
    multipliers.get ⟨9484+i.val, by have := i.isLt; omega⟩ *
      (cuts.get i).beta.get f.bookA * (cuts.get i).beta.get f.bookB * f.cl4
  else 0

def bookNumerator (f : Features) : ℤ :=
  probScale^2 * indicatorBookNumerator f + weightedBookNumerator f

def densityNumerator (f : Features) : ℤ :=
  (10000 * bit f.tau - 4641) *
    (multipliers.get 9509 * f.target + multipliers.get 9510 * (1-f.target))

def selectorNumerator (f : Features) : ℤ :=
  ∑ i : Fin 9, if (selectors.get i).tau = f.tau then
    let s := selectors.get i
    let a := s.pi.get (f.patterns.get 0)
    let b := s.pi.get (f.patterns.get 1)
    let d := s.pi.get (f.patterns.get 2)
    s.weight * (5*f.target*(a*b*(probScale-d) + a*(probScale-b)*d +
      (probScale-a)*b*d) - 2*probScale^3)
  else 0

/-- Successful lookup includes flag support and in-bounds, typed Q coordinates.
Missing flags propagate None; no negative integer is converted to Nat. -/
def matrixLookup (b : Block) (a c : Fin 64) : Option ℤ := do
  let i ← (List.finRange b.n).find? (fun i => b.flags.get i == a)
  let j ← (List.finRange b.n).find? (fun j => b.flags.get j == c)
  return b.q i j

def fourRootBlock (r : Fin 16) : Option (Fin 6) :=
  match r.val with
  | 0 => some 0
  | 1 => some 1
  | 3 => some 2
  | 7 => some 3
  | 15 => some 4
  | _ => none

def psdNumerator (f : Features) : Option ℤ := do
  let four ← match fourRootBlock f.root4 with
    | none => some 0
    | some b => matrixLookup (blocks.get b) f.fourA f.fourB
  let two ← matrixLookup (blocks.get 5) f.twoA f.twoB
  return four + two

structure Evaluation where
  left : ℤ
  right : ℤ
  valid : Bool

/-- Signed integer expression at the pinned common denominator scale. -/
def evaluate (G : LabelledStructure 6) : Evaluation :=
  let f := features G
  let q := psdNumerator f
  { left := selectorScale * selectorNumerator f
    right := clScale * clNumerator f + bookScale * bookNumerator f +
      densityScale * densityNumerator f + psdScale * q.getD 0
    valid := q.isSome }

def classStructure (i : Fin 835) : LabelledStructure 6 :=
  MaskEncoding.decodeStructure (BitVec.ofNat 20 (classes.get i)) 0

def classValues (i : Fin 835) : Vector Evaluation 720 :=
  Vector.ofFn (fun j : Fin 720 => evaluate (Cover.kernelPermutation j • classStructure i))

/-- Exact finite identity, including every required flag lookup's success.
A false/missing lookup cannot be accepted merely because its default is zero. -/
def ClassStatement (i : Fin 835) : Prop :=
  let values := classValues i
  (∀ j : Fin 720, (values.get j).valid = true) ∧
  (∑ j : Fin 720, (values.get j).left) = coefficients.get i ∧
  (∑ j : Fin 720, ((values.get j).left - (values.get j).right)) =
    720*margin + slacks.get i ∧ 0 ≤ slacks.get i

instance (i : Fin 835) : Decidable (ClassStatement i) := by
  let values := classValues i
  change Decidable ((∀ j : Fin 720, (values.get j).valid = true) ∧
    (∑ j : Fin 720, (values.get j).left) = coefficients.get i ∧
    (∑ j : Fin 720, ((values.get j).left - (values.get j).right)) =
      720*margin + slacks.get i ∧ 0 ≤ slacks.get i)
  infer_instance

end TightCycleC5.Bridge.P32Arithmetic
