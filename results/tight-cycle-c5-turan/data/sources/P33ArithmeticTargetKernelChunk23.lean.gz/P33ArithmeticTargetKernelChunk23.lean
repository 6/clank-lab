-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk92 :
    ∀ i : Fin (min 128 (40547 - 128 * 92)),
      targetCountsMatch (classAt (targetKernelClass ⟨92, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk92

theorem target_counts_kernel_chunk93 :
    ∀ i : Fin (min 128 (40547 - 128 * 93)),
      targetCountsMatch (classAt (targetKernelClass ⟨93, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk93

theorem target_counts_kernel_chunk94 :
    ∀ i : Fin (min 128 (40547 - 128 * 94)),
      targetCountsMatch (classAt (targetKernelClass ⟨94, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk94

theorem target_counts_kernel_chunk95 :
    ∀ i : Fin (min 128 (40547 - 128 * 95)),
      targetCountsMatch (classAt (targetKernelClass ⟨95, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk95


end TightCycleC5.Bridge.P33Arithmetic
