import KernelShard24Blocks0
import KernelShard24Blocks1
import KernelShard24Blocks2
import KernelShard24Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard24 : kernelShardCheck 24 kernelWitness24 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (24 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness24 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_24_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard24
end TightCycleC5.Bridge.Cover
