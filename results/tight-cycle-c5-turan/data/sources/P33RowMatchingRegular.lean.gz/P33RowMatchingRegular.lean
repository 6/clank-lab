import P33RowMatchingRegularFeatures
import P33RowMatchingCodes
import P33RowMatchingData
import P33RowMatchingLookup
import P33Rows

namespace TightCycleC5.Bridge.P33RowMatching
open Finset
set_option maxHeartbeats 2000000

def regularKey (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) : Nat :=
  P33Arithmetic.canonical K.mask K.colours [(p 0).val,(p 1).val] [(p 4).val,(p 5).val]
def regularType (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) : Nat :=
  colourAt K p 0 + 2*colourAt K p 1
def regularQueryValid (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) : Prop :=
  ∀ b : Fin 3, regularType K p = (P33Arithmetic.blocks[b.val]!).typeCode →
    P33Arithmetic.lookup (P33Arithmetic.blocks[b.val]!).flags (regularKey K p) <
      (P33Arithmetic.blocks[b.val]!).flags.size

theorem regular_types_formula : ∀ i : Fin 120,
    P33Rows.regularTypes[i.val]! = if i.val < 40 then 0 else if i.val < 80 then 2 else 3 := by
  decide +kernel

/-- The sentinel 120 cannot be confused with a valid row. Bounds are
required only for the selected type, exactly as in the checker. -/
theorem chunk_index_iff (typ q0 q1 q2 i : Nat) (hi : i < 120)
    (h0 : typ = 0 → q0 < 40) (h2 : typ = 2 → q1 < 40) (h3 : typ = 3 → q2 < 40) :
    (i = if typ = 3 then 80+q2 else if typ = 2 then 40+q1 else if typ = 0 then q0 else 120) ↔
      typ = (if i < 40 then 0 else if i < 80 then 2 else 3) ∧
      (if i < 40 then q0 else if i < 80 then q1 else q2) = i % 40 := by
  constructor
  · intro he
    split_ifs at he with ht3 ht2 ht0
    · have hq := h3 ht3
      have hi40 : ¬i < 40 := by omega
      have hi80 : ¬i < 80 := by omega
      simp only [if_neg hi40, if_neg hi80]
      exact ⟨ht3,by omega⟩
    · have hq := h2 ht2
      have hi40 : ¬i < 40 := by omega
      have hi80 : i < 80 := by omega
      simp only [if_neg hi40, if_pos hi80]
      exact ⟨ht2,by omega⟩
    · have hq := h0 ht0
      have hi40 : i < 40 := by omega
      simp only [if_pos hi40]
      exact ⟨ht0,by omega⟩
    · omega
  · intro h
    by_cases hi40 : i < 40
    · simp only [if_pos hi40] at h
      rcases h with ⟨rfl,hq⟩
      norm_num only
      simp only [ite_false,ite_true]
      omega
    · by_cases hi80 : i < 80
      · simp only [if_neg hi40, if_pos hi80] at h
        rcases h with ⟨rfl,hq⟩
        norm_num only
        simp only [ite_false,ite_true]
        omega
      · simp only [if_neg hi40, if_neg hi80] at h
        rcases h with ⟨rfl,hq⟩
        norm_num only
        simp only [ite_false,ite_true]
        omega

theorem regular_index_iff (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (i : Fin 120) (hv : regularQueryValid K p) :
    i.val = (P33Arithmetic.featuresAt P33Arithmetic.localFlags P33Arithmetic.globalFlags
      P33Arithmetic.blocks K p).degreeIndex ↔
    ((structureAt K p).color 0).toNat + 2*((structureAt K p).color 1).toNat = P33Rows.regularTypes[i.val]! ∧
      P33Rows.canonicalRegular (fun x u v => (structureAt K p).edge {x,u,v})
        (structureAt K p).color 0 1 4 5 = P33Rows.regularFlags[i.val]! := by
  have ht0 := (regular_tables_checked (0 : Fin 3)).2.2.1
  have ht1 := (regular_tables_checked (1 : Fin 3)).2.2.1
  have ht2 := (regular_tables_checked (2 : Fin 3)).2.2.1
  norm_num at ht0 ht1 ht2
  have hbounds (b : Fin 3) (h : regularType K p = (P33Arithmetic.blocks[b.val]!).typeCode) :
      P33Arithmetic.lookup (P33Arithmetic.blocks[b.val]!).flags (regularKey K p) < 40 := by
    have hh := hv b h
    rw [(regular_tables_checked b).2.2.2.1] at hh
    exact hh
  rw [features_degreeIndex, ht0, ht1, ht2]
  change (i.val = if regularType K p = 3 then 80 + P33Arithmetic.lookup (P33Arithmetic.blocks[2]!).flags (regularKey K p)
    else if regularType K p = 2 then 40 + P33Arithmetic.lookup (P33Arithmetic.blocks[1]!).flags (regularKey K p)
    else if regularType K p = 0 then P33Arithmetic.lookup (P33Arithmetic.blocks[0]!).flags (regularKey K p) else 120) ↔ _
  have hchunk := chunk_index_iff (regularType K p)
    (P33Arithmetic.lookup (P33Arithmetic.blocks[0]!).flags (regularKey K p))
    (P33Arithmetic.lookup (P33Arithmetic.blocks[1]!).flags (regularKey K p))
    (P33Arithmetic.lookup (P33Arithmetic.blocks[2]!).flags (regularKey K p)) i.val i.isLt
    (fun h => by simpa using hbounds (0 : Fin 3) (h.trans ht0.symm))
    (fun h => by simpa using hbounds (1 : Fin 3) (h.trans ht1.symm))
    (fun h => by simpa using hbounds (2 : Fin 3) (h.trans ht2.symm))
  rw [hchunk]
  have hb : i.val / 40 < 3 := by omega
  let b : Fin 3 := ⟨i.val / 40,hb⟩
  have hsel : (if i.val < 40 then P33Arithmetic.lookup (P33Arithmetic.blocks[0]!).flags (regularKey K p)
      else if i.val < 80 then P33Arithmetic.lookup (P33Arithmetic.blocks[1]!).flags (regularKey K p)
      else P33Arithmetic.lookup (P33Arithmetic.blocks[2]!).flags (regularKey K p)) =
      P33Arithmetic.lookup (P33Arithmetic.blocks[b.val]!).flags (regularKey K p) := by
    dsimp only [b]
    split_ifs with hi40 hi80
    · rw [show i.val / 40 = 0 by omega]
    · rw [show i.val / 40 = 1 by omega]
    · rw [show i.val / 40 = 2 by omega]
  rw [hsel, ← regular_types_formula i]
  have ha := regular_tables_aligned i
  have hn := (regular_tables_checked b).2.2.2.2
  have hs := (regular_tables_checked b).2.2.2.1
  have hroot : regularType K p = ((structureAt K p).color 0).toNat + 2*((structureAt K p).color 1).toNat := by
    simp only [regularType, colourAt, colour_at]
  constructor
  · rintro ⟨ht,hq⟩
    have hvb : P33Arithmetic.lookup (P33Arithmetic.blocks[b.val]!).flags (regularKey K p) <
        (P33Arithmetic.blocks[b.val]!).flags.size := hv b (ht.trans ha.2.symm)
    have he := (lookup_eq_iff _ hn _ _ (by rw [hs]; omega) hvb).mp hq
    rw [ha.1] at he
    exact ⟨hroot.symm.trans ht, (canonical_regular K p).symm.trans he⟩
  · rintro ⟨ht,hflag⟩
    have ht' : regularType K p = P33Rows.regularTypes[i.val]! := hroot.trans ht
    have hvb := hv b (ht'.trans ha.2.symm)
    refine ⟨ht', (lookup_eq_iff _ hn _ _ (by rw [hs]; omega) hvb).2 ?_⟩
    rw [ha.1]
    exact (canonical_regular K p).trans hflag

theorem degreeDiff_real (ls : Array (Array Nat)) (gs : Array Nat)
    (bs : Array P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) :
    ((P33Arithmetic.featuresAt ls gs bs K p).degreeDiff : ℝ) =
      (if (structureAt K p).edge {0,2,3} then 1 else 0) -
        (if (structureAt K p).edge {1,2,3} then 1 else 0) := by
  rw [features_degreeDiff]
  simp only [edgeAt, edge_at K p 0 2 3 (by decide) (by decide) (by decide),
    edge_at K p 1 2 3 (by decide) (by decide) (by decide)]
  cases h0 : (structureAt K p).edge {0,2,3} <;>
    cases h1 : (structureAt K p).edge {1,2,3} <;> norm_num [h0,h1]

/-- No positivity assumption on the source regularity coefficient is introduced. -/
theorem regular_row_match (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (i : Fin 120) (hv : regularQueryValid K p) :
    (P33Arithmetic.regularityRow (P33Arithmetic.featuresAt P33Arithmetic.localFlags
      P33Arithmetic.globalFlags P33Arithmetic.blocks K p) i.val : ℝ) / 1000000000 =
      P33Rows.sourceRegularRow i (structureAt K p) := by
  rw [P33Arithmetic.regularityRow]
  change _ = ((if (structureAt K p).edge {0,2,3} then 1 else 0) -
      (if (structureAt K p).edge {1,2,3} then 1 else 0)) *
    (if ((structureAt K p).color 0).toNat + 2*((structureAt K p).color 1).toNat = P33Rows.regularTypes[i.val]! ∧
      P33Rows.canonicalRegular (fun x u v => (structureAt K p).edge {x,u,v})
        (structureAt K p).color 0 1 4 5 = P33Rows.regularFlags[i.val]! then 1 else 0)
  have hc := regular_index_iff K p i hv
  by_cases hi : i.val = (P33Arithmetic.featuresAt P33Arithmetic.localFlags P33Arithmetic.globalFlags
      P33Arithmetic.blocks K p).degreeIndex
  · rw [if_pos hi, if_pos (hc.mp hi)]
    push_cast
    rw [degreeDiff_real]
    ring
  · rw [if_neg hi, if_neg (fun h => hi (hc.mpr h))]
    norm_num

#print axioms regular_types_formula
#print axioms chunk_index_iff
#print axioms regular_index_iff
#print axioms degreeDiff_real
#print axioms regular_row_match
end TightCycleC5.Bridge.P33RowMatching
