-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk48 :
    ∀ i : Fin (min 128 (40547 - 128 * 48)),
      targetCountsMatch (classAt (targetKernelClass ⟨48, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk48

theorem target_counts_kernel_chunk49 :
    ∀ i : Fin (min 128 (40547 - 128 * 49)),
      targetCountsMatch (classAt (targetKernelClass ⟨49, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk49

theorem target_counts_kernel_chunk50 :
    ∀ i : Fin (min 128 (40547 - 128 * 50)),
      targetCountsMatch (classAt (targetKernelClass ⟨50, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk50

theorem target_counts_kernel_chunk51 :
    ∀ i : Fin (min 128 (40547 - 128 * 51)),
      targetCountsMatch (classAt (targetKernelClass ⟨51, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk51


end TightCycleC5.Bridge.P33Arithmetic
