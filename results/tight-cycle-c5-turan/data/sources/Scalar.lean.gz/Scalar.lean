import Mathlib

/-!
# The scalar facts behind the Mubayi–Rödl recursion

`L = α / 6` with `α = 2√3 − 3` is the fixed point of
`L = max_x (x²(1 − x)/2 + L (1 − x)³)`, attained at `x = ρ = (3 − √3)/2`.

* `scalar_step` (R1's cubic part, homogeneous form): for `x, y ≥ 0`,
  `x² y / 2 + L y³ ≤ L (x + y)³`. It closes the induction of the upper
  bound. The proof is the identity
  `L (x + y)³ − x² y / 2 − L y³ = (x / 6) · α (x − √3 y)²`,
  written as `4α · Q = (2αx + (3α − 3) y)²` to avoid dividing by `α`.
* `lower_step`: the same identity, with a one-vertex rounding error, for the
  integer part sizes `a = ⌈ρ n⌉` of the construction:
  `L n³ − 2n² ≤ C(a,2)(n − a) + L (n − a)³ − 2(n − a)²`.
-/

namespace TightCycleC5

/-- The Lagrangian density `α / 6` of the Mubayi–Rödl construction. -/
noncomputable def turanL : ℝ := (2 * Real.sqrt 3 - 3) / 6

theorem sqrt3_sq : Real.sqrt 3 ^ 2 = 3 := Real.sq_sqrt (by norm_num)

theorem sqrt3_gt : 3 / 2 < Real.sqrt 3 := by
  have h := sqrt3_sq
  have h0 := Real.sqrt_nonneg 3
  nlinarith

theorem sqrt3_lt : Real.sqrt 3 < 2 := by
  have h := sqrt3_sq
  have h0 := Real.sqrt_nonneg 3
  nlinarith

theorem alpha_pos : 0 < 2 * Real.sqrt 3 - 3 := by
  have := sqrt3_gt
  linarith

theorem turanL_nonneg : 0 ≤ turanL := by
  have := alpha_pos
  unfold turanL
  positivity

/-- The quadratic form `α x² + (3α − 3) x y + 3α y²` is a perfect square
times `α`, so it is nonnegative. -/
theorem quad_nonneg (x y : ℝ) :
    0 ≤ (2 * Real.sqrt 3 - 3) * x ^ 2 + (3 * (2 * Real.sqrt 3 - 3) - 3) * x * y
      + 3 * (2 * Real.sqrt 3 - 3) * y ^ 2 := by
  set s := Real.sqrt 3
  have hs : s ^ 2 = 3 := sqrt3_sq
  have ha : 0 < 2 * s - 3 := alpha_pos
  have h4 : 4 * (2 * s - 3) * ((2 * s - 3) * x ^ 2 + (3 * (2 * s - 3) - 3) * x * y
      + 3 * (2 * s - 3) * y ^ 2) = (2 * (2 * s - 3) * x + (3 * (2 * s - 3) - 3) * y) ^ 2 := by
    linear_combination 12 * y ^ 2 * hs
  have hsq := sq_nonneg (2 * (2 * s - 3) * x + (3 * (2 * s - 3) - 3) * y)
  rw [← h4] at hsq
  by_contra hneg
  push Not at hneg
  nlinarith

/-- **The scalar step** (R1's cubic part): `x² y / 2 + L y³ ≤ L (x + y)³`
for `x, y ≥ 0`. -/
theorem scalar_step {x y : ℝ} (hx : 0 ≤ x) (_hy : 0 ≤ y) :
    x ^ 2 * y / 2 + turanL * y ^ 3 ≤ turanL * (x + y) ^ 3 := by
  have hQ := quad_nonneg x y
  have hid : turanL * (x + y) ^ 3 - (x ^ 2 * y / 2 + turanL * y ^ 3) =
      x / 6 * ((2 * Real.sqrt 3 - 3) * x ^ 2 + (3 * (2 * Real.sqrt 3 - 3) - 3) * x * y
        + 3 * (2 * Real.sqrt 3 - 3) * y ^ 2) := by
    unfold turanL; ring
  have : 0 ≤ x / 6 * ((2 * Real.sqrt 3 - 3) * x ^ 2 + (3 * (2 * Real.sqrt 3 - 3) - 3) * x * y
        + 3 * (2 * Real.sqrt 3 - 3) * y ^ 2) := mul_nonneg (by positivity) hQ
  linarith

/-- The top-part proportion `ρ = (3 − √3)/2` of the construction. -/
noncomputable def rho : ℝ := (3 - Real.sqrt 3) / 2

theorem rho_pos : 0 < rho := by
  have := sqrt3_lt
  unfold rho; linarith

theorem rho_lt_one : rho < 1 := by
  have := sqrt3_gt
  unfold rho; linarith

/-- **The lower-bound step.** If `a` and `m` are reals with `1 ≤ a`,
`0 ≤ m` and `ρ (a + m) ≤ a < ρ (a + m) + 1`, then
`L (a + m)³ − 2 (a + m)² ≤ a (a − 1) m / 2 + L m³ − 2 m²`. -/
theorem lower_step {a m : ℝ} (ha : 1 ≤ a) (hm : 0 ≤ m) (hlo : rho * (a + m) ≤ a)
    (hhi : a < rho * (a + m) + 1) :
    turanL * (a + m) ^ 3 - 2 * (a + m) ^ 2 ≤ a * (a - 1) * m / 2 + turanL * m ^ 3 - 2 * m ^ 2 := by
  set s := Real.sqrt 3 with hs_def
  have hs : s ^ 2 = 3 := sqrt3_sq
  have hs1 : 3 / 2 < s := sqrt3_gt
  have hs2 : s < 2 := sqrt3_lt
  -- the identity: the difference is `−(α a/6)(a − s m)² − a m/2 + 2a² + 4am`
  have hid : a * (a - 1) * m / 2 + turanL * m ^ 3 - 2 * m ^ 2 -
      (turanL * (a + m) ^ 3 - 2 * (a + m) ^ 2) =
      -((2 * s - 3) * a / 6) * (a - s * m) ^ 2 - a * m / 2 + 2 * a ^ 2 + 4 * a * m := by
    unfold turanL
    linear_combination a * m * (-4 * a + 2 * m * s - 3 * m) / 6 * hs
  -- `a − s m = (1 + s)(a − ρ (a + m)) ∈ [0, 1 + s)`
  have hd : a - s * m = (1 + s) * (a - rho * (a + m)) := by
    unfold rho
    linear_combination (-(a + m) / 2) * hs
  have hd0 : 0 ≤ a - s * m := by
    rw [hd]; apply mul_nonneg <;> linarith
  have hd1 : a - s * m ≤ 1 + s := by
    rw [hd]
    have : a - rho * (a + m) ≤ 1 := by linarith
    nlinarith
  have hsq : (a - s * m) ^ 2 ≤ 8 := by nlinarith
  have hal : 0 ≤ 2 * s - 3 := by linarith
  have hal1 : 2 * s - 3 ≤ 1 := by linarith
  have hterm : (2 * s - 3) * a / 6 * (a - s * m) ^ 2 ≤ 2 * a := by
    have h1 : (2 * s - 3) * (a - s * m) ^ 2 ≤ 8 := by
      have := mul_le_mul hal1 hsq (sq_nonneg _) zero_le_one
      linarith
    have h2 : a * ((2 * s - 3) * (a - s * m) ^ 2) ≤ a * 8 :=
      mul_le_mul_of_nonneg_left h1 (by linarith)
    nlinarith
  have hmain : 0 ≤ -((2 * s - 3) * a / 6) * (a - s * m) ^ 2 - a * m / 2 + 2 * a ^ 2
      + 4 * a * m := by
    have ham : 0 ≤ a * m := mul_nonneg (by linarith) hm
    nlinarith
  linarith

end TightCycleC5
