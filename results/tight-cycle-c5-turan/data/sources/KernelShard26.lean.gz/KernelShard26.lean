import KernelShard26Blocks0
import KernelShard26Blocks1
import KernelShard26Blocks2
import KernelShard26Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard26 : kernelShardCheck 26 kernelWitness26 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (26 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness26 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_26_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard26
end TightCycleC5.Bridge.Cover
