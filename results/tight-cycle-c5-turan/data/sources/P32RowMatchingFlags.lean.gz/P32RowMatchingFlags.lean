import P32RowMatchingPSD

namespace TightCycleC5.Bridge.P32RowMatching
open Finset
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000

/-- Realize precisely the edge function queried by the accepted flag rows. -/
noncomputable def graphOf (G : LabelledStructure 6) : Finset (Finset (Fin 6)) :=
  univ.filter (fun s => G.edge s)

theorem graph_edge (G : LabelledStructure 6) (x u v : Fin 6) :
    P32Flag.edge (graphOf G) x u v = G.edge {x,u,v} := by
  simp [P32Flag.edge, graphOf]

theorem four_key_eq (G : LabelledStructure 6) (z : Fin 6) :
    P32Flag.fourKey (graphOf G) (fun i : Fin 4 => Fin.castAdd 2 i) z =
      (P32Arithmetic.flag4 (fun a b c => G.edge {a,b,c}) z).val := by
  simp [P32Flag.fourKey, P32Arithmetic.flag4, graph_edge]

theorem two_key_eq (G : LabelledStructure 6) (a b : Fin 6) :
    P32Flag.twoKey (graphOf G) (fun i : Fin 2 => Fin.castAdd 4 i) a b =
      (P32Arithmetic.flag2 (fun a b c => G.edge {a,b,c}) a b).val := by
  simp [P32Flag.twoKey, P32Arithmetic.flag2, graph_edge]

theorem root_bits_checked : ∀ (e : Fin 5) (a b c d : Bool),
    (a = decide (0 < e.val) ∧ b = decide (1 < e.val) ∧
      c = decide (2 < e.val) ∧ d = decide (3 < e.val)) ↔
    a.toNat + 2*b.toNat + 4*c.toNat + 8*d.toNat = 2^e.val-1 := by
  decide +kernel

theorem root_pass_eq (G : LabelledStructure 6) (e : Fin 5) :
    P32Flag.rootPass e (graphOf G) (fun i : Fin 4 => Fin.castAdd 2 i) ↔
      (P32Arithmetic.features G).root4.val = 2^e.val-1 := by
  simp only [P32Flag.rootPass, graph_edge]
  exact root_bits_checked e _ _ _ _

noncomputable def psdRows (G : LabelledStructure 6) : ℝ :=
  P32Flag.row0 (graphOf G) (Function.Embedding.refl _) +
  P32Flag.row1 (graphOf G) (Function.Embedding.refl _) +
  P32Flag.row2 (graphOf G) (Function.Embedding.refl _) +
  P32Flag.row3 (graphOf G) (Function.Embedding.refl _) +
  P32Flag.row4 (graphOf G) (Function.Embedding.refl _) +
  P32Flag.row5 (graphOf G) (Function.Embedding.refl _)

theorem row0_optional (G : LabelledStructure 6) :
    P32Flag.row0 (graphOf G) (Function.Embedding.refl _) =
      (if (P32Arithmetic.features G).root4.val = 0 then
        zeroExtend P32PSD.matrix0
          (flagLookup P32Flag.code0 (P32Arithmetic.features G).fourA.val)
          (flagLookup P32Flag.code0 (P32Arithmetic.features G).fourB.val) else 0) := by
  unfold P32Flag.row0 P32Flag.literalFourRow
  dsimp only
  rw [flag_indicator_trace P32PSD.matrix0 P32Flag.code0 P32Flag.injective0]
  simp only [Function.Embedding.refl_apply, four_key_eq]
  simp only [P32Flag.rootIndicator, root_pass_eq]
  norm_num only
  split_ifs <;> simp_all [P32Arithmetic.features]

theorem row1_optional (G : LabelledStructure 6) :
    P32Flag.row1 (graphOf G) (Function.Embedding.refl _) =
      (if (P32Arithmetic.features G).root4.val = 1 then
        zeroExtend P32PSD.matrix1
          (flagLookup P32Flag.code1 (P32Arithmetic.features G).fourA.val)
          (flagLookup P32Flag.code1 (P32Arithmetic.features G).fourB.val) else 0) := by
  unfold P32Flag.row1 P32Flag.literalFourRow
  dsimp only
  rw [flag_indicator_trace P32PSD.matrix1 P32Flag.code1 P32Flag.injective1]
  simp only [Function.Embedding.refl_apply, four_key_eq]
  simp only [P32Flag.rootIndicator, root_pass_eq]
  norm_num only
  split_ifs <;> simp_all [P32Arithmetic.features]

theorem row2_optional (G : LabelledStructure 6) :
    P32Flag.row2 (graphOf G) (Function.Embedding.refl _) =
      (if (P32Arithmetic.features G).root4.val = 3 then
        zeroExtend P32PSD.matrix2
          (flagLookup P32Flag.code2 (P32Arithmetic.features G).fourA.val)
          (flagLookup P32Flag.code2 (P32Arithmetic.features G).fourB.val) else 0) := by
  unfold P32Flag.row2 P32Flag.literalFourRow
  dsimp only
  rw [flag_indicator_trace P32PSD.matrix2 P32Flag.code2 P32Flag.injective2]
  simp only [Function.Embedding.refl_apply, four_key_eq]
  simp only [P32Flag.rootIndicator, root_pass_eq]
  norm_num only
  split_ifs <;> simp_all [P32Arithmetic.features]

theorem row3_optional (G : LabelledStructure 6) :
    P32Flag.row3 (graphOf G) (Function.Embedding.refl _) =
      (if (P32Arithmetic.features G).root4.val = 7 then
        zeroExtend P32PSD.matrix3
          (flagLookup P32Flag.code3 (P32Arithmetic.features G).fourA.val)
          (flagLookup P32Flag.code3 (P32Arithmetic.features G).fourB.val) else 0) := by
  unfold P32Flag.row3 P32Flag.literalFourRow
  dsimp only
  rw [flag_indicator_trace P32PSD.matrix3 P32Flag.code3 P32Flag.injective3]
  simp only [Function.Embedding.refl_apply, four_key_eq]
  simp only [P32Flag.rootIndicator, root_pass_eq]
  norm_num only
  split_ifs <;> simp_all [P32Arithmetic.features]

theorem row4_optional (G : LabelledStructure 6) :
    P32Flag.row4 (graphOf G) (Function.Embedding.refl _) =
      (if (P32Arithmetic.features G).root4.val = 15 then
        zeroExtend P32PSD.matrix4
          (flagLookup P32Flag.code4 (P32Arithmetic.features G).fourA.val)
          (flagLookup P32Flag.code4 (P32Arithmetic.features G).fourB.val) else 0) := by
  unfold P32Flag.row4 P32Flag.literalFourRow
  dsimp only
  rw [flag_indicator_trace P32PSD.matrix4 P32Flag.code4 P32Flag.injective4]
  simp only [Function.Embedding.refl_apply, four_key_eq]
  simp only [P32Flag.rootIndicator, root_pass_eq]
  norm_num only
  split_ifs <;> simp_all [P32Arithmetic.features]

theorem row5_optional (G : LabelledStructure 6) :
    P32Flag.row5 (graphOf G) (Function.Embedding.refl _) =
      zeroExtend P32PSD.matrix5
        (flagLookup P32Flag.code5 (P32Arithmetic.features G).twoA.val)
        (flagLookup P32Flag.code5 (P32Arithmetic.features G).twoB.val) := by
  unfold P32Flag.row5 P32Flag.literalTwoRow
  dsimp only
  rw [flag_indicator_trace P32PSD.matrix5 P32Flag.code5 P32Flag.injective5]
  simp only [Function.Embedding.refl_apply, two_key_eq]
  rfl

#print axioms graph_edge
#print axioms four_key_eq
#print axioms two_key_eq
#print axioms root_bits_checked
#print axioms root_pass_eq
#print axioms row0_optional
#print axioms row1_optional
#print axioms row2_optional
#print axioms row3_optional
#print axioms row4_optional
#print axioms row5_optional
end TightCycleC5.Bridge.P32RowMatching
