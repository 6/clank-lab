import P33ArithmeticCore
import SOSGram
import FlagVectors

/-! Source integer SOS entries and literal full traces. No native trust or
finite-class assumption is used in these uniform algebraic lemmas. -/
namespace TightCycleC5.Bridge.P33PSDMatching
open Finset Matrix

def rootQuery (b : P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Fin 6 → Fin 6) : ℕ :=
  P33Arithmetic.encoded K.mask K.colours
    ((List.range b.roots).map (fun v => (p (Fin.ofNat 6 v)).val))

def leftQuery (b : P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Fin 6 → Fin 6) : ℕ :=
  if b.roots = 2 then
    P33Arithmetic.canonical K.mask K.colours [(p 0).val,(p 1).val] [(p 2).val,(p 3).val]
  else P33Arithmetic.encoded K.mask K.colours
    (((List.range b.roots).map (fun v => (p (Fin.ofNat 6 v)).val)) ++ [(p 4).val])

def rightQuery (b : P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Fin 6 → Fin 6) : ℕ :=
  if b.roots = 2 then
    P33Arithmetic.canonical K.mask K.colours [(p 0).val,(p 1).val] [(p 4).val,(p 5).val]
  else P33Arithmetic.encoded K.mask K.colours
    (((List.range b.roots).map (fun v => (p (Fin.ofNat 6 v)).val)) ++ [(p 5).val])

/-- Exact actual-query bounds; no completeness outside the listed basis. -/
def ValidLookups (b : P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Fin 6 → Fin 6) : Prop :=
  rootQuery b K p = b.typeCode →
    P33Arithmetic.lookup b.flags (leftQuery b K p) < b.flags.size ∧
    P33Arithmetic.lookup b.flags (rightQuery b K p) < b.flags.size

def sourceContribution (b : P33Arithmetic.Block) (K : P33Arithmetic.Class)
    (p : Fin 6 → Fin 6) : ℤ :=
  if rootQuery b K p = b.typeCode then
    1000000000 * P33Arithmetic.blockEntry b
      (P33Arithmetic.lookup b.flags (leftQuery b K p))
      (P33Arithmetic.lookup b.flags (rightQuery b K p))
  else 0

/-- An executable source fold is the full finite sum, preserving every term. -/
theorem array_foldl_add {α : Type*} [Inhabited α] (a : Array α) (f : α → ℤ) :
    a.foldl (fun s t => s + f t) 0 = ∑ k : Fin a.size, f a[k.val]! := by
  have ht : (a.map f).toList = List.ofFn (fun k : Fin a.size => f a[k.val]!) := by
    apply List.ext_getElem <;> simp
  calc
    _ = (a.map f).sum := by rw [Array.sum_eq_foldl, Array.foldl_map]
    _ = (List.ofFn (fun k : Fin a.size => f a[k.val]!)).sum := by
      rw [← Array.sum_toList, ht]
    _ = _ := List.sum_ofFn

/-- The source evaluator is the full ordered block sum with its literal
root test and its two actual lookup queries. -/
theorem psdAt_eq_sum (blocks : Array P33Arithmetic.Block) (K : P33Arithmetic.Class)
    (p : Fin 6 → Fin 6) :
    P33Arithmetic.psdAt blocks K p =
      ∑ b : Fin blocks.size, sourceContribution blocks[b.val]! K p := by
  unfold P33Arithmetic.psdAt
  have hf (s : ℤ) (b : P33Arithmetic.Block) :
      (let root := (List.range b.roots).map (fun v => (p (Fin.ofNat 6 v)).val)
       if P33Arithmetic.encoded K.mask K.colours root = b.typeCode then
         let fa := if b.roots = 2 then
           P33Arithmetic.canonical K.mask K.colours [(p 0).val,(p 1).val] [(p 2).val,(p 3).val]
           else P33Arithmetic.encoded K.mask K.colours (root ++ [(p 4).val])
         let fb := if b.roots = 2 then
           P33Arithmetic.canonical K.mask K.colours [(p 0).val,(p 1).val] [(p 4).val,(p 5).val]
           else P33Arithmetic.encoded K.mask K.colours (root ++ [(p 5).val])
         s + 1000000000 * P33Arithmetic.blockEntry b
           (P33Arithmetic.lookup b.flags fa) (P33Arithmetic.lookup b.flags fb)
       else s) = s + sourceContribution b K p := by
    dsimp [sourceContribution, rootQuery, leftQuery, rightQuery]
    split_ifs <;> simp
  simp only [hf, array_foldl_add]

/-- Pointwise equality of every source term gives equality of every ordered
assembled matrix entry, without building or checking a dense matrix. -/
theorem blockEntry_eq_sos {d t : ℕ} (b : P33Arithmetic.Block)
    (w : Fin t → ℕ) (A : Fin t → Matrix (Fin d) (Fin d) ℤ)
    (hsize : b.terms.size = t)
    (hterm : ∀ k : Fin t, ∀ i j : Fin d,
      P33Arithmetic.termEntry b.terms[k.val]! i.val j.val = (w k : ℤ) * A k i j) :
    ∀ i j : Fin d, P33Arithmetic.blockEntry b i.val j.val = integerSOS w A i j := by
  subst t
  intro i j
  simp only [P33Arithmetic.blockEntry, array_foldl_add, integerSOS]
  exact Finset.sum_congr rfl (fun k _ => hterm k i j)

/-- A valid source index identifies the optional lookup by its exact code. -/
theorem lookup_eq_some {d : ℕ} (code : Fin d → ℕ) (hinj : Function.Injective code)
    (flags : Array ℕ) (hsize : flags.size = d)
    (hcode : ∀ i : Fin d, code i = flags[i.val]!) (key : ℕ)
    (hvalid : P33Arithmetic.lookup flags key < d) :
    flagLookup code key = some ⟨P33Arithmetic.lookup flags key, hvalid⟩ := by
  apply (flagLookup_some_iff code hinj key _).mpr
  rw [hcode]
  have hi : flags.toList.idxOf key < flags.toList.length := by
    simpa [P33Arithmetic.lookup, hsize] using hvalid
  have ha : flags.toList.idxOf key < flags.size := by simpa using hi
  change key = flags[flags.toList.idxOf key]!
  rw [getElem!_pos flags _ ha]
  exact (List.getElem_idxOf hi).symm

/-- The entire ordered trace, including all off-diagonal entries, equals
its actual selected entry once source lookups have been validated. -/
theorem trace_of_lookup_valid {d : ℕ} (Q : Matrix (Fin d) (Fin d) ℝ)
    (code : Fin d → ℕ) (hinj : Function.Injective code)
    (flags : Array ℕ) (hsize : flags.size = d)
    (hcode : ∀ i : Fin d, code i = flags[i.val]!) (a b : ℕ)
    (ha : P33Arithmetic.lookup flags a < d) (hb : P33Arithmetic.lookup flags b < d) :
    (∑ i, ∑ j, Q i j * (if a = code i then 1 else 0) *
      (if b = code j then 1 else 0)) =
      Q ⟨P33Arithmetic.lookup flags a,ha⟩ ⟨P33Arithmetic.lookup flags b,hb⟩ := by
  rw [flag_indicator_trace Q code hinj,
    lookup_eq_some code hinj flags hsize hcode a ha,
    lookup_eq_some code hinj flags hsize hcode b hb]
  rfl

/-- Normalize the source SOS entry by the same single scale as the actual
PSD matrix. This identity requires no positivity or PSD hypothesis. -/
theorem source_full_trace {d : ℕ} (source : P33Arithmetic.Block)
    (q : Matrix (Fin d) (Fin d) ℤ) (scale : ℕ)
    (hentry : ∀ i j : Fin d, P33Arithmetic.blockEntry source i.val j.val = q i j)
    (code : Fin d → ℕ) (hinj : Function.Injective code)
    (hsize : source.flags.size = d)
    (hcode : ∀ i : Fin d, code i = source.flags[i.val]!) (a b : ℕ)
    (ha : P33Arithmetic.lookup source.flags a < d)
    (hb : P33Arithmetic.lookup source.flags b < d) :
    (∑ i, ∑ j, scaleIntMatrix q scale i j * (if a = code i then 1 else 0) *
      (if b = code j then 1 else 0)) =
      (P33Arithmetic.blockEntry source (P33Arithmetic.lookup source.flags a)
        (P33Arithmetic.lookup source.flags b) : ℝ) / (scale : ℝ) := by
  rw [trace_of_lookup_valid _ code hinj source.flags hsize hcode a b ha hb]
  rw [hentry ⟨_,ha⟩ ⟨_,hb⟩]
  rfl

#print axioms psdAt_eq_sum
#print axioms array_foldl_add
#print axioms blockEntry_eq_sos
#print axioms lookup_eq_some
#print axioms trace_of_lookup_valid
#print axioms source_full_trace
end TightCycleC5.Bridge.P33PSDMatching
