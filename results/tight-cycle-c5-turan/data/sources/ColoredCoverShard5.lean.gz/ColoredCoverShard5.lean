import ColoredCoverSemantics

namespace TightCycleC5.Bridge.ColoredCover
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def coloredWitness160 : Array Nat := #[4997520, 4998240, 4998960, 4999680, 4998984, 4999704, 5000400, 5001120, 5001840, 5002560, 5003280, 5004000, 5003304, 5004024, 5004720, 5005440, 5006160, 5006880, 5007600, 5008320, 5007624, 5008344, 5009040, 5009760, 5010480, 5011200, 5011920, 5012640, 5011944, 5012664, 5013360, 5014080, 5014800, 5015520, 5016240, 5016960, 5016264, 5016984, 5017680, 5018400, 5019120, 5019840, 5020560, 5021280, 5020584, 5021304, 5022000, 5022720, 5023440, 5024160, 5024880, 5025600, 5024904, 5025624, 5026320, 5027040, 5027760, 5028480, 5029200, 5029920, 5029224, 5029944, 5030640, 5031360]

theorem colored_row160 : ∀ c : Fin 64,
    readRow witnessRows (160 * 64 + c.val) = coloredWitness160[c.val]! := by
  decide +kernel
#print axioms colored_row160

theorem colored_check160 : ∀ c : Fin 64,
    checkColored 160 (BitVec.ofNat 6 c.val) (coloredWitness160[c.val]!) = true := by
  decide +kernel
#print axioms colored_check160

theorem colored_family160 : ∀ c : Fin 64,
    checkColored 160 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (160 * 64 + c.val)) = true := by
  intro c
  rw [colored_row160]
  exact colored_check160 c
#print axioms colored_family160

def coloredWitness161 : Array Nat := #[5032080, 5032800, 5033520, 5034240, 5033544, 5034264, 5034960, 5035680, 5036400, 5037120, 5037840, 5038560, 5037864, 5038584, 5039280, 5040000, 5040720, 5041440, 5042160, 5042880, 5042184, 5042904, 5043600, 5044320, 5045040, 5045760, 5046480, 5047200, 5046504, 5047224, 5047920, 5048640, 5049360, 5050080, 5050800, 5051520, 5050824, 5051544, 5052240, 5052960, 5053680, 5054400, 5055120, 5055840, 5055144, 5055864, 5056560, 5057280, 5058000, 5058720, 5059440, 5060160, 5059464, 5060184, 5060880, 5061600, 5062320, 5063040, 5063760, 5064480, 5063784, 5064504, 5065200, 5065920]

theorem colored_row161 : ∀ c : Fin 64,
    readRow witnessRows (161 * 64 + c.val) = coloredWitness161[c.val]! := by
  decide +kernel
#print axioms colored_row161

theorem colored_check161 : ∀ c : Fin 64,
    checkColored 161 (BitVec.ofNat 6 c.val) (coloredWitness161[c.val]!) = true := by
  decide +kernel
#print axioms colored_check161

theorem colored_family161 : ∀ c : Fin 64,
    checkColored 161 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (161 * 64 + c.val)) = true := by
  intro c
  rw [colored_row161]
  exact colored_check161 c
#print axioms colored_family161

def coloredWitness162 : Array Nat := #[5066640, 5067360, 5068080, 5068800, 5068104, 5068824, 5069520, 5070240, 5068128, 5068848, 5069526, 5070246, 5069550, 5070270, 5070960, 5071680, 5072400, 5073120, 5073840, 5074560, 5073864, 5074584, 5075280, 5076000, 5073888, 5074608, 5075286, 5076006, 5075310, 5076030, 5076720, 5077440, 5072401, 5073121, 5073841, 5074561, 5073865, 5074585, 5075281, 5076001, 5073889, 5074609, 5075287, 5076007, 5075311, 5076031, 5076721, 5077441, 5078160, 5078880, 5079600, 5080320, 5079624, 5080344, 5081040, 5081760, 5079648, 5080368, 5081046, 5081766, 5081070, 5081790, 5082480, 5083200]

theorem colored_row162 : ∀ c : Fin 64,
    readRow witnessRows (162 * 64 + c.val) = coloredWitness162[c.val]! := by
  decide +kernel
#print axioms colored_row162

theorem colored_check162 : ∀ c : Fin 64,
    checkColored 162 (BitVec.ofNat 6 c.val) (coloredWitness162[c.val]!) = true := by
  decide +kernel
#print axioms colored_check162

theorem colored_family162 : ∀ c : Fin 64,
    checkColored 162 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (162 * 64 + c.val)) = true := by
  intro c
  rw [colored_row162]
  exact colored_check162 c
#print axioms colored_family162

def coloredWitness163 : Array Nat := #[5083920, 5084640, 5085360, 5086080, 5085384, 5086104, 5086800, 5087520, 5088240, 5088960, 5089680, 5090400, 5089704, 5090424, 5091120, 5091840, 5092560, 5093280, 5094000, 5094720, 5094024, 5094744, 5095440, 5096160, 5096880, 5097600, 5098320, 5099040, 5098344, 5099064, 5099760, 5100480, 5092561, 5093281, 5094001, 5094721, 5094025, 5094745, 5095441, 5096161, 5096881, 5097601, 5098321, 5099041, 5098345, 5099065, 5099761, 5100481, 5101200, 5101920, 5102640, 5103360, 5102664, 5103384, 5104080, 5104800, 5105520, 5106240, 5106960, 5107680, 5106984, 5107704, 5108400, 5109120]

theorem colored_row163 : ∀ c : Fin 64,
    readRow witnessRows (163 * 64 + c.val) = coloredWitness163[c.val]! := by
  decide +kernel
#print axioms colored_row163

theorem colored_check163 : ∀ c : Fin 64,
    checkColored 163 (BitVec.ofNat 6 c.val) (coloredWitness163[c.val]!) = true := by
  decide +kernel
#print axioms colored_check163

theorem colored_family163 : ∀ c : Fin 64,
    checkColored 163 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (163 * 64 + c.val)) = true := by
  intro c
  rw [colored_row163]
  exact colored_check163 c
#print axioms colored_family163

def coloredWitness164 : Array Nat := #[5109840, 5110560, 5111280, 5112000, 5112720, 5113440, 5114160, 5114880, 5112726, 5113446, 5114166, 5114886, 5115600, 5116320, 5117040, 5117760, 5118480, 5119200, 5119920, 5120640, 5121360, 5122080, 5122800, 5123520, 5121366, 5122086, 5122806, 5123526, 5124240, 5124960, 5125680, 5126400, 5118481, 5119201, 5119921, 5120641, 5121361, 5122081, 5122801, 5123521, 5121367, 5122087, 5122807, 5123527, 5124241, 5124961, 5125681, 5126401, 5127120, 5127840, 5128560, 5129280, 5130000, 5130720, 5131440, 5132160, 5130006, 5130726, 5131446, 5132166, 5132880, 5133600, 5134320, 5135040]

theorem colored_row164 : ∀ c : Fin 64,
    readRow witnessRows (164 * 64 + c.val) = coloredWitness164[c.val]! := by
  decide +kernel
#print axioms colored_row164

theorem colored_check164 : ∀ c : Fin 64,
    checkColored 164 (BitVec.ofNat 6 c.val) (coloredWitness164[c.val]!) = true := by
  decide +kernel
#print axioms colored_check164

theorem colored_family164 : ∀ c : Fin 64,
    checkColored 164 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (164 * 64 + c.val)) = true := by
  intro c
  rw [colored_row164]
  exact colored_check164 c
#print axioms colored_family164

def coloredWitness165 : Array Nat := #[5135760, 5136480, 5137200, 5137920, 5137224, 5137944, 5138640, 5139360, 5137248, 5137968, 5138646, 5139366, 5138670, 5139390, 5140080, 5140800, 5141520, 5142240, 5142960, 5143680, 5142984, 5143704, 5144400, 5145120, 5143008, 5143728, 5144406, 5145126, 5144430, 5145150, 5145840, 5146560, 5141521, 5142241, 5142961, 5143681, 5142985, 5143705, 5144401, 5145121, 5143009, 5143729, 5144407, 5145127, 5144431, 5145151, 5145841, 5146561, 5147280, 5148000, 5148720, 5149440, 5148744, 5149464, 5150160, 5150880, 5148768, 5149488, 5150166, 5150886, 5150190, 5150910, 5151600, 5152320]

theorem colored_row165 : ∀ c : Fin 64,
    readRow witnessRows (165 * 64 + c.val) = coloredWitness165[c.val]! := by
  decide +kernel
#print axioms colored_row165

theorem colored_check165 : ∀ c : Fin 64,
    checkColored 165 (BitVec.ofNat 6 c.val) (coloredWitness165[c.val]!) = true := by
  decide +kernel
#print axioms colored_check165

theorem colored_family165 : ∀ c : Fin 64,
    checkColored 165 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (165 * 64 + c.val)) = true := by
  intro c
  rw [colored_row165]
  exact colored_check165 c
#print axioms colored_family165

def coloredWitness166 : Array Nat := #[5153040, 5153760, 5153880, 5154480, 5154000, 5154504, 5154624, 5155200, 5155920, 5156640, 5156760, 5157360, 5156880, 5157384, 5157504, 5158080, 5155922, 5156642, 5156762, 5157362, 5156882, 5157386, 5157506, 5158082, 5158800, 5159520, 5159640, 5160240, 5159760, 5160264, 5160384, 5160960, 5161680, 5162400, 5162520, 5163120, 5162640, 5163144, 5163264, 5163840, 5164560, 5165280, 5165400, 5166000, 5165520, 5166024, 5166144, 5166720, 5164562, 5165282, 5165402, 5166002, 5165522, 5166026, 5166146, 5166722, 5167440, 5168160, 5168280, 5168880, 5168400, 5168904, 5169024, 5169600]

theorem colored_row166 : ∀ c : Fin 64,
    readRow witnessRows (166 * 64 + c.val) = coloredWitness166[c.val]! := by
  decide +kernel
#print axioms colored_row166

theorem colored_check166 : ∀ c : Fin 64,
    checkColored 166 (BitVec.ofNat 6 c.val) (coloredWitness166[c.val]!) = true := by
  decide +kernel
#print axioms colored_check166

theorem colored_family166 : ∀ c : Fin 64,
    checkColored 166 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (166 * 64 + c.val)) = true := by
  intro c
  rw [colored_row166]
  exact colored_check166 c
#print axioms colored_family166

def coloredWitness167 : Array Nat := #[5170320, 5171040, 5171160, 5171760, 5171280, 5171784, 5171904, 5172480, 5173200, 5173920, 5174040, 5174640, 5174160, 5174664, 5174784, 5175360, 5173202, 5173922, 5174042, 5174642, 5174162, 5174666, 5174786, 5175362, 5176080, 5176800, 5176920, 5177520, 5177040, 5177544, 5177664, 5178240, 5178960, 5179680, 5179800, 5180400, 5179920, 5180424, 5180544, 5181120, 5181840, 5182560, 5182680, 5183280, 5182800, 5183304, 5183424, 5184000, 5181842, 5182562, 5182682, 5183282, 5182802, 5183306, 5183426, 5184002, 5184720, 5185440, 5185560, 5186160, 5185680, 5186184, 5186304, 5186880]

theorem colored_row167 : ∀ c : Fin 64,
    readRow witnessRows (167 * 64 + c.val) = coloredWitness167[c.val]! := by
  decide +kernel
#print axioms colored_row167

theorem colored_check167 : ∀ c : Fin 64,
    checkColored 167 (BitVec.ofNat 6 c.val) (coloredWitness167[c.val]!) = true := by
  decide +kernel
#print axioms colored_check167

theorem colored_family167 : ∀ c : Fin 64,
    checkColored 167 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (167 * 64 + c.val)) = true := by
  intro c
  rw [colored_row167]
  exact colored_check167 c
#print axioms colored_family167

def coloredWitness168 : Array Nat := #[5187600, 5188320, 5188440, 5189040, 5189760, 5190480, 5190600, 5191200, 5191920, 5192640, 5192760, 5193360, 5194080, 5194800, 5194920, 5195520, 5196240, 5196960, 5197080, 5197680, 5198400, 5199120, 5199240, 5199840, 5200560, 5201280, 5201400, 5202000, 5202720, 5203440, 5203560, 5204160, 5204880, 5205600, 5205720, 5206320, 5207040, 5207760, 5207880, 5208480, 5209200, 5209920, 5210040, 5210640, 5211360, 5212080, 5212200, 5212800, 5213520, 5214240, 5214360, 5214960, 5215680, 5216400, 5216520, 5217120, 5217840, 5218560, 5218680, 5219280, 5220000, 5220720, 5220840, 5221440]

theorem colored_row168 : ∀ c : Fin 64,
    readRow witnessRows (168 * 64 + c.val) = coloredWitness168[c.val]! := by
  decide +kernel
#print axioms colored_row168

theorem colored_check168 : ∀ c : Fin 64,
    checkColored 168 (BitVec.ofNat 6 c.val) (coloredWitness168[c.val]!) = true := by
  decide +kernel
#print axioms colored_check168

theorem colored_family168 : ∀ c : Fin 64,
    checkColored 168 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (168 * 64 + c.val)) = true := by
  intro c
  rw [colored_row168]
  exact colored_check168 c
#print axioms colored_family168

def coloredWitness169 : Array Nat := #[5222160, 5222880, 5223000, 5223600, 5224320, 5225040, 5225160, 5225760, 5226480, 5227200, 5227320, 5227920, 5228640, 5229360, 5229480, 5230080, 5230800, 5231520, 5231640, 5232240, 5232960, 5233680, 5233800, 5234400, 5235120, 5235840, 5235960, 5236560, 5237280, 5238000, 5238120, 5238720, 5239440, 5240160, 5240280, 5240880, 5241600, 5242320, 5242440, 5243040, 5243760, 5244480, 5244600, 5245200, 5245920, 5246640, 5246760, 5247360, 5248080, 5248800, 5248920, 5249520, 5250240, 5250960, 5251080, 5251680, 5252400, 5253120, 5253240, 5253840, 5254560, 5255280, 5255400, 5256000]

theorem colored_row169 : ∀ c : Fin 64,
    readRow witnessRows (169 * 64 + c.val) = coloredWitness169[c.val]! := by
  decide +kernel
#print axioms colored_row169

theorem colored_check169 : ∀ c : Fin 64,
    checkColored 169 (BitVec.ofNat 6 c.val) (coloredWitness169[c.val]!) = true := by
  decide +kernel
#print axioms colored_check169

theorem colored_family169 : ∀ c : Fin 64,
    checkColored 169 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (169 * 64 + c.val)) = true := by
  intro c
  rw [colored_row169]
  exact colored_check169 c
#print axioms colored_family169

def coloredWitness170 : Array Nat := #[5256720, 5257440, 5257560, 5258160, 5258880, 5259600, 5259720, 5260320, 5261040, 5261760, 5261880, 5262480, 5263200, 5263920, 5264040, 5264640, 5261042, 5261762, 5261882, 5262482, 5263202, 5263922, 5264042, 5264642, 5265360, 5266080, 5266200, 5266800, 5267520, 5268240, 5268360, 5268960, 5269680, 5270400, 5270520, 5271120, 5271840, 5272560, 5272680, 5273280, 5274000, 5274720, 5274840, 5275440, 5276160, 5276880, 5277000, 5277600, 5274002, 5274722, 5274842, 5275442, 5276162, 5276882, 5277002, 5277602, 5278320, 5279040, 5279160, 5279760, 5280480, 5281200, 5281320, 5281920]

theorem colored_row170 : ∀ c : Fin 64,
    readRow witnessRows (170 * 64 + c.val) = coloredWitness170[c.val]! := by
  decide +kernel
#print axioms colored_row170

theorem colored_check170 : ∀ c : Fin 64,
    checkColored 170 (BitVec.ofNat 6 c.val) (coloredWitness170[c.val]!) = true := by
  decide +kernel
#print axioms colored_check170

theorem colored_family170 : ∀ c : Fin 64,
    checkColored 170 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (170 * 64 + c.val)) = true := by
  intro c
  rw [colored_row170]
  exact colored_check170 c
#print axioms colored_family170

def coloredWitness171 : Array Nat := #[5282640, 5283360, 5283480, 5284080, 5284800, 5285520, 5285640, 5286240, 5286960, 5287680, 5287800, 5288400, 5289120, 5289840, 5289960, 5290560, 5286962, 5287682, 5287802, 5288402, 5289122, 5289842, 5289962, 5290562, 5291280, 5292000, 5292120, 5292720, 5293440, 5294160, 5294280, 5294880, 5295600, 5296320, 5296440, 5297040, 5297760, 5298480, 5298600, 5299200, 5299920, 5300640, 5300760, 5301360, 5302080, 5302800, 5302920, 5303520, 5299922, 5300642, 5300762, 5301362, 5302082, 5302802, 5302922, 5303522, 5304240, 5304960, 5305080, 5305680, 5306400, 5307120, 5307240, 5307840]

theorem colored_row171 : ∀ c : Fin 64,
    readRow witnessRows (171 * 64 + c.val) = coloredWitness171[c.val]! := by
  decide +kernel
#print axioms colored_row171

theorem colored_check171 : ∀ c : Fin 64,
    checkColored 171 (BitVec.ofNat 6 c.val) (coloredWitness171[c.val]!) = true := by
  decide +kernel
#print axioms colored_check171

theorem colored_family171 : ∀ c : Fin 64,
    checkColored 171 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (171 * 64 + c.val)) = true := by
  intro c
  rw [colored_row171]
  exact colored_check171 c
#print axioms colored_family171

def coloredWitness172 : Array Nat := #[5308560, 5309280, 5309401, 5310000, 5309523, 5310026, 5310148, 5310720, 5311440, 5312160, 5312281, 5312880, 5313600, 5314320, 5314441, 5315040, 5311466, 5312186, 5313626, 5314346, 5312403, 5312906, 5314563, 5315066, 5315760, 5316480, 5317200, 5317920, 5317226, 5317946, 5318640, 5319360, 5311588, 5313748, 5312308, 5314468, 5312429, 5314589, 5313028, 5315188, 5315881, 5317321, 5316601, 5318041, 5317348, 5318761, 5318068, 5319481, 5316003, 5317443, 5317469, 5318883, 5316723, 5318163, 5318189, 5319603, 5320080, 5320800, 5320921, 5321520, 5321043, 5321546, 5321668, 5322240]

theorem colored_row172 : ∀ c : Fin 64,
    readRow witnessRows (172 * 64 + c.val) = coloredWitness172[c.val]! := by
  decide +kernel
#print axioms colored_row172

theorem colored_check172 : ∀ c : Fin 64,
    checkColored 172 (BitVec.ofNat 6 c.val) (coloredWitness172[c.val]!) = true := by
  decide +kernel
#print axioms colored_check172

theorem colored_family172 : ∀ c : Fin 64,
    checkColored 172 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (172 * 64 + c.val)) = true := by
  intro c
  rw [colored_row172]
  exact colored_check172 c
#print axioms colored_family172

def coloredWitness173 : Array Nat := #[5322960, 5323680, 5323801, 5324400, 5323923, 5324426, 5324548, 5325120, 5325840, 5326560, 5326681, 5327280, 5328000, 5328720, 5328841, 5329440, 5325866, 5326586, 5328026, 5328746, 5326803, 5327306, 5328963, 5329466, 5330160, 5330880, 5331600, 5332320, 5331626, 5332346, 5333040, 5333760, 5325988, 5328148, 5326708, 5328868, 5326829, 5328989, 5327428, 5329588, 5330281, 5331721, 5331001, 5332441, 5331748, 5333161, 5332468, 5333881, 5330403, 5331843, 5331869, 5333283, 5331123, 5332563, 5332589, 5334003, 5334480, 5335200, 5335321, 5335920, 5335443, 5335946, 5336068, 5336640]

theorem colored_row173 : ∀ c : Fin 64,
    readRow witnessRows (173 * 64 + c.val) = coloredWitness173[c.val]! := by
  decide +kernel
#print axioms colored_row173

theorem colored_check173 : ∀ c : Fin 64,
    checkColored 173 (BitVec.ofNat 6 c.val) (coloredWitness173[c.val]!) = true := by
  decide +kernel
#print axioms colored_check173

theorem colored_family173 : ∀ c : Fin 64,
    checkColored 173 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (173 * 64 + c.val)) = true := by
  intro c
  rw [colored_row173]
  exact colored_check173 c
#print axioms colored_family173

def coloredWitness174 : Array Nat := #[5337360, 5338080, 5338201, 5338800, 5339520, 5340240, 5340361, 5340960, 5341680, 5342400, 5342521, 5343120, 5343840, 5344560, 5344681, 5345280, 5346000, 5346720, 5347440, 5348160, 5348880, 5349600, 5350320, 5351040, 5351760, 5352480, 5353200, 5353920, 5354640, 5355360, 5356080, 5356800, 5346121, 5347561, 5346841, 5348281, 5349001, 5350441, 5349721, 5351161, 5351881, 5353321, 5352601, 5354041, 5354761, 5356201, 5355481, 5356921, 5357520, 5358240, 5358361, 5358960, 5359680, 5360400, 5360521, 5361120, 5361840, 5362560, 5362681, 5363280, 5364000, 5364720, 5364841, 5365440]

theorem colored_row174 : ∀ c : Fin 64,
    readRow witnessRows (174 * 64 + c.val) = coloredWitness174[c.val]! := by
  decide +kernel
#print axioms colored_row174

theorem colored_check174 : ∀ c : Fin 64,
    checkColored 174 (BitVec.ofNat 6 c.val) (coloredWitness174[c.val]!) = true := by
  decide +kernel
#print axioms colored_check174

theorem colored_family174 : ∀ c : Fin 64,
    checkColored 174 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (174 * 64 + c.val)) = true := by
  intro c
  rw [colored_row174]
  exact colored_check174 c
#print axioms colored_family174

def coloredWitness175 : Array Nat := #[5366160, 5366880, 5367001, 5367600, 5368320, 5369040, 5369161, 5369760, 5370480, 5371200, 5371321, 5371920, 5372640, 5373360, 5373481, 5374080, 5374800, 5375520, 5376240, 5376960, 5377680, 5378400, 5379120, 5379840, 5380560, 5381280, 5382000, 5382720, 5383440, 5384160, 5384880, 5385600, 5374921, 5376361, 5375641, 5377081, 5377801, 5379241, 5378521, 5379961, 5380681, 5382121, 5381401, 5382841, 5383561, 5385001, 5384281, 5385721, 5386320, 5387040, 5387161, 5387760, 5388480, 5389200, 5389321, 5389920, 5390640, 5391360, 5391481, 5392080, 5392800, 5393520, 5393641, 5394240]

theorem colored_row175 : ∀ c : Fin 64,
    readRow witnessRows (175 * 64 + c.val) = coloredWitness175[c.val]! := by
  decide +kernel
#print axioms colored_row175

theorem colored_check175 : ∀ c : Fin 64,
    checkColored 175 (BitVec.ofNat 6 c.val) (coloredWitness175[c.val]!) = true := by
  decide +kernel
#print axioms colored_check175

theorem colored_family175 : ∀ c : Fin 64,
    checkColored 175 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (175 * 64 + c.val)) = true := by
  intro c
  rw [colored_row175]
  exact colored_check175 c
#print axioms colored_family175

def coloredWitness176 : Array Nat := #[5394960, 5395680, 5396400, 5397120, 5396424, 5397144, 5397840, 5398560, 5399280, 5400000, 5400720, 5401440, 5400744, 5401464, 5402160, 5402880, 5399282, 5400002, 5400722, 5401442, 5400746, 5401466, 5402162, 5402882, 5403600, 5404320, 5405040, 5405760, 5405064, 5405784, 5406480, 5407200, 5407920, 5408640, 5409360, 5410080, 5409384, 5410104, 5410800, 5411520, 5412240, 5412960, 5413680, 5414400, 5413704, 5414424, 5415120, 5415840, 5412242, 5412962, 5413682, 5414402, 5413706, 5414426, 5415122, 5415842, 5416560, 5417280, 5418000, 5418720, 5418024, 5418744, 5419440, 5420160]

theorem colored_row176 : ∀ c : Fin 64,
    readRow witnessRows (176 * 64 + c.val) = coloredWitness176[c.val]! := by
  decide +kernel
#print axioms colored_row176

theorem colored_check176 : ∀ c : Fin 64,
    checkColored 176 (BitVec.ofNat 6 c.val) (coloredWitness176[c.val]!) = true := by
  decide +kernel
#print axioms colored_check176

theorem colored_family176 : ∀ c : Fin 64,
    checkColored 176 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (176 * 64 + c.val)) = true := by
  intro c
  rw [colored_row176]
  exact colored_check176 c
#print axioms colored_family176

def coloredWitness177 : Array Nat := #[5420880, 5421600, 5422320, 5423040, 5422344, 5423064, 5423760, 5424480, 5425200, 5425920, 5426640, 5427360, 5426664, 5427384, 5428080, 5428800, 5425202, 5425922, 5426642, 5427362, 5426666, 5427386, 5428082, 5428802, 5429520, 5430240, 5430960, 5431680, 5430984, 5431704, 5432400, 5433120, 5433840, 5434560, 5435280, 5436000, 5435304, 5436024, 5436720, 5437440, 5438160, 5438880, 5439600, 5440320, 5439624, 5440344, 5441040, 5441760, 5438162, 5438882, 5439602, 5440322, 5439626, 5440346, 5441042, 5441762, 5442480, 5443200, 5443920, 5444640, 5443944, 5444664, 5445360, 5446080]

theorem colored_row177 : ∀ c : Fin 64,
    readRow witnessRows (177 * 64 + c.val) = coloredWitness177[c.val]! := by
  decide +kernel
#print axioms colored_row177

theorem colored_check177 : ∀ c : Fin 64,
    checkColored 177 (BitVec.ofNat 6 c.val) (coloredWitness177[c.val]!) = true := by
  decide +kernel
#print axioms colored_check177

theorem colored_family177 : ∀ c : Fin 64,
    checkColored 177 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (177 * 64 + c.val)) = true := by
  intro c
  rw [colored_row177]
  exact colored_check177 c
#print axioms colored_family177

def coloredWitness178 : Array Nat := #[5446800, 5447520, 5447646, 5448240, 5447766, 5448264, 5448960, 5449680, 5447910, 5449086, 5448408, 5449806, 5448528, 5449926, 5450070, 5450400, 5451120, 5451840, 5451966, 5452560, 5452086, 5452584, 5453280, 5454000, 5452230, 5453406, 5452728, 5454126, 5452848, 5454246, 5454390, 5454720, 5455440, 5456160, 5456286, 5456880, 5456406, 5456904, 5457600, 5458320, 5456550, 5457726, 5457048, 5458446, 5457168, 5458566, 5458710, 5459040, 5459760, 5460480, 5460606, 5461200, 5460726, 5461224, 5461920, 5462640, 5460870, 5462046, 5461368, 5462766, 5461488, 5462886, 5463030, 5463360]

theorem colored_row178 : ∀ c : Fin 64,
    readRow witnessRows (178 * 64 + c.val) = coloredWitness178[c.val]! := by
  decide +kernel
#print axioms colored_row178

theorem colored_check178 : ∀ c : Fin 64,
    checkColored 178 (BitVec.ofNat 6 c.val) (coloredWitness178[c.val]!) = true := by
  decide +kernel
#print axioms colored_check178

theorem colored_family178 : ∀ c : Fin 64,
    checkColored 178 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (178 * 64 + c.val)) = true := by
  intro c
  rw [colored_row178]
  exact colored_check178 c
#print axioms colored_family178

def coloredWitness179 : Array Nat := #[5464080, 5464800, 5464926, 5465520, 5466240, 5466960, 5467680, 5468400, 5466366, 5467806, 5467086, 5468526, 5469120, 5469840, 5469966, 5470560, 5471280, 5472000, 5472126, 5472720, 5473440, 5474160, 5474880, 5475600, 5473566, 5475006, 5474286, 5475726, 5476320, 5477040, 5477166, 5477760, 5478480, 5479200, 5479326, 5479920, 5480640, 5481360, 5482080, 5482800, 5480766, 5482206, 5481486, 5482926, 5483520, 5484240, 5484366, 5484960, 5485680, 5486400, 5486526, 5487120, 5487840, 5488560, 5489280, 5490000, 5487966, 5489406, 5488686, 5490126, 5490720, 5491440, 5491566, 5492160]

theorem colored_row179 : ∀ c : Fin 64,
    readRow witnessRows (179 * 64 + c.val) = coloredWitness179[c.val]! := by
  decide +kernel
#print axioms colored_row179

theorem colored_check179 : ∀ c : Fin 64,
    checkColored 179 (BitVec.ofNat 6 c.val) (coloredWitness179[c.val]!) = true := by
  decide +kernel
#print axioms colored_check179

theorem colored_family179 : ∀ c : Fin 64,
    checkColored 179 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (179 * 64 + c.val)) = true := by
  intro c
  rw [colored_row179]
  exact colored_check179 c
#print axioms colored_family179

def coloredWitness180 : Array Nat := #[5492880, 5493600, 5494320, 5495040, 5495760, 5496480, 5497200, 5497920, 5498640, 5499360, 5500080, 5500800, 5501520, 5502240, 5502960, 5503680, 5504400, 5505120, 5505840, 5506560, 5507280, 5508000, 5508720, 5509440, 5510160, 5510880, 5511600, 5512320, 5513040, 5513760, 5514480, 5515200, 5515920, 5516640, 5517360, 5518080, 5518800, 5519520, 5520240, 5520960, 5521680, 5522400, 5523120, 5523840, 5524560, 5525280, 5526000, 5526720, 5527440, 5528160, 5528880, 5529600, 5530320, 5531040, 5531760, 5532480, 5533200, 5533920, 5534640, 5535360, 5536080, 5536800, 5537520, 5538240]

theorem colored_row180 : ∀ c : Fin 64,
    readRow witnessRows (180 * 64 + c.val) = coloredWitness180[c.val]! := by
  decide +kernel
#print axioms colored_row180

theorem colored_check180 : ∀ c : Fin 64,
    checkColored 180 (BitVec.ofNat 6 c.val) (coloredWitness180[c.val]!) = true := by
  decide +kernel
#print axioms colored_check180

theorem colored_family180 : ∀ c : Fin 64,
    checkColored 180 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (180 * 64 + c.val)) = true := by
  intro c
  rw [colored_row180]
  exact colored_check180 c
#print axioms colored_family180

def coloredWitness181 : Array Nat := #[5538960, 5539680, 5539806, 5540400, 5541120, 5541840, 5542560, 5543280, 5541246, 5542686, 5541966, 5543406, 5544000, 5544720, 5544846, 5545440, 5546160, 5546880, 5547006, 5547600, 5548320, 5549040, 5549760, 5550480, 5548446, 5549886, 5549166, 5550606, 5551200, 5551920, 5552046, 5552640, 5553360, 5554080, 5554206, 5554800, 5555520, 5556240, 5556960, 5557680, 5555646, 5557086, 5556366, 5557806, 5558400, 5559120, 5559246, 5559840, 5560560, 5561280, 5561406, 5562000, 5562720, 5563440, 5564160, 5564880, 5562846, 5564286, 5563566, 5565006, 5565600, 5566320, 5566446, 5567040]

theorem colored_row181 : ∀ c : Fin 64,
    readRow witnessRows (181 * 64 + c.val) = coloredWitness181[c.val]! := by
  decide +kernel
#print axioms colored_row181

theorem colored_check181 : ∀ c : Fin 64,
    checkColored 181 (BitVec.ofNat 6 c.val) (coloredWitness181[c.val]!) = true := by
  decide +kernel
#print axioms colored_check181

theorem colored_family181 : ∀ c : Fin 64,
    checkColored 181 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (181 * 64 + c.val)) = true := by
  intro c
  rw [colored_row181]
  exact colored_check181 c
#print axioms colored_family181

def coloredWitness182 : Array Nat := #[5567760, 5568480, 5569200, 5569920, 5570640, 5571360, 5572080, 5572800, 5573520, 5574240, 5574960, 5575680, 5576400, 5577120, 5577840, 5578560, 5573522, 5574242, 5574962, 5575682, 5576402, 5577122, 5577842, 5578562, 5579280, 5580000, 5580720, 5581440, 5582160, 5582880, 5583600, 5584320, 5585040, 5585760, 5586480, 5587200, 5587920, 5588640, 5589360, 5590080, 5590800, 5591520, 5592240, 5592960, 5593680, 5594400, 5595120, 5595840, 5590802, 5591522, 5592242, 5592962, 5593682, 5594402, 5595122, 5595842, 5596560, 5597280, 5598000, 5598720, 5599440, 5600160, 5600880, 5601600]

theorem colored_row182 : ∀ c : Fin 64,
    readRow witnessRows (182 * 64 + c.val) = coloredWitness182[c.val]! := by
  decide +kernel
#print axioms colored_row182

theorem colored_check182 : ∀ c : Fin 64,
    checkColored 182 (BitVec.ofNat 6 c.val) (coloredWitness182[c.val]!) = true := by
  decide +kernel
#print axioms colored_check182

theorem colored_family182 : ∀ c : Fin 64,
    checkColored 182 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (182 * 64 + c.val)) = true := by
  intro c
  rw [colored_row182]
  exact colored_check182 c
#print axioms colored_family182

def coloredWitness183 : Array Nat := #[5602320, 5603040, 5603760, 5604480, 5605200, 5605920, 5606640, 5607360, 5608080, 5608800, 5609520, 5610240, 5610960, 5611680, 5612400, 5613120, 5608082, 5608802, 5609522, 5610242, 5610962, 5611682, 5612402, 5613122, 5613840, 5614560, 5615280, 5616000, 5616720, 5617440, 5618160, 5618880, 5619600, 5620320, 5621040, 5621760, 5622480, 5623200, 5623920, 5624640, 5625360, 5626080, 5626800, 5627520, 5628240, 5628960, 5629680, 5630400, 5625362, 5626082, 5626802, 5627522, 5628242, 5628962, 5629682, 5630402, 5631120, 5631840, 5632560, 5633280, 5634000, 5634720, 5635440, 5636160]

theorem colored_row183 : ∀ c : Fin 64,
    readRow witnessRows (183 * 64 + c.val) = coloredWitness183[c.val]! := by
  decide +kernel
#print axioms colored_row183

theorem colored_check183 : ∀ c : Fin 64,
    checkColored 183 (BitVec.ofNat 6 c.val) (coloredWitness183[c.val]!) = true := by
  decide +kernel
#print axioms colored_check183

theorem colored_family183 : ∀ c : Fin 64,
    checkColored 183 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (183 * 64 + c.val)) = true := by
  intro c
  rw [colored_row183]
  exact colored_check183 c
#print axioms colored_family183

def coloredWitness184 : Array Nat := #[5636880, 5637600, 5638320, 5639040, 5638344, 5639064, 5639760, 5640480, 5641200, 5641920, 5642640, 5643360, 5642664, 5643384, 5644080, 5644800, 5641202, 5641922, 5642642, 5643362, 5642666, 5643386, 5644082, 5644802, 5645520, 5646240, 5646960, 5647680, 5646984, 5647704, 5648400, 5649120, 5649840, 5650560, 5651280, 5652000, 5651304, 5652024, 5652720, 5653440, 5654160, 5654880, 5655600, 5656320, 5655624, 5656344, 5657040, 5657760, 5654162, 5654882, 5655602, 5656322, 5655626, 5656346, 5657042, 5657762, 5658480, 5659200, 5659920, 5660640, 5659944, 5660664, 5661360, 5662080]

theorem colored_row184 : ∀ c : Fin 64,
    readRow witnessRows (184 * 64 + c.val) = coloredWitness184[c.val]! := by
  decide +kernel
#print axioms colored_row184

theorem colored_check184 : ∀ c : Fin 64,
    checkColored 184 (BitVec.ofNat 6 c.val) (coloredWitness184[c.val]!) = true := by
  decide +kernel
#print axioms colored_check184

theorem colored_family184 : ∀ c : Fin 64,
    checkColored 184 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (184 * 64 + c.val)) = true := by
  intro c
  rw [colored_row184]
  exact colored_check184 c
#print axioms colored_family184

def coloredWitness185 : Array Nat := #[5662800, 5663520, 5664240, 5664960, 5664264, 5664984, 5665680, 5666400, 5667120, 5667840, 5668560, 5669280, 5668584, 5669304, 5670000, 5670720, 5667122, 5667842, 5668562, 5669282, 5668586, 5669306, 5670002, 5670722, 5671440, 5672160, 5672880, 5673600, 5672904, 5673624, 5674320, 5675040, 5675760, 5676480, 5677200, 5677920, 5677224, 5677944, 5678640, 5679360, 5680080, 5680800, 5681520, 5682240, 5681544, 5682264, 5682960, 5683680, 5680082, 5680802, 5681522, 5682242, 5681546, 5682266, 5682962, 5683682, 5684400, 5685120, 5685840, 5686560, 5685864, 5686584, 5687280, 5688000]

theorem colored_row185 : ∀ c : Fin 64,
    readRow witnessRows (185 * 64 + c.val) = coloredWitness185[c.val]! := by
  decide +kernel
#print axioms colored_row185

theorem colored_check185 : ∀ c : Fin 64,
    checkColored 185 (BitVec.ofNat 6 c.val) (coloredWitness185[c.val]!) = true := by
  decide +kernel
#print axioms colored_check185

theorem colored_family185 : ∀ c : Fin 64,
    checkColored 185 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (185 * 64 + c.val)) = true := by
  intro c
  rw [colored_row185]
  exact colored_check185 c
#print axioms colored_family185

def coloredWitness186 : Array Nat := #[5688720, 5689440, 5690160, 5690880, 5691600, 5692320, 5693040, 5693760, 5694480, 5695200, 5695920, 5696640, 5697360, 5698080, 5698800, 5699520, 5700240, 5700960, 5701680, 5702400, 5703120, 5703840, 5704560, 5705280, 5706000, 5706720, 5707440, 5708160, 5708880, 5709600, 5710320, 5711040, 5711760, 5712480, 5713200, 5713920, 5714640, 5715360, 5716080, 5716800, 5717520, 5718240, 5718960, 5719680, 5720400, 5721120, 5721840, 5722560, 5723280, 5724000, 5724720, 5725440, 5726160, 5726880, 5727600, 5728320, 5729040, 5729760, 5730480, 5731200, 5731920, 5732640, 5733360, 5734080]

theorem colored_row186 : ∀ c : Fin 64,
    readRow witnessRows (186 * 64 + c.val) = coloredWitness186[c.val]! := by
  decide +kernel
#print axioms colored_row186

theorem colored_check186 : ∀ c : Fin 64,
    checkColored 186 (BitVec.ofNat 6 c.val) (coloredWitness186[c.val]!) = true := by
  decide +kernel
#print axioms colored_check186

theorem colored_family186 : ∀ c : Fin 64,
    checkColored 186 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (186 * 64 + c.val)) = true := by
  intro c
  rw [colored_row186]
  exact colored_check186 c
#print axioms colored_family186

def coloredWitness187 : Array Nat := #[5734800, 5735520, 5736240, 5736960, 5737680, 5738400, 5739120, 5739840, 5740560, 5741280, 5742000, 5742720, 5743440, 5744160, 5744880, 5745600, 5746320, 5747040, 5747760, 5748480, 5749200, 5749920, 5750640, 5751360, 5752080, 5752800, 5753520, 5754240, 5754960, 5755680, 5756400, 5757120, 5757840, 5758560, 5759280, 5760000, 5760720, 5761440, 5762160, 5762880, 5763600, 5764320, 5765040, 5765760, 5766480, 5767200, 5767920, 5768640, 5769360, 5770080, 5770800, 5771520, 5772240, 5772960, 5773680, 5774400, 5775120, 5775840, 5776560, 5777280, 5778000, 5778720, 5779440, 5780160]

theorem colored_row187 : ∀ c : Fin 64,
    readRow witnessRows (187 * 64 + c.val) = coloredWitness187[c.val]! := by
  decide +kernel
#print axioms colored_row187

theorem colored_check187 : ∀ c : Fin 64,
    checkColored 187 (BitVec.ofNat 6 c.val) (coloredWitness187[c.val]!) = true := by
  decide +kernel
#print axioms colored_check187

theorem colored_family187 : ∀ c : Fin 64,
    checkColored 187 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (187 * 64 + c.val)) = true := by
  intro c
  rw [colored_row187]
  exact colored_check187 c
#print axioms colored_family187

def coloredWitness188 : Array Nat := #[5780880, 5781600, 5782320, 5783040, 5783760, 5784480, 5785200, 5785920, 5786640, 5787360, 5788080, 5788800, 5789520, 5790240, 5790960, 5791680, 5786642, 5787362, 5788082, 5788802, 5789522, 5790242, 5790962, 5791682, 5792400, 5793120, 5793840, 5794560, 5795280, 5796000, 5796720, 5797440, 5798160, 5798880, 5799600, 5800320, 5801040, 5801760, 5802480, 5803200, 5803920, 5804640, 5805360, 5806080, 5806800, 5807520, 5808240, 5808960, 5803922, 5804642, 5805362, 5806082, 5806802, 5807522, 5808242, 5808962, 5809680, 5810400, 5811120, 5811840, 5812560, 5813280, 5814000, 5814720]

theorem colored_row188 : ∀ c : Fin 64,
    readRow witnessRows (188 * 64 + c.val) = coloredWitness188[c.val]! := by
  decide +kernel
#print axioms colored_row188

theorem colored_check188 : ∀ c : Fin 64,
    checkColored 188 (BitVec.ofNat 6 c.val) (coloredWitness188[c.val]!) = true := by
  decide +kernel
#print axioms colored_check188

theorem colored_family188 : ∀ c : Fin 64,
    checkColored 188 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (188 * 64 + c.val)) = true := by
  intro c
  rw [colored_row188]
  exact colored_check188 c
#print axioms colored_family188

def coloredWitness189 : Array Nat := #[5815440, 5816160, 5816880, 5817600, 5818320, 5819040, 5819760, 5820480, 5821200, 5821920, 5822640, 5823360, 5824080, 5824800, 5825520, 5826240, 5821202, 5821922, 5822642, 5823362, 5824082, 5824802, 5825522, 5826242, 5826960, 5827680, 5828400, 5829120, 5829840, 5830560, 5831280, 5832000, 5832720, 5833440, 5834160, 5834880, 5835600, 5836320, 5837040, 5837760, 5838480, 5839200, 5839920, 5840640, 5841360, 5842080, 5842800, 5843520, 5838482, 5839202, 5839922, 5840642, 5841362, 5842082, 5842802, 5843522, 5844240, 5844960, 5845680, 5846400, 5847120, 5847840, 5848560, 5849280]

theorem colored_row189 : ∀ c : Fin 64,
    readRow witnessRows (189 * 64 + c.val) = coloredWitness189[c.val]! := by
  decide +kernel
#print axioms colored_row189

theorem colored_check189 : ∀ c : Fin 64,
    checkColored 189 (BitVec.ofNat 6 c.val) (coloredWitness189[c.val]!) = true := by
  decide +kernel
#print axioms colored_check189

theorem colored_family189 : ∀ c : Fin 64,
    checkColored 189 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (189 * 64 + c.val)) = true := by
  intro c
  rw [colored_row189]
  exact colored_check189 c
#print axioms colored_family189

def coloredWitness190 : Array Nat := #[5850000, 5850720, 5851440, 5852160, 5851464, 5852184, 5852880, 5853600, 5854320, 5855040, 5855760, 5856480, 5855784, 5856504, 5857200, 5857920, 5858640, 5859360, 5860080, 5860800, 5860104, 5860824, 5861520, 5862240, 5862960, 5863680, 5864400, 5865120, 5864424, 5865144, 5865840, 5866560, 5867280, 5868000, 5868720, 5869440, 5868744, 5869464, 5870160, 5870880, 5871600, 5872320, 5873040, 5873760, 5873064, 5873784, 5874480, 5875200, 5875920, 5876640, 5877360, 5878080, 5877384, 5878104, 5878800, 5879520, 5880240, 5880960, 5881680, 5882400, 5881704, 5882424, 5883120, 5883840]

theorem colored_row190 : ∀ c : Fin 64,
    readRow witnessRows (190 * 64 + c.val) = coloredWitness190[c.val]! := by
  decide +kernel
#print axioms colored_row190

theorem colored_check190 : ∀ c : Fin 64,
    checkColored 190 (BitVec.ofNat 6 c.val) (coloredWitness190[c.val]!) = true := by
  decide +kernel
#print axioms colored_check190

theorem colored_family190 : ∀ c : Fin 64,
    checkColored 190 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (190 * 64 + c.val)) = true := by
  intro c
  rw [colored_row190]
  exact colored_check190 c
#print axioms colored_family190

def coloredWitness191 : Array Nat := #[5884560, 5885280, 5886000, 5886720, 5886024, 5886744, 5887440, 5888160, 5888880, 5889600, 5890320, 5891040, 5890344, 5891064, 5891760, 5892480, 5893200, 5893920, 5894640, 5895360, 5894664, 5895384, 5896080, 5896800, 5897520, 5898240, 5898960, 5899680, 5898984, 5899704, 5900400, 5901120, 5901840, 5902560, 5903280, 5904000, 5903304, 5904024, 5904720, 5905440, 5906160, 5906880, 5907600, 5908320, 5907624, 5908344, 5909040, 5909760, 5910480, 5911200, 5911920, 5912640, 5911944, 5912664, 5913360, 5914080, 5914800, 5915520, 5916240, 5916960, 5916264, 5916984, 5917680, 5918400]

theorem colored_row191 : ∀ c : Fin 64,
    readRow witnessRows (191 * 64 + c.val) = coloredWitness191[c.val]! := by
  decide +kernel
#print axioms colored_row191

theorem colored_check191 : ∀ c : Fin 64,
    checkColored 191 (BitVec.ofNat 6 c.val) (coloredWitness191[c.val]!) = true := by
  decide +kernel
#print axioms colored_check191

theorem colored_family191 : ∀ c : Fin 64,
    checkColored 191 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (191 * 64 + c.val)) = true := by
  intro c
  rw [colored_row191]
  exact colored_check191 c
#print axioms colored_family191

end TightCycleC5.Bridge.ColoredCover
