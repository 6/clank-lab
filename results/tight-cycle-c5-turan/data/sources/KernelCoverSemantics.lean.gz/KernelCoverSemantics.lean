import CoverSemantics

/-! A kernel-only route for the same finite witness checker. The existing
compiler-backed cover remains separate until this route's checks pass. -/
namespace TightCycleC5.Bridge.Cover
open Finset MaskEncoding

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_perm_block0 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (0 * 16 + j.val)) (forward (Fin.ofNat 720 (0 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (0 * 16 + j.val)) (backward (Fin.ofNat 720 (0 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block0

theorem kernel_perm_block1 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (1 * 16 + j.val)) (forward (Fin.ofNat 720 (1 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (1 * 16 + j.val)) (backward (Fin.ofNat 720 (1 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block1

theorem kernel_perm_block2 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (2 * 16 + j.val)) (forward (Fin.ofNat 720 (2 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (2 * 16 + j.val)) (backward (Fin.ofNat 720 (2 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block2

theorem kernel_perm_block3 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (3 * 16 + j.val)) (forward (Fin.ofNat 720 (3 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (3 * 16 + j.val)) (backward (Fin.ofNat 720 (3 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block3

theorem kernel_perm_block4 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (4 * 16 + j.val)) (forward (Fin.ofNat 720 (4 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (4 * 16 + j.val)) (backward (Fin.ofNat 720 (4 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block4

theorem kernel_perm_block5 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (5 * 16 + j.val)) (forward (Fin.ofNat 720 (5 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (5 * 16 + j.val)) (backward (Fin.ofNat 720 (5 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block5

theorem kernel_perm_block6 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (6 * 16 + j.val)) (forward (Fin.ofNat 720 (6 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (6 * 16 + j.val)) (backward (Fin.ofNat 720 (6 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block6

theorem kernel_perm_block7 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (7 * 16 + j.val)) (forward (Fin.ofNat 720 (7 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (7 * 16 + j.val)) (backward (Fin.ofNat 720 (7 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block7

theorem kernel_perm_block8 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (8 * 16 + j.val)) (forward (Fin.ofNat 720 (8 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (8 * 16 + j.val)) (backward (Fin.ofNat 720 (8 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block8

theorem kernel_perm_block9 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (9 * 16 + j.val)) (forward (Fin.ofNat 720 (9 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (9 * 16 + j.val)) (backward (Fin.ofNat 720 (9 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block9

theorem kernel_perm_block10 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (10 * 16 + j.val)) (forward (Fin.ofNat 720 (10 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (10 * 16 + j.val)) (backward (Fin.ofNat 720 (10 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block10

theorem kernel_perm_block11 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (11 * 16 + j.val)) (forward (Fin.ofNat 720 (11 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (11 * 16 + j.val)) (backward (Fin.ofNat 720 (11 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block11

theorem kernel_perm_block12 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (12 * 16 + j.val)) (forward (Fin.ofNat 720 (12 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (12 * 16 + j.val)) (backward (Fin.ofNat 720 (12 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block12

theorem kernel_perm_block13 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (13 * 16 + j.val)) (forward (Fin.ofNat 720 (13 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (13 * 16 + j.val)) (backward (Fin.ofNat 720 (13 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block13

theorem kernel_perm_block14 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (14 * 16 + j.val)) (forward (Fin.ofNat 720 (14 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (14 * 16 + j.val)) (backward (Fin.ofNat 720 (14 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block14

theorem kernel_perm_block15 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (15 * 16 + j.val)) (forward (Fin.ofNat 720 (15 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (15 * 16 + j.val)) (backward (Fin.ofNat 720 (15 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block15

theorem kernel_perm_block16 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (16 * 16 + j.val)) (forward (Fin.ofNat 720 (16 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (16 * 16 + j.val)) (backward (Fin.ofNat 720 (16 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block16

theorem kernel_perm_block17 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (17 * 16 + j.val)) (forward (Fin.ofNat 720 (17 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (17 * 16 + j.val)) (backward (Fin.ofNat 720 (17 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block17

theorem kernel_perm_block18 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (18 * 16 + j.val)) (forward (Fin.ofNat 720 (18 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (18 * 16 + j.val)) (backward (Fin.ofNat 720 (18 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block18

theorem kernel_perm_block19 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (19 * 16 + j.val)) (forward (Fin.ofNat 720 (19 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (19 * 16 + j.val)) (backward (Fin.ofNat 720 (19 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block19

theorem kernel_perm_block20 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (20 * 16 + j.val)) (forward (Fin.ofNat 720 (20 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (20 * 16 + j.val)) (backward (Fin.ofNat 720 (20 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block20

theorem kernel_perm_block21 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (21 * 16 + j.val)) (forward (Fin.ofNat 720 (21 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (21 * 16 + j.val)) (backward (Fin.ofNat 720 (21 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block21

theorem kernel_perm_block22 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (22 * 16 + j.val)) (forward (Fin.ofNat 720 (22 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (22 * 16 + j.val)) (backward (Fin.ofNat 720 (22 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block22

theorem kernel_perm_block23 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (23 * 16 + j.val)) (forward (Fin.ofNat 720 (23 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (23 * 16 + j.val)) (backward (Fin.ofNat 720 (23 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block23

theorem kernel_perm_block24 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (24 * 16 + j.val)) (forward (Fin.ofNat 720 (24 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (24 * 16 + j.val)) (backward (Fin.ofNat 720 (24 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block24

theorem kernel_perm_block25 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (25 * 16 + j.val)) (forward (Fin.ofNat 720 (25 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (25 * 16 + j.val)) (backward (Fin.ofNat 720 (25 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block25

theorem kernel_perm_block26 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (26 * 16 + j.val)) (forward (Fin.ofNat 720 (26 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (26 * 16 + j.val)) (backward (Fin.ofNat 720 (26 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block26

theorem kernel_perm_block27 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (27 * 16 + j.val)) (forward (Fin.ofNat 720 (27 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (27 * 16 + j.val)) (backward (Fin.ofNat 720 (27 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block27

theorem kernel_perm_block28 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (28 * 16 + j.val)) (forward (Fin.ofNat 720 (28 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (28 * 16 + j.val)) (backward (Fin.ofNat 720 (28 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block28

theorem kernel_perm_block29 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (29 * 16 + j.val)) (forward (Fin.ofNat 720 (29 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (29 * 16 + j.val)) (backward (Fin.ofNat 720 (29 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block29

theorem kernel_perm_block30 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (30 * 16 + j.val)) (forward (Fin.ofNat 720 (30 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (30 * 16 + j.val)) (backward (Fin.ofNat 720 (30 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block30

theorem kernel_perm_block31 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (31 * 16 + j.val)) (forward (Fin.ofNat 720 (31 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (31 * 16 + j.val)) (backward (Fin.ofNat 720 (31 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block31

theorem kernel_perm_block32 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (32 * 16 + j.val)) (forward (Fin.ofNat 720 (32 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (32 * 16 + j.val)) (backward (Fin.ofNat 720 (32 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block32

theorem kernel_perm_block33 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (33 * 16 + j.val)) (forward (Fin.ofNat 720 (33 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (33 * 16 + j.val)) (backward (Fin.ofNat 720 (33 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block33

theorem kernel_perm_block34 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (34 * 16 + j.val)) (forward (Fin.ofNat 720 (34 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (34 * 16 + j.val)) (backward (Fin.ofNat 720 (34 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block34

theorem kernel_perm_block35 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (35 * 16 + j.val)) (forward (Fin.ofNat 720 (35 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (35 * 16 + j.val)) (backward (Fin.ofNat 720 (35 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block35

theorem kernel_perm_block36 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (36 * 16 + j.val)) (forward (Fin.ofNat 720 (36 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (36 * 16 + j.val)) (backward (Fin.ofNat 720 (36 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block36

theorem kernel_perm_block37 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (37 * 16 + j.val)) (forward (Fin.ofNat 720 (37 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (37 * 16 + j.val)) (backward (Fin.ofNat 720 (37 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block37

theorem kernel_perm_block38 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (38 * 16 + j.val)) (forward (Fin.ofNat 720 (38 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (38 * 16 + j.val)) (backward (Fin.ofNat 720 (38 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block38

theorem kernel_perm_block39 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (39 * 16 + j.val)) (forward (Fin.ofNat 720 (39 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (39 * 16 + j.val)) (backward (Fin.ofNat 720 (39 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block39

theorem kernel_perm_block40 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (40 * 16 + j.val)) (forward (Fin.ofNat 720 (40 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (40 * 16 + j.val)) (backward (Fin.ofNat 720 (40 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block40

theorem kernel_perm_block41 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (41 * 16 + j.val)) (forward (Fin.ofNat 720 (41 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (41 * 16 + j.val)) (backward (Fin.ofNat 720 (41 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block41

theorem kernel_perm_block42 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (42 * 16 + j.val)) (forward (Fin.ofNat 720 (42 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (42 * 16 + j.val)) (backward (Fin.ofNat 720 (42 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block42

theorem kernel_perm_block43 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (43 * 16 + j.val)) (forward (Fin.ofNat 720 (43 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (43 * 16 + j.val)) (backward (Fin.ofNat 720 (43 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block43

theorem kernel_perm_block44 : ∀ (j : Fin 16) (v : Fin 6),
    backward (Fin.ofNat 720 (44 * 16 + j.val)) (forward (Fin.ofNat 720 (44 * 16 + j.val)) v) = v ∧
    forward (Fin.ofNat 720 (44 * 16 + j.val)) (backward (Fin.ofNat 720 (44 * 16 + j.val)) v) = v := by
  decide +kernel
#print axioms kernel_perm_block44

theorem kernel_perm_checks : ∀ (j : Fin 720) (v : Fin 6),
    backward j (forward j v) = v ∧ forward j (backward j v) = v := by
  intro j v
  have blocks : ∀ (b : Fin 45) (c : Fin 16) (v : Fin 6),
      backward (Fin.ofNat 720 (b.val * 16 + c.val)) (forward (Fin.ofNat 720 (b.val * 16 + c.val)) v) = v ∧
      forward (Fin.ofNat 720 (b.val * 16 + c.val)) (backward (Fin.ofNat 720 (b.val * 16 + c.val)) v) = v := by
    intro b
    fin_cases b
    · exact kernel_perm_block0
    · exact kernel_perm_block1
    · exact kernel_perm_block2
    · exact kernel_perm_block3
    · exact kernel_perm_block4
    · exact kernel_perm_block5
    · exact kernel_perm_block6
    · exact kernel_perm_block7
    · exact kernel_perm_block8
    · exact kernel_perm_block9
    · exact kernel_perm_block10
    · exact kernel_perm_block11
    · exact kernel_perm_block12
    · exact kernel_perm_block13
    · exact kernel_perm_block14
    · exact kernel_perm_block15
    · exact kernel_perm_block16
    · exact kernel_perm_block17
    · exact kernel_perm_block18
    · exact kernel_perm_block19
    · exact kernel_perm_block20
    · exact kernel_perm_block21
    · exact kernel_perm_block22
    · exact kernel_perm_block23
    · exact kernel_perm_block24
    · exact kernel_perm_block25
    · exact kernel_perm_block26
    · exact kernel_perm_block27
    · exact kernel_perm_block28
    · exact kernel_perm_block29
    · exact kernel_perm_block30
    · exact kernel_perm_block31
    · exact kernel_perm_block32
    · exact kernel_perm_block33
    · exact kernel_perm_block34
    · exact kernel_perm_block35
    · exact kernel_perm_block36
    · exact kernel_perm_block37
    · exact kernel_perm_block38
    · exact kernel_perm_block39
    · exact kernel_perm_block40
    · exact kernel_perm_block41
    · exact kernel_perm_block42
    · exact kernel_perm_block43
    · exact kernel_perm_block44
  let b : Fin 45 := ⟨j.val / 16, by have := j.isLt; omega⟩
  let c : Fin 16 := ⟨j.val % 16, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 16 + c.val = j.val := by dsimp [b, c]; omega
  have hj : Fin.ofNat 720 (b.val * 16 + c.val) = j := by
    ext
    change (b.val * 16 + c.val) % 720 = j.val
    rw [he, Nat.mod_eq_of_lt j.isLt]
  simpa only [hj] using blocks b c v
#print axioms kernel_perm_checks

theorem kernel_backward_forward : ∀ j v, backward j (forward j v) = v :=
  fun j v => (kernel_perm_checks j v).1
theorem kernel_forward_backward : ∀ j v, forward j (backward j v) = v :=
  fun j v => (kernel_perm_checks j v).2

def kernelPermutation (j : Fin 720) : Equiv.Perm (Fin 6) where
  toFun := forward j
  invFun := backward j
  left_inv := kernel_backward_forward j
  right_inv := kernel_forward_backward j

theorem kernel_triple_block0 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (0 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (0 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block0

theorem kernel_triple_block1 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (1 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (1 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block1

theorem kernel_triple_block2 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (2 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (2 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block2

theorem kernel_triple_block3 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (3 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (3 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block3

theorem kernel_triple_block4 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (4 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (4 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block4

theorem kernel_triple_block5 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (5 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (5 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block5

theorem kernel_triple_block6 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (6 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (6 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block6

theorem kernel_triple_block7 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (7 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (7 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block7

theorem kernel_triple_block8 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (8 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (8 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block8

theorem kernel_triple_block9 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (9 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (9 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block9

theorem kernel_triple_block10 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (10 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (10 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block10

theorem kernel_triple_block11 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (11 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (11 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block11

theorem kernel_triple_block12 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (12 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (12 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block12

theorem kernel_triple_block13 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (13 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (13 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block13

theorem kernel_triple_block14 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (14 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (14 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block14

theorem kernel_triple_block15 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (15 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (15 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block15

theorem kernel_triple_block16 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (16 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (16 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block16

theorem kernel_triple_block17 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (17 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (17 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block17

theorem kernel_triple_block18 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (18 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (18 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block18

theorem kernel_triple_block19 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (19 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (19 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block19

theorem kernel_triple_block20 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (20 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (20 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block20

theorem kernel_triple_block21 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (21 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (21 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block21

theorem kernel_triple_block22 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (22 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (22 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block22

theorem kernel_triple_block23 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (23 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (23 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block23

theorem kernel_triple_block24 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (24 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (24 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block24

theorem kernel_triple_block25 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (25 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (25 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block25

theorem kernel_triple_block26 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (26 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (26 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block26

theorem kernel_triple_block27 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (27 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (27 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block27

theorem kernel_triple_block28 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (28 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (28 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block28

theorem kernel_triple_block29 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (29 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (29 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block29

theorem kernel_triple_block30 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (30 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (30 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block30

theorem kernel_triple_block31 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (31 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (31 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block31

theorem kernel_triple_block32 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (32 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (32 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block32

theorem kernel_triple_block33 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (33 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (33 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block33

theorem kernel_triple_block34 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (34 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (34 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block34

theorem kernel_triple_block35 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (35 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (35 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block35

theorem kernel_triple_block36 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (36 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (36 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block36

theorem kernel_triple_block37 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (37 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (37 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block37

theorem kernel_triple_block38 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (38 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (38 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block38

theorem kernel_triple_block39 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (39 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (39 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block39

theorem kernel_triple_block40 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (40 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (40 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block40

theorem kernel_triple_block41 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (41 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (41 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block41

theorem kernel_triple_block42 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (42 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (42 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block42

theorem kernel_triple_block43 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (43 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (43 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block43

theorem kernel_triple_block44 : ∀ (j : Fin 16) (i : Fin 20),
    tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (44 * 16 + j.val))).symm.toEmbedding) =
      inverseTripleIndex (Fin.ofNat 720 (44 * 16 + j.val)) i := by decide +kernel
#print axioms kernel_triple_block44

theorem kernel_inverse_triple_correct : ∀ j i,
    tripleIndex ((tripleAt i).map (kernelPermutation j).symm.toEmbedding) =
      inverseTripleIndex j i := by
  intro j i
  have blocks : ∀ (b : Fin 45) (c : Fin 16) (i : Fin 20),
      tripleIndex ((tripleAt i).map (kernelPermutation (Fin.ofNat 720 (b.val * 16 + c.val))).symm.toEmbedding) =
        inverseTripleIndex (Fin.ofNat 720 (b.val * 16 + c.val)) i := by
    intro b
    fin_cases b
    · exact kernel_triple_block0
    · exact kernel_triple_block1
    · exact kernel_triple_block2
    · exact kernel_triple_block3
    · exact kernel_triple_block4
    · exact kernel_triple_block5
    · exact kernel_triple_block6
    · exact kernel_triple_block7
    · exact kernel_triple_block8
    · exact kernel_triple_block9
    · exact kernel_triple_block10
    · exact kernel_triple_block11
    · exact kernel_triple_block12
    · exact kernel_triple_block13
    · exact kernel_triple_block14
    · exact kernel_triple_block15
    · exact kernel_triple_block16
    · exact kernel_triple_block17
    · exact kernel_triple_block18
    · exact kernel_triple_block19
    · exact kernel_triple_block20
    · exact kernel_triple_block21
    · exact kernel_triple_block22
    · exact kernel_triple_block23
    · exact kernel_triple_block24
    · exact kernel_triple_block25
    · exact kernel_triple_block26
    · exact kernel_triple_block27
    · exact kernel_triple_block28
    · exact kernel_triple_block29
    · exact kernel_triple_block30
    · exact kernel_triple_block31
    · exact kernel_triple_block32
    · exact kernel_triple_block33
    · exact kernel_triple_block34
    · exact kernel_triple_block35
    · exact kernel_triple_block36
    · exact kernel_triple_block37
    · exact kernel_triple_block38
    · exact kernel_triple_block39
    · exact kernel_triple_block40
    · exact kernel_triple_block41
    · exact kernel_triple_block42
    · exact kernel_triple_block43
    · exact kernel_triple_block44
  let b : Fin 45 := ⟨j.val / 16, by have := j.isLt; omega⟩
  let c : Fin 16 := ⟨j.val % 16, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 16 + c.val = j.val := by dsimp [b, c]; omega
  have hj : Fin.ofNat 720 (b.val * 16 + c.val) = j := by
    ext
    change (b.val * 16 + c.val) % 720 = j.val
    rw [he, Nat.mod_eq_of_lt j.isLt]
  simpa only [hj] using blocks b c i

theorem kernel_fastPermute_eq (j : Fin 720) (m : BitVec 20) :
    fastPermute j m = permuteMask (kernelPermutation j) m := by
  apply BitVec.eq_of_getLsbD_eq
  intro i hi
  rw [fastPermute_bit j m ⟨i, hi⟩]
  change _ = (graphCode (kernelPermutation j • decodeStructure m 0)).getLsbD i
  rw [graphCode_bit _ ⟨i, hi⟩]
  change _ = (decodeStructure m 0).edge ((tripleAt ⟨i, hi⟩).map (kernelPermutation j).symm.toEmbedding)
  simp only [decodeStructure, card_map, tripleAt_card, ↓reduceIte, kernel_inverse_triple_correct]

def kernelCycleEmbedding (c : Fin 72) : Fin 5 ↪ Fin 6 :=
  (Fin.castLEEmb (by decide : 5 ≤ 6)).trans (kernelPermutation (cyclePermutation c)).toEmbedding

theorem kernel_cycle_bit_present : ∀ (c : Fin 72) (i : Fin 5),
    cycleMasks[c.val]!.testBit
      (tripleIndex {kernelCycleEmbedding c i, kernelCycleEmbedding c (i + 1),
        kernelCycleEmbedding c (i + 2)}) = true := by decide +kernel

theorem kernel_cycleMask_sound (c : Fin 72) (m : BitVec 20)
    (h : m.toNat &&& cycleMasks[c.val]! = cycleMasks[c.val]!) : CodeContainsC5 m := by
  refine ⟨kernelCycleEmbedding c, fun i => ?_⟩
  have ht := congrArg (fun t : Nat => t.testBit
    (tripleIndex {kernelCycleEmbedding c i, kernelCycleEmbedding c (i + 1),
      kernelCycleEmbedding c (i + 2)})) h
  rw [Nat.testBit_and, kernel_cycle_bit_present c i] at ht
  simpa only [Bool.and_true, BitVec.getLsbD] using ht

theorem kernel_witness_sound (m : BitVec 20) (w : Nat) (h : checkWitness m w = true) :
    CodeContainsC5 m ∨ ∃ k : Fin 835, ∃ p : Equiv.Perm (Fin 6),
      m = permuteMask p (representative k) := by
  by_cases hw : w < 72
  · left
    apply kernel_cycleMask_sound ⟨w, hw⟩ m
    exact of_decide_eq_true (by simpa only [checkWitness, if_pos hw] using h)
  · right
    refine ⟨witnessClass w, kernelPermutation (witnessPermutation w), ?_⟩
    have he : fastPermute (witnessPermutation w) (representative (witnessClass w)) = m :=
      of_decide_eq_true (by simpa only [checkWitness, if_neg hw] using h)
    rw [kernel_fastPermute_eq] at he
    exact he.symm

def readKernelWitness (rows : Array (Array Nat)) (i : Nat) : Nat :=
  (rows[i / 256]!)[i % 256]!

def kernelShardCheck (shard : Nat) (rows : Array (Array Nat)) : Prop :=
  ∀ i : Fin 32768,
    checkWitness (BitVec.ofNat 20 (shard * 32768 + i.val)) (readKernelWitness rows i.val) = true

#print axioms kernel_backward_forward
#print axioms kernel_forward_backward
#print axioms kernel_inverse_triple_correct
#print axioms kernel_fastPermute_eq
#print axioms kernel_cycle_bit_present
#print axioms kernel_cycleMask_sound
#print axioms kernel_witness_sound
end TightCycleC5.Bridge.Cover
