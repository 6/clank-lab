import RandomSelector

/-! Independent Bernoulli product marginalization used in PROOF Lemma 8.
All equalities are finite algebra and do not need probability bounds. -/
namespace TightCycleC5.Bridge
open Finset

noncomputable def finsetBoolEquiv {A : Type*} [Fintype A] [DecidableEq A] :
    Finset A ≃ (A → Bool) where
  toFun S a := decide (a ∈ S)
  invFun b := univ.filter (fun a => b a = true)
  left_inv S := by ext a; simp
  right_inv b := by funext a; simp

theorem bernoulli_sum_product {A : Type*} [Fintype A] [DecidableEq A]
    (q : A → Bool → ℝ) :
    (∑ S : Finset A, ∏ a, q a (decide (a ∈ S))) = ∏ a, (q a false + q a true) := by
  classical
  have h := Equiv.sum_comp (finsetBoolEquiv (A := A)) (fun b : A → Bool => ∏ a, q a (b a))
  change (∑ S : Finset A, ∏ a, q a (decide (a ∈ S))) = _ at h
  rw [h, ← Fintype.prod_sum]
  apply Finset.prod_congr rfl
  intro a _
  simp [add_comm]

/-- The total weight of all global cuts with one specified local outcome
on e is the product of the specified local probabilities. -/
theorem bernoulli_fixed_outcome {n : ℕ} (π : Fin n → ℝ)
    (e T : Finset (Fin n)) (hT : T ⊆ e) :
    (∑ S : Finset (Fin n), HelperG.Random.wt π S *
      (if e ∩ S = T then 1 else 0)) =
      (∏ a ∈ T, π a) * ∏ a ∈ e \ T, (1 - π a) := by
  classical
  let q : Fin n → Bool → ℝ := fun a b =>
    (if b then π a else 1 - π a) *
      (if a ∈ e → b = decide (a ∈ T) then 1 else 0)
  have he : ∀ S : Finset (Fin n),
      (∀ a : Fin n, a ∈ e → decide (a ∈ S) = decide (a ∈ T)) ↔ e ∩ S = T := by
    intro S
    constructor
    · intro h
      ext a
      by_cases hae : a ∈ e
      · have hh : (a ∈ S) ↔ a ∈ T := by simpa using h a hae
        simp [hae, hh]
      · have hat : a ∉ T := fun h => hae (hT h)
        simp [hae, hat]
    · intro h a hae
      have hh : (a ∈ S) ↔ a ∈ T := by
        have := congrArg (fun U : Finset (Fin n) => a ∈ U) h
        simpa [hae] using this
      simp only [Bool.decide_congr hh]
  have hp : ∀ S : Finset (Fin n), ∏ a, q a (decide (a ∈ S)) =
      HelperG.Random.wt π S * (if e ∩ S = T then 1 else 0) := by
    intro S
    simp only [q, Finset.prod_mul_distrib, Fintype.prod_boole, he,
      decide_eq_true_eq, HelperG.Random.wt]
  have hlocal : ∀ a, q a false + q a true =
      if a ∈ T then π a else if a ∈ e \ T then 1 - π a else 1 := by
    intro a
    by_cases ht : a ∈ T
    · have he := hT ht
      simp [q, ht, he]
    · by_cases he : a ∈ e <;> simp [q, ht, he]
  have h := bernoulli_sum_product q
  simp_rw [hp, hlocal] at h
  rw [h]
  rw [Finset.prod_ite]
  simp only [Finset.filter_mem_eq_inter, univ_inter]
  have heq : (∏ a ∈ univ.filter (fun a => a ∉ T),
      if a ∈ e \ T then 1 - π a else 1) = ∏ a ∈ e \ T, (1 - π a) := by
    rw [Finset.prod_ite]
    simp only [Finset.prod_const_one, mul_one]
    apply Finset.prod_congr
    · ext a
      simp only [mem_filter, mem_univ, mem_sdiff, true_and]
      tauto
    · intro a _
      rfl
  rw [heq]

#print axioms bernoulli_sum_product
#print axioms bernoulli_fixed_outcome
end TightCycleC5.Bridge
