import P33PSDSeed23Data

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33PSD

theorem seed23_weights : ∀ k, 0 ≤ weight23 k := by decide +kernel
theorem seed23_gram : (fun i j => (seed23 i j : ℚ)) =
    rationalGram weight23 vec23 := by native_decide
theorem seed23_psd : (intMatrixReal seed23).PosSemidef :=
  rational_gram_posSemidef seed23 weight23 vec23 seed23_weights seed23_gram

def changedSeed23 : Matrix (Fin 100) (Fin 100) ℤ :=
  fun i j => seed23 i j + if i = 0 ∧ j = 0 then 1 else 0
theorem seed23_rejects_corruption :
    (fun i j => (changedSeed23 i j : ℚ)) ≠ rationalGram weight23 vec23 := by native_decide

#print axioms seed23_weights
#print axioms seed23_gram
#print axioms seed23_psd
#print axioms seed23_rejects_corruption
end TightCycleC5.Bridge.P33PSD
