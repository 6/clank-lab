import SelectorCertificate
import P32SelectorData

/-! The actual nine P32 selectors, with exact data bounds and normalized
weights. All finite data checks in this group use kernel reduction. -/
namespace TightCycleC5.Bridge.P32Selector
open Finset
set_option maxRecDepth 100000

def inputBounds (P W : Int) (roots : Array Int) (ps : Array (Array Int))
    (ws : Array Int) : Prop :=
  0 < P ∧ 0 < W ∧ roots.size = 9 ∧ ps.size = 9 ∧ ws.size = 9 ∧
    (∑ j : Fin 9, ws[j.val]!) = W ∧ ∀ j : Fin 9,
      (roots[j.val]! = 0 ∨ roots[j.val]! = 1) ∧ 0 ≤ ws[j.val]! ∧
      ps[j.val]!.size = 8 ∧ ∀ p : Fin 8, 0 ≤ (ps[j.val]!)[p.val]! ∧ (ps[j.val]!)[p.val]! ≤ P

set_option maxHeartbeats 0 in
theorem checked_data : inputBounds probabilityScale weightScale rootCodes probabilities weights := by
  unfold inputBounds
  decide +kernel

theorem probabilityScale_pos : 0 < probabilityScale := checked_data.1
theorem weightScale_pos : 0 < weightScale := checked_data.2.1

def rootEdge (j : Fin 9) : Bool := decide (rootCodes[j.val]! = 1)

theorem rootEdge_exact (j : Fin 9) : ((rootEdge j).toNat : Int) = rootCodes[j.val]! := by
  have h := (checked_data.2.2.2.2.2.2 j).1
  rcases h with h | h <;> simp [rootEdge, h]

noncomputable def probability (j : Fin 9) (p : Fin 8) : ℝ :=
  ((probabilities[j.val]!)[p.val]! : ℝ) / (probabilityScale : ℝ)

theorem probability_bounds (j : Fin 9) (p : Fin 8) :
    0 ≤ probability j p ∧ probability j p ≤ 1 := by
  have hp := (checked_data.2.2.2.2.2.2 j).2.2.2 p
  have hP : (0 : ℝ) < probabilityScale := by exact_mod_cast probabilityScale_pos
  have h0 : (0 : ℝ) ≤ (probabilities[j.val]!)[p.val]! := by exact_mod_cast hp.1
  have h1 : ((probabilities[j.val]!)[p.val]! : ℝ) ≤ probabilityScale := by exact_mod_cast hp.2
  constructor
  · exact div_nonneg h0 hP.le
  · exact (div_le_one hP).2 h1

noncomputable def weight (j : Fin 9) : ℝ := (weights[j.val]! : ℝ) / (weightScale : ℝ)

theorem weight_nonneg (j : Fin 9) : 0 ≤ weight j := by
  apply div_nonneg
  · exact_mod_cast (checked_data.2.2.2.2.2.2 j).2.1
  · exact_mod_cast weightScale_pos.le

theorem weights_sum : (∑ j : Fin 9, weight j) = 1 := by
  have hsum := checked_data.2.2.2.2.2.1
  have hsumR : (∑ j : Fin 9, (weights[j.val]! : ℝ)) = (weightScale : ℝ) := by
    exact_mod_cast hsum
  unfold weight
  rw [← Finset.sum_div, hsumR, div_self]
  exact ne_of_gt (by exact_mod_cast weightScale_pos : (0 : ℝ) < weightScale)

noncomputable def descriptor (j : Fin 9) : SelectorCertificate.Descriptor :=
  ⟨rootEdge j, probability j⟩

theorem numerator_mean_le {n : Nat} (j : Fin 9) (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (S : Finset (Fin n)) :
    uniformMean (fun σ : Fin 6 ↪ Fin n =>
      SelectorCertificate.numerator (descriptor j) (sampleStructure σ H S)) ≤
      6 * selectorD (SelectorCertificate.rootIndicator (descriptor j) H) * (maxCut H : ℝ) /
        ((n - 3).descFactorial 3 : ℝ) :=
  SelectorCertificate.numerator_mean_le (descriptor j)
    (fun p => (probability_bounds j p).1) (fun p => (probability_bounds j p).2) H hH S

noncomputable def margin (G : LabelledStructure 6) : ℝ :=
  ∑ j : Fin 9, weight j * (SelectorCertificate.numerator (descriptor j) G -
    (2 / 5 : ℝ) * SelectorCertificate.denominator (descriptor j) G)

theorem margin_mean {n : Nat} (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (hn : 6 ≤ n) :
    uniformMean (fun σ : Fin 6 ↪ Fin n => margin (sampleStructure σ H S)) =
      ∑ j : Fin 9, weight j *
        (selectorN H (SelectorCertificate.rootIndicator (descriptor j) H)
          (SelectorCertificate.probabilities (descriptor j) H) -
          (2 / 5 : ℝ) * selectorD (SelectorCertificate.rootIndicator (descriptor j) H)) := by
  have hmean : uniformMean (fun σ : Fin 6 ↪ Fin n => margin (sampleStructure σ H S)) =
      ∑ j : Fin 9, weight j *
        (uniformMean (fun σ : Fin 6 ↪ Fin n =>
          SelectorCertificate.numerator (descriptor j) (sampleStructure σ H S)) -
          (2 / 5 : ℝ) * uniformMean (fun σ : Fin 6 ↪ Fin n =>
            SelectorCertificate.denominator (descriptor j) (sampleStructure σ H S))) := by
    unfold uniformMean margin
    rw [Finset.sum_comm]
    rw [Finset.sum_div]
    apply Finset.sum_congr rfl
    intro j _
    simp_rw [mul_sub, Finset.sum_sub_distrib, ← Finset.mul_sum]
    ring
  rw [hmean]
  simp_rw [SelectorCertificate.numerator_mean, SelectorCertificate.denominator_mean _ _ _ hn]

theorem positive_margin_selector {n : Nat} (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (hn : 6 ≤ n)
    (hpositive : 0 < uniformMean (fun σ : Fin 6 ↪ Fin n => margin (sampleStructure σ H S))) :
    ∃ j : Fin 9,
      (2 / 5 : ℝ) * selectorD (SelectorCertificate.rootIndicator (descriptor j) H) <
        selectorN H (SelectorCertificate.rootIndicator (descriptor j) H)
          (SelectorCertificate.probabilities (descriptor j) H) := by
  rw [margin_mean H S hn] at hpositive
  by_contra h
  push Not at h
  have hsum : (∑ j : Fin 9, weight j *
      (selectorN H (SelectorCertificate.rootIndicator (descriptor j) H)
        (SelectorCertificate.probabilities (descriptor j) H) -
        (2 / 5 : ℝ) * selectorD (SelectorCertificate.rootIndicator (descriptor j) H))) ≤ 0 := by
    apply Finset.sum_nonpos
    intro j _
    exact mul_nonpos_of_nonneg_of_nonpos (weight_nonneg j) (sub_nonpos.mpr (h j))
  linarith

set_option maxHeartbeats 0 in
theorem rejects_negative_probability :
    ¬ inputBounds probabilityScale weightScale rootCodes
      (probabilities.set! 0 (probabilities[0]!.set! 0 (-1))) weights := by
  unfold inputBounds
  decide +kernel

#print axioms checked_data
#print axioms probabilityScale_pos
#print axioms weightScale_pos
#print axioms rootEdge_exact
#print axioms probability_bounds
#print axioms weight_nonneg
#print axioms weights_sum
#print axioms numerator_mean_le
#print axioms margin_mean
#print axioms positive_margin_selector
#print axioms rejects_negative_probability
end TightCycleC5.Bridge.P32Selector
