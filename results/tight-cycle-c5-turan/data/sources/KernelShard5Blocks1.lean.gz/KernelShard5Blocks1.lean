import KernelRowIndex
import KernelWitness5

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_5_32 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 32 * 256 + i.val))
      kernelWitness5Row32[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_32

theorem kernelBlock_5_33 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 33 * 256 + i.val))
      kernelWitness5Row33[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_33

theorem kernelBlock_5_34 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 34 * 256 + i.val))
      kernelWitness5Row34[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_34

theorem kernelBlock_5_35 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 35 * 256 + i.val))
      kernelWitness5Row35[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_35

theorem kernelBlock_5_36 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 36 * 256 + i.val))
      kernelWitness5Row36[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_36

theorem kernelBlock_5_37 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 37 * 256 + i.val))
      kernelWitness5Row37[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_37

theorem kernelBlock_5_38 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 38 * 256 + i.val))
      kernelWitness5Row38[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_38

theorem kernelBlock_5_39 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 39 * 256 + i.val))
      kernelWitness5Row39[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_39

theorem kernelBlock_5_40 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 40 * 256 + i.val))
      kernelWitness5Row40[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_40

theorem kernelBlock_5_41 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 41 * 256 + i.val))
      kernelWitness5Row41[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_41

theorem kernelBlock_5_42 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 42 * 256 + i.val))
      kernelWitness5Row42[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_42

theorem kernelBlock_5_43 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 43 * 256 + i.val))
      kernelWitness5Row43[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_43

theorem kernelBlock_5_44 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 44 * 256 + i.val))
      kernelWitness5Row44[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_44

theorem kernelBlock_5_45 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 45 * 256 + i.val))
      kernelWitness5Row45[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_45

theorem kernelBlock_5_46 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 46 * 256 + i.val))
      kernelWitness5Row46[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_46

theorem kernelBlock_5_47 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 47 * 256 + i.val))
      kernelWitness5Row47[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_47

theorem kernelBlock_5_48 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 48 * 256 + i.val))
      kernelWitness5Row48[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_48

theorem kernelBlock_5_49 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 49 * 256 + i.val))
      kernelWitness5Row49[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_49

theorem kernelBlock_5_50 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 50 * 256 + i.val))
      kernelWitness5Row50[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_50

theorem kernelBlock_5_51 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 51 * 256 + i.val))
      kernelWitness5Row51[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_51

theorem kernelBlock_5_52 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 52 * 256 + i.val))
      kernelWitness5Row52[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_52

theorem kernelBlock_5_53 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 53 * 256 + i.val))
      kernelWitness5Row53[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_53

theorem kernelBlock_5_54 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 54 * 256 + i.val))
      kernelWitness5Row54[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_54

theorem kernelBlock_5_55 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 55 * 256 + i.val))
      kernelWitness5Row55[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_55

theorem kernelBlock_5_56 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 56 * 256 + i.val))
      kernelWitness5Row56[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_56

theorem kernelBlock_5_57 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 57 * 256 + i.val))
      kernelWitness5Row57[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_57

theorem kernelBlock_5_58 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 58 * 256 + i.val))
      kernelWitness5Row58[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_58

theorem kernelBlock_5_59 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 59 * 256 + i.val))
      kernelWitness5Row59[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_59

theorem kernelBlock_5_60 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 60 * 256 + i.val))
      kernelWitness5Row60[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_60

theorem kernelBlock_5_61 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 61 * 256 + i.val))
      kernelWitness5Row61[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_61

theorem kernelBlock_5_62 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 62 * 256 + i.val))
      kernelWitness5Row62[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_62

theorem kernelBlock_5_63 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (5 * 32768 + 63 * 256 + i.val))
      kernelWitness5Row63[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_5_63

end TightCycleC5.Bridge.Cover
