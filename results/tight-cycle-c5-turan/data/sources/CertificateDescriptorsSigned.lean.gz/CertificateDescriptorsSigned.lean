import CertificateDescriptorsData
import Mathlib
namespace TightCycleC5.Bridge.CertificateDescriptors
set_option maxRecDepth 10000
set_option maxHeartbeats 4000000

-- Each kernel reduction touches at most one 128-entry signed block.
theorem p32_blocks_nonneg (b : Fin 75) :
    (p32YBlocks[b.val]!).all (fun z => decide (0 ≤ z)) = true := by
  fin_cases b <;> decide +kernel

theorem p33a_blocks_nonneg (b : Fin 101) :
    (p33aYBlocks[b.val]!).all (fun z => decide (0 ≤ z)) = true := by
  fin_cases b <;> decide +kernel

theorem p33b_blocks_nonneg (b : Fin 101) :
    (p33bYBlocks[b.val]!).all (fun z => decide (0 ≤ z)) = true := by
  fin_cases b <;> decide +kernel

#print axioms p32_blocks_nonneg
#print axioms p33a_blocks_nonneg
#print axioms p33b_blocks_nonneg
end TightCycleC5.Bridge.CertificateDescriptors
