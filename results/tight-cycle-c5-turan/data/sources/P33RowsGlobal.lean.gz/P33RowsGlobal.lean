import P33RowsBounds
import TargetNormalization

namespace TightCycleC5.Bridge.P33Rows
open Finset

noncomputable def densityBound : ℝ := 464101615 / 1000000000

def globalCode {V : Type*} (e : EdgeFn V) (c : ColorFn V) (a b d : V) : Nat :=
  8 * (e a b d).toNat + 2 ^ ((c a).toNat + (c b).toNat + (c d).toNat) - 1

def globalFlag {V : Type*} (flag : Nat) (e : EdgeFn V) (c : ColorFn V) (a b d : V) : ℝ :=
  if globalCode e c a b d = flag then 1 else 0

def densityFlag {V : Type*} (flag : Option Nat) (e : EdgeFn V) (c : ColorFn V)
    (a b d : V) : ℝ := match flag with
  | none => 1
  | some f => globalFlag f e c a b d

def cutValue {V : Type*} (e : EdgeFn V) (c : ColorFn V) (x u v : V) : ℝ :=
  if e x u v = true ∧ (c x).toNat + (c u).toNat + (c v).toNat = 1 then 1 else 0

def edgeValue {V : Type*} (e : EdgeFn V) (x u v : V) : ℝ := if e x u v then 1 else 0

noncomputable def cutRow (flag : Nat) (G : LabelledStructure 6) : ℝ :=
  (cutValue (fun x u v => G.edge {x,u,v}) G.color 0 1 2 - 2 / 5) *
    globalFlag flag (fun x u v => G.edge {x,u,v}) G.color 3 4 5

noncomputable def densityRow (flag : Option Nat) (G : LabelledStructure 6) : ℝ :=
  (edgeValue (fun x u v => G.edge {x,u,v}) 0 1 2 - densityBound) *
    densityFlag flag (fun x u v => G.edge {x,u,v}) G.color 3 4 5

theorem globalFlag_zero_one {V : Type*} (flag : Nat) (e : EdgeFn V) (c : ColorFn V)
    (a b d : V) : globalFlag flag e c a b d = 0 ∨ globalFlag flag e c a b d = 1 := by
  unfold globalFlag
  split_ifs <;> simp

theorem densityFlag_zero_one {V : Type*} (flag : Option Nat) (e : EdgeFn V) (c : ColorFn V)
    (a b d : V) : densityFlag flag e c a b d = 0 ∨ densityFlag flag e c a b d = 1 := by
  cases flag with
  | none => simp [densityFlag]
  | some f => exact globalFlag_zero_one f e c a b d

/-- Outside-colour count one is exactly cut-intersection size two.
Distinctness is explicit; repeated vertices are not silently counted thrice. -/
theorem cutValue_actual {n : Nat} (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (x u v : Fin n)
    (hxu : x ≠ u) (hxv : x ≠ v) (huv : u ≠ v) :
    cutValue (actualEdge H) (actualColor S) x u v =
      if ({x,u,v} : Finset (Fin n)) ∈ H ∧ (({x,u,v} : Finset (Fin n)) ∩ S).card = 2
        then 1 else 0 := by
  by_cases he : ({x,u,v} : Finset (Fin n)) ∈ H <;>
    by_cases hx : x ∈ S <;> by_cases hu : u ∈ S <;> by_cases hv : v ∈ S <;>
    simp [cutValue, actualEdge, actualColor, he, hx, hu, hv,
      hxu, hxv, huv]

noncomputable def cutTriple {n : Nat} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (t : Triple n) : ℝ := cutValue (actualEdge H) (actualColor S) (t 0) (t 1) (t 2)
noncomputable def edgeTriple {n : Nat} (H : Finset (Finset (Fin n)))
    (t : Triple n) : ℝ := edgeValue (actualEdge H) (t 0) (t 1) (t 2)
noncomputable def flagTriple {n : Nat} (flag : Option Nat)
    (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) (t : Triple n) : ℝ :=
  densityFlag flag (actualEdge H) (actualColor S) (t 0) (t 1) (t 2)

noncomputable def tripleRatio (n : Nat) : ℝ :=
  (n : ℝ) * ((n : ℝ) - 1) * ((n : ℝ) - 2) /
    (((n : ℝ) - 3) * ((n : ℝ) - 4) * ((n : ℝ) - 5))
noncomputable def tripleError (n : Nat) : ℝ :=
  (9 * (n : ℝ) ^ 2 - 45 * (n : ℝ) + 60) /
    (((n : ℝ) - 3) * ((n : ℝ) - 4) * ((n : ℝ) - 5))

theorem centered_abs_le (v threshold : ℝ) (hv : v = 0 ∨ v = 1)
    (ht0 : 0 ≤ threshold) (ht1 : threshold ≤ 1) : |v - threshold| ≤ 1 := by
  rcases hv with rfl | rfl <;> rw [abs_le] <;> constructor <;> linarith

theorem mean_sub_const {Ω : Type*} [Fintype Ω] [Nonempty Ω] (f : Ω → ℝ) (a : ℝ) :
    uniformMean (fun x => f x - a) = uniformMean f - a := by
  have he : uniformMean (fun _x : Ω => a) = a := uniformMean_const a
  unfold uniformMean at *
  rw [sum_sub_distrib, sub_div, he]

/-- Exact Lemma 4 consequence with the finite deficit hypothesis retained. -/
theorem triple_flag_lower {n : Nat} (hn : 12 ≤ n) (g F : Triple n → ℝ)
    (hg : ∀ t, |g t| ≤ 1) (hF : ∀ t, F t = 0 ∨ F t = 1)
    (δ : ℝ) (hδ : 0 ≤ δ) (hm : -δ ≤ uniformMean g) :
    -tripleRatio n * δ - tripleError n ≤ uniformMean (sixTripleProduct g F) := by
  classical
  letI : Nonempty (Triple n) := ⟨Fin.castLEEmb (by omega : 3 ≤ n)⟩
  have hf0 : ∀ t, 0 ≤ F t := by intro t; rcases hF t with h | h <;> norm_num [h]
  have hf1 : ∀ t, |F t| ≤ 1 := by intro t; rcases hF t with h | h <;> norm_num [h]
  have hμ0 : 0 ≤ uniformMean F := uniformMean_nonneg hf0
  have hμ1 : uniformMean F ≤ 1 :=
    (le_abs_self _).trans (uniformMean_abs_le_const F 1 hf1)
  have hp : -δ ≤ uniformMean g * uniformMean F := by
    have h1 := mul_le_mul_of_nonneg_right hm hμ0
    have h2 := mul_le_mul_of_nonpos_left hμ1 (neg_nonpos.mpr hδ)
    nlinarith
  have hnR : (12 : ℝ) ≤ n := by exact_mod_cast hn
  have hρ : 0 ≤ tripleRatio n := by
    unfold tripleRatio
    exact div_nonneg (mul_nonneg (mul_nonneg (by linarith) (by linarith)) (by linarith))
      (mul_nonneg (mul_nonneg (by linarith) (by linarith)) (by linarith))
  obtain ⟨ε, he, hε⟩ := disjoint_triple_product hn g F hg hf1
  change uniformMean (sixTripleProduct g F) = tripleRatio n * uniformMean g * uniformMean F - ε at he
  change |ε| ≤ tripleError n at hε
  have hs := mul_le_mul_of_nonneg_left hp hρ
  have heps := (le_abs_self ε).trans hε
  rw [he]
  nlinarith

/-- Fin 3 injections name the actual three-element set in their label order. -/
theorem embeddingSet_three {n : Nat} (t : Triple n) : embeddingSet t = {t 0,t 1,t 2} := by
  ext x
  simp only [embeddingSet, mem_map, mem_univ, true_and, mem_insert, mem_singleton]
  constructor
  · rintro ⟨i,rfl⟩
    fin_cases i <;> simp
  · rintro (rfl | rfl | rfl)
    · exact ⟨0,rfl⟩
    · exact ⟨1,rfl⟩
    · exact ⟨2,rfl⟩

theorem cutTriple_mean {n : Nat} (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (S : Finset (Fin n)) :
    uniformMean (cutTriple H S) = (cutCount H S : ℝ) / (n.choose 3 : ℝ) := by
  have he : cutTriple H S = fun t : Triple n =>
      if embeddingSet t ∈ H ∧ (embeddingSet t ∩ S).card = 2 then (1 : ℝ) else 0 := by
    funext t
    rw [embeddingSet_three]
    exact cutValue_actual H S _ _ _
      (t.injective.ne (by decide)) (t.injective.ne (by decide)) (t.injective.ne (by decide))
  rw [he, embeddingSet_mean 3 (fun e : Finset (Fin n) =>
    if e ∈ H ∧ (e ∩ S).card = 2 then (1 : ℝ) else 0)]
  simp only [Fintype.card_fin]
  congr 1
  have hf : ∀ e : Finset (Fin n),
      (if e ∈ H ∧ (e ∩ S).card = 2 then (1 : ℝ) else 0) =
        if e ∈ H then (if (e ∩ S).card = 2 then 1 else 0) else 0 := by
    intro e
    split_ifs <;> simp_all
  simp_rw [hf]
  rw [← sum_filter, filter_all_triples H hH]
  rw [cutCount, Finset.card_eq_sum_ones]
  simp only [Nat.cast_sum, sum_filter]
  apply sum_congr rfl
  intro e _
  split_ifs <;> norm_num

theorem edgeTriple_mean {n : Nat} (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H) :
    uniformMean (edgeTriple H) = (H.card : ℝ) / (n.choose 3 : ℝ) := by
  have he : edgeTriple H = fun t : Triple n => if embeddingSet t ∈ H then (1 : ℝ) else 0 := by
    funext t
    simp [edgeTriple, edgeValue, actualEdge, embeddingSet_three]
  rw [he, embeddingSet_mean 3 (fun e : Finset (Fin n) => if e ∈ H then (1 : ℝ) else 0)]
  simp only [Fintype.card_fin]
  congr 1
  rw [← sum_filter, filter_all_triples H hH]
  simp

theorem cutRow_sample {n : Nat} (flag : Nat) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) :
    cutRow flag (sampleStructure σ H S) =
      (cutValue (actualEdge H) (actualColor S) (σ 0) (σ 1) (σ 2) - 2 / 5) *
        globalFlag flag (actualEdge H) (actualColor S) (σ 3) (σ 4) (σ 5) := by
  have he : (fun x u v => (sampleStructure σ H S).edge {x,u,v}) =
      (fun x u v => actualEdge H (σ x) (σ u) (σ v)) := by
    funext x u v
    simp [sampleStructure, actualEdge]
  unfold cutRow
  rw [he]
  rfl

theorem densityRow_sample {n : Nat} (flag : Option Nat) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) :
    densityRow flag (sampleStructure σ H S) =
      (edgeValue (actualEdge H) (σ 0) (σ 1) (σ 2) - densityBound) *
        densityFlag flag (actualEdge H) (actualColor S) (σ 3) (σ 4) (σ 5) := by
  have he : (fun x u v => (sampleStructure σ H S).edge {x,u,v}) =
      (fun x u v => actualEdge H (σ x) (σ u) (σ v)) := by
    funext x u v
    simp [sampleStructure, actualEdge]
  unfold densityRow
  rw [he]
  rfl

theorem cutRow_asSix {n : Nat} (flag : Nat) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) :
    cutRow flag (sampleStructure σ H S) =
      sixTripleProduct (fun t => cutTriple H S t - 2 / 5) (flagTriple (some flag) H S) σ := by
  have he : ∀ (root : Triple n) (free : Fin 3 ↪ Outside root),
      cutRow flag (sampleStructure (joinSample root free) H S) =
        sixTripleProduct (fun t => cutTriple H S t - 2 / 5) (flagTriple (some flag) H S)
          (joinSample root free) := by
    intro root free
    rw [cutRow_sample, sixTripleProduct_join]
    change (cutValue (actualEdge H) (actualColor S)
      (joinSample root free (Fin.castAdd 3 (0 : Fin 3)))
      (joinSample root free (Fin.castAdd 3 (1 : Fin 3)))
      (joinSample root free (Fin.castAdd 3 (2 : Fin 3))) - 2 / 5) *
      globalFlag flag (actualEdge H) (actualColor S)
        (joinSample root free (Fin.natAdd 3 (0 : Fin 3)))
        (joinSample root free (Fin.natAdd 3 (1 : Fin 3)))
        (joinSample root free (Fin.natAdd 3 (2 : Fin 3))) = _
    simp only [joinSample_root, joinSample_free]
    rfl
  have h := he (splitSampleEquiv (r := 3) (f := 3) σ).1 (splitSampleEquiv (r := 3) (f := 3) σ).2
  simpa only [joinSample_split] using h

theorem densityRow_asSix {n : Nat} (flag : Option Nat) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) :
    densityRow flag (sampleStructure σ H S) =
      sixTripleProduct (fun t => edgeTriple H t - densityBound) (flagTriple flag H S) σ := by
  have he : ∀ (root : Triple n) (free : Fin 3 ↪ Outside root),
      densityRow flag (sampleStructure (joinSample root free) H S) =
        sixTripleProduct (fun t => edgeTriple H t - densityBound) (flagTriple flag H S)
          (joinSample root free) := by
    intro root free
    rw [densityRow_sample, sixTripleProduct_join]
    change (edgeValue (actualEdge H)
      (joinSample root free (Fin.castAdd 3 (0 : Fin 3)))
      (joinSample root free (Fin.castAdd 3 (1 : Fin 3)))
      (joinSample root free (Fin.castAdd 3 (2 : Fin 3))) - densityBound) *
      densityFlag flag (actualEdge H) (actualColor S)
        (joinSample root free (Fin.natAdd 3 (0 : Fin 3)))
        (joinSample root free (Fin.natAdd 3 (1 : Fin 3)))
        (joinSample root free (Fin.natAdd 3 (2 : Fin 3))) = _
    simp only [joinSample_root, joinSample_free]
    rfl
  have h := he (splitSampleEquiv (r := 3) (f := 3) σ).1 (splitSampleEquiv (r := 3) (f := 3) σ).2
  simpa only [joinSample_split] using h

theorem cutRow_mean_lower {n : Nat} (flag : Nat)
    (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H) (S : Finset (Fin n))
    (hn : 12 ≤ n) (δ : ℝ) (hδ : 0 ≤ δ)
    (hcut : (2 / 5 - δ) * (n.choose 3 : ℝ) ≤ cutCount H S) :
    -tripleRatio n * δ - tripleError n ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => cutRow flag (sampleStructure σ H S)) := by
  classical
  letI : Nonempty (Triple n) := ⟨Fin.castLEEmb (by omega : 3 ≤ n)⟩
  have hcpos : (0 : ℝ) < (n.choose 3 : ℝ) := by
    exact_mod_cast Nat.choose_pos (by omega : 3 ≤ n)
  have hm : -δ ≤ uniformMean (fun t => cutTriple H S t - 2 / 5) := by
    rw [mean_sub_const, cutTriple_mean H hH S]
    have h := (le_div_iff₀ hcpos).mpr hcut
    linarith
  have he := funext (cutRow_asSix flag H S)
  rw [he]
  apply triple_flag_lower hn _ _ _ _ δ hδ hm
  · intro t
    apply centered_abs_le _ _ _ (by norm_num) (by norm_num)
    unfold cutTriple cutValue
    split_ifs <;> simp
  · intro t
    exact densityFlag_zero_one (some flag) _ _ _ _ _

theorem densityRow_mean_lower {n : Nat} (flag : Option Nat)
    (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H) (S : Finset (Fin n))
    (hn : 12 ≤ n) (δ : ℝ) (hδ : 0 ≤ δ)
    (hdensity : (densityBound - δ) * (n.choose 3 : ℝ) ≤ H.card) :
    -tripleRatio n * δ - tripleError n ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => densityRow flag (sampleStructure σ H S)) := by
  classical
  letI : Nonempty (Triple n) := ⟨Fin.castLEEmb (by omega : 3 ≤ n)⟩
  have hcpos : (0 : ℝ) < (n.choose 3 : ℝ) := by
    exact_mod_cast Nat.choose_pos (by omega : 3 ≤ n)
  have hm : -δ ≤ uniformMean (fun t => edgeTriple H t - densityBound) := by
    rw [mean_sub_const, edgeTriple_mean H hH]
    have h := (le_div_iff₀ hcpos).mpr hdensity
    linarith
  have he := funext (densityRow_asSix flag H S)
  rw [he]
  apply triple_flag_lower hn _ _ _ _ δ hδ hm
  · intro t
    apply centered_abs_le _ _ _ (by norm_num [densityBound]) (by norm_num [densityBound])
    unfold edgeTriple edgeValue
    split_ifs <;> simp
  · intro t
    exact densityFlag_zero_one flag _ _ _ _ _

theorem sixTripleProduct_one {n : Nat} (g : Triple n → ℝ) (σ : Fin 6 ↪ Fin n) :
    sixTripleProduct g (fun _ => 1) σ = g ((Fin.castAddEmb 3).trans σ) := by
  have hf : (sixDisjointTripleEquiv σ).val.1 = (Fin.castAddEmb 3).trans σ := rfl
  change g (sixDisjointTripleEquiv σ).val.1 * 1 = _
  rw [hf, mul_one]

/-- The ninth density row has its exact one-triple mean, with no collision loss. -/
theorem densityRow_none_mean {n : Nat} (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (S : Finset (Fin n)) (hn : 6 ≤ n) :
    uniformMean (fun σ : Fin 6 ↪ Fin n => densityRow none (sampleStructure σ H S)) =
      (H.card : ℝ) / (n.choose 3 : ℝ) - densityBound := by
  classical
  letI : Nonempty (Triple n) := ⟨Fin.castLEEmb (by omega : 3 ≤ n)⟩
  have he := funext (densityRow_asSix none H S)
  rw [he]
  change uniformMean (sixTripleProduct (fun t => edgeTriple H t - densityBound) (fun _ => 1)) = _
  have ho := funext (sixTripleProduct_one (fun t => edgeTriple H t - densityBound))
  rw [ho]
  rw [uniformMean_restrict_three hn (Fin.castAddEmb 3) (fun t => edgeTriple H t - densityBound),
    mean_sub_const, edgeTriple_mean H hH]

theorem densityRow_none_lower {n : Nat} (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (S : Finset (Fin n)) (hn : 6 ≤ n) (δ : ℝ)
    (hdensity : (densityBound - δ) * (n.choose 3 : ℝ) ≤ H.card) :
    -δ ≤ uniformMean (fun σ : Fin 6 ↪ Fin n => densityRow none (sampleStructure σ H S)) := by
  rw [densityRow_none_mean H hH S hn]
  have hcpos : (0 : ℝ) < (n.choose 3 : ℝ) := by
    exact_mod_cast Nat.choose_pos (by omega : 3 ≤ n)
  have h := (le_div_iff₀ hcpos).mpr hdensity
  linarith

#print axioms cutRow_sample
#print axioms densityRow_sample
#print axioms cutRow_asSix
#print axioms densityRow_asSix
#print axioms cutRow_mean_lower
#print axioms densityRow_mean_lower
#print axioms sixTripleProduct_one
#print axioms densityRow_none_mean
#print axioms densityRow_none_lower

#print axioms globalFlag_zero_one
#print axioms densityFlag_zero_one
#print axioms cutValue_actual
#print axioms centered_abs_le
#print axioms mean_sub_const
#print axioms triple_flag_lower
#print axioms embeddingSet_three
#print axioms cutTriple_mean
#print axioms edgeTriple_mean
end TightCycleC5.Bridge.P33Rows
