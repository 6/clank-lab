import P33FlagData
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace TightCycleC5.Bridge.P33Flag
open ColouredFlags

theorem basis0_size : basis0Data.size = 40 := by decide +kernel
theorem basis0_psd_data : ∀ i, basis0 i = P33PSD.flags0[i.val]! := by decide +kernel
theorem basis0_steps : ∀ i : Fin 39,
    basis0 i.castSucc < basis0 i.succ := by decide +kernel
theorem basis0_injective : Function.Injective basis0 :=
  (Fin.strictMono_iff_lt_succ.mpr basis0_steps).injective
theorem basis0_range : ∀ i, basis0 i < 256 := by decide +kernel
theorem basis0_canonical : ∀ i, canonical4 (BitVec.ofNat 8 (basis0 i)) = basis0 i := by decide +kernel
theorem basis0_root : ∀ i, basis0 i % 4 = type0 := by decide +kernel
#print axioms basis0_size
#print axioms basis0_psd_data
#print axioms basis0_steps
#print axioms basis0_injective
#print axioms basis0_range
#print axioms basis0_canonical
#print axioms basis0_root

theorem basis6_size : basis6Data.size = 128 := by decide +kernel
theorem basis6_psd_data : ∀ i, basis6 i = P33PSD.flags6[i.val]! := by decide +kernel
theorem basis6_steps : ∀ i : Fin 127,
    basis6 i.castSucc < basis6 i.succ := by decide +kernel
theorem basis6_injective : Function.Injective basis6 :=
  (Fin.strictMono_iff_lt_succ.mpr basis6_steps).injective
theorem basis6_range : ∀ i, basis6 i < 32768 := by decide +kernel
theorem basis6_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis6 i))).toNat = type6 := by decide +kernel
#print axioms basis6_size
#print axioms basis6_psd_data
#print axioms basis6_steps
#print axioms basis6_injective
#print axioms basis6_range
#print axioms basis6_root

theorem basis12_size : basis12Data.size = 128 := by decide +kernel
theorem basis12_psd_data : ∀ i, basis12 i = P33PSD.flags12[i.val]! := by decide +kernel
theorem basis12_steps : ∀ i : Fin 127,
    basis12 i.castSucc < basis12 i.succ := by decide +kernel
theorem basis12_injective : Function.Injective basis12 :=
  (Fin.strictMono_iff_lt_succ.mpr basis12_steps).injective
theorem basis12_range : ∀ i, basis12 i < 32768 := by decide +kernel
theorem basis12_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis12 i))).toNat = type12 := by decide +kernel
#print axioms basis12_size
#print axioms basis12_psd_data
#print axioms basis12_steps
#print axioms basis12_injective
#print axioms basis12_range
#print axioms basis12_root

theorem basis18_size : basis18Data.size = 100 := by decide +kernel
theorem basis18_psd_data : ∀ i, basis18 i = P33PSD.flags18[i.val]! := by decide +kernel
theorem basis18_steps : ∀ i : Fin 99,
    basis18 i.castSucc < basis18 i.succ := by decide +kernel
theorem basis18_injective : Function.Injective basis18 :=
  (Fin.strictMono_iff_lt_succ.mpr basis18_steps).injective
theorem basis18_range : ∀ i, basis18 i < 32768 := by decide +kernel
theorem basis18_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis18 i))).toNat = type18 := by decide +kernel
#print axioms basis18_size
#print axioms basis18_psd_data
#print axioms basis18_steps
#print axioms basis18_injective
#print axioms basis18_range
#print axioms basis18_root

theorem basis24_size : basis24Data.size = 100 := by decide +kernel
theorem basis24_psd_data : ∀ i, basis24 i = P33PSD.flags24[i.val]! := by decide +kernel
theorem basis24_steps : ∀ i : Fin 99,
    basis24 i.castSucc < basis24 i.succ := by decide +kernel
theorem basis24_injective : Function.Injective basis24 :=
  (Fin.strictMono_iff_lt_succ.mpr basis24_steps).injective
theorem basis24_range : ∀ i, basis24 i < 32768 := by decide +kernel
theorem basis24_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis24 i))).toNat = type24 := by decide +kernel
#print axioms basis24_size
#print axioms basis24_psd_data
#print axioms basis24_steps
#print axioms basis24_injective
#print axioms basis24_range
#print axioms basis24_root

theorem basis30_size : basis30Data.size = 78 := by decide +kernel
theorem basis30_psd_data : ∀ i, basis30 i = P33PSD.flags30[i.val]! := by decide +kernel
theorem basis30_steps : ∀ i : Fin 77,
    basis30 i.castSucc < basis30 i.succ := by decide +kernel
theorem basis30_injective : Function.Injective basis30 :=
  (Fin.strictMono_iff_lt_succ.mpr basis30_steps).injective
theorem basis30_range : ∀ i, basis30 i < 32768 := by decide +kernel
theorem basis30_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis30 i))).toNat = type30 := by decide +kernel
#print axioms basis30_size
#print axioms basis30_psd_data
#print axioms basis30_steps
#print axioms basis30_injective
#print axioms basis30_range
#print axioms basis30_root

theorem basis36_size : basis36Data.size = 60 := by decide +kernel
theorem basis36_psd_data : ∀ i, basis36 i = P33PSD.flags36[i.val]! := by decide +kernel
theorem basis36_steps : ∀ i : Fin 59,
    basis36 i.castSucc < basis36 i.succ := by decide +kernel
theorem basis36_injective : Function.Injective basis36 :=
  (Fin.strictMono_iff_lt_succ.mpr basis36_steps).injective
theorem basis36_range : ∀ i, basis36 i < 32768 := by decide +kernel
theorem basis36_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis36 i))).toNat = type36 := by decide +kernel
#print axioms basis36_size
#print axioms basis36_psd_data
#print axioms basis36_steps
#print axioms basis36_injective
#print axioms basis36_range
#print axioms basis36_root

end TightCycleC5.Bridge.P33Flag
