import KernelRowIndex
import KernelWitness2

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_2_96 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 96 * 256 + i.val))
      kernelWitness2Row96[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_96

theorem kernelBlock_2_97 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 97 * 256 + i.val))
      kernelWitness2Row97[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_97

theorem kernelBlock_2_98 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 98 * 256 + i.val))
      kernelWitness2Row98[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_98

theorem kernelBlock_2_99 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 99 * 256 + i.val))
      kernelWitness2Row99[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_99

theorem kernelBlock_2_100 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 100 * 256 + i.val))
      kernelWitness2Row100[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_100

theorem kernelBlock_2_101 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 101 * 256 + i.val))
      kernelWitness2Row101[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_101

theorem kernelBlock_2_102 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 102 * 256 + i.val))
      kernelWitness2Row102[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_102

theorem kernelBlock_2_103 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 103 * 256 + i.val))
      kernelWitness2Row103[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_103

theorem kernelBlock_2_104 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 104 * 256 + i.val))
      kernelWitness2Row104[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_104

theorem kernelBlock_2_105 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 105 * 256 + i.val))
      kernelWitness2Row105[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_105

theorem kernelBlock_2_106 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 106 * 256 + i.val))
      kernelWitness2Row106[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_106

theorem kernelBlock_2_107 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 107 * 256 + i.val))
      kernelWitness2Row107[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_107

theorem kernelBlock_2_108 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 108 * 256 + i.val))
      kernelWitness2Row108[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_108

theorem kernelBlock_2_109 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 109 * 256 + i.val))
      kernelWitness2Row109[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_109

theorem kernelBlock_2_110 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 110 * 256 + i.val))
      kernelWitness2Row110[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_110

theorem kernelBlock_2_111 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 111 * 256 + i.val))
      kernelWitness2Row111[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_111

theorem kernelBlock_2_112 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 112 * 256 + i.val))
      kernelWitness2Row112[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_112

theorem kernelBlock_2_113 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 113 * 256 + i.val))
      kernelWitness2Row113[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_113

theorem kernelBlock_2_114 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 114 * 256 + i.val))
      kernelWitness2Row114[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_114

theorem kernelBlock_2_115 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 115 * 256 + i.val))
      kernelWitness2Row115[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_115

theorem kernelBlock_2_116 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 116 * 256 + i.val))
      kernelWitness2Row116[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_116

theorem kernelBlock_2_117 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 117 * 256 + i.val))
      kernelWitness2Row117[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_117

theorem kernelBlock_2_118 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 118 * 256 + i.val))
      kernelWitness2Row118[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_118

theorem kernelBlock_2_119 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 119 * 256 + i.val))
      kernelWitness2Row119[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_119

theorem kernelBlock_2_120 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 120 * 256 + i.val))
      kernelWitness2Row120[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_120

theorem kernelBlock_2_121 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 121 * 256 + i.val))
      kernelWitness2Row121[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_121

theorem kernelBlock_2_122 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 122 * 256 + i.val))
      kernelWitness2Row122[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_122

theorem kernelBlock_2_123 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 123 * 256 + i.val))
      kernelWitness2Row123[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_123

theorem kernelBlock_2_124 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 124 * 256 + i.val))
      kernelWitness2Row124[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_124

theorem kernelBlock_2_125 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 125 * 256 + i.val))
      kernelWitness2Row125[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_125

theorem kernelBlock_2_126 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 126 * 256 + i.val))
      kernelWitness2Row126[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_126

theorem kernelBlock_2_127 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 127 * 256 + i.val))
      kernelWitness2Row127[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_127

end TightCycleC5.Bridge.Cover
