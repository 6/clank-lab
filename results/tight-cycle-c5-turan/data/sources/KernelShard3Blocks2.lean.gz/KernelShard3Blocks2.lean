import KernelRowIndex
import KernelWitness3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_3_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 64 * 256 + i.val))
      kernelWitness3Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_64

theorem kernelBlock_3_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 65 * 256 + i.val))
      kernelWitness3Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_65

theorem kernelBlock_3_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 66 * 256 + i.val))
      kernelWitness3Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_66

theorem kernelBlock_3_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 67 * 256 + i.val))
      kernelWitness3Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_67

theorem kernelBlock_3_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 68 * 256 + i.val))
      kernelWitness3Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_68

theorem kernelBlock_3_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 69 * 256 + i.val))
      kernelWitness3Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_69

theorem kernelBlock_3_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 70 * 256 + i.val))
      kernelWitness3Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_70

theorem kernelBlock_3_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 71 * 256 + i.val))
      kernelWitness3Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_71

theorem kernelBlock_3_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 72 * 256 + i.val))
      kernelWitness3Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_72

theorem kernelBlock_3_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 73 * 256 + i.val))
      kernelWitness3Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_73

theorem kernelBlock_3_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 74 * 256 + i.val))
      kernelWitness3Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_74

theorem kernelBlock_3_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 75 * 256 + i.val))
      kernelWitness3Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_75

theorem kernelBlock_3_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 76 * 256 + i.val))
      kernelWitness3Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_76

theorem kernelBlock_3_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 77 * 256 + i.val))
      kernelWitness3Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_77

theorem kernelBlock_3_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 78 * 256 + i.val))
      kernelWitness3Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_78

theorem kernelBlock_3_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 79 * 256 + i.val))
      kernelWitness3Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_79

theorem kernelBlock_3_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 80 * 256 + i.val))
      kernelWitness3Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_80

theorem kernelBlock_3_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 81 * 256 + i.val))
      kernelWitness3Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_81

theorem kernelBlock_3_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 82 * 256 + i.val))
      kernelWitness3Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_82

theorem kernelBlock_3_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 83 * 256 + i.val))
      kernelWitness3Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_83

theorem kernelBlock_3_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 84 * 256 + i.val))
      kernelWitness3Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_84

theorem kernelBlock_3_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 85 * 256 + i.val))
      kernelWitness3Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_85

theorem kernelBlock_3_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 86 * 256 + i.val))
      kernelWitness3Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_86

theorem kernelBlock_3_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 87 * 256 + i.val))
      kernelWitness3Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_87

theorem kernelBlock_3_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 88 * 256 + i.val))
      kernelWitness3Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_88

theorem kernelBlock_3_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 89 * 256 + i.val))
      kernelWitness3Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_89

theorem kernelBlock_3_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 90 * 256 + i.val))
      kernelWitness3Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_90

theorem kernelBlock_3_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 91 * 256 + i.val))
      kernelWitness3Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_91

theorem kernelBlock_3_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 92 * 256 + i.val))
      kernelWitness3Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_92

theorem kernelBlock_3_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 93 * 256 + i.val))
      kernelWitness3Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_93

theorem kernelBlock_3_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 94 * 256 + i.val))
      kernelWitness3Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_94

theorem kernelBlock_3_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 95 * 256 + i.val))
      kernelWitness3Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_95

end TightCycleC5.Bridge.Cover
