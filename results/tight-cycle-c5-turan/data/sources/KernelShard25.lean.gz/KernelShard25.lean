import KernelShard25Blocks0
import KernelShard25Blocks1
import KernelShard25Blocks2
import KernelShard25Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard25 : kernelShardCheck 25 kernelWitness25 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (25 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness25 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_25_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard25
end TightCycleC5.Bridge.Cover
