-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk296 :
    ∀ i : Fin (min 128 (40547 - 128 * 296)),
      targetCountsMatch (classAt (targetKernelClass ⟨296, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk296

theorem target_counts_kernel_chunk297 :
    ∀ i : Fin (min 128 (40547 - 128 * 297)),
      targetCountsMatch (classAt (targetKernelClass ⟨297, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk297

theorem target_counts_kernel_chunk298 :
    ∀ i : Fin (min 128 (40547 - 128 * 298)),
      targetCountsMatch (classAt (targetKernelClass ⟨298, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk298

theorem target_counts_kernel_chunk299 :
    ∀ i : Fin (min 128 (40547 - 128 * 299)),
      targetCountsMatch (classAt (targetKernelClass ⟨299, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk299


end TightCycleC5.Bridge.P33Arithmetic
