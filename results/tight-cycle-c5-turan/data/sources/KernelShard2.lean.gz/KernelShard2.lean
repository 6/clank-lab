import KernelShard2Blocks0
import KernelShard2Blocks1
import KernelShard2Blocks2
import KernelShard2Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard2 : kernelShardCheck 2 kernelWitness2 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (2 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness2 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_2_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard2
end TightCycleC5.Bridge.Cover
