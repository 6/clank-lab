import P32PSDGram0Rows0
import P32PSDGram0Rows1
import P32PSDGram0Rows2
import P32PSDGram0Rows3
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace TightCycleC5.Bridge.P32PSD.Kernel
theorem gram0 : q0 = u0 * u0.transpose := by
  ext i j
  fin_cases i
  · exact gram0_row0 j
  · exact gram0_row1 j
  · exact gram0_row2 j
  · exact gram0_row3 j
  · exact gram0_row4 j
  · exact gram0_row5 j
  · exact gram0_row6 j
  · exact gram0_row7 j
  · exact gram0_row8 j
  · exact gram0_row9 j
  · exact gram0_row10 j
  · exact gram0_row11 j
  · exact gram0_row12 j
  · exact gram0_row13 j
  · exact gram0_row14 j
  · exact gram0_row15 j
  · exact gram0_row16 j
  · exact gram0_row17 j
  · exact gram0_row18 j
  · exact gram0_row19 j
  · exact gram0_row20 j
  · exact gram0_row21 j
  · exact gram0_row22 j
  · exact gram0_row23 j
  · exact gram0_row24 j
  · exact gram0_row25 j
  · exact gram0_row26 j
  · exact gram0_row27 j
  · exact gram0_row28 j
  · exact gram0_row29 j
  · exact gram0_row30 j
  · exact gram0_row31 j
  · exact gram0_row32 j
  · exact gram0_row33 j
  · exact gram0_row34 j
  · exact gram0_row35 j
  · exact gram0_row36 j
  · exact gram0_row37 j
  · exact gram0_row38 j
  · exact gram0_row39 j
  · exact gram0_row40 j
  · exact gram0_row41 j
  · exact gram0_row42 j
  · exact gram0_row43 j
  · exact gram0_row44 j
  · exact gram0_row45 j
  · exact gram0_row46 j
  · exact gram0_row47 j
  · exact gram0_row48 j
  · exact gram0_row49 j
  · exact gram0_row50 j
  · exact gram0_row51 j
  · exact gram0_row52 j
  · exact gram0_row53 j
  · exact gram0_row54 j
  · exact gram0_row55 j
  · exact gram0_row56 j
  · exact gram0_row57 j
  · exact gram0_row58 j
  · exact gram0_row59 j
  · exact gram0_row60 j
  · exact gram0_row61 j
  · exact gram0_row62 j
  · exact gram0_row63 j
theorem diagonal0 : ∀ i, q0 i i ≤ m0 := by decide +kernel
#print axioms gram0
#print axioms diagonal0
end TightCycleC5.Bridge.P32PSD.Kernel
