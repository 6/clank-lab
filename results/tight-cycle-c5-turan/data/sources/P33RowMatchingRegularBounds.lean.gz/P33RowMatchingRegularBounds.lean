import P33RowMatchingRegular
import P33RowMatchingGlobalCodes
import P33PSDMatchingCore

namespace TightCycleC5.Bridge.P33RowMatching
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000

/-- Only the three actual regularity blocks and their actual right queries
are needed; no flag-basis completeness premise is introduced. -/
theorem regularQuery_of_blockBounds (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (h : ∀ b : Fin 3, P33PSDMatching.ValidLookups P33Arithmetic.blocks[b.val]! K p) :
    regularQueryValid K p := by
  intro b ht
  have hroots := (regular_tables_checked b).2.1
  have hr : P33PSDMatching.rootQuery P33Arithmetic.blocks[b.val]! K p = regularType K p := by
    unfold P33PSDMatching.rootQuery
    rw [hroots]
    change P33Arithmetic.encoded K.mask K.colours [(p 0).val,(p 1).val] = regularType K p
    exact encoded_two K.mask K.colours (p 0).val (p 1).val
  have hv := (h b (hr.trans ht)).2
  simpa only [P33PSDMatching.rightQuery,hroots,↓reduceIte,regularKey] using hv

#print axioms regularQuery_of_blockBounds
end TightCycleC5.Bridge.P33RowMatching
