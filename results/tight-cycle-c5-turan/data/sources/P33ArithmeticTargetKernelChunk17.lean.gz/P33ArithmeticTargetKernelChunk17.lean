-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk68 :
    ∀ i : Fin (min 128 (40547 - 128 * 68)),
      targetCountsMatch (classAt (targetKernelClass ⟨68, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk68

theorem target_counts_kernel_chunk69 :
    ∀ i : Fin (min 128 (40547 - 128 * 69)),
      targetCountsMatch (classAt (targetKernelClass ⟨69, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk69

theorem target_counts_kernel_chunk70 :
    ∀ i : Fin (min 128 (40547 - 128 * 70)),
      targetCountsMatch (classAt (targetKernelClass ⟨70, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk70

theorem target_counts_kernel_chunk71 :
    ∀ i : Fin (min 128 (40547 - 128 * 71)),
      targetCountsMatch (classAt (targetKernelClass ⟨71, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk71


end TightCycleC5.Bridge.P33Arithmetic
