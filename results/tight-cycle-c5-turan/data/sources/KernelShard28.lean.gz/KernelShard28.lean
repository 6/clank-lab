import KernelShard28Blocks0
import KernelShard28Blocks1
import KernelShard28Blocks2
import KernelShard28Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard28 : kernelShardCheck 28 kernelWitness28 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (28 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness28 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_28_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard28
end TightCycleC5.Bridge.Cover
