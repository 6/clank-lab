import ColoredCoverSemantics

namespace TightCycleC5.Bridge.ColoredCover
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def coloredWitness832 : Array Nat := #[29157840, 29158560, 29158680, 29159280, 29160000, 29160720, 29160840, 29161440, 29160006, 29160726, 29160846, 29161446, 29162160, 29162880, 29163000, 29163600, 29160012, 29160732, 29160852, 29161452, 29162162, 29162882, 29163002, 29163602, 29162168, 29162888, 29163008, 29163608, 29164320, 29165040, 29165160, 29165760, 29159169, 29159385, 29159505, 29166480, 29161329, 29161545, 29161665, 29167200, 29161335, 29161551, 29161671, 29167206, 29163489, 29163705, 29163825, 29167920, 29161341, 29161557, 29161677, 29167212, 29163491, 29163707, 29163827, 29167922, 29163497, 29163713, 29163833, 29167928, 29165649, 29165865, 29165985, 29168640]

theorem colored_row832 : ∀ c : Fin 64,
    readRow witnessRows (832 * 64 + c.val) = coloredWitness832[c.val]! := by
  decide +kernel
#print axioms colored_row832

theorem colored_check832 : ∀ c : Fin 64,
    checkColored 832 (BitVec.ofNat 6 c.val) (coloredWitness832[c.val]!) = true := by
  decide +kernel
#print axioms colored_check832

theorem colored_family832 : ∀ c : Fin 64,
    checkColored 832 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (832 * 64 + c.val)) = true := by
  intro c
  rw [colored_row832]
  exact colored_check832 c
#print axioms colored_family832

def coloredWitness833 : Array Nat := #[29169360, 29170080, 29170200, 29170800, 29171520, 29172240, 29172360, 29172960, 29171526, 29172246, 29172366, 29172966, 29173680, 29174400, 29174520, 29175120, 29171532, 29172252, 29172372, 29172972, 29173682, 29174402, 29174522, 29175122, 29173688, 29174408, 29174528, 29175128, 29175840, 29176560, 29176680, 29177280, 29178000, 29178720, 29178840, 29179440, 29180160, 29180880, 29181000, 29181600, 29180166, 29180886, 29181006, 29181606, 29182320, 29183040, 29183160, 29183760, 29180172, 29180892, 29181012, 29181612, 29182322, 29183042, 29183162, 29183762, 29182328, 29183048, 29183168, 29183768, 29184480, 29185200, 29185320, 29185920]

theorem colored_row833 : ∀ c : Fin 64,
    readRow witnessRows (833 * 64 + c.val) = coloredWitness833[c.val]! := by
  decide +kernel
#print axioms colored_row833

theorem colored_check833 : ∀ c : Fin 64,
    checkColored 833 (BitVec.ofNat 6 c.val) (coloredWitness833[c.val]!) = true := by
  decide +kernel
#print axioms colored_check833

theorem colored_family833 : ∀ c : Fin 64,
    checkColored 833 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (833 * 64 + c.val)) = true := by
  intro c
  rw [colored_row833]
  exact colored_check833 c
#print axioms colored_family833

def coloredWitness834 : Array Nat := #[29186640, 29187360, 29187481, 29188080, 29187603, 29188106, 29188228, 29188800, 29187723, 29188130, 29188252, 29188806, 29189520, 29190240, 29190361, 29190960, 29187849, 29188160, 29189546, 29190266, 29188396, 29188836, 29190483, 29190986, 29188516, 29188860, 29190603, 29191010, 29190729, 29191040, 29191680, 29192400, 29187993, 29189668, 29188304, 29190388, 29188426, 29190509, 29188962, 29191108, 29188546, 29190629, 29188986, 29191132, 29190873, 29191801, 29191184, 29192521, 29188672, 29190773, 29190899, 29191923, 29189130, 29191276, 29191306, 29192643, 29189250, 29191396, 29191426, 29192763, 29191552, 29192889, 29193033, 29193120]

theorem colored_row834 : ∀ c : Fin 64,
    readRow witnessRows (834 * 64 + c.val) = coloredWitness834[c.val]! := by
  decide +kernel
#print axioms colored_row834

theorem colored_check834 : ∀ c : Fin 64,
    checkColored 834 (BitVec.ofNat 6 c.val) (coloredWitness834[c.val]!) = true := by
  decide +kernel
#print axioms colored_check834

theorem colored_family834 : ∀ c : Fin 64,
    checkColored 834 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (834 * 64 + c.val)) = true := by
  intro c
  rw [colored_row834]
  exact colored_check834 c
#print axioms colored_family834

end TightCycleC5.Bridge.ColoredCover
