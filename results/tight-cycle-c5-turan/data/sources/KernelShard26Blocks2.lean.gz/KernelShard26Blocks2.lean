import KernelRowIndex
import KernelWitness26

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_26_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 64 * 256 + i.val))
      kernelWitness26Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_64

theorem kernelBlock_26_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 65 * 256 + i.val))
      kernelWitness26Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_65

theorem kernelBlock_26_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 66 * 256 + i.val))
      kernelWitness26Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_66

theorem kernelBlock_26_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 67 * 256 + i.val))
      kernelWitness26Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_67

theorem kernelBlock_26_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 68 * 256 + i.val))
      kernelWitness26Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_68

theorem kernelBlock_26_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 69 * 256 + i.val))
      kernelWitness26Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_69

theorem kernelBlock_26_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 70 * 256 + i.val))
      kernelWitness26Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_70

theorem kernelBlock_26_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 71 * 256 + i.val))
      kernelWitness26Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_71

theorem kernelBlock_26_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 72 * 256 + i.val))
      kernelWitness26Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_72

theorem kernelBlock_26_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 73 * 256 + i.val))
      kernelWitness26Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_73

theorem kernelBlock_26_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 74 * 256 + i.val))
      kernelWitness26Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_74

theorem kernelBlock_26_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 75 * 256 + i.val))
      kernelWitness26Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_75

theorem kernelBlock_26_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 76 * 256 + i.val))
      kernelWitness26Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_76

theorem kernelBlock_26_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 77 * 256 + i.val))
      kernelWitness26Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_77

theorem kernelBlock_26_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 78 * 256 + i.val))
      kernelWitness26Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_78

theorem kernelBlock_26_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 79 * 256 + i.val))
      kernelWitness26Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_79

theorem kernelBlock_26_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 80 * 256 + i.val))
      kernelWitness26Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_80

theorem kernelBlock_26_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 81 * 256 + i.val))
      kernelWitness26Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_81

theorem kernelBlock_26_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 82 * 256 + i.val))
      kernelWitness26Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_82

theorem kernelBlock_26_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 83 * 256 + i.val))
      kernelWitness26Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_83

theorem kernelBlock_26_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 84 * 256 + i.val))
      kernelWitness26Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_84

theorem kernelBlock_26_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 85 * 256 + i.val))
      kernelWitness26Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_85

theorem kernelBlock_26_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 86 * 256 + i.val))
      kernelWitness26Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_86

theorem kernelBlock_26_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 87 * 256 + i.val))
      kernelWitness26Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_87

theorem kernelBlock_26_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 88 * 256 + i.val))
      kernelWitness26Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_88

theorem kernelBlock_26_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 89 * 256 + i.val))
      kernelWitness26Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_89

theorem kernelBlock_26_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 90 * 256 + i.val))
      kernelWitness26Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_90

theorem kernelBlock_26_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 91 * 256 + i.val))
      kernelWitness26Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_91

theorem kernelBlock_26_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 92 * 256 + i.val))
      kernelWitness26Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_92

theorem kernelBlock_26_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 93 * 256 + i.val))
      kernelWitness26Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_93

theorem kernelBlock_26_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 94 * 256 + i.val))
      kernelWitness26Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_94

theorem kernelBlock_26_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 95 * 256 + i.val))
      kernelWitness26Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_95

end TightCycleC5.Bridge.Cover
