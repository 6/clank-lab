import KernelShard29Blocks0
import KernelShard29Blocks1
import KernelShard29Blocks2
import KernelShard29Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard29 : kernelShardCheck 29 kernelWitness29 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (29 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness29 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_29_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard29
end TightCycleC5.Bridge.Cover
