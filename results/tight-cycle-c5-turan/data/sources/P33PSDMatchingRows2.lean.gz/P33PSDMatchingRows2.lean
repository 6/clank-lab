import P33PSDMatchingRowsBase
import P33PSDMatchingEntries2
import P33FlagRows2
namespace TightCycleC5.Bridge.P33PSDMatching

theorem source_row2 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block2 K p) :
    (sourceContribution P33Arithmetic.block2 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row2 (p.symm • decoded K.mask K.colours) :=
  pair_contribution_eq P33Arithmetic.block2 rfl P33PSD.q2 P33PSD.scale source_entry2
    P33Flag.basis2 P33Flag.basis2_injective rfl (fun _ => rfl) P33Flag.type2 rfl K p hv
#print axioms source_row2

theorem source_row8 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block8 K p) :
    (sourceContribution P33Arithmetic.block8 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row8 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block8 rfl P33PSD.q8 P33PSD.scale source_entry8
    P33Flag.basis8 P33Flag.basis8_injective rfl (fun _ => rfl) P33Flag.type8 rfl K p hv
#print axioms source_row8

theorem source_row14 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block14 K p) :
    (sourceContribution P33Arithmetic.block14 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row14 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block14 rfl P33PSD.q14 P33PSD.scale source_entry14
    P33Flag.basis14 P33Flag.basis14_injective rfl (fun _ => rfl) P33Flag.type14 rfl K p hv
#print axioms source_row14

theorem source_row20 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block20 K p) :
    (sourceContribution P33Arithmetic.block20 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row20 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block20 rfl P33PSD.q20 P33PSD.scale source_entry20
    P33Flag.basis20 P33Flag.basis20_injective rfl (fun _ => rfl) P33Flag.type20 rfl K p hv
#print axioms source_row20

theorem source_row26 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block26 K p) :
    (sourceContribution P33Arithmetic.block26 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row26 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block26 rfl P33PSD.q26 P33PSD.scale source_entry26
    P33Flag.basis26 P33Flag.basis26_injective rfl (fun _ => rfl) P33Flag.type26 rfl K p hv
#print axioms source_row26

theorem source_row32 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block32 K p) :
    (sourceContribution P33Arithmetic.block32 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row32 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block32 rfl P33PSD.q32 P33PSD.scale source_entry32
    P33Flag.basis32 P33Flag.basis32_injective rfl (fun _ => rfl) P33Flag.type32 rfl K p hv
#print axioms source_row32

end TightCycleC5.Bridge.P33PSDMatching
