import P33RowMatchingLiteralWeights
import CertificateDescriptorsFinite

namespace TightCycleC5.Bridge.P33RowMatching
set_option maxRecDepth 100000
set_option maxHeartbeats 0

/-- Full literal vector alignment, including its length. -/
def weightAlignment (ys : Array Int) : Prop := ys = CertificateDescriptors.p33aYData

theorem cl_source_scale_aligned : P33Arithmetic.sosScale = CertificateDescriptors.p33aScale := by
  decide +kernel

theorem exact_weight_alignment : weightAlignment P33Arithmetic.denseInequalities := dense_source_array

/-- The complete equality predicate rejects a planted signed coefficient gap. -/
theorem weight_alignment_corruption_rejected :
    ¬weightAlignment (P33Arithmetic.denseInequalities.set! 0 (-1)) := by
  intro h
  have hz := CertificateDescriptors.p33a_signed_checked.2 ⟨0,by decide⟩
  change (P33Arithmetic.denseInequalities.set! 0 (-1)) = CertificateDescriptors.p33aYData at h
  rw [←h,Array.getElem!_set!_self P33Arithmetic.denseInequalities 0 (-1)
    (by decide +kernel)] at hz
  norm_num at hz

#print axioms cl_source_scale_aligned
#print axioms exact_weight_alignment
#print axioms weight_alignment_corruption_rejected
end TightCycleC5.Bridge.P33RowMatching
