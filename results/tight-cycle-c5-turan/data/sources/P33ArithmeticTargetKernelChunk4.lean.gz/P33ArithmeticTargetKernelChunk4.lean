-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk16 :
    ∀ i : Fin (min 128 (40547 - 128 * 16)),
      targetCountsMatch (classAt (targetKernelClass ⟨16, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk16

theorem target_counts_kernel_chunk17 :
    ∀ i : Fin (min 128 (40547 - 128 * 17)),
      targetCountsMatch (classAt (targetKernelClass ⟨17, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk17

theorem target_counts_kernel_chunk18 :
    ∀ i : Fin (min 128 (40547 - 128 * 18)),
      targetCountsMatch (classAt (targetKernelClass ⟨18, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk18

theorem target_counts_kernel_chunk19 :
    ∀ i : Fin (min 128 (40547 - 128 * 19)),
      targetCountsMatch (classAt (targetKernelClass ⟨19, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk19


end TightCycleC5.Bridge.P33Arithmetic
