import ColoredCoverSemantics

namespace TightCycleC5.Bridge.ColoredCover
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def coloredWitness96 : Array Nat := #[2741760, 2742480, 2743200, 2743920, 2743224, 2743944, 2744640, 2745360, 2746080, 2746800, 2747520, 2748240, 2747544, 2748264, 2748960, 2749680, 2750400, 2751120, 2751840, 2752560, 2751864, 2752584, 2753280, 2754000, 2754720, 2755440, 2756160, 2756880, 2756184, 2756904, 2757600, 2758320, 2750401, 2751121, 2751841, 2752561, 2751865, 2752585, 2753281, 2754001, 2754721, 2755441, 2756161, 2756881, 2756185, 2756905, 2757601, 2758321, 2759040, 2759760, 2760480, 2761200, 2760504, 2761224, 2761920, 2762640, 2763360, 2764080, 2764800, 2765520, 2764824, 2765544, 2766240, 2766960]

theorem colored_row96 : ∀ c : Fin 64,
    readRow witnessRows (96 * 64 + c.val) = coloredWitness96[c.val]! := by
  decide +kernel
#print axioms colored_row96

theorem colored_check96 : ∀ c : Fin 64,
    checkColored 96 (BitVec.ofNat 6 c.val) (coloredWitness96[c.val]!) = true := by
  decide +kernel
#print axioms colored_check96

theorem colored_family96 : ∀ c : Fin 64,
    checkColored 96 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (96 * 64 + c.val)) = true := by
  intro c
  rw [colored_row96]
  exact colored_check96 c
#print axioms colored_family96

def coloredWitness97 : Array Nat := #[2767680, 2768400, 2769120, 2769840, 2770560, 2771280, 2772000, 2772720, 2770566, 2771286, 2772006, 2772726, 2773440, 2774160, 2774880, 2775600, 2776320, 2777040, 2777760, 2778480, 2779200, 2779920, 2780640, 2781360, 2779206, 2779926, 2780646, 2781366, 2782080, 2782800, 2783520, 2784240, 2776321, 2777041, 2777761, 2778481, 2779201, 2779921, 2780641, 2781361, 2779207, 2779927, 2780647, 2781367, 2782081, 2782801, 2783521, 2784241, 2784960, 2785680, 2786400, 2787120, 2787840, 2788560, 2789280, 2790000, 2787846, 2788566, 2789286, 2790006, 2790720, 2791440, 2792160, 2792880]

theorem colored_row97 : ∀ c : Fin 64,
    readRow witnessRows (97 * 64 + c.val) = coloredWitness97[c.val]! := by
  decide +kernel
#print axioms colored_row97

theorem colored_check97 : ∀ c : Fin 64,
    checkColored 97 (BitVec.ofNat 6 c.val) (coloredWitness97[c.val]!) = true := by
  decide +kernel
#print axioms colored_check97

theorem colored_family97 : ∀ c : Fin 64,
    checkColored 97 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (97 * 64 + c.val)) = true := by
  intro c
  rw [colored_row97]
  exact colored_check97 c
#print axioms colored_family97

def coloredWitness98 : Array Nat := #[2793600, 2794320, 2794456, 2795040, 2795760, 2796480, 2797200, 2797920, 2798640, 2799360, 2800080, 2800800, 2801520, 2802240, 2802960, 2803680, 2795896, 2797336, 2796616, 2798056, 2804400, 2805120, 2805256, 2805840, 2806560, 2807280, 2808000, 2808720, 2809440, 2810160, 2810880, 2811600, 2798776, 2800216, 2799496, 2800936, 2806696, 2808136, 2807416, 2808856, 2812320, 2813040, 2813176, 2813760, 2814480, 2815200, 2815920, 2816640, 2801656, 2803096, 2802376, 2803816, 2809576, 2811016, 2810296, 2811736, 2814616, 2816056, 2815336, 2816776, 2817360, 2818080, 2818216, 2818800]

theorem colored_row98 : ∀ c : Fin 64,
    readRow witnessRows (98 * 64 + c.val) = coloredWitness98[c.val]! := by
  decide +kernel
#print axioms colored_row98

theorem colored_check98 : ∀ c : Fin 64,
    checkColored 98 (BitVec.ofNat 6 c.val) (coloredWitness98[c.val]!) = true := by
  decide +kernel
#print axioms colored_check98

theorem colored_family98 : ∀ c : Fin 64,
    checkColored 98 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (98 * 64 + c.val)) = true := by
  intro c
  rw [colored_row98]
  exact colored_check98 c
#print axioms colored_family98

def coloredWitness99 : Array Nat := #[2819520, 2820240, 2820960, 2821680, 2822400, 2823120, 2823840, 2824560, 2822406, 2823126, 2823846, 2824566, 2825280, 2826000, 2826720, 2827440, 2828160, 2828880, 2829600, 2830320, 2831040, 2831760, 2832480, 2833200, 2831046, 2831766, 2832486, 2833206, 2833920, 2834640, 2835360, 2836080, 2836800, 2837520, 2838240, 2838960, 2839680, 2840400, 2841120, 2841840, 2839686, 2840406, 2841126, 2841846, 2842560, 2843280, 2844000, 2844720, 2845440, 2846160, 2846880, 2847600, 2848320, 2849040, 2849760, 2850480, 2848326, 2849046, 2849766, 2850486, 2851200, 2851920, 2852640, 2853360]

theorem colored_row99 : ∀ c : Fin 64,
    readRow witnessRows (99 * 64 + c.val) = coloredWitness99[c.val]! := by
  decide +kernel
#print axioms colored_row99

theorem colored_check99 : ∀ c : Fin 64,
    checkColored 99 (BitVec.ofNat 6 c.val) (coloredWitness99[c.val]!) = true := by
  decide +kernel
#print axioms colored_check99

theorem colored_family99 : ∀ c : Fin 64,
    checkColored 99 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (99 * 64 + c.val)) = true := by
  intro c
  rw [colored_row99]
  exact colored_check99 c
#print axioms colored_family99

def coloredWitness100 : Array Nat := #[2854080, 2854800, 2854936, 2855520, 2856240, 2856960, 2857680, 2858400, 2856246, 2856966, 2857686, 2858406, 2859120, 2859840, 2860560, 2861280, 2856376, 2857816, 2857096, 2858536, 2862000, 2862720, 2862856, 2863440, 2862006, 2862726, 2862857, 2863446, 2864160, 2864880, 2865600, 2866320, 2856382, 2857822, 2857102, 2858542, 2862001, 2862721, 2862862, 2863441, 2862007, 2862727, 2862863, 2863447, 2864161, 2864881, 2865601, 2866321, 2859256, 2860696, 2859976, 2861416, 2864296, 2865736, 2865016, 2866456, 2864297, 2865737, 2865017, 2866457, 2867040, 2867760, 2867896, 2868480]

theorem colored_row100 : ∀ c : Fin 64,
    readRow witnessRows (100 * 64 + c.val) = coloredWitness100[c.val]! := by
  decide +kernel
#print axioms colored_row100

theorem colored_check100 : ∀ c : Fin 64,
    checkColored 100 (BitVec.ofNat 6 c.val) (coloredWitness100[c.val]!) = true := by
  decide +kernel
#print axioms colored_check100

theorem colored_family100 : ∀ c : Fin 64,
    checkColored 100 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (100 * 64 + c.val)) = true := by
  intro c
  rw [colored_row100]
  exact colored_check100 c
#print axioms colored_family100

def coloredWitness101 : Array Nat := #[2869200, 2869920, 2870640, 2871360, 2870664, 2871384, 2872080, 2872800, 2870688, 2871408, 2872086, 2872806, 2872110, 2872830, 2873520, 2874240, 2874960, 2875680, 2876400, 2877120, 2876424, 2877144, 2877840, 2878560, 2876448, 2877168, 2877846, 2878566, 2877870, 2878590, 2879280, 2880000, 2874961, 2875681, 2876401, 2877121, 2876425, 2877145, 2877841, 2878561, 2876449, 2877169, 2877847, 2878567, 2877871, 2878591, 2879281, 2880001, 2880720, 2881440, 2882160, 2882880, 2882184, 2882904, 2883600, 2884320, 2882208, 2882928, 2883606, 2884326, 2883630, 2884350, 2885040, 2885760]

theorem colored_row101 : ∀ c : Fin 64,
    readRow witnessRows (101 * 64 + c.val) = coloredWitness101[c.val]! := by
  decide +kernel
#print axioms colored_row101

theorem colored_check101 : ∀ c : Fin 64,
    checkColored 101 (BitVec.ofNat 6 c.val) (coloredWitness101[c.val]!) = true := by
  decide +kernel
#print axioms colored_check101

theorem colored_family101 : ∀ c : Fin 64,
    checkColored 101 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (101 * 64 + c.val)) = true := by
  intro c
  rw [colored_row101]
  exact colored_check101 c
#print axioms colored_family101

def coloredWitness102 : Array Nat := #[2886480, 2887200, 2887920, 2888640, 2889360, 2890080, 2890800, 2891520, 2889366, 2890086, 2890806, 2891526, 2892240, 2892960, 2893680, 2894400, 2895120, 2895840, 2896560, 2897280, 2898000, 2898720, 2899440, 2900160, 2898006, 2898726, 2899446, 2900166, 2900880, 2901600, 2902320, 2903040, 2903760, 2904480, 2905200, 2905920, 2906640, 2907360, 2908080, 2908800, 2906646, 2907366, 2908086, 2908806, 2909520, 2910240, 2910960, 2911680, 2912400, 2913120, 2913840, 2914560, 2915280, 2916000, 2916720, 2917440, 2915286, 2916006, 2916726, 2917446, 2918160, 2918880, 2919600, 2920320]

theorem colored_row102 : ∀ c : Fin 64,
    readRow witnessRows (102 * 64 + c.val) = coloredWitness102[c.val]! := by
  decide +kernel
#print axioms colored_row102

theorem colored_check102 : ∀ c : Fin 64,
    checkColored 102 (BitVec.ofNat 6 c.val) (coloredWitness102[c.val]!) = true := by
  decide +kernel
#print axioms colored_check102

theorem colored_family102 : ∀ c : Fin 64,
    checkColored 102 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (102 * 64 + c.val)) = true := by
  intro c
  rw [colored_row102]
  exact colored_check102 c
#print axioms colored_family102

def coloredWitness103 : Array Nat := #[2921040, 2921760, 2922480, 2923200, 2923920, 2924640, 2925360, 2926080, 2926800, 2927520, 2928240, 2928960, 2929680, 2930400, 2931120, 2931840, 2932560, 2933280, 2934000, 2934720, 2935440, 2936160, 2936880, 2937600, 2938320, 2939040, 2939760, 2940480, 2941200, 2941920, 2942640, 2943360, 2944080, 2944800, 2945520, 2946240, 2946960, 2947680, 2948400, 2949120, 2949840, 2950560, 2951280, 2952000, 2952720, 2953440, 2954160, 2954880, 2955600, 2956320, 2957040, 2957760, 2958480, 2959200, 2959920, 2960640, 2961360, 2962080, 2962800, 2963520, 2964240, 2964960, 2965680, 2966400]

theorem colored_row103 : ∀ c : Fin 64,
    readRow witnessRows (103 * 64 + c.val) = coloredWitness103[c.val]! := by
  decide +kernel
#print axioms colored_row103

theorem colored_check103 : ∀ c : Fin 64,
    checkColored 103 (BitVec.ofNat 6 c.val) (coloredWitness103[c.val]!) = true := by
  decide +kernel
#print axioms colored_check103

theorem colored_family103 : ∀ c : Fin 64,
    checkColored 103 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (103 * 64 + c.val)) = true := by
  intro c
  rw [colored_row103]
  exact colored_check103 c
#print axioms colored_family103

def coloredWitness104 : Array Nat := #[2967120, 2967840, 2968560, 2969280, 2970000, 2970720, 2971440, 2972160, 2970006, 2970726, 2971446, 2972166, 2972880, 2973600, 2974320, 2975040, 2975760, 2976480, 2977200, 2977920, 2978640, 2979360, 2980080, 2980800, 2978646, 2979366, 2980086, 2980806, 2981520, 2982240, 2982960, 2983680, 2984400, 2985120, 2985840, 2986560, 2987280, 2988000, 2988720, 2989440, 2987286, 2988006, 2988726, 2989446, 2990160, 2990880, 2991600, 2992320, 2993040, 2993760, 2994480, 2995200, 2995920, 2996640, 2997360, 2998080, 2995926, 2996646, 2997366, 2998086, 2998800, 2999520, 3000240, 3000960]

theorem colored_row104 : ∀ c : Fin 64,
    readRow witnessRows (104 * 64 + c.val) = coloredWitness104[c.val]! := by
  decide +kernel
#print axioms colored_row104

theorem colored_check104 : ∀ c : Fin 64,
    checkColored 104 (BitVec.ofNat 6 c.val) (coloredWitness104[c.val]!) = true := by
  decide +kernel
#print axioms colored_check104

theorem colored_family104 : ∀ c : Fin 64,
    checkColored 104 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (104 * 64 + c.val)) = true := by
  intro c
  rw [colored_row104]
  exact colored_check104 c
#print axioms colored_family104

def coloredWitness105 : Array Nat := #[3001680, 3002400, 3003120, 3003840, 3004560, 3005280, 3006000, 3006720, 3004566, 3005286, 3006006, 3006726, 3007440, 3008160, 3008880, 3009600, 3010320, 3011040, 3011760, 3012480, 3013200, 3013920, 3014640, 3015360, 3013206, 3013926, 3014646, 3015366, 3016080, 3016800, 3017520, 3018240, 3010321, 3011041, 3011761, 3012481, 3013201, 3013921, 3014641, 3015361, 3013207, 3013927, 3014647, 3015367, 3016081, 3016801, 3017521, 3018241, 3018960, 3019680, 3020400, 3021120, 3021840, 3022560, 3023280, 3024000, 3021846, 3022566, 3023286, 3024006, 3024720, 3025440, 3026160, 3026880]

theorem colored_row105 : ∀ c : Fin 64,
    readRow witnessRows (105 * 64 + c.val) = coloredWitness105[c.val]! := by
  decide +kernel
#print axioms colored_row105

theorem colored_check105 : ∀ c : Fin 64,
    checkColored 105 (BitVec.ofNat 6 c.val) (coloredWitness105[c.val]!) = true := by
  decide +kernel
#print axioms colored_check105

theorem colored_family105 : ∀ c : Fin 64,
    checkColored 105 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (105 * 64 + c.val)) = true := by
  intro c
  rw [colored_row105]
  exact colored_check105 c
#print axioms colored_family105

def coloredWitness106 : Array Nat := #[3027600, 3028320, 3029040, 3029760, 3030480, 3031200, 3031920, 3032640, 3033360, 3034080, 3034800, 3035520, 3036240, 3036960, 3037680, 3038400, 3039120, 3039840, 3040560, 3041280, 3042000, 3042720, 3043440, 3044160, 3044880, 3045600, 3046320, 3047040, 3047760, 3048480, 3049200, 3049920, 3039121, 3039841, 3040561, 3041281, 3042001, 3042721, 3043441, 3044161, 3044881, 3045601, 3046321, 3047041, 3047761, 3048481, 3049201, 3049921, 3050640, 3051360, 3052080, 3052800, 3053520, 3054240, 3054960, 3055680, 3056400, 3057120, 3057840, 3058560, 3059280, 3060000, 3060720, 3061440]

theorem colored_row106 : ∀ c : Fin 64,
    readRow witnessRows (106 * 64 + c.val) = coloredWitness106[c.val]! := by
  decide +kernel
#print axioms colored_row106

theorem colored_check106 : ∀ c : Fin 64,
    checkColored 106 (BitVec.ofNat 6 c.val) (coloredWitness106[c.val]!) = true := by
  decide +kernel
#print axioms colored_check106

theorem colored_family106 : ∀ c : Fin 64,
    checkColored 106 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (106 * 64 + c.val)) = true := by
  intro c
  rw [colored_row106]
  exact colored_check106 c
#print axioms colored_family106

def coloredWitness107 : Array Nat := #[3062160, 3062880, 3063600, 3064320, 3065040, 3065760, 3066480, 3067200, 3065046, 3065766, 3066486, 3067206, 3067920, 3068640, 3069360, 3070080, 3070800, 3071520, 3072240, 3072960, 3073680, 3074400, 3075120, 3075840, 3073686, 3074406, 3075126, 3075846, 3076560, 3077280, 3078000, 3078720, 3070801, 3071521, 3072241, 3072961, 3073681, 3074401, 3075121, 3075841, 3073687, 3074407, 3075127, 3075847, 3076561, 3077281, 3078001, 3078721, 3079440, 3080160, 3080880, 3081600, 3082320, 3083040, 3083760, 3084480, 3082326, 3083046, 3083766, 3084486, 3085200, 3085920, 3086640, 3087360]

theorem colored_row107 : ∀ c : Fin 64,
    readRow witnessRows (107 * 64 + c.val) = coloredWitness107[c.val]! := by
  decide +kernel
#print axioms colored_row107

theorem colored_check107 : ∀ c : Fin 64,
    checkColored 107 (BitVec.ofNat 6 c.val) (coloredWitness107[c.val]!) = true := by
  decide +kernel
#print axioms colored_check107

theorem colored_family107 : ∀ c : Fin 64,
    checkColored 107 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (107 * 64 + c.val)) = true := by
  intro c
  rw [colored_row107]
  exact colored_check107 c
#print axioms colored_family107

def coloredWitness108 : Array Nat := #[3088080, 3088800, 3089520, 3090240, 3089544, 3090264, 3090960, 3091680, 3092400, 3093120, 3093840, 3094560, 3093864, 3094584, 3095280, 3096000, 3089312, 3096720, 3090752, 3097440, 3090776, 3097464, 3092192, 3098160, 3093632, 3098880, 3095072, 3099600, 3095096, 3099624, 3096512, 3100320, 3101040, 3101760, 3102480, 3103200, 3102504, 3103224, 3103920, 3104640, 3105360, 3106080, 3106800, 3107520, 3106824, 3107544, 3108240, 3108960, 3102272, 3109680, 3103712, 3110400, 3103736, 3110424, 3105152, 3111120, 3106592, 3111840, 3108032, 3112560, 3108056, 3112584, 3109472, 3113280]

theorem colored_row108 : ∀ c : Fin 64,
    readRow witnessRows (108 * 64 + c.val) = coloredWitness108[c.val]! := by
  decide +kernel
#print axioms colored_row108

theorem colored_check108 : ∀ c : Fin 64,
    checkColored 108 (BitVec.ofNat 6 c.val) (coloredWitness108[c.val]!) = true := by
  decide +kernel
#print axioms colored_check108

theorem colored_family108 : ∀ c : Fin 64,
    checkColored 108 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (108 * 64 + c.val)) = true := by
  intro c
  rw [colored_row108]
  exact colored_check108 c
#print axioms colored_family108

def coloredWitness109 : Array Nat := #[3114000, 3114720, 3115440, 3116160, 3115464, 3116184, 3116880, 3117600, 3118320, 3119040, 3119760, 3120480, 3119784, 3120504, 3121200, 3121920, 3122640, 3123360, 3124080, 3124800, 3124104, 3124824, 3125520, 3126240, 3126960, 3127680, 3128400, 3129120, 3128424, 3129144, 3129840, 3130560, 3131280, 3132000, 3132720, 3133440, 3132744, 3133464, 3134160, 3134880, 3135600, 3136320, 3137040, 3137760, 3137064, 3137784, 3138480, 3139200, 3139920, 3140640, 3141360, 3142080, 3141384, 3142104, 3142800, 3143520, 3144240, 3144960, 3145680, 3146400, 3145704, 3146424, 3147120, 3147840]

theorem colored_row109 : ∀ c : Fin 64,
    readRow witnessRows (109 * 64 + c.val) = coloredWitness109[c.val]! := by
  decide +kernel
#print axioms colored_row109

theorem colored_check109 : ∀ c : Fin 64,
    checkColored 109 (BitVec.ofNat 6 c.val) (coloredWitness109[c.val]!) = true := by
  decide +kernel
#print axioms colored_check109

theorem colored_family109 : ∀ c : Fin 64,
    checkColored 109 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (109 * 64 + c.val)) = true := by
  intro c
  rw [colored_row109]
  exact colored_check109 c
#print axioms colored_family109

def coloredWitness110 : Array Nat := #[3148560, 3149280, 3150000, 3150720, 3151440, 3152160, 3152880, 3153600, 3154320, 3155040, 3155760, 3156480, 3157200, 3157920, 3158640, 3159360, 3160080, 3160800, 3161520, 3162240, 3162960, 3163680, 3164400, 3165120, 3165840, 3166560, 3167280, 3168000, 3168720, 3169440, 3170160, 3170880, 3171600, 3172320, 3173040, 3173760, 3174480, 3175200, 3175920, 3176640, 3177360, 3178080, 3178800, 3179520, 3180240, 3180960, 3181680, 3182400, 3183120, 3183840, 3184560, 3185280, 3186000, 3186720, 3187440, 3188160, 3188880, 3189600, 3190320, 3191040, 3191760, 3192480, 3193200, 3193920]

theorem colored_row110 : ∀ c : Fin 64,
    readRow witnessRows (110 * 64 + c.val) = coloredWitness110[c.val]! := by
  decide +kernel
#print axioms colored_row110

theorem colored_check110 : ∀ c : Fin 64,
    checkColored 110 (BitVec.ofNat 6 c.val) (coloredWitness110[c.val]!) = true := by
  decide +kernel
#print axioms colored_check110

theorem colored_family110 : ∀ c : Fin 64,
    checkColored 110 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (110 * 64 + c.val)) = true := by
  intro c
  rw [colored_row110]
  exact colored_check110 c
#print axioms colored_family110

def coloredWitness111 : Array Nat := #[3194640, 3195360, 3196080, 3196800, 3197520, 3198240, 3198960, 3199680, 3200400, 3201120, 3201840, 3202560, 3203280, 3204000, 3204720, 3205440, 3206160, 3206880, 3207600, 3208320, 3209040, 3209760, 3210480, 3211200, 3211920, 3212640, 3213360, 3214080, 3214800, 3215520, 3216240, 3216960, 3217680, 3218400, 3219120, 3219840, 3220560, 3221280, 3222000, 3222720, 3223440, 3224160, 3224880, 3225600, 3226320, 3227040, 3227760, 3228480, 3229200, 3229920, 3230640, 3231360, 3232080, 3232800, 3233520, 3234240, 3234960, 3235680, 3236400, 3237120, 3237840, 3238560, 3239280, 3240000]

theorem colored_row111 : ∀ c : Fin 64,
    readRow witnessRows (111 * 64 + c.val) = coloredWitness111[c.val]! := by
  decide +kernel
#print axioms colored_row111

theorem colored_check111 : ∀ c : Fin 64,
    checkColored 111 (BitVec.ofNat 6 c.val) (coloredWitness111[c.val]!) = true := by
  decide +kernel
#print axioms colored_check111

theorem colored_family111 : ∀ c : Fin 64,
    checkColored 111 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (111 * 64 + c.val)) = true := by
  intro c
  rw [colored_row111]
  exact colored_check111 c
#print axioms colored_family111

def coloredWitness112 : Array Nat := #[3240720, 3241440, 3242160, 3242880, 3242185, 3242905, 3243600, 3244320, 3245040, 3245760, 3246480, 3247200, 3246505, 3247225, 3247920, 3248640, 3249360, 3250080, 3250800, 3251520, 3252240, 3252960, 3253680, 3254400, 3255120, 3255840, 3256560, 3257280, 3258000, 3258720, 3259440, 3260160, 3249385, 3250105, 3252265, 3252985, 3250825, 3251545, 3253705, 3254425, 3255145, 3255865, 3258025, 3258745, 3256585, 3257305, 3259465, 3260185, 3260880, 3261600, 3262320, 3263040, 3262345, 3263065, 3263760, 3264480, 3265200, 3265920, 3266640, 3267360, 3266665, 3267385, 3268080, 3268800]

theorem colored_row112 : ∀ c : Fin 64,
    readRow witnessRows (112 * 64 + c.val) = coloredWitness112[c.val]! := by
  decide +kernel
#print axioms colored_row112

theorem colored_check112 : ∀ c : Fin 64,
    checkColored 112 (BitVec.ofNat 6 c.val) (coloredWitness112[c.val]!) = true := by
  decide +kernel
#print axioms colored_check112

theorem colored_family112 : ∀ c : Fin 64,
    checkColored 112 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (112 * 64 + c.val)) = true := by
  intro c
  rw [colored_row112]
  exact colored_check112 c
#print axioms colored_family112

def coloredWitness113 : Array Nat := #[3269520, 3270240, 3270960, 3271680, 3270985, 3271705, 3272400, 3273120, 3273840, 3274560, 3275280, 3276000, 3275305, 3276025, 3276720, 3277440, 3278160, 3278880, 3279600, 3280320, 3281040, 3281760, 3282480, 3283200, 3283920, 3284640, 3285360, 3286080, 3286800, 3287520, 3288240, 3288960, 3278185, 3278905, 3281065, 3281785, 3279625, 3280345, 3282505, 3283225, 3283945, 3284665, 3286825, 3287545, 3285385, 3286105, 3288265, 3288985, 3289680, 3290400, 3291120, 3291840, 3291145, 3291865, 3292560, 3293280, 3294000, 3294720, 3295440, 3296160, 3295465, 3296185, 3296880, 3297600]

theorem colored_row113 : ∀ c : Fin 64,
    readRow witnessRows (113 * 64 + c.val) = coloredWitness113[c.val]! := by
  decide +kernel
#print axioms colored_row113

theorem colored_check113 : ∀ c : Fin 64,
    checkColored 113 (BitVec.ofNat 6 c.val) (coloredWitness113[c.val]!) = true := by
  decide +kernel
#print axioms colored_check113

theorem colored_family113 : ∀ c : Fin 64,
    checkColored 113 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (113 * 64 + c.val)) = true := by
  intro c
  rw [colored_row113]
  exact colored_check113 c
#print axioms colored_family113

def coloredWitness114 : Array Nat := #[3298320, 3299040, 3299760, 3300480, 3301200, 3301920, 3302640, 3303360, 3304080, 3304800, 3305520, 3306240, 3306960, 3307680, 3308400, 3309120, 3309840, 3310560, 3311280, 3312000, 3312720, 3313440, 3314160, 3314880, 3315600, 3316320, 3317040, 3317760, 3318480, 3319200, 3319920, 3320640, 3321360, 3322080, 3322800, 3323520, 3324240, 3324960, 3325680, 3326400, 3327120, 3327840, 3328560, 3329280, 3330000, 3330720, 3331440, 3332160, 3332880, 3333600, 3334320, 3335040, 3335760, 3336480, 3337200, 3337920, 3338640, 3339360, 3340080, 3340800, 3341520, 3342240, 3342960, 3343680]

theorem colored_row114 : ∀ c : Fin 64,
    readRow witnessRows (114 * 64 + c.val) = coloredWitness114[c.val]! := by
  decide +kernel
#print axioms colored_row114

theorem colored_check114 : ∀ c : Fin 64,
    checkColored 114 (BitVec.ofNat 6 c.val) (coloredWitness114[c.val]!) = true := by
  decide +kernel
#print axioms colored_check114

theorem colored_family114 : ∀ c : Fin 64,
    checkColored 114 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (114 * 64 + c.val)) = true := by
  intro c
  rw [colored_row114]
  exact colored_check114 c
#print axioms colored_family114

def coloredWitness115 : Array Nat := #[3344400, 3345120, 3345840, 3346560, 3347280, 3348000, 3348720, 3349440, 3350160, 3350880, 3351600, 3352320, 3353040, 3353760, 3354480, 3355200, 3355920, 3356640, 3357360, 3358080, 3358800, 3359520, 3360240, 3360960, 3361680, 3362400, 3363120, 3363840, 3364560, 3365280, 3366000, 3366720, 3367440, 3368160, 3368880, 3369600, 3370320, 3371040, 3371760, 3372480, 3373200, 3373920, 3374640, 3375360, 3376080, 3376800, 3377520, 3378240, 3378960, 3379680, 3380400, 3381120, 3381840, 3382560, 3383280, 3384000, 3384720, 3385440, 3386160, 3386880, 3387600, 3388320, 3389040, 3389760]

theorem colored_row115 : ∀ c : Fin 64,
    readRow witnessRows (115 * 64 + c.val) = coloredWitness115[c.val]! := by
  decide +kernel
#print axioms colored_row115

theorem colored_check115 : ∀ c : Fin 64,
    checkColored 115 (BitVec.ofNat 6 c.val) (coloredWitness115[c.val]!) = true := by
  decide +kernel
#print axioms colored_check115

theorem colored_family115 : ∀ c : Fin 64,
    checkColored 115 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (115 * 64 + c.val)) = true := by
  intro c
  rw [colored_row115]
  exact colored_check115 c
#print axioms colored_family115

def coloredWitness116 : Array Nat := #[3390480, 3391200, 3391920, 3392640, 3393360, 3394080, 3394800, 3395520, 3396240, 3396960, 3397680, 3398400, 3399120, 3399840, 3400560, 3401280, 3402000, 3402720, 3403440, 3404160, 3404880, 3405600, 3406320, 3407040, 3407760, 3408480, 3409200, 3409920, 3410640, 3411360, 3412080, 3412800, 3413520, 3414240, 3414960, 3415680, 3416400, 3417120, 3417840, 3418560, 3419280, 3420000, 3420720, 3421440, 3422160, 3422880, 3423600, 3424320, 3425040, 3425760, 3426480, 3427200, 3427920, 3428640, 3429360, 3430080, 3430800, 3431520, 3432240, 3432960, 3433680, 3434400, 3435120, 3435840]

theorem colored_row116 : ∀ c : Fin 64,
    readRow witnessRows (116 * 64 + c.val) = coloredWitness116[c.val]! := by
  decide +kernel
#print axioms colored_row116

theorem colored_check116 : ∀ c : Fin 64,
    checkColored 116 (BitVec.ofNat 6 c.val) (coloredWitness116[c.val]!) = true := by
  decide +kernel
#print axioms colored_check116

theorem colored_family116 : ∀ c : Fin 64,
    checkColored 116 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (116 * 64 + c.val)) = true := by
  intro c
  rw [colored_row116]
  exact colored_check116 c
#print axioms colored_family116

def coloredWitness117 : Array Nat := #[3436560, 3437280, 3438000, 3438720, 3439440, 3440160, 3440880, 3441600, 3442320, 3443040, 3443760, 3444480, 3445200, 3445920, 3446640, 3447360, 3448080, 3448800, 3449520, 3450240, 3450960, 3451680, 3452400, 3453120, 3453840, 3454560, 3455280, 3456000, 3456720, 3457440, 3458160, 3458880, 3459600, 3460320, 3461040, 3461760, 3462480, 3463200, 3463920, 3464640, 3465360, 3466080, 3466800, 3467520, 3468240, 3468960, 3469680, 3470400, 3471120, 3471840, 3472560, 3473280, 3474000, 3474720, 3475440, 3476160, 3476880, 3477600, 3478320, 3479040, 3479760, 3480480, 3481200, 3481920]

theorem colored_row117 : ∀ c : Fin 64,
    readRow witnessRows (117 * 64 + c.val) = coloredWitness117[c.val]! := by
  decide +kernel
#print axioms colored_row117

theorem colored_check117 : ∀ c : Fin 64,
    checkColored 117 (BitVec.ofNat 6 c.val) (coloredWitness117[c.val]!) = true := by
  decide +kernel
#print axioms colored_check117

theorem colored_family117 : ∀ c : Fin 64,
    checkColored 117 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (117 * 64 + c.val)) = true := by
  intro c
  rw [colored_row117]
  exact colored_check117 c
#print axioms colored_family117

def coloredWitness118 : Array Nat := #[3482640, 3483360, 3484080, 3484800, 3485520, 3486240, 3486960, 3487680, 3488400, 3489120, 3489840, 3490560, 3491280, 3492000, 3492720, 3493440, 3494160, 3494880, 3495600, 3496320, 3497040, 3497760, 3498480, 3499200, 3499920, 3500640, 3501360, 3502080, 3502800, 3503520, 3504240, 3504960, 3505680, 3506400, 3507120, 3507840, 3508560, 3509280, 3510000, 3510720, 3511440, 3512160, 3512880, 3513600, 3514320, 3515040, 3515760, 3516480, 3517200, 3517920, 3518640, 3519360, 3520080, 3520800, 3521520, 3522240, 3522960, 3523680, 3524400, 3525120, 3525840, 3526560, 3527280, 3528000]

theorem colored_row118 : ∀ c : Fin 64,
    readRow witnessRows (118 * 64 + c.val) = coloredWitness118[c.val]! := by
  decide +kernel
#print axioms colored_row118

theorem colored_check118 : ∀ c : Fin 64,
    checkColored 118 (BitVec.ofNat 6 c.val) (coloredWitness118[c.val]!) = true := by
  decide +kernel
#print axioms colored_check118

theorem colored_family118 : ∀ c : Fin 64,
    checkColored 118 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (118 * 64 + c.val)) = true := by
  intro c
  rw [colored_row118]
  exact colored_check118 c
#print axioms colored_family118

def coloredWitness119 : Array Nat := #[3528720, 3529440, 3530160, 3530880, 3531600, 3532320, 3533040, 3533760, 3534480, 3535200, 3535920, 3536640, 3537360, 3538080, 3538800, 3539520, 3540240, 3540960, 3541680, 3542400, 3543120, 3543840, 3544560, 3545280, 3546000, 3546720, 3547440, 3548160, 3548880, 3549600, 3550320, 3551040, 3551760, 3552480, 3553200, 3553920, 3554640, 3555360, 3556080, 3556800, 3557520, 3558240, 3558960, 3559680, 3560400, 3561120, 3561840, 3562560, 3563280, 3564000, 3564720, 3565440, 3566160, 3566880, 3567600, 3568320, 3569040, 3569760, 3570480, 3571200, 3571920, 3572640, 3573360, 3574080]

theorem colored_row119 : ∀ c : Fin 64,
    readRow witnessRows (119 * 64 + c.val) = coloredWitness119[c.val]! := by
  decide +kernel
#print axioms colored_row119

theorem colored_check119 : ∀ c : Fin 64,
    checkColored 119 (BitVec.ofNat 6 c.val) (coloredWitness119[c.val]!) = true := by
  decide +kernel
#print axioms colored_check119

theorem colored_family119 : ∀ c : Fin 64,
    checkColored 119 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (119 * 64 + c.val)) = true := by
  intro c
  rw [colored_row119]
  exact colored_check119 c
#print axioms colored_family119

def coloredWitness120 : Array Nat := #[3574800, 3575520, 3576240, 3576960, 3576264, 3576984, 3577680, 3578400, 3579120, 3579840, 3580560, 3581280, 3580584, 3581304, 3582000, 3582720, 3583440, 3584160, 3584880, 3585600, 3584904, 3585624, 3586320, 3587040, 3587760, 3588480, 3589200, 3589920, 3589224, 3589944, 3590640, 3591360, 3592080, 3592800, 3593520, 3594240, 3593544, 3594264, 3594960, 3595680, 3596400, 3597120, 3597840, 3598560, 3597864, 3598584, 3599280, 3600000, 3600720, 3601440, 3602160, 3602880, 3602184, 3602904, 3603600, 3604320, 3605040, 3605760, 3606480, 3607200, 3606504, 3607224, 3607920, 3608640]

theorem colored_row120 : ∀ c : Fin 64,
    readRow witnessRows (120 * 64 + c.val) = coloredWitness120[c.val]! := by
  decide +kernel
#print axioms colored_row120

theorem colored_check120 : ∀ c : Fin 64,
    checkColored 120 (BitVec.ofNat 6 c.val) (coloredWitness120[c.val]!) = true := by
  decide +kernel
#print axioms colored_check120

theorem colored_family120 : ∀ c : Fin 64,
    checkColored 120 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (120 * 64 + c.val)) = true := by
  intro c
  rw [colored_row120]
  exact colored_check120 c
#print axioms colored_family120

def coloredWitness121 : Array Nat := #[3609360, 3610080, 3610800, 3611520, 3610824, 3611544, 3612240, 3612960, 3613680, 3614400, 3615120, 3615840, 3615144, 3615864, 3616560, 3617280, 3618000, 3618720, 3619440, 3620160, 3619464, 3620184, 3620880, 3621600, 3622320, 3623040, 3623760, 3624480, 3623784, 3624504, 3625200, 3625920, 3626640, 3627360, 3628080, 3628800, 3628104, 3628824, 3629520, 3630240, 3630960, 3631680, 3632400, 3633120, 3632424, 3633144, 3633840, 3634560, 3635280, 3636000, 3636720, 3637440, 3636744, 3637464, 3638160, 3638880, 3639600, 3640320, 3641040, 3641760, 3641064, 3641784, 3642480, 3643200]

theorem colored_row121 : ∀ c : Fin 64,
    readRow witnessRows (121 * 64 + c.val) = coloredWitness121[c.val]! := by
  decide +kernel
#print axioms colored_row121

theorem colored_check121 : ∀ c : Fin 64,
    checkColored 121 (BitVec.ofNat 6 c.val) (coloredWitness121[c.val]!) = true := by
  decide +kernel
#print axioms colored_check121

theorem colored_family121 : ∀ c : Fin 64,
    checkColored 121 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (121 * 64 + c.val)) = true := by
  intro c
  rw [colored_row121]
  exact colored_check121 c
#print axioms colored_family121

def coloredWitness122 : Array Nat := #[3643920, 3644640, 3645360, 3646080, 3645385, 3646105, 3646800, 3647520, 3648240, 3648960, 3649680, 3650400, 3649705, 3650425, 3651120, 3651840, 3652560, 3653280, 3654000, 3654720, 3655440, 3656160, 3656880, 3657600, 3658320, 3659040, 3659760, 3660480, 3661200, 3661920, 3662640, 3663360, 3652585, 3653305, 3655465, 3656185, 3654025, 3654745, 3656905, 3657625, 3658345, 3659065, 3661225, 3661945, 3659785, 3660505, 3662665, 3663385, 3664080, 3664800, 3665520, 3666240, 3665545, 3666265, 3666960, 3667680, 3668400, 3669120, 3669840, 3670560, 3669865, 3670585, 3671280, 3672000]

theorem colored_row122 : ∀ c : Fin 64,
    readRow witnessRows (122 * 64 + c.val) = coloredWitness122[c.val]! := by
  decide +kernel
#print axioms colored_row122

theorem colored_check122 : ∀ c : Fin 64,
    checkColored 122 (BitVec.ofNat 6 c.val) (coloredWitness122[c.val]!) = true := by
  decide +kernel
#print axioms colored_check122

theorem colored_family122 : ∀ c : Fin 64,
    checkColored 122 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (122 * 64 + c.val)) = true := by
  intro c
  rw [colored_row122]
  exact colored_check122 c
#print axioms colored_family122

def coloredWitness123 : Array Nat := #[3672720, 3673440, 3674160, 3674880, 3674185, 3674905, 3675600, 3676320, 3677040, 3677760, 3678480, 3679200, 3678505, 3679225, 3679920, 3680640, 3681360, 3682080, 3682800, 3683520, 3684240, 3684960, 3685680, 3686400, 3687120, 3687840, 3688560, 3689280, 3690000, 3690720, 3691440, 3692160, 3681385, 3682105, 3684265, 3684985, 3682825, 3683545, 3685705, 3686425, 3687145, 3687865, 3690025, 3690745, 3688585, 3689305, 3691465, 3692185, 3692880, 3693600, 3694320, 3695040, 3694345, 3695065, 3695760, 3696480, 3697200, 3697920, 3698640, 3699360, 3698665, 3699385, 3700080, 3700800]

theorem colored_row123 : ∀ c : Fin 64,
    readRow witnessRows (123 * 64 + c.val) = coloredWitness123[c.val]! := by
  decide +kernel
#print axioms colored_row123

theorem colored_check123 : ∀ c : Fin 64,
    checkColored 123 (BitVec.ofNat 6 c.val) (coloredWitness123[c.val]!) = true := by
  decide +kernel
#print axioms colored_check123

theorem colored_family123 : ∀ c : Fin 64,
    checkColored 123 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (123 * 64 + c.val)) = true := by
  intro c
  rw [colored_row123]
  exact colored_check123 c
#print axioms colored_family123

def coloredWitness124 : Array Nat := #[3701520, 3702240, 3702960, 3703680, 3704400, 3705120, 3705840, 3706560, 3707280, 3708000, 3708720, 3709440, 3710160, 3710880, 3711600, 3712320, 3713040, 3713760, 3714480, 3715200, 3715920, 3716640, 3717360, 3718080, 3718800, 3719520, 3720240, 3720960, 3721680, 3722400, 3723120, 3723840, 3724560, 3725280, 3726000, 3726720, 3727440, 3728160, 3728880, 3729600, 3730320, 3731040, 3731760, 3732480, 3733200, 3733920, 3734640, 3735360, 3736080, 3736800, 3737520, 3738240, 3738960, 3739680, 3740400, 3741120, 3741840, 3742560, 3743280, 3744000, 3744720, 3745440, 3746160, 3746880]

theorem colored_row124 : ∀ c : Fin 64,
    readRow witnessRows (124 * 64 + c.val) = coloredWitness124[c.val]! := by
  decide +kernel
#print axioms colored_row124

theorem colored_check124 : ∀ c : Fin 64,
    checkColored 124 (BitVec.ofNat 6 c.val) (coloredWitness124[c.val]!) = true := by
  decide +kernel
#print axioms colored_check124

theorem colored_family124 : ∀ c : Fin 64,
    checkColored 124 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (124 * 64 + c.val)) = true := by
  intro c
  rw [colored_row124]
  exact colored_check124 c
#print axioms colored_family124

def coloredWitness125 : Array Nat := #[3747600, 3748320, 3749040, 3749760, 3750480, 3751200, 3751920, 3752640, 3753360, 3754080, 3754800, 3755520, 3756240, 3756960, 3757680, 3758400, 3759120, 3759840, 3760560, 3761280, 3762000, 3762720, 3763440, 3764160, 3764880, 3765600, 3766320, 3767040, 3767760, 3768480, 3769200, 3769920, 3770640, 3771360, 3772080, 3772800, 3773520, 3774240, 3774960, 3775680, 3776400, 3777120, 3777840, 3778560, 3779280, 3780000, 3780720, 3781440, 3782160, 3782880, 3783600, 3784320, 3785040, 3785760, 3786480, 3787200, 3787920, 3788640, 3789360, 3790080, 3790800, 3791520, 3792240, 3792960]

theorem colored_row125 : ∀ c : Fin 64,
    readRow witnessRows (125 * 64 + c.val) = coloredWitness125[c.val]! := by
  decide +kernel
#print axioms colored_row125

theorem colored_check125 : ∀ c : Fin 64,
    checkColored 125 (BitVec.ofNat 6 c.val) (coloredWitness125[c.val]!) = true := by
  decide +kernel
#print axioms colored_check125

theorem colored_family125 : ∀ c : Fin 64,
    checkColored 125 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (125 * 64 + c.val)) = true := by
  intro c
  rw [colored_row125]
  exact colored_check125 c
#print axioms colored_family125

def coloredWitness126 : Array Nat := #[3793680, 3794400, 3795120, 3795840, 3796560, 3797280, 3798000, 3798720, 3799440, 3800160, 3800880, 3801600, 3802320, 3803040, 3803760, 3804480, 3805200, 3805920, 3806640, 3807360, 3808080, 3808800, 3809520, 3810240, 3810960, 3811680, 3812400, 3813120, 3813840, 3814560, 3815280, 3816000, 3816720, 3817440, 3818160, 3818880, 3819600, 3820320, 3821040, 3821760, 3822480, 3823200, 3823920, 3824640, 3825360, 3826080, 3826800, 3827520, 3828240, 3828960, 3829680, 3830400, 3831120, 3831840, 3832560, 3833280, 3834000, 3834720, 3835440, 3836160, 3836880, 3837600, 3838320, 3839040]

theorem colored_row126 : ∀ c : Fin 64,
    readRow witnessRows (126 * 64 + c.val) = coloredWitness126[c.val]! := by
  decide +kernel
#print axioms colored_row126

theorem colored_check126 : ∀ c : Fin 64,
    checkColored 126 (BitVec.ofNat 6 c.val) (coloredWitness126[c.val]!) = true := by
  decide +kernel
#print axioms colored_check126

theorem colored_family126 : ∀ c : Fin 64,
    checkColored 126 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (126 * 64 + c.val)) = true := by
  intro c
  rw [colored_row126]
  exact colored_check126 c
#print axioms colored_family126

def coloredWitness127 : Array Nat := #[3839760, 3840480, 3841200, 3841920, 3842640, 3843360, 3844080, 3844800, 3845520, 3846240, 3846960, 3847680, 3848400, 3849120, 3849840, 3850560, 3851280, 3852000, 3852720, 3853440, 3854160, 3854880, 3855600, 3856320, 3857040, 3857760, 3858480, 3859200, 3859920, 3860640, 3861360, 3862080, 3862800, 3863520, 3864240, 3864960, 3865680, 3866400, 3867120, 3867840, 3868560, 3869280, 3870000, 3870720, 3871440, 3872160, 3872880, 3873600, 3874320, 3875040, 3875760, 3876480, 3877200, 3877920, 3878640, 3879360, 3880080, 3880800, 3881520, 3882240, 3882960, 3883680, 3884400, 3885120]

theorem colored_row127 : ∀ c : Fin 64,
    readRow witnessRows (127 * 64 + c.val) = coloredWitness127[c.val]! := by
  decide +kernel
#print axioms colored_row127

theorem colored_check127 : ∀ c : Fin 64,
    checkColored 127 (BitVec.ofNat 6 c.val) (coloredWitness127[c.val]!) = true := by
  decide +kernel
#print axioms colored_check127

theorem colored_family127 : ∀ c : Fin 64,
    checkColored 127 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (127 * 64 + c.val)) = true := by
  intro c
  rw [colored_row127]
  exact colored_check127 c
#print axioms colored_family127

end TightCycleC5.Bridge.ColoredCover
