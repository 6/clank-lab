import P32PSDGram5Rows0
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace TightCycleC5.Bridge.P32PSD.Kernel
theorem gram5 : q5 = u5 * u5.transpose := by
  ext i j
  fin_cases i
  · exact gram5_row0 j
  · exact gram5_row1 j
  · exact gram5_row2 j
  · exact gram5_row3 j
  · exact gram5_row4 j
  · exact gram5_row5 j
  · exact gram5_row6 j
  · exact gram5_row7 j
  · exact gram5_row8 j
  · exact gram5_row9 j
  · exact gram5_row10 j
  · exact gram5_row11 j
theorem diagonal5 : ∀ i, q5 i i ≤ m5 := by decide +kernel
#print axioms gram5
#print axioms diagonal5
end TightCycleC5.Bridge.P32PSD.Kernel
