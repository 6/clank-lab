import P33ArithmeticTarget

/-! The genuine full permutation mean of the literal coefficient-one
target is the actual bad/missing count. Inversion is explicit. -/
namespace TightCycleC5.Bridge.P33Arithmetic

theorem sample_perm_class (K : Class) (p : Equiv.Perm (Fin 6)) :
    sampleStructure p.toEmbedding (classGraph K) (classCut K) =
      p.symm • decodedClass K := by
  have he : samplePerm p.symm (Function.Embedding.refl (Fin 6)) = p.toEmbedding := by
    ext v
    rfl
  simpa only [he, sample_classGraph_cut] using
    sampleStructure_equivariant p.symm (Function.Embedding.refl (Fin 6))
      (classGraph K) (classCut K)

theorem literalTarget_inverse_perm_mean (K : Class) :
    uniformMean (fun p : Equiv.Perm (Fin 6) => literalTarget (p.symm • decodedClass K)) =
      countedTarget K := by
  have hn := literalTarget_normalization (classGraph K) (classGraph_three K)
    (classCut K) (by decide : 6 ≤ 6)
  have hc : Nat.choose 6 3 = 20 := by decide
  calc
    _ = uniformMean (fun p : Equiv.Perm (Fin 6) =>
        literalTarget (sampleStructure p.toEmbedding (classGraph K) (classCut K))) := by
      congr 1
      funext p
      rw [sample_perm_class]
    _ = uniformMean (fun σ : Fin 6 ↪ Fin 6 =>
        literalTarget (sampleStructure σ (classGraph K) (classCut K))) :=
      uniformMean_equiv_between (Equiv.embeddingEquivOfFinite (Fin 6)).symm
        (fun σ => literalTarget (sampleStructure σ (classGraph K) (classCut K)))
    _ = countedTarget K := by
      simpa only [hc, Nat.cast_ofNat, countedTarget] using hn

/-- Exactly the requested genuine Fin720 mean, in the original action
convention, with no SOS scale on the target. -/
theorem literalTarget_kernel_mean (K : Class) :
    uniformMean (fun j : Fin 720 =>
      literalTarget (Cover.kernelPermutation j • decodedClass K)) = countedTarget K := by
  calc
    _ = uniformMean (fun j : Fin 720 =>
        literalTarget ((Cover.kernelPermutation j).symm • decodedClass K)) :=
      (inverse_relabel_mean K literalTarget).symm
    _ = uniformMean (fun p : Equiv.Perm (Fin 6) =>
        literalTarget (p.symm • decodedClass K)) :=
      Cover.PermutationEnumeration.uniformMean_kernelPermutation
        (fun p => literalTarget (p.symm • decodedClass K))
    _ = countedTarget K := literalTarget_inverse_perm_mean K

#print axioms sample_perm_class
#print axioms literalTarget_inverse_perm_mean
#print axioms literalTarget_kernel_mean
end TightCycleC5.Bridge.P33Arithmetic
