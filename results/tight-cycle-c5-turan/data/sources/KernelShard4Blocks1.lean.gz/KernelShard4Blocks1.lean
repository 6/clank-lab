import KernelRowIndex
import KernelWitness4

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_4_32 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 32 * 256 + i.val))
      kernelWitness4Row32[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_32

theorem kernelBlock_4_33 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 33 * 256 + i.val))
      kernelWitness4Row33[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_33

theorem kernelBlock_4_34 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 34 * 256 + i.val))
      kernelWitness4Row34[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_34

theorem kernelBlock_4_35 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 35 * 256 + i.val))
      kernelWitness4Row35[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_35

theorem kernelBlock_4_36 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 36 * 256 + i.val))
      kernelWitness4Row36[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_36

theorem kernelBlock_4_37 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 37 * 256 + i.val))
      kernelWitness4Row37[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_37

theorem kernelBlock_4_38 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 38 * 256 + i.val))
      kernelWitness4Row38[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_38

theorem kernelBlock_4_39 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 39 * 256 + i.val))
      kernelWitness4Row39[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_39

theorem kernelBlock_4_40 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 40 * 256 + i.val))
      kernelWitness4Row40[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_40

theorem kernelBlock_4_41 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 41 * 256 + i.val))
      kernelWitness4Row41[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_41

theorem kernelBlock_4_42 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 42 * 256 + i.val))
      kernelWitness4Row42[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_42

theorem kernelBlock_4_43 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 43 * 256 + i.val))
      kernelWitness4Row43[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_43

theorem kernelBlock_4_44 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 44 * 256 + i.val))
      kernelWitness4Row44[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_44

theorem kernelBlock_4_45 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 45 * 256 + i.val))
      kernelWitness4Row45[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_45

theorem kernelBlock_4_46 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 46 * 256 + i.val))
      kernelWitness4Row46[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_46

theorem kernelBlock_4_47 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 47 * 256 + i.val))
      kernelWitness4Row47[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_47

theorem kernelBlock_4_48 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 48 * 256 + i.val))
      kernelWitness4Row48[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_48

theorem kernelBlock_4_49 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 49 * 256 + i.val))
      kernelWitness4Row49[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_49

theorem kernelBlock_4_50 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 50 * 256 + i.val))
      kernelWitness4Row50[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_50

theorem kernelBlock_4_51 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 51 * 256 + i.val))
      kernelWitness4Row51[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_51

theorem kernelBlock_4_52 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 52 * 256 + i.val))
      kernelWitness4Row52[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_52

theorem kernelBlock_4_53 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 53 * 256 + i.val))
      kernelWitness4Row53[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_53

theorem kernelBlock_4_54 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 54 * 256 + i.val))
      kernelWitness4Row54[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_54

theorem kernelBlock_4_55 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 55 * 256 + i.val))
      kernelWitness4Row55[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_55

theorem kernelBlock_4_56 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 56 * 256 + i.val))
      kernelWitness4Row56[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_56

theorem kernelBlock_4_57 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 57 * 256 + i.val))
      kernelWitness4Row57[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_57

theorem kernelBlock_4_58 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 58 * 256 + i.val))
      kernelWitness4Row58[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_58

theorem kernelBlock_4_59 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 59 * 256 + i.val))
      kernelWitness4Row59[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_59

theorem kernelBlock_4_60 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 60 * 256 + i.val))
      kernelWitness4Row60[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_60

theorem kernelBlock_4_61 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 61 * 256 + i.val))
      kernelWitness4Row61[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_61

theorem kernelBlock_4_62 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 62 * 256 + i.val))
      kernelWitness4Row62[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_62

theorem kernelBlock_4_63 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (4 * 32768 + 63 * 256 + i.val))
      kernelWitness4Row63[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_4_63

end TightCycleC5.Bridge.Cover
