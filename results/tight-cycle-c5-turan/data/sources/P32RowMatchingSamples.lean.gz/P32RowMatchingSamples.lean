import P32RowMatchingFlags
import SixSampling

namespace TightCycleC5.Bridge.P32RowMatching
set_option backward.isDefEq.respectTransparency false

/-- Exact sample-edge transport; no graph validity hypothesis is needed. -/
theorem graph_edge_sample {n : Nat} (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) (x u v : Fin 6) :
    P32Flag.edge (graphOf (sampleStructure σ H S)) x u v =
      P32Flag.edge H (σ x) (σ u) (σ v) := by
  rw [graph_edge]
  simp [sampleStructure, P32Flag.edge]

theorem literal_four_row_sample {n k : Nat} (e : Fin 5)
    (Q : Matrix (Fin k) (Fin k) ℝ) (code : Fin k → Nat)
    (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) :
    P32Flag.literalFourRow e Q code (graphOf (sampleStructure σ H S))
      (Function.Embedding.refl _) = P32Flag.literalFourRow e Q code H σ := by
  simp [P32Flag.literalFourRow, P32Flag.rootIndicator, P32Flag.rootPass,
    P32Flag.fourKey, graph_edge_sample]

theorem literal_two_row_sample {n k : Nat}
    (Q : Matrix (Fin k) (Fin k) ℝ) (code : Fin k → Nat)
    (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) :
    P32Flag.literalTwoRow Q code (graphOf (sampleStructure σ H S))
      (Function.Embedding.refl _) = P32Flag.literalTwoRow Q code H σ := by
  simp [P32Flag.literalTwoRow, P32Flag.twoKey, graph_edge_sample]

/-- This is the exact six-injection expression used by aggregate graph bounds. -/
theorem psd_rows_sample {n : Nat} (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) :
    psdRows (sampleStructure σ H S) =
      P32Flag.row0 H σ + P32Flag.row1 H σ + P32Flag.row2 H σ +
        P32Flag.row3 H σ + P32Flag.row4 H σ + P32Flag.row5 H σ := by
  simp only [psdRows, P32Flag.row0, P32Flag.row1, P32Flag.row2, P32Flag.row3,
    P32Flag.row4, P32Flag.row5, literal_four_row_sample, literal_two_row_sample]

#print axioms graph_edge_sample
#print axioms literal_four_row_sample
#print axioms literal_two_row_sample
#print axioms psd_rows_sample
end TightCycleC5.Bridge.P32RowMatching
