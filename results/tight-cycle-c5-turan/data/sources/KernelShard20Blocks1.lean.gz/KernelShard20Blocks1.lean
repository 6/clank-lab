import KernelRowIndex
import KernelWitness20

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_20_32 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 32 * 256 + i.val))
      kernelWitness20Row32[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_32

theorem kernelBlock_20_33 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 33 * 256 + i.val))
      kernelWitness20Row33[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_33

theorem kernelBlock_20_34 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 34 * 256 + i.val))
      kernelWitness20Row34[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_34

theorem kernelBlock_20_35 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 35 * 256 + i.val))
      kernelWitness20Row35[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_35

theorem kernelBlock_20_36 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 36 * 256 + i.val))
      kernelWitness20Row36[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_36

theorem kernelBlock_20_37 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 37 * 256 + i.val))
      kernelWitness20Row37[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_37

theorem kernelBlock_20_38 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 38 * 256 + i.val))
      kernelWitness20Row38[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_38

theorem kernelBlock_20_39 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 39 * 256 + i.val))
      kernelWitness20Row39[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_39

theorem kernelBlock_20_40 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 40 * 256 + i.val))
      kernelWitness20Row40[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_40

theorem kernelBlock_20_41 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 41 * 256 + i.val))
      kernelWitness20Row41[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_41

theorem kernelBlock_20_42 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 42 * 256 + i.val))
      kernelWitness20Row42[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_42

theorem kernelBlock_20_43 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 43 * 256 + i.val))
      kernelWitness20Row43[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_43

theorem kernelBlock_20_44 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 44 * 256 + i.val))
      kernelWitness20Row44[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_44

theorem kernelBlock_20_45 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 45 * 256 + i.val))
      kernelWitness20Row45[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_45

theorem kernelBlock_20_46 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 46 * 256 + i.val))
      kernelWitness20Row46[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_46

theorem kernelBlock_20_47 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 47 * 256 + i.val))
      kernelWitness20Row47[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_47

theorem kernelBlock_20_48 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 48 * 256 + i.val))
      kernelWitness20Row48[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_48

theorem kernelBlock_20_49 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 49 * 256 + i.val))
      kernelWitness20Row49[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_49

theorem kernelBlock_20_50 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 50 * 256 + i.val))
      kernelWitness20Row50[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_50

theorem kernelBlock_20_51 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 51 * 256 + i.val))
      kernelWitness20Row51[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_51

theorem kernelBlock_20_52 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 52 * 256 + i.val))
      kernelWitness20Row52[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_52

theorem kernelBlock_20_53 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 53 * 256 + i.val))
      kernelWitness20Row53[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_53

theorem kernelBlock_20_54 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 54 * 256 + i.val))
      kernelWitness20Row54[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_54

theorem kernelBlock_20_55 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 55 * 256 + i.val))
      kernelWitness20Row55[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_55

theorem kernelBlock_20_56 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 56 * 256 + i.val))
      kernelWitness20Row56[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_56

theorem kernelBlock_20_57 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 57 * 256 + i.val))
      kernelWitness20Row57[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_57

theorem kernelBlock_20_58 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 58 * 256 + i.val))
      kernelWitness20Row58[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_58

theorem kernelBlock_20_59 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 59 * 256 + i.val))
      kernelWitness20Row59[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_59

theorem kernelBlock_20_60 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 60 * 256 + i.val))
      kernelWitness20Row60[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_60

theorem kernelBlock_20_61 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 61 * 256 + i.val))
      kernelWitness20Row61[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_61

theorem kernelBlock_20_62 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 62 * 256 + i.val))
      kernelWitness20Row62[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_62

theorem kernelBlock_20_63 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 63 * 256 + i.val))
      kernelWitness20Row63[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_63

end TightCycleC5.Bridge.Cover
