import P32Cover
import KernelCoverSemantics
import ColoredCoverData

/-! The coloured cover is reduced to the 835 uncoloured representatives
and all 64 colourings. Each finite witness still supplies an actual
permutation of a stored P33 representative. -/
namespace TightCycleC5.Bridge.ColoredCover
open Finset MaskEncoding Cover

def readRow (rows : Array (Array Nat)) (i : Nat) : Nat :=
  (rows[i / 256]!)[i % 256]!

def classPacked (k : Fin 40547) : Nat := readRow classRows k.val

def classMask (k : Fin 40547) : BitVec 20 := BitVec.ofNat 20 (classPacked k / 64)
def classColor (k : Fin 40547) : BitVec 6 := BitVec.ofNat 6 (classPacked k)
def classRep (k : Fin 40547) : LabelledStructure 6 := decodeStructure (classMask k) (classColor k)
def witnessClass (w : Nat) : Fin 40547 := Fin.ofNat 40547 (w / 720)
def witnessPerm (w : Nat) : Fin 720 := Fin.ofNat 720 w

def fastColor (j : Fin 720) (c : BitVec 6) : BitVec 6 :=
  (BitVec.ofBoolListLE (List.ofFn (fun v : Fin 6 => c.getLsbD (backward j v).val))).cast
    List.length_ofFn

theorem fastColor_bit (j : Fin 720) (c : BitVec 6) (v : Fin 6) :
    (fastColor j c).getLsbD v.val = c.getLsbD (backward j v).val := by
  simp only [fastColor, BitVec.getLsbD_cast, BitVec.getLsbD_ofBoolListLE]
  rw [List.getD_eq_getElem?_getD, List.getElem?_ofFn]
  simp [v.isLt]

theorem permuteColor_bit (p : Equiv.Perm (Fin 6)) (c : BitVec 6) (v : Fin 6) :
    (permuteColor p c).getLsbD v.val = c.getLsbD (p.symm v).val := by
  change (colorCode (p • decodeStructure 0 c)).getLsbD v.val = _
  rw [colorCode_bit]
  rfl

theorem fastColor_eq (j : Fin 720) (c : BitVec 6) :
    fastColor j c = permuteColor (kernelPermutation j) c := by
  apply BitVec.eq_of_getLsbD_eq
  intro v hv
  rw [fastColor_bit j c ⟨v, hv⟩, permuteColor_bit _ c ⟨v, hv⟩]
  rfl

theorem permuteColor_cancel (p : Equiv.Perm (Fin 6)) (c : BitVec 6) :
    permuteColor p (permuteColor p.symm c) = c := by
  apply BitVec.eq_of_getLsbD_eq
  intro v hv
  rw [permuteColor_bit p _ ⟨v, hv⟩, permuteColor_bit p.symm c (p.symm ⟨v, hv⟩)]
  simp

def checkColored (k : Fin 835) (c : BitVec 6) (w : Nat) : Bool :=
  decide (fastPermute (witnessPerm w) (classMask (witnessClass w)) = representative k ∧
    fastColor (witnessPerm w) (classColor (witnessClass w)) = c)

def finiteCheckRows (rows : Array (Array Nat)) : Prop :=
  ∀ (k : Fin 835) (c : Fin 64),
    checkColored k (BitVec.ofNat 6 c.val) (readRow rows (k.val * 64 + c.val)) = true

def finiteCheck : Prop := finiteCheckRows witnessRows

/-- A finite table hit is converted into a genuine coloured orbit witness. -/
theorem witness_sound (k : Fin 835) (c : BitVec 6) (w : Nat)
    (h : checkColored k c w = true) :
    ∃ l : Fin 40547, ∃ p : Equiv.Perm (Fin 6),
      decodeStructure (representative k) c = p • classRep l := by
  have hv := of_decide_eq_true h
  rw [kernel_fastPermute_eq, fastColor_eq] at hv
  refine ⟨witnessClass w, kernelPermutation (witnessPerm w), ?_⟩
  have he := decode_permute (kernelPermutation (witnessPerm w))
    (classMask (witnessClass w)) (classColor (witnessClass w))
  simpa only [hv.1, hv.2, classRep] using he

theorem colored_mask_cover (h : finiteCheck) (m : BitVec 20) (c : BitVec 6)
    (hC : ¬ CodeContainsC5 m) :
    ∃ l : Fin 40547, ∃ p : Equiv.Perm (Fin 6), decodeStructure m c = p • classRep l := by
  obtain ⟨k, p, hp⟩ := p32_mask_cover m hC
  let c' := permuteColor p.symm c
  let ci : Fin 64 := ⟨c'.toNat, c'.toFin.isLt⟩
  have hc : BitVec.ofNat 6 ci.val = c' := by simp [ci]
  have hw := h k ci
  rw [hc] at hw
  obtain ⟨l, q, hq⟩ := witness_sound k c' _ hw
  refine ⟨l, p * q, ?_⟩
  calc
    decodeStructure m c = p • decodeStructure (representative k) c' := by
      rw [hp]
      simpa only [c', permuteColor_cancel] using decode_permute p (representative k) c'
    _ = p • (q • classRep l) := by rw [hq]
    _ = (p * q) • classRep l := (mul_smul p q _).symm

theorem sample_cover (h : finiteCheck) {n : ℕ} (σ : Fin 6 ↪ Fin n)
    {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H)
    (S : Finset (Fin n)) :
    ∃ l : Fin 40547, ∃ p : Equiv.Perm (Fin 6), sampleStructure σ H S = p • classRep l := by
  obtain ⟨l, p, hp⟩ := colored_mask_cover h (graphCode (sampleStructure σ H S))
    (colorCode (sampleStructure σ H S)) (sample_code_c5free σ hH hC S)
  exact ⟨l, p, (encode_sample σ hH S).symm.trans hp⟩

noncomputable def classOf (h : finiteCheck) {n : ℕ} {H : Finset (Finset (Fin n))}
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (S : Finset (Fin n))
    (σ : Fin 6 ↪ Fin n) : Fin 40547 :=
  Classical.choose (sample_cover h σ hH hC S)

theorem classOf_cover (h : finiteCheck) {n : ℕ} {H : Finset (Finset (Fin n))}
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (S : Finset (Fin n)) :
    ∀ σ : Fin 6 ↪ Fin n, ∃ p : Equiv.Perm (Fin 6),
      sampleStructure σ H S = p • classRep (classOf h hH hC S σ) := by
  intro σ
  exact Classical.choose_spec (sample_cover h σ hH hC S)

theorem class_probability (h : finiteCheck) {n : ℕ} (hn : 6 ≤ n)
    {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H)
    (S : Finset (Fin n)) :
    (∀ k, 0 ≤ classMass (classOf h hH hC S) k) ∧
      ∑ k, classMass (classOf h hH hC S) k = 1 :=
  six_class_probability hn (classOf h hH hC S)

theorem class_expansion (h : finiteCheck) {n : ℕ} {H : Finset (Finset (Fin n))}
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (S : Finset (Fin n))
    (row : LabelledStructure 6 → ℝ) :
    uniformMean (fun σ : Fin 6 ↪ Fin n => row (sampleStructure σ H S)) =
      ∑ k, classMass (classOf h hH hC S) k *
        uniformMean (fun p : Equiv.Perm (Fin 6) => row (p • classRep k)) :=
  six_class_expansion H S (classOf h hH hC S) classRep (classOf_cover h hH hC S) row

#print axioms fastColor_bit
#print axioms permuteColor_bit
#print axioms fastColor_eq
#print axioms permuteColor_cancel
#print axioms witness_sound
#print axioms colored_mask_cover
#print axioms sample_cover
#print axioms classOf_cover
#print axioms class_probability
#print axioms class_expansion
end TightCycleC5.Bridge.ColoredCover
