import P33RowMatchingLocal
import P33RowMatchingGlobal
import P33ArithmeticFinite

namespace TightCycleC5.Bridge.P33RowMatching
open Finset
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem classCheck_ranges (K : P33Arithmetic.Class) (h : P33Arithmetic.classCheck K = true) :
    K.mask < 2^20 ∧ K.colours < 64 := by
  simp only [P33Arithmetic.classCheck, Bool.and_eq_true, decide_eq_true_eq] at h
  tauto

theorem classCheck_lookups (K : P33Arithmetic.Class) (h : P33Arithmetic.classCheck K = true)
    (j : Fin 720) : P33Arithmetic.lookupsValid K j = true := by
  have hl : (List.finRange 720).all (P33Arithmetic.lookupsValid K) = true := by
    simp only [P33Arithmetic.classCheck, Bool.and_eq_true] at h
    tauto
  exact (List.all_eq_true.mp hl) j (by simp)

theorem localQuery_of_lookups (K : P33Arithmetic.Class) (j : Fin 720)
    (h : P33Arithmetic.lookupsValid K j = true) : localQueryValid K (Cover.kernelPermutation j) := by
  unfold localQueryValid localKey colourAt
  by_contra hn
  have hb := Nat.le_of_not_gt hn
  change P33Arithmetic.localFlags[(P33Arithmetic.colour K.colours ((Cover.kernelPermutation j) 0).val)]!.size ≤
    P33Arithmetic.lookup P33Arithmetic.localFlags[P33Arithmetic.colour K.colours ((Cover.kernelPermutation j) 0).val]!
      (P33Arithmetic.canonical K.mask K.colours [((Cover.kernelPermutation j) 0).val]
        [((Cover.kernelPermutation j) 3).val,((Cover.kernelPermutation j) 4).val,((Cover.kernelPermutation j) 5).val]) at hb
  simp [P33Arithmetic.lookupsValid, P33Arithmetic.order_eq_kernelPermutation, hb] at h

theorem globalQuery_of_lookups (K : P33Arithmetic.Class) (j : Fin 720)
    (h : P33Arithmetic.lookupsValid K j = true) : globalQueryValid K (Cover.kernelPermutation j) := by
  unfold globalQueryValid globalKey
  by_contra hn
  have hb := Nat.le_of_not_gt hn
  simp [P33Arithmetic.lookupsValid, P33Arithmetic.order_eq_kernelPermutation, hb] at h

#print axioms classCheck_ranges
#print axioms classCheck_lookups
#print axioms localQuery_of_lookups
#print axioms globalQuery_of_lookups
end TightCycleC5.Bridge.P33RowMatching
