-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk64 :
    ∀ i : Fin (min 128 (40547 - 128 * 64)),
      targetCountsMatch (classAt (targetKernelClass ⟨64, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk64

theorem target_counts_kernel_chunk65 :
    ∀ i : Fin (min 128 (40547 - 128 * 65)),
      targetCountsMatch (classAt (targetKernelClass ⟨65, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk65

theorem target_counts_kernel_chunk66 :
    ∀ i : Fin (min 128 (40547 - 128 * 66)),
      targetCountsMatch (classAt (targetKernelClass ⟨66, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk66

theorem target_counts_kernel_chunk67 :
    ∀ i : Fin (min 128 (40547 - 128 * 67)),
      targetCountsMatch (classAt (targetKernelClass ⟨67, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk67


end TightCycleC5.Bridge.P33Arithmetic
