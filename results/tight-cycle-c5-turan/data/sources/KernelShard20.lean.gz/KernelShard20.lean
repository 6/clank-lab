import KernelShard20Blocks0
import KernelShard20Blocks1
import KernelShard20Blocks2
import KernelShard20Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard20 : kernelShardCheck 20 kernelWitness20 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (20 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness20 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_20_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard20
end TightCycleC5.Bridge.Cover
