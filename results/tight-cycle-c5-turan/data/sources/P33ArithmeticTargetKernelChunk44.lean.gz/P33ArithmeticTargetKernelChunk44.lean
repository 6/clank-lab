-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk176 :
    ∀ i : Fin (min 128 (40547 - 128 * 176)),
      targetCountsMatch (classAt (targetKernelClass ⟨176, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk176

theorem target_counts_kernel_chunk177 :
    ∀ i : Fin (min 128 (40547 - 128 * 177)),
      targetCountsMatch (classAt (targetKernelClass ⟨177, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk177

theorem target_counts_kernel_chunk178 :
    ∀ i : Fin (min 128 (40547 - 128 * 178)),
      targetCountsMatch (classAt (targetKernelClass ⟨178, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk178

theorem target_counts_kernel_chunk179 :
    ∀ i : Fin (min 128 (40547 - 128 * 179)),
      targetCountsMatch (classAt (targetKernelClass ⟨179, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk179


end TightCycleC5.Bridge.P33Arithmetic
