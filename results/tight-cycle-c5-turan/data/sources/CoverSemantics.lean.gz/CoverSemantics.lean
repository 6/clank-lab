import MaskEncoding
import CoverPermutationData

/-! Exact permutation tables are checked before use. The finite witness
checker has a semantic soundness proof; witness bytes are untrusted data. -/
namespace TightCycleC5.Bridge.Cover
open Finset MaskEncoding

def forward (j : Fin 720) (v : Fin 6) : Fin 6 :=
  Fin.ofNat 6 ((forwardCodes[j.val]! >>> (3 * v.val)) &&& 7)
def backward (j : Fin 720) (v : Fin 6) : Fin 6 :=
  Fin.ofNat 6 ((inverseCodes[j.val]! >>> (3 * v.val)) &&& 7)

theorem backward_forward : ∀ j v, backward j (forward j v) = v := by native_decide
theorem forward_backward : ∀ j v, forward j (backward j v) = v := by native_decide

def permutation (j : Fin 720) : Equiv.Perm (Fin 6) where
  toFun := forward j
  invFun := backward j
  left_inv := backward_forward j
  right_inv := forward_backward j

def inverseTripleIndex (j : Fin 720) (i : Fin 20) : Nat :=
  (inverseTripleCodes[j.val]! >>> (5 * i.val)) &&& 31

theorem inverse_triple_correct : ∀ j i,
    tripleIndex ((tripleAt i).map (permutation j).symm.toEmbedding) =
      inverseTripleIndex j i := by native_decide

def fastPermute (j : Fin 720) (m : BitVec 20) : BitVec 20 :=
  (BitVec.ofBoolListLE
    (List.ofFn (fun i : Fin 20 => m.getLsbD (inverseTripleIndex j i)))).cast List.length_ofFn

theorem fastPermute_bit (j : Fin 720) (m : BitVec 20) (i : Fin 20) :
    (fastPermute j m).getLsbD i.val = m.getLsbD (inverseTripleIndex j i) := by
  simp only [fastPermute, BitVec.getLsbD_cast, BitVec.getLsbD_ofBoolListLE]
  rw [List.getD_eq_getElem?_getD, List.getElem?_ofFn]
  simp [i.isLt]

/-- The optimized bit lookup is the original graph permutation, for every mask. -/
theorem fastPermute_eq (j : Fin 720) (m : BitVec 20) :
    fastPermute j m = permuteMask (permutation j) m := by
  apply BitVec.eq_of_getLsbD_eq
  intro i hi
  rw [fastPermute_bit j m ⟨i, hi⟩]
  change _ = (graphCode (permutation j • decodeStructure m 0)).getLsbD i
  rw [graphCode_bit _ ⟨i, hi⟩]
  change _ = (decodeStructure m 0).edge ((tripleAt ⟨i, hi⟩).map (permutation j).symm.toEmbedding)
  simp only [decodeStructure, card_map, tripleAt_card, ↓reduceIte, inverse_triple_correct]

def cyclePermutation (c : Fin 72) : Fin 720 := Fin.ofNat 720 cyclePermutations[c.val]!
def cycleEmbedding (c : Fin 72) : Fin 5 ↪ Fin 6 :=
  (Fin.castLEEmb (by decide : 5 ≤ 6)).trans (permutation (cyclePermutation c)).toEmbedding

theorem cycle_bit_present : ∀ (c : Fin 72) (i : Fin 5),
    cycleMasks[c.val]!.testBit
      (tripleIndex {cycleEmbedding c i, cycleEmbedding c (i + 1), cycleEmbedding c (i + 2)}) = true :=
  by native_decide

/-- A subset bit test supplies an actual injective tight-cycle witness. -/
theorem cycleMask_sound (c : Fin 72) (m : BitVec 20)
    (h : m.toNat &&& cycleMasks[c.val]! = cycleMasks[c.val]!) : CodeContainsC5 m := by
  refine ⟨cycleEmbedding c, fun i => ?_⟩
  have ht := congrArg (fun t : Nat => t.testBit
    (tripleIndex {cycleEmbedding c i, cycleEmbedding c (i + 1), cycleEmbedding c (i + 2)})) h
  rw [Nat.testBit_and, cycle_bit_present c i] at ht
  simpa only [Bool.and_true, BitVec.getLsbD] using ht

def representative (k : Fin 835) : BitVec 20 := BitVec.ofNat 20 Family.classes[k.val]!
def witnessClass (w : Nat) : Fin 835 := Fin.ofNat 835 ((w - 72) / 720)
def witnessPermutation (w : Nat) : Fin 720 := Fin.ofNat 720 (w - 72)

def checkWitness (m : BitVec 20) (w : Nat) : Bool :=
  if w < 72 then decide (m.toNat &&& cycleMasks[w]! = cycleMasks[w]!)
  else decide (fastPermute (witnessPermutation w) (representative (witnessClass w)) = m)

/-- Neither a class index nor a Boolean result is itself a graph premise. -/
theorem witness_sound (m : BitVec 20) (w : Nat) (h : checkWitness m w = true) :
    CodeContainsC5 m ∨ ∃ k : Fin 835, ∃ p : Equiv.Perm (Fin 6),
      m = permuteMask p (representative k) := by
  by_cases hw : w < 72
  · left
    apply cycleMask_sound ⟨w, hw⟩ m
    exact of_decide_eq_true (by simpa only [checkWitness, if_pos hw] using h)
  · right
    refine ⟨witnessClass w, permutation (witnessPermutation w), ?_⟩
    have he : fastPermute (witnessPermutation w) (representative (witnessClass w)) = m :=
      of_decide_eq_true (by simpa only [checkWitness, if_neg hw] using h)
    rw [fastPermute_eq] at he
    exact he.symm

def hexNibble (b : UInt8) : Nat :=
  if b.toNat ≤ 57 then b.toNat - 48 else b.toNat - 87

def readWitness (bytes : ByteArray) (i : Nat) : Nat :=
  let byte (j : Nat) := 16 * hexNibble bytes[6*i + 2*j]! + hexNibble bytes[6*i + 2*j + 1]!
  byte 0 + 256 * byte 1 + 65536 * byte 2

def shardCheckBytes (shard : Nat) (bytes : ByteArray) : Prop :=
  ∀ i : Fin 32768,
    checkWitness (BitVec.ofNat 20 (shard * 32768 + i.val)) (readWitness bytes i.val) = true

def shardCheck (shard : Nat) (hex : String) : Prop :=
  shardCheckBytes shard hex.toUTF8

#print axioms backward_forward
#print axioms forward_backward
#print axioms inverse_triple_correct
#print axioms fastPermute_bit
#print axioms fastPermute_eq
#print axioms cycle_bit_present
#print axioms cycleMask_sound
#print axioms witness_sound
end TightCycleC5.Bridge.Cover
