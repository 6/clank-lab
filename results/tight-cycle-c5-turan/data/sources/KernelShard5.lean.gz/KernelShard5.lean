import KernelShard5Blocks0
import KernelShard5Blocks1
import KernelShard5Blocks2
import KernelShard5Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard5 : kernelShardCheck 5 kernelWitness5 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (5 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness5 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_5_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard5
end TightCycleC5.Bridge.Cover
