import PairDeletion
import CLRows
import PairBook

/-! PROOF §3 Lemma 2: weighted pair-book rows, including finite diagonals. -/
namespace TightCycleC5.Bridge
open Finset
variable {n : ℕ}

def pairBookRow (H : Finset (Finset (Fin n))) (x a : Fin n)
    (w : Fin n → ℝ) (c d : Fin n) : ℝ :=
  (if HelperG.Lk H x a c ∧ HelperG.Lk H x a d ∧ ¬ HelperG.Lk H x c d ∧
      ({a, c, d} : Finset (Fin n)) ∉ H then w c * w d else 0) -
    (if HelperG.K4 H x a c d then w c * w d else 0)

theorem pairBookRow_full_nonneg (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (x a : Fin n)
    (w : Fin n → ℝ) (hw : ∀ z, 0 ≤ w z) :
    0 ≤ ∑ c, ∑ d, pairBookRow H x a w c d := by
  simpa [pairBookRow, Finset.sum_sub_distrib] using
    sub_nonneg.mpr (HelperG.pair_book H hH hC x a w hw)

theorem pairBookRow_diagonal_le (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (x a : Fin n) (w : Fin n → ℝ) (W : ℝ)
    (hw : ∀ z, 0 ≤ w z) (hW : ∀ z, w z ≤ W) (c : Fin n) :
    pairBookRow H x a w c c ≤ W ^ 2 := by
  simp only [pairBookRow, HelperG.K4, HelperG.Lk,
    three_graph_no_repeat hH a c, false_and, if_false, sub_zero]
  split_ifs
  · nlinarith [mul_self_le_mul_self (hw c) (hW c)]
  · exact sq_nonneg W

theorem pairBookRow_zero_left (H : Finset (Finset (Fin n))) (x a : Fin n)
    (w : Fin n → ℝ) {c : Fin n} (hc : w c = 0) (d : Fin n) :
    pairBookRow H x a w c d = 0 := by simp [pairBookRow, hc]

theorem pairBookRow_zero_right (H : Finset (Finset (Fin n))) (x a : Fin n)
    (w : Fin n → ℝ) (c : Fin n) {d : Fin n} (hd : w d = 0) :
    pairBookRow H x a w c d = 0 := by simp [pairBookRow, hd]

theorem pairBookRow_outside_nonneg {R : Type*} (root : R ↪ Fin n)
    (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H)
    (x a : Fin n) (w : Fin n → ℝ) (hw : ∀ z, 0 ≤ w z)
    (hz : ∀ z, z ∈ Set.range root → w z = 0) :
    0 ≤ ∑ c : Outside root, ∑ d : Outside root,
      pairBookRow H x a w c.val d.val := by
  rw [sum2_outside_support root (pairBookRow H x a w)
    (fun c hc d => pairBookRow_zero_left H x a w (hz c hc) d)
    (fun c d hd => pairBookRow_zero_right H x a w c (hz d hd))]
  exact pairBookRow_full_nonneg H hH hC x a w hw

theorem pairBookRow_free_mean_lower (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (hn : 12 ≤ n)
    (root : Fin 4 ↪ Fin n) (w : Fin n → ℝ) (W : ℝ)
    (hw : ∀ z, 0 ≤ w z) (hW : ∀ z, w z ≤ W)
    (hz : ∀ z, z ∈ Set.range root → w z = 0) :
    -(W ^ 2 / ((n : ℝ) - 5)) ≤ uniformMean (fun free : Fin 2 ↪ Outside root =>
      pairBookRow H (root 0) (root 3) w (free 0).val (free 1).val) := by
  classical
  have hcard : Fintype.card (Outside root) = n - 4 := by
    simpa only [Fintype.card_fin] using outside_card root
  have hk : 2 ≤ Fintype.card (Outside root) := by rw [hcard]; omega
  have h := distinct_pair_mean_lower
    (fun c d : Outside root => pairBookRow H (root 0) (root 3) w c.val d.val) (W ^ 2) hk
    (fun c => pairBookRow_diagonal_le H hH (root 0) (root 3) w W hw hW c.val)
    (pairBookRow_outside_nonneg root H hH hC (root 0) (root 3) w hw hz)
  have hcardR : (Fintype.card (Outside root) : ℝ) = (n : ℝ) - 4 := by
    rw [hcard, Nat.cast_sub (by omega : 4 ≤ n)]
    norm_num
  simpa only [hcardR, sub_sub, show (4 : ℝ) + 1 = 5 by norm_num] using h

noncomputable def pairBookSixRow (H : Finset (Finset (Fin n)))
    (w : (Fin 4 ↪ Fin n) → Fin n → ℝ) (g : (Fin 4 ↪ Fin n) → ℝ)
    (σ : Fin 6 ↪ Fin n) : ℝ :=
  let rf := splitSampleEquiv (r := 4) (f := 2) σ
  g rf.1 * pairBookRow H (rf.1 0) (rf.1 3) (w rf.1) (rf.2 0).val (rf.2 1).val

/-- Full Lemma 2, with an arbitrary nonnegative weight function for each
root assignment, bounded by the same W and zero on its four roots. -/
theorem pair_book_six_row_lower (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (hn : 12 ≤ n)
    (w : (Fin 4 ↪ Fin n) → Fin n → ℝ) (W : ℝ)
    (hw : ∀ root z, 0 ≤ w root z) (hW : ∀ root z, w root z ≤ W)
    (hz : ∀ (root : Fin 4 ↪ Fin n) z, z ∈ Set.range root → w root z = 0)
    (g : (Fin 4 ↪ Fin n) → ℝ) (hg : ∀ root, g root = 0 ∨ g root = 1) :
    -(W ^ 2 / ((n : ℝ) - 5)) ≤ uniformMean (pairBookSixRow H w g) := by
  classical
  letI : Nonempty (Fin 4 ↪ Fin n) := ⟨Fin.castLEEmb (by omega : 4 ≤ n)⟩
  rw [uniformMean_joinSample (r := 4) (f := 2)]
  simp only [pairBookSixRow, splitSampleEquiv_join]
  apply root_mean_lower
  intro root
  rw [uniformMean_const_mul]
  apply root_indicator_lower _
    (pairBookRow_free_mean_lower H hH hC hn root (w root) W (hw root) (hW root) (hz root))
    (hg root)
  apply neg_nonpos.mpr
  apply div_nonneg (sq_nonneg W)
  have hnR : (12 : ℝ) ≤ n := by exact_mod_cast hn
  linarith

#print axioms pairBookRow_full_nonneg
#print axioms pairBookRow_diagonal_le
#print axioms pairBookRow_zero_left
#print axioms pairBookRow_zero_right
#print axioms pairBookRow_outside_nonneg
#print axioms pairBookRow_free_mean_lower
#print axioms pair_book_six_row_lower
end TightCycleC5.Bridge
