-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk204 :
    ∀ i : Fin (min 128 (40547 - 128 * 204)),
      targetCountsMatch (classAt (targetKernelClass ⟨204, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk204

theorem target_counts_kernel_chunk205 :
    ∀ i : Fin (min 128 (40547 - 128 * 205)),
      targetCountsMatch (classAt (targetKernelClass ⟨205, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk205

theorem target_counts_kernel_chunk206 :
    ∀ i : Fin (min 128 (40547 - 128 * 206)),
      targetCountsMatch (classAt (targetKernelClass ⟨206, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk206

theorem target_counts_kernel_chunk207 :
    ∀ i : Fin (min 128 (40547 - 128 * 207)),
      targetCountsMatch (classAt (targetKernelClass ⟨207, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk207


end TightCycleC5.Bridge.P33Arithmetic
