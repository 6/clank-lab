import P32FlagRows

/-! P32 literal-row lower bounds using the existing normalized matrix facts.
The inherited Gram and diagonal facts use only standard axioms. -/
namespace TightCycleC5.Bridge.P32Flag
open Finset Matrix

theorem row0_lower {n : ℕ} (hn : 12 ≤ n) (G : Finset (Finset (Fin n))) :
    -P32PSD.bound0 / ((n : ℝ) - 5) ≤ uniformMean (row0 G) := by
  exact literalFourRow_lower 0 P32PSD.normalized_psd0
    P32PSD.normalized_nonneg0 P32PSD.normalized_diagonal0 hn code0 injective0 G

theorem row1_lower {n : ℕ} (hn : 12 ≤ n) (G : Finset (Finset (Fin n))) :
    -P32PSD.bound1 / ((n : ℝ) - 5) ≤ uniformMean (row1 G) := by
  exact literalFourRow_lower 1 P32PSD.normalized_psd1
    P32PSD.normalized_nonneg1 P32PSD.normalized_diagonal1 hn code1 injective1 G

theorem row2_lower {n : ℕ} (hn : 12 ≤ n) (G : Finset (Finset (Fin n))) :
    -P32PSD.bound2 / ((n : ℝ) - 5) ≤ uniformMean (row2 G) := by
  exact literalFourRow_lower 2 P32PSD.normalized_psd2
    P32PSD.normalized_nonneg2 P32PSD.normalized_diagonal2 hn code2 injective2 G

theorem row3_lower {n : ℕ} (hn : 12 ≤ n) (G : Finset (Finset (Fin n))) :
    -P32PSD.bound3 / ((n : ℝ) - 5) ≤ uniformMean (row3 G) := by
  exact literalFourRow_lower 3 P32PSD.normalized_psd3
    P32PSD.normalized_nonneg3 P32PSD.normalized_diagonal3 hn code3 injective3 G

theorem row4_lower {n : ℕ} (hn : 12 ≤ n) (G : Finset (Finset (Fin n))) :
    -P32PSD.bound4 / ((n : ℝ) - 5) ≤ uniformMean (row4 G) := by
  exact literalFourRow_lower 4 P32PSD.normalized_psd4
    P32PSD.normalized_nonneg4 P32PSD.normalized_diagonal4 hn code4 injective4 G

theorem row5_lower {n : ℕ} (hn : 12 ≤ n) (G : Finset (Finset (Fin n))) :
    -((4 * (n : ℝ) - 14) * P32PSD.bound5 /
      (((n : ℝ) - 4) * ((n : ℝ) - 5))) ≤ uniformMean (row5 G) := by
  exact literalTwoRow_lower P32PSD.normalized_psd5
    P32PSD.normalized_nonneg5 P32PSD.normalized_diagonal5 hn code5 injective5 G

#print axioms row0_lower
#print axioms row1_lower
#print axioms row2_lower
#print axioms row3_lower
#print axioms row4_lower
#print axioms row5_lower
end TightCycleC5.Bridge.P32Flag
