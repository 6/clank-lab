-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk292 :
    ∀ i : Fin (min 128 (40547 - 128 * 292)),
      targetCountsMatch (classAt (targetKernelClass ⟨292, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk292

theorem target_counts_kernel_chunk293 :
    ∀ i : Fin (min 128 (40547 - 128 * 293)),
      targetCountsMatch (classAt (targetKernelClass ⟨293, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk293

theorem target_counts_kernel_chunk294 :
    ∀ i : Fin (min 128 (40547 - 128 * 294)),
      targetCountsMatch (classAt (targetKernelClass ⟨294, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk294

theorem target_counts_kernel_chunk295 :
    ∀ i : Fin (min 128 (40547 - 128 * 295)),
      targetCountsMatch (classAt (targetKernelClass ⟨295, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk295


end TightCycleC5.Bridge.P33Arithmetic
