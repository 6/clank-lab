import P33FlagData
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace TightCycleC5.Bridge.P33Flag
open ColouredFlags

theorem basis4_size : basis4Data.size = 128 := by decide +kernel
theorem basis4_psd_data : ∀ i, basis4 i = P33PSD.flags4[i.val]! := by decide +kernel
theorem basis4_steps : ∀ i : Fin 127,
    basis4 i.castSucc < basis4 i.succ := by decide +kernel
theorem basis4_injective : Function.Injective basis4 :=
  (Fin.strictMono_iff_lt_succ.mpr basis4_steps).injective
theorem basis4_range : ∀ i, basis4 i < 32768 := by decide +kernel
theorem basis4_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis4 i))).toNat = type4 := by decide +kernel
#print axioms basis4_size
#print axioms basis4_psd_data
#print axioms basis4_steps
#print axioms basis4_injective
#print axioms basis4_range
#print axioms basis4_root

theorem basis10_size : basis10Data.size = 128 := by decide +kernel
theorem basis10_psd_data : ∀ i, basis10 i = P33PSD.flags10[i.val]! := by decide +kernel
theorem basis10_steps : ∀ i : Fin 127,
    basis10 i.castSucc < basis10 i.succ := by decide +kernel
theorem basis10_injective : Function.Injective basis10 :=
  (Fin.strictMono_iff_lt_succ.mpr basis10_steps).injective
theorem basis10_range : ∀ i, basis10 i < 32768 := by decide +kernel
theorem basis10_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis10 i))).toNat = type10 := by decide +kernel
#print axioms basis10_size
#print axioms basis10_psd_data
#print axioms basis10_steps
#print axioms basis10_injective
#print axioms basis10_range
#print axioms basis10_root

theorem basis16_size : basis16Data.size = 100 := by decide +kernel
theorem basis16_psd_data : ∀ i, basis16 i = P33PSD.flags16[i.val]! := by decide +kernel
theorem basis16_steps : ∀ i : Fin 99,
    basis16 i.castSucc < basis16 i.succ := by decide +kernel
theorem basis16_injective : Function.Injective basis16 :=
  (Fin.strictMono_iff_lt_succ.mpr basis16_steps).injective
theorem basis16_range : ∀ i, basis16 i < 32768 := by decide +kernel
theorem basis16_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis16 i))).toNat = type16 := by decide +kernel
#print axioms basis16_size
#print axioms basis16_psd_data
#print axioms basis16_steps
#print axioms basis16_injective
#print axioms basis16_range
#print axioms basis16_root

theorem basis22_size : basis22Data.size = 100 := by decide +kernel
theorem basis22_psd_data : ∀ i, basis22 i = P33PSD.flags22[i.val]! := by decide +kernel
theorem basis22_steps : ∀ i : Fin 99,
    basis22 i.castSucc < basis22 i.succ := by decide +kernel
theorem basis22_injective : Function.Injective basis22 :=
  (Fin.strictMono_iff_lt_succ.mpr basis22_steps).injective
theorem basis22_range : ∀ i, basis22 i < 32768 := by decide +kernel
theorem basis22_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis22 i))).toNat = type22 := by decide +kernel
#print axioms basis22_size
#print axioms basis22_psd_data
#print axioms basis22_steps
#print axioms basis22_injective
#print axioms basis22_range
#print axioms basis22_root

theorem basis28_size : basis28Data.size = 78 := by decide +kernel
theorem basis28_psd_data : ∀ i, basis28 i = P33PSD.flags28[i.val]! := by decide +kernel
theorem basis28_steps : ∀ i : Fin 77,
    basis28 i.castSucc < basis28 i.succ := by decide +kernel
theorem basis28_injective : Function.Injective basis28 :=
  (Fin.strictMono_iff_lt_succ.mpr basis28_steps).injective
theorem basis28_range : ∀ i, basis28 i < 32768 := by decide +kernel
theorem basis28_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis28 i))).toNat = type28 := by decide +kernel
#print axioms basis28_size
#print axioms basis28_psd_data
#print axioms basis28_steps
#print axioms basis28_injective
#print axioms basis28_range
#print axioms basis28_root

theorem basis34_size : basis34Data.size = 60 := by decide +kernel
theorem basis34_psd_data : ∀ i, basis34 i = P33PSD.flags34[i.val]! := by decide +kernel
theorem basis34_steps : ∀ i : Fin 59,
    basis34 i.castSucc < basis34 i.succ := by decide +kernel
theorem basis34_injective : Function.Injective basis34 :=
  (Fin.strictMono_iff_lt_succ.mpr basis34_steps).injective
theorem basis34_range : ∀ i, basis34 i < 32768 := by decide +kernel
theorem basis34_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis34 i))).toNat = type34 := by decide +kernel
#print axioms basis34_size
#print axioms basis34_psd_data
#print axioms basis34_steps
#print axioms basis34_injective
#print axioms basis34_range
#print axioms basis34_root

end TightCycleC5.Bridge.P33Flag
