import KernelCoverSemantics

namespace TightCycleC5.Bridge.Cover

theorem kernelReadRow (rows : Array (Array Nat)) (b : Nat) (c : Fin 256) :
    readKernelWitness rows (b * 256 + c.val) = (rows[b]!)[c.val]! := by
  simp [readKernelWitness, Nat.add_div, Nat.add_mod,
    Nat.div_eq_of_lt c.isLt, Nat.mod_eq_of_lt c.isLt, Nat.not_le_of_lt c.isLt]

#print axioms kernelReadRow
end TightCycleC5.Bridge.Cover
