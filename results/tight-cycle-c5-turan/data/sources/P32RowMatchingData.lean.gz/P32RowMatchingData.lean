import P32ArithmeticSemantics
import CertificateDescriptorsBook
import CertificateDescriptorsDensity
import P32Book

/-! Exact cross-identification of independently quoted certificate sources. -/
namespace TightCycleC5.Bridge.P32RowMatching
open Finset
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000

theorem weight_scale_eq : P32Arithmetic.weightScale = CertificateDescriptors.p32WeightScale := rfl
theorem probability_scale_eq : P32Arithmetic.probScale = P32Book.probabilityScale := rfl

/-- Compiler trust only for this cross-quotation comparison; see measured kernel failures. -/
theorem multipliers_eq : P32Arithmetic.multipliers.toArray = CertificateDescriptors.p32YData := by
  native_decide

theorem numerator_eq (i : Fin 9511) :
    P32Arithmetic.multipliers.get i = CertificateDescriptors.p32Numerator i := by
  have hi : i.val < P32Arithmetic.multipliers.toArray.size := by
    rw [Vector.size_toArray]; exact i.isLt
  unfold CertificateDescriptors.p32Numerator
  rw [← multipliers_eq]
  rw [getElem!_pos P32Arithmetic.multipliers.toArray i.val hi]
  rfl

theorem book_restrictions_eq : ∀ r : Fin 529,
    P32Arithmetic.bookRestriction r = CertificateDescriptors.bookMask r := by
  decide +kernel

theorem cut_roots_eq : ∀ i : Fin 25, (P32Arithmetic.cuts.get i).root = P32Book.rootType i := by
  decide +kernel

theorem cut_weights_eq : ∀ (i : Fin 25) (p : Fin 32),
    (P32Arithmetic.cuts.get i).beta.get p = (P32Book.weights[i.val]!)[p.val]! := by
  decide +kernel

#print axioms weight_scale_eq
#print axioms probability_scale_eq
#print axioms multipliers_eq
#print axioms numerator_eq
#print axioms book_restrictions_eq
#print axioms cut_roots_eq
#print axioms cut_weights_eq
end TightCycleC5.Bridge.P32RowMatching
