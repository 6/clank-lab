import P33ArithmeticSoundness
import CoverPermutationData

/-! Computable literal finite predicates, before correspondence with the
other concrete P33 flag/row helpers. No class inequality is asserted here. -/
namespace TightCycleC5.Bridge.P33Arithmetic

structure Term where
  weight : Int
  vector : Array Int
  matrix : Array (Array Int)
  deriving Inhabited

structure Block where
  n : Nat
  roots : Nat
  typeCode : Nat
  flags : Array Nat
  terms : Array Term
  deriving Inhabited

structure Class where
  mask : Nat
  colours : Nat
  quotedTarget : Int
  deriving Inhabited

/-- Same literal forward table as the accepted kernelPermutation.
The equality to that genuine permutation is proved by the adapter. -/
def order (j : Fin 720) (v : Fin 6) : Fin 6 :=
  Fin.ofNat 6 ((Cover.forwardCodes[j.val]! >>> (3 * v.val)) &&& 7)

def triples (n : Nat) : List (Nat × Nat × Nat) :=
  (List.range n).flatMap fun a => (List.range n).flatMap fun b =>
    ((List.range n).filter fun c => a < b ∧ b < c).map fun c => (a,b,c)

def tripleIndex (a b c : Nat) : Nat :=
  let lo := min a (min b c)
  let hi := max a (max b c)
  let mid := a + b + c - lo - hi
  20 - (6 - lo).choose 3 + ((5 - lo).choose 2 - (6 - mid).choose 2) + hi - mid - 1

def edge (m a b c : Nat) : Nat := if m.testBit (tripleIndex a b c) then 1 else 0
def colour (c v : Nat) : Nat := if c.testBit v then 1 else 0

/-- Frozen encoding: low n bits are colours, followed by lexicographic
triple edge bits. Lists here contain distinct vertices in every checked use. -/
def encoded (m c : Nat) (p : List Nat) : Nat :=
  (p.zipIdx.foldl (fun s (v,i) => s + (colour c v <<< i)) 0) +
  ((triples p.length).zipIdx.foldl (fun s (t,i) =>
    s + (edge m p[t.1]! p[t.2.1]! p[t.2.2]! <<< (p.length + i))) 0)

def canonical (m c : Nat) (root free : List Nat) : Nat :=
  ((free.permutations.map fun q => encoded m c (root ++ q)).min?).getD 0

def lookup (flags : Array Nat) (code : Nat) : Nat := flags.toList.idxOf code

def termEntry (t : Term) (i j : Nat) : Int :=
  t.weight * (if t.matrix.isEmpty then t.vector[i]! * t.vector[j]!
    else (t.matrix[i]!)[j]!)

def blockEntry (b : Block) (i j : Nat) : Int :=
  b.terms.foldl (fun s t => s + termEntry t i j) 0

/-- All ordered entries of the assembled SOS matrix; no triangle is dropped. -/
def blockMatrix (b : Block) : Fin b.flags.size → Fin b.flags.size → Int :=
  fun i j => blockEntry b i.val j.val

/-- Cache the expensive predicates once per order, before sparse row sums. -/
structure Features where
  localIndex : Nat
  localSign : Int
  degreeIndex : Nat
  degreeDiff : Int
  globalIndex : Nat
  cutValue : Int
  densityValue : Int
  tau : Nat
  rootColour : Nat
  patterns : Array Nat
  freeColours : Array Nat
  clValue : Int
  deriving Inhabited

def featuresAt (localFlags : Array (Array Nat)) (globalFlags : Array Nat)
    (blocks : Array Block) (K : Class) (perm : Fin 6 → Fin 6) : Features := Id.run do
  let p := fun i : Fin 6 => (perm i).val
  let e := fun a b c : Fin 6 => edge K.mask (p a) (p b) (p c)
  let c := fun a : Fin 6 => colour K.colours (p a)
  let localCode := canonical K.mask K.colours [p 0] [p 3,p 4,p 5]
  let li := 40 * c 0 + lookup localFlags[c 0]! localCode
  let count := c 1 + c 2
  let sign : Int := (e 0 1 2 : Int) * ((if count = 1 then 1 else 0) -
    (if count = 0 then 1 else 0)) * (if c 0 = 0 then 1 else -1)
  let typ := c 0 + 2*c 1
  let mut di := 120
  for bi in [:3] do
    let b := blocks[bi]!
    if typ = b.typeCode then
      di := 40*bi + lookup b.flags (canonical K.mask K.colours [p 0,p 1] [p 4,p 5])
  let gi := lookup globalFlags (canonical K.mask K.colours [] [p 3,p 4,p 5])
  let good := e 0 1 2 * (if c 0 + c 1 + c 2 = 1 then 1 else 0)
  let ab : Int := e 0 3 4
  let ad : Int := e 0 3 5
  let bd : Int := e 0 4 5
  return ⟨li,sign,di,(e 0 2 3 : Int) - e 1 2 3,gi,
    5*(good : Int)-2,1000000000*(e 0 1 2 : Int)-464101615,
    e 0 1 2,c 0+2*c 1+4*c 2,
    #[4*e 0 1 3+2*e 0 2 3+e 1 2 3,
      4*e 0 1 4+2*e 0 2 4+e 1 2 4,
      4*e 0 1 5+2*e 0 2 5+e 1 2 5],
    #[c 3,c 4,c 5],ab*ad*(1-bd)-ab*ad*bd*(e 3 4 5 : Int)⟩

def features (localFlags : Array (Array Nat)) (globalFlags : Array Nat)
    (blocks : Array Block) (K : Class) (j : Fin 720) : Features :=
  featuresAt localFlags globalFlags blocks K (order j)

/-- Descriptor i is interpreted directly, with all three individual
pattern and colour membership tests; no zeta/superset optimization. -/
def clPass (f : Features) (i : Nat) : Bool :=
  let z := if i < 510 then i else i-510
  let tau := if i < 510 then i/255 else z/6120
  let rc := (z/765)%8
  let colours := (z/255)%3+1
  let mask := z%255+1
  tau == f.tau && (i < 510 || rc == f.rootColour) &&
    f.patterns.all (fun p => mask.testBit p) &&
    (i < 510 || f.freeColours.all (fun c => colours.testBit c))

/-- Integer-scaled individual inequality row, with all 12847 indices.
Signed regularity rows are kept separate. -/
def inequalityRow (f : Features) (i : Nat) : Int :=
  if i < 80 then if i = f.localIndex then 1000000000*f.localSign else 0
  else if i < 88 then if i-80 = f.globalIndex then 200000000*f.cutValue else 0
  else if i < 97 then if i = 96 ∨ i-88 = f.globalIndex then f.densityValue else 0
  else if clPass f (i-97) then 1000000000*f.clValue else 0

def regularityRow (f : Features) (i : Nat) : Int :=
  if i = f.degreeIndex then 1000000000*f.degreeDiff else 0

def psdAt (blocks : Array Block) (K : Class) (perm : Fin 6 → Fin 6) : Int :=
  let p := fun i : Fin 6 => (perm i).val
  blocks.foldl (fun s b =>
    let root := (List.range b.roots).map fun v => p (Fin.ofNat 6 v)
    if encoded K.mask K.colours root = b.typeCode then
      let fa := if b.roots = 2 then
        canonical K.mask K.colours [p 0,p 1] [p 2,p 3]
        else encoded K.mask K.colours (root ++ [p 4])
      let fb := if b.roots = 2 then
        canonical K.mask K.colours [p 0,p 1] [p 4,p 5]
        else encoded K.mask K.colours (root ++ [p 5])
      s + 1000000000 * blockEntry b (lookup b.flags fa) (lookup b.flags fb)
    else s) 0

def psdOrder (blocks : Array Block) (K : Class) (j : Fin 720) : Int :=
  psdAt blocks K (order j)

def targetNumerator (K : Class) : Int :=
  (triples 6).foldl (fun s t =>
    let count := colour K.colours t.1 + colour K.colours t.2.1 + colour K.colours t.2.2
    let e : Int := edge K.mask t.1 t.2.1 t.2.2
    s + (if count = 0 ∨ count = 2 then e else 0) -
      (if count = 1 then 1-e else 0)) 0

end TightCycleC5.Bridge.P33Arithmetic
