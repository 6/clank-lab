import MeanBounds
import PairTripleLoss

/-! Absolute finite loss for two ordered pairs sharing a free vertex space. -/
namespace TightCycleC5.Bridge
open Finset

theorem pair_pair_disjoint_abs_le {A : Type*} [Fintype A] [DecidableEq A]
    (hk : 4 ≤ Fintype.card A) (g h : (Fin 2 ↪ A) → ℝ)
    (hg : ∀ t, |g t| ≤ 1) (hh0 : ∀ t, 0 ≤ h t) (hh1 : ∀ t, h t ≤ 1) :
    |uniformMean (disjointSampleProduct g h)| ≤
      ((Fintype.card A : ℝ) * ((Fintype.card A : ℝ) - 1) /
        (((Fintype.card A : ℝ) - 2) * ((Fintype.card A : ℝ) - 3))) * |uniformMean g| +
      (4 * (Fintype.card A : ℝ) - 6) /
        (((Fintype.card A : ℝ) - 2) * ((Fintype.card A : ℝ) - 3)) := by
  classical
  let k := Fintype.card A
  letI : Nonempty (Fin 2 ↪ A) :=
    ⟨(Fin.castLEEmb (by omega : 2 ≤ k)).trans (Fintype.equivFin A).symm.toEmbedding⟩
  have hl := disjointSampleProduct_abs_le g h hg hh0 hh1
  let a : ℝ := k.descFactorial 2
  let b : ℝ := (k - 2).descFactorial 2
  have ha : a = (k : ℝ) * ((k : ℝ) - 1) := descFactorial_two_cast (by omega)
  have hb : b = ((k : ℝ) - 2) * ((k : ℝ) - 3) := by
    change ((k - 2).descFactorial 2 : ℝ) = _
    rw [descFactorial_two_cast (by omega : 2 ≤ k - 2), Nat.cast_sub (by omega : 2 ≤ k)]
    ring
  have hkR : (4 : ℝ) ≤ k := by exact_mod_cast hk
  have hap : 0 < a := by rw [ha]; exact mul_pos (by linarith) (by linarith)
  have hbp : 0 < b := by rw [hb]; exact mul_pos (by linarith) (by linarith)
  have hspace : (Fintype.card ((Fin 2 ↪ A) × (Fin 2 ↪ A)) : ℝ) = a * a := by
    simp only [Fintype.card_prod, Nat.cast_mul, Fintype.card_embedding_eq, Fintype.card_fin, a, k]
  have hgood : ((disjointEmbeddingPairs A 2 2).card : ℝ) = a * b := by
    rw [disjointEmbeddingPairs_card, Nat.cast_mul]
  have hbad : (((disjointEmbeddingPairs A 2 2)ᶜ).card : ℝ) = a * a - a * b := by
    rw [Finset.card_compl, Nat.cast_sub (Finset.card_le_univ _), hspace, hgood]
  have hratio : a * a / (a * b) = a / b := by field_simp
  have herror : (a * a - a * b) / (a * b) = (4 * (k : ℝ) - 6) /
      (((k : ℝ) - 2) * ((k : ℝ) - 3)) := by
    calc
      _ = (a - b) / b := by field_simp
      _ = _ := by rw [ha, hb]; congr 1; ring
  rw [hspace, hgood, hbad, hratio, herror, ha, hb] at hl
  exact hl

#print axioms pair_pair_disjoint_abs_le
end TightCycleC5.Bridge
