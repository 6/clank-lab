import P33ArithmeticRanges

namespace TightCycleC5.Bridge.P33Arithmetic

/-- Two adjacent checked ranges check their concatenation. -/
theorem rangeCheck_add (start left right : Nat)
    (hl : rangeCheck start left = true)
    (hr : rangeCheck (start + left) right = true) :
    rangeCheck start (left + right) = true := by
  apply List.all_eq_true.mpr
  intro off hoff
  have ho : off < left + right := List.mem_range.mp hoff
  by_cases hleft : off < left
  · exact List.all_eq_true.mp hl off (List.mem_range.mpr hleft)
  · have hh : off - left < right := by omega
    have he : start + left + (off - left) = start + off := by omega
    have h := List.all_eq_true.mp hr (off - left) (List.mem_range.mpr hh)
    simpa only [he] using h

/-- The last range is partial; every other range has exactly 64 entries. -/
def checkpointShardLength (s : Fin 634) : Nat :=
  min 64 (40547 - s.val * 64)

def checkpointShardIndex (s : Fin 634) (j : Fin (checkpointShardLength s)) :
    Fin 40547 :=
  ⟨s.val * 64 + j.val, by
    have hs := s.isLt
    have hj := j.isLt
    simp only [checkpointShardLength, lt_min_iff] at hj
    omega⟩

theorem checkpoint_shard_sizes :
    (∀ s : Fin 633, checkpointShardLength ⟨s.val, by omega⟩ = 64) ∧
      checkpointShardLength 633 = 35 := by decide +kernel

theorem checkpoint_shard_cover (i : Fin 40547) :
    ∃ s : Fin 634, ∃ j : Fin (checkpointShardLength s),
      checkpointShardIndex s j = i := by
  have hi := i.isLt
  have hm := Nat.mod_lt i.val (by decide : 0 < 64)
  have hd := Nat.div_add_mod i.val 64
  let s : Fin 634 := ⟨i.val / 64, by omega⟩
  have hj : i.val % 64 < checkpointShardLength s := by
    simp only [checkpointShardLength, s, lt_min_iff]
    omega
  refine ⟨s, ⟨i.val % 64, hj⟩, ?_⟩
  apply Fin.ext
  simp only [checkpointShardIndex, s]
  omega

/-- Exactly the finite checks still needed: no class is omitted by the ranges. -/
theorem checkpoint_ranges_sound
    (h : ∀ s : Fin 634,
      rangeCheck (s.val * 64) (checkpointShardLength s) = true) :
    ∀ i : Fin 40547, classCheck (classAt i) = true := by
  intro i
  obtain ⟨s, j, he⟩ := checkpoint_shard_cover i
  subst i
  apply rangeCheck_sound (s.val * 64) (checkpointShardLength s) (h s)
  · simp only [checkpointShardIndex]
    omega
  · have hj := j.isLt
    simp only [checkpointShardIndex]
    omega

#print axioms rangeCheck_add
#print axioms checkpoint_shard_sizes
#print axioms checkpoint_shard_cover
#print axioms checkpoint_ranges_sound
end TightCycleC5.Bridge.P33Arithmetic
