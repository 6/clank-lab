import P32RowMatchingClassValidity
import P32RowMatchingCL
import P32RowMatchingBookSum
import P32RowMatchingDensity

namespace TightCycleC5.Bridge.P32RowMatching
open Finset

noncomputable def clRows (G : LabelledStructure 6) : ℝ :=
  ∑ i : Fin 1020, CertificateDescriptors.p32CLWeight i *
    CLCertificate.row (CertificateDescriptors.p32CL i) G

noncomputable def densityRows (G : LabelledStructure 6) : ℝ :=
  ∑ b : Bool, CertificateDescriptors.densityWeight b * CertificateDescriptors.densityRow b G

/-- The finite arithmetic class bound with actual descriptor and flag rows.
The sole conditional premise is the finite arithmetic class check. -/
theorem class_margin_bound_rows_of_check (i : Fin 835)
    (h : P32Arithmetic.ClassStatement i) :
    (1 : ℝ)/10000 +
      uniformMean (fun p : Equiv.Perm (Fin 6) => clRows (p • P32Arithmetic.classStructure i)) +
      uniformMean (fun p : Equiv.Perm (Fin 6) =>
        (indicatorBookRows (p • P32Arithmetic.classStructure i) +
          weightedBookRows (p • P32Arithmetic.classStructure i))) +
      uniformMean (fun p : Equiv.Perm (Fin 6) => densityRows (p • P32Arithmetic.classStructure i)) +
      uniformMean (fun p : Equiv.Perm (Fin 6) => psdRows (p • P32Arithmetic.classStructure i)) ≤
      uniformMean (fun p : Equiv.Perm (Fin 6) => P32Arithmetic.selectorMargin (p • P32Arithmetic.classStructure i)) := by
  have hb := P32Arithmetic.class_margin_bound_of_check i h
  simp_rw [cl_contribution_eq, book_contribution_eq, density_contribution_eq] at hb
  rw [class_psd_mean_eq_of_check i h] at hb
  simpa only [clRows, densityRows, sum_bool_true_false] using hb

#print axioms class_margin_bound_rows_of_check
end TightCycleC5.Bridge.P32RowMatching
