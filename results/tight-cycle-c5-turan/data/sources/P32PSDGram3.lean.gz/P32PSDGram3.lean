import P32PSDGram3Rows0
import P32PSDGram3Rows1
import P32PSDGram3Rows2
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace TightCycleC5.Bridge.P32PSD.Kernel
theorem gram3 : q3 = u3 * u3.transpose := by
  ext i j
  fin_cases i
  · exact gram3_row0 j
  · exact gram3_row1 j
  · exact gram3_row2 j
  · exact gram3_row3 j
  · exact gram3_row4 j
  · exact gram3_row5 j
  · exact gram3_row6 j
  · exact gram3_row7 j
  · exact gram3_row8 j
  · exact gram3_row9 j
  · exact gram3_row10 j
  · exact gram3_row11 j
  · exact gram3_row12 j
  · exact gram3_row13 j
  · exact gram3_row14 j
  · exact gram3_row15 j
  · exact gram3_row16 j
  · exact gram3_row17 j
  · exact gram3_row18 j
  · exact gram3_row19 j
  · exact gram3_row20 j
  · exact gram3_row21 j
  · exact gram3_row22 j
  · exact gram3_row23 j
  · exact gram3_row24 j
  · exact gram3_row25 j
  · exact gram3_row26 j
  · exact gram3_row27 j
  · exact gram3_row28 j
  · exact gram3_row29 j
  · exact gram3_row30 j
  · exact gram3_row31 j
  · exact gram3_row32 j
  · exact gram3_row33 j
  · exact gram3_row34 j
  · exact gram3_row35 j
  · exact gram3_row36 j
  · exact gram3_row37 j
  · exact gram3_row38 j
theorem diagonal3 : ∀ i, q3 i i ≤ m3 := by decide +kernel
#print axioms gram3
#print axioms diagonal3
end TightCycleC5.Bridge.P32PSD.Kernel
