-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk184 :
    ∀ i : Fin (min 128 (40547 - 128 * 184)),
      targetCountsMatch (classAt (targetKernelClass ⟨184, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk184

theorem target_counts_kernel_chunk185 :
    ∀ i : Fin (min 128 (40547 - 128 * 185)),
      targetCountsMatch (classAt (targetKernelClass ⟨185, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk185

theorem target_counts_kernel_chunk186 :
    ∀ i : Fin (min 128 (40547 - 128 * 186)),
      targetCountsMatch (classAt (targetKernelClass ⟨186, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk186

theorem target_counts_kernel_chunk187 :
    ∀ i : Fin (min 128 (40547 - 128 * 187)),
      targetCountsMatch (classAt (targetKernelClass ⟨187, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk187


end TightCycleC5.Bridge.P33Arithmetic
