import P32ClassBridge
import P33ClassBridge
import P33ArithmeticReplay

/-! Assemble the two actual BLLP propositions and apply the existing
kernel-checked conditional endpoint. The placeholder proof is not used. -/
namespace TightCycleC5.Bridge

theorem p33_checked : P33Statement :=
  P33ClassBridge.p33_of_checked_classes P33Arithmetic.p33_arithmetic_replay

theorem mubayi_rodl_checked : type_of% @TightCycleC5.mubayi_rodl :=
  TightCycleC5.mubayi_rodl_of_bllp P32ClassBridge.p32 p33_checked

#print axioms p33_checked
#print axioms mubayi_rodl_checked
end TightCycleC5.Bridge
