import P33ArithmeticTargetDense
import P33ArithmeticCover

/-! Exact finite-class integration interface in the accepted coloured-cover
indexing. Both remaining proof obligations are explicit; this is PARTIAL. -/
namespace TightCycleC5.Bridge.P33Arithmetic

/-- Each checked arithmetic class gives the original class-representative
mean once concrete normalized nuisance correspondence is supplied. -/
theorem checked_classRep_sourceMean_nonpos (k : Fin 40547)
    (h : classCheck (classAt k) = true) (nuisance : LabelledStructure 6 → ℝ)
    (hm : ∀ j : Fin 720,
      (denseNuisanceAt (classAt k) (Cover.kernelPermutation j) : ℝ) /
        1000000000 / (sosScale : ℝ) =
      nuisance ((Cover.kernelPermutation j).symm • ColoredCover.classRep k)) :
    uniformMean (fun j : Fin 720 =>
      literalTarget (Cover.kernelPermutation j • ColoredCover.classRep k) +
        nuisance (Cover.kernelPermutation j • ColoredCover.classRep k)) ≤ 0 := by
  have hm' : ∀ j : Fin 720,
      (denseNuisanceAt (classAt k) (Cover.kernelPermutation j) : ℝ) /
        1000000000 / (sosScale : ℝ) =
      nuisance ((Cover.kernelPermutation j).symm • decodedClass (classAt k)) := by
    simpa only [decodedClass_eq_classRep] using hm
  simpa only [decodedClass_eq_classRep] using
    classCheck_sourceRow_mean_nonpos k h nuisance hm'

/-- The exact two obligations to close full P33 finite arithmetic:
all genuine class checks and pointwise literal normalized source matching. -/
theorem all_classRep_sourceMean_nonpos
    (h : ∀ k : Fin 40547, classCheck (classAt k) = true)
    (nuisance : LabelledStructure 6 → ℝ)
    (hm : ∀ (k : Fin 40547) (j : Fin 720),
      (denseNuisanceAt (classAt k) (Cover.kernelPermutation j) : ℝ) /
        1000000000 / (sosScale : ℝ) =
      nuisance ((Cover.kernelPermutation j).symm • ColoredCover.classRep k)) :
    ∀ k : Fin 40547, uniformMean (fun j : Fin 720 =>
      literalTarget (Cover.kernelPermutation j • ColoredCover.classRep k) +
        nuisance (Cover.kernelPermutation j • ColoredCover.classRep k)) ≤ 0 := by
  intro k
  exact checked_classRep_sourceMean_nonpos k (h k) nuisance (hm k)

#print axioms checked_classRep_sourceMean_nonpos
#print axioms all_classRep_sourceMean_nonpos
end TightCycleC5.Bridge.P33Arithmetic
