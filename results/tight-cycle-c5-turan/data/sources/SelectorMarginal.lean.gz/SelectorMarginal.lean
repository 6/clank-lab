import ProductMarginals
import BLLP

/-! The independent-product step in PROOF §3 Lemma 8. -/
namespace TightCycleC5.Bridge
open Finset
variable {n : ℕ}

noncomputable def exactlyTwoProbability (π : Fin n → ℝ) (e : Finset (Fin n)) : ℝ :=
  ∑ z ∈ e, (1 - π z) * ∏ v ∈ e.erase z, π v

theorem inter_eq_erase_iff (e S : Finset (Fin n)) {z : Fin n} (hz : z ∈ e) :
    e ∩ S = e.erase z ↔ z ∉ S ∧ ∀ a ∈ e, a ≠ z → a ∈ S := by
  constructor
  · intro he
    constructor
    · intro hzs
      have hh : z ∈ e.erase z := he ▸ mem_inter.mpr ⟨hz, hzs⟩
      exact (mem_erase.mp hh).1 rfl
    · intro a ha haz
      have hh : a ∈ e ∩ S := he.symm ▸ mem_erase.mpr ⟨haz, ha⟩
      exact (mem_inter.mp hh).2
  · rintro ⟨hzs, h⟩
    ext a
    simp only [mem_inter, mem_erase]
    constructor
    · rintro ⟨ha, has⟩
      exact ⟨fun haz => hzs (haz ▸ has), ha⟩
    · rintro ⟨haz, ha⟩
      exact ⟨ha, h a ha haz⟩

theorem three_set_two_indicator (e S : Finset (Fin n)) (he : e.card = 3) :
    (if (e ∩ S).card = 2 then (1 : ℝ) else 0) =
      ∑ z ∈ e, if e ∩ S = e.erase z then 1 else 0 := by
  obtain ⟨a, b, c, hab, hac, hbc, rfl⟩ := card_eq_three.mp he
  rw [sum_insert (by simp [hab, hac]), sum_insert (by simp [hbc]), sum_singleton]
  simp only [inter_eq_erase_iff _ _ (by simp : a ∈ ({a, b, c} : Finset (Fin n))),
    inter_eq_erase_iff _ _ (by simp : b ∈ ({a, b, c} : Finset (Fin n))),
    inter_eq_erase_iff _ _ (by simp : c ∈ ({a, b, c} : Finset (Fin n)))]
  by_cases ha : a ∈ S <;> by_cases hb : b ∈ S <;> by_cases hc : c ∈ S <;>
    simp [ha, hb, hc, hab, hac, hbc, hab.symm, hac.symm, hbc.symm]

theorem exactlyTwoProbability_marginal (π : Fin n → ℝ) (e : Finset (Fin n)) (he : e.card = 3) :
    (∑ S : Finset (Fin n), HelperG.Random.wt π S *
      (if (e ∩ S).card = 2 then 1 else 0)) = exactlyTwoProbability π e := by
  simp_rw [three_set_two_indicator e _ he, Finset.mul_sum]
  rw [Finset.sum_comm]
  unfold exactlyTwoProbability
  apply Finset.sum_congr rfl
  intro z hz
  rw [bernoulli_fixed_outcome π e (e.erase z) (erase_subset _ _)]
  have hs : e \ e.erase z = {z} := by
    ext a
    simp only [mem_sdiff, mem_erase, mem_singleton]
    constructor
    · intro h
      by_contra haz
      exact h.2 ⟨haz, h.1⟩
    · rintro rfl
      simp [hz]
  rw [hs, prod_singleton, mul_comm]

/-- Exact independent marginalization for every edge avoiding the roots.
Probabilities at the roots may be arbitrary because counted edges avoid them. -/
theorem selector_marginal (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (R : Finset (Fin n)) (π : Fin n → ℝ) :
    (∑ S : Finset (Fin n), HelperG.Random.wt π S * (HelperG.Random.sel H R S : ℝ)) =
      ∑ e ∈ H.filter (fun e => Disjoint e R), exactlyTwoProbability π e := by
  have hsel : ∀ S : Finset (Fin n), (HelperG.Random.sel H R S : ℝ) =
      ∑ e ∈ H.filter (fun e => Disjoint e R),
        if (e ∩ S).card = 2 then 1 else 0 := by
    intro S
    rw [HelperG.Random.sel, ← Finset.filter_filter, Finset.card_eq_sum_ones]
    simp only [Nat.cast_sum, Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro e _
    split_ifs <;> norm_num
  simp_rw [hsel, Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro e he
  exact exactlyTwoProbability_marginal π e (hH e (mem_filter.mp he).1)

theorem random_maxCut_eq (H : Finset (Finset (Fin n))) :
    HelperG.Random.maxCut H = maxCut H := rfl

/-- The checked independent-product identity combined with the original
random_selector theorem, using exactly BLLP's maxCut. -/
theorem selector_probability_le_maxCut (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (R : Finset (Fin n)) (π : Fin n → ℝ)
    (hπ0 : ∀ v, 0 ≤ π v) (hπ1 : ∀ v, π v ≤ 1) :
    (∑ e ∈ H.filter (fun e => Disjoint e R), exactlyTwoProbability π e) ≤ (maxCut H : ℝ) := by
  rw [← selector_marginal H hH R π]
  exact HelperG.Random.random_selector H R π hπ0 hπ1

#print axioms inter_eq_erase_iff
#print axioms three_set_two_indicator
#print axioms exactlyTwoProbability_marginal
#print axioms selector_marginal
#print axioms random_maxCut_eq
#print axioms selector_probability_le_maxCut
end TightCycleC5.Bridge
