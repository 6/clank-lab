import KernelRowIndex
import KernelWitness22

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_22_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 64 * 256 + i.val))
      kernelWitness22Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_64

theorem kernelBlock_22_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 65 * 256 + i.val))
      kernelWitness22Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_65

theorem kernelBlock_22_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 66 * 256 + i.val))
      kernelWitness22Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_66

theorem kernelBlock_22_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 67 * 256 + i.val))
      kernelWitness22Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_67

theorem kernelBlock_22_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 68 * 256 + i.val))
      kernelWitness22Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_68

theorem kernelBlock_22_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 69 * 256 + i.val))
      kernelWitness22Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_69

theorem kernelBlock_22_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 70 * 256 + i.val))
      kernelWitness22Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_70

theorem kernelBlock_22_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 71 * 256 + i.val))
      kernelWitness22Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_71

theorem kernelBlock_22_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 72 * 256 + i.val))
      kernelWitness22Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_72

theorem kernelBlock_22_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 73 * 256 + i.val))
      kernelWitness22Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_73

theorem kernelBlock_22_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 74 * 256 + i.val))
      kernelWitness22Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_74

theorem kernelBlock_22_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 75 * 256 + i.val))
      kernelWitness22Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_75

theorem kernelBlock_22_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 76 * 256 + i.val))
      kernelWitness22Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_76

theorem kernelBlock_22_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 77 * 256 + i.val))
      kernelWitness22Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_77

theorem kernelBlock_22_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 78 * 256 + i.val))
      kernelWitness22Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_78

theorem kernelBlock_22_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 79 * 256 + i.val))
      kernelWitness22Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_79

theorem kernelBlock_22_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 80 * 256 + i.val))
      kernelWitness22Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_80

theorem kernelBlock_22_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 81 * 256 + i.val))
      kernelWitness22Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_81

theorem kernelBlock_22_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 82 * 256 + i.val))
      kernelWitness22Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_82

theorem kernelBlock_22_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 83 * 256 + i.val))
      kernelWitness22Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_83

theorem kernelBlock_22_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 84 * 256 + i.val))
      kernelWitness22Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_84

theorem kernelBlock_22_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 85 * 256 + i.val))
      kernelWitness22Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_85

theorem kernelBlock_22_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 86 * 256 + i.val))
      kernelWitness22Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_86

theorem kernelBlock_22_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 87 * 256 + i.val))
      kernelWitness22Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_87

theorem kernelBlock_22_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 88 * 256 + i.val))
      kernelWitness22Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_88

theorem kernelBlock_22_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 89 * 256 + i.val))
      kernelWitness22Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_89

theorem kernelBlock_22_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 90 * 256 + i.val))
      kernelWitness22Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_90

theorem kernelBlock_22_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 91 * 256 + i.val))
      kernelWitness22Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_91

theorem kernelBlock_22_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 92 * 256 + i.val))
      kernelWitness22Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_92

theorem kernelBlock_22_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 93 * 256 + i.val))
      kernelWitness22Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_93

theorem kernelBlock_22_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 94 * 256 + i.val))
      kernelWitness22Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_94

theorem kernelBlock_22_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (22 * 32768 + 95 * 256 + i.val))
      kernelWitness22Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_22_95

end TightCycleC5.Bridge.Cover
