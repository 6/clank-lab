import P32RowMatchingPSDSum

namespace TightCycleC5.Bridge.P32RowMatching

/-- The arithmetic class check proves lookup validity for every genuine
permutation, rather than imposing a universal flag support hypothesis. -/
theorem class_psd_valid_of_check (i : Fin 835) (h : P32Arithmetic.ClassStatement i)
    (p : Equiv.Perm (Fin 6)) :
    (P32Arithmetic.psdNumerator
      (P32Arithmetic.features (p • P32Arithmetic.classStructure i))).isSome = true := by
  obtain ⟨j, rfl⟩ := Cover.PermutationEnumeration.kernelPermutation_bijective.2 p
  exact P32Arithmetic.lookups_succeed_of_check i h j

theorem class_psd_mean_eq_of_check (i : Fin 835) (h : P32Arithmetic.ClassStatement i) :
    uniformMean (fun p : Equiv.Perm (Fin 6) =>
      P32Arithmetic.psdContribution (p • P32Arithmetic.classStructure i)) =
    uniformMean (fun p : Equiv.Perm (Fin 6) => psdRows (p • P32Arithmetic.classStructure i)) := by
  congr 1
  funext p
  exact psd_contribution_eq _ (class_psd_valid_of_check i h p)

#print axioms class_psd_valid_of_check
#print axioms class_psd_mean_eq_of_check
end TightCycleC5.Bridge.P32RowMatching
