import P32PSDGram0
import P32PSDGram1
import P32PSDGram2
import P32PSDGram3
import P32PSDGram4
import P32PSDGram5
import GramSoundness

/-! Exact P32 Gram and diagonal facts, checked by kernel reduction. -/
namespace TightCycleC5.Bridge.P32PSD

theorem gram0 : q0 = u0 * u0.transpose := Kernel.gram0
theorem diagonal0 : ∀ i, q0 i i ≤ m0 := Kernel.diagonal0
theorem psd0 : (intMatrixReal q0).PosSemidef := int_gram_posSemidef q0 u0 gram0
theorem diagonal_real0 : ∀ i, intMatrixReal q0 i i ≤ (m0 : ℝ) :=
  int_diagonal_bound q0 m0 diagonal0
theorem bound_nonneg0 : (0 : ℝ) ≤ (m0 : ℝ) := by norm_num [m0]

theorem gram1 : q1 = u1 * u1.transpose := Kernel.gram1
theorem diagonal1 : ∀ i, q1 i i ≤ m1 := Kernel.diagonal1
theorem psd1 : (intMatrixReal q1).PosSemidef := int_gram_posSemidef q1 u1 gram1
theorem diagonal_real1 : ∀ i, intMatrixReal q1 i i ≤ (m1 : ℝ) :=
  int_diagonal_bound q1 m1 diagonal1
theorem bound_nonneg1 : (0 : ℝ) ≤ (m1 : ℝ) := by norm_num [m1]

theorem gram2 : q2 = u2 * u2.transpose := Kernel.gram2
theorem diagonal2 : ∀ i, q2 i i ≤ m2 := Kernel.diagonal2
theorem psd2 : (intMatrixReal q2).PosSemidef := int_gram_posSemidef q2 u2 gram2
theorem diagonal_real2 : ∀ i, intMatrixReal q2 i i ≤ (m2 : ℝ) :=
  int_diagonal_bound q2 m2 diagonal2
theorem bound_nonneg2 : (0 : ℝ) ≤ (m2 : ℝ) := by norm_num [m2]

theorem gram3 : q3 = u3 * u3.transpose := Kernel.gram3
theorem diagonal3 : ∀ i, q3 i i ≤ m3 := Kernel.diagonal3
theorem psd3 : (intMatrixReal q3).PosSemidef := int_gram_posSemidef q3 u3 gram3
theorem diagonal_real3 : ∀ i, intMatrixReal q3 i i ≤ (m3 : ℝ) :=
  int_diagonal_bound q3 m3 diagonal3
theorem bound_nonneg3 : (0 : ℝ) ≤ (m3 : ℝ) := by norm_num [m3]

theorem gram4 : q4 = u4 * u4.transpose := Kernel.gram4
theorem diagonal4 : ∀ i, q4 i i ≤ m4 := Kernel.diagonal4
theorem psd4 : (intMatrixReal q4).PosSemidef := int_gram_posSemidef q4 u4 gram4
theorem diagonal_real4 : ∀ i, intMatrixReal q4 i i ≤ (m4 : ℝ) :=
  int_diagonal_bound q4 m4 diagonal4
theorem bound_nonneg4 : (0 : ℝ) ≤ (m4 : ℝ) := by norm_num [m4]

theorem gram5 : q5 = u5 * u5.transpose := Kernel.gram5
theorem diagonal5 : ∀ i, q5 i i ≤ m5 := Kernel.diagonal5
theorem psd5 : (intMatrixReal q5).PosSemidef := int_gram_posSemidef q5 u5 gram5
theorem diagonal_real5 : ∀ i, intMatrixReal q5 i i ≤ (m5 : ℝ) :=
  int_diagonal_bound q5 m5 diagonal5
theorem bound_nonneg5 : (0 : ℝ) ≤ (m5 : ℝ) := by norm_num [m5]

def changedQ0 : Matrix (Fin 64) (Fin 64) ℤ :=
  fun i j => q0 i j + if i = 0 ∧ j = 0 then 1 else 0

theorem rejects_changed_matrix : changedQ0 ≠ u0 * u0.transpose := by
  intro h
  have he := congrArg (fun A : Matrix (Fin 64) (Fin 64) ℤ => A 0 0) (h.trans gram0.symm)
  change q0 0 0 + 1 = q0 0 0 at he
  omega

#print axioms gram0
#print axioms diagonal0
#print axioms psd0
#print axioms diagonal_real0
#print axioms bound_nonneg0
#print axioms gram1
#print axioms diagonal1
#print axioms psd1
#print axioms diagonal_real1
#print axioms bound_nonneg1
#print axioms gram2
#print axioms diagonal2
#print axioms psd2
#print axioms diagonal_real2
#print axioms bound_nonneg2
#print axioms gram3
#print axioms diagonal3
#print axioms psd3
#print axioms diagonal_real3
#print axioms bound_nonneg3
#print axioms gram4
#print axioms diagonal4
#print axioms psd4
#print axioms diagonal_real4
#print axioms bound_nonneg4
#print axioms gram5
#print axioms diagonal5
#print axioms psd5
#print axioms diagonal_real5
#print axioms bound_nonneg5
#print axioms rejects_changed_matrix

end TightCycleC5.Bridge.P32PSD
