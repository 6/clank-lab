import P32PSDGram2Rows0
import P32PSDGram2Rows1
import P32PSDGram2Rows2
import P32PSDGram2Rows3
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace TightCycleC5.Bridge.P32PSD.Kernel
theorem gram2 : q2 = u2 * u2.transpose := by
  ext i j
  fin_cases i
  · exact gram2_row0 j
  · exact gram2_row1 j
  · exact gram2_row2 j
  · exact gram2_row3 j
  · exact gram2_row4 j
  · exact gram2_row5 j
  · exact gram2_row6 j
  · exact gram2_row7 j
  · exact gram2_row8 j
  · exact gram2_row9 j
  · exact gram2_row10 j
  · exact gram2_row11 j
  · exact gram2_row12 j
  · exact gram2_row13 j
  · exact gram2_row14 j
  · exact gram2_row15 j
  · exact gram2_row16 j
  · exact gram2_row17 j
  · exact gram2_row18 j
  · exact gram2_row19 j
  · exact gram2_row20 j
  · exact gram2_row21 j
  · exact gram2_row22 j
  · exact gram2_row23 j
  · exact gram2_row24 j
  · exact gram2_row25 j
  · exact gram2_row26 j
  · exact gram2_row27 j
  · exact gram2_row28 j
  · exact gram2_row29 j
  · exact gram2_row30 j
  · exact gram2_row31 j
  · exact gram2_row32 j
  · exact gram2_row33 j
  · exact gram2_row34 j
  · exact gram2_row35 j
  · exact gram2_row36 j
  · exact gram2_row37 j
  · exact gram2_row38 j
  · exact gram2_row39 j
  · exact gram2_row40 j
  · exact gram2_row41 j
  · exact gram2_row42 j
  · exact gram2_row43 j
  · exact gram2_row44 j
  · exact gram2_row45 j
  · exact gram2_row46 j
  · exact gram2_row47 j
  · exact gram2_row48 j
  · exact gram2_row49 j
theorem diagonal2 : ∀ i, q2 i i ≤ m2 := by decide +kernel
#print axioms gram2
#print axioms diagonal2
end TightCycleC5.Bridge.P32PSD.Kernel
