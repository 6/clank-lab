import P33ArithmeticMean
import P33ArithmeticTargetMean

/-! Final mean transport for a checked finite class. The final theorem
retains an explicit pointwise nuisance correspondence premise; it is
PARTIAL until the separately owned concrete row adapters discharge it. -/
namespace TightCycleC5.Bridge.P33Arithmetic
open Finset

theorem literalMean_add {ι : Type*} [Fintype ι] (f g : ι → ℝ) :
    uniformMean (fun i => f i + g i) = uniformMean f + uniformMean g := by
  simp only [uniformMean, sum_add_distrib, add_div]

/-- Actual target row plus the dense evaluator, in its forward convention. -/
theorem classCheck_literal_forwardMean_nonpos (k : Fin 40547)
    (h : classCheck (classAt k) = true) :
    uniformMean (fun j : Fin 720 =>
      literalTarget ((Cover.kernelPermutation j).symm • decodedClass (classAt k)) +
      (denseNuisanceAt (classAt k) (Cover.kernelPermutation j) : ℝ) /
        1000000000 / (sosScale : ℝ)) ≤ 0 := by
  have hd := classCheck_real_denseMean_nonpos (classAt k) h
  have hd' : uniformMean (fun j : Fin 720 =>
      (targetNumerator (classAt k) : ℝ) / 20 +
      (denseNuisanceAt (classAt k) (Cover.kernelPermutation j) : ℝ) /
        1000000000 / (sosScale : ℝ)) ≤ 0 := by
    simpa only [uniformMean, Fintype.card_fin, Nat.cast_ofNat] using hd
  have ht : uniformMean (fun j : Fin 720 =>
      literalTarget ((Cover.kernelPermutation j).symm • decodedClass (classAt k))) =
      (targetNumerator (classAt k) : ℝ) / 20 := by
    calc
      _ = uniformMean (fun p : Equiv.Perm (Fin 6) =>
          literalTarget (p.symm • decodedClass (classAt k))) :=
        Cover.PermutationEnumeration.uniformMean_kernelPermutation
          (fun p => literalTarget (p.symm • decodedClass (classAt k)))
      _ = countedTarget (classAt k) := literalTarget_inverse_perm_mean _
      _ = _ := (target_normalized k).symm
  rw [literalMean_add, ht]
  rwa [literalMean_add, uniformMean_const] at hd'

/-- Plug in the actual full-trace PSD and signed scalar row function.
The target is literal, coefficient one, and never divided by SOS scale.
No unchecked optimized arithmetic is hidden in the correspondence premise. -/
theorem classCheck_sourceRow_mean_nonpos (k : Fin 40547)
    (h : classCheck (classAt k) = true) (nuisance : LabelledStructure 6 → ℝ)
    (hm : ∀ j : Fin 720,
      (denseNuisanceAt (classAt k) (Cover.kernelPermutation j) : ℝ) /
        1000000000 / (sosScale : ℝ) =
      nuisance ((Cover.kernelPermutation j).symm • decodedClass (classAt k))) :
    uniformMean (fun j : Fin 720 =>
      literalTarget (Cover.kernelPermutation j • decodedClass (classAt k)) +
        nuisance (Cover.kernelPermutation j • decodedClass (classAt k))) ≤ 0 := by
  have hf := classCheck_literal_forwardMean_nonpos k h
  simp_rw [hm] at hf
  exact (inverse_relabel_mean (classAt k) (fun G => literalTarget G + nuisance G)) ▸ hf

#print axioms literalMean_add
#print axioms classCheck_literal_forwardMean_nonpos
#print axioms classCheck_sourceRow_mean_nonpos
end TightCycleC5.Bridge.P33Arithmetic
