import KernelShard9Blocks0
import KernelShard9Blocks1
import KernelShard9Blocks2
import KernelShard9Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard9 : kernelShardCheck 9 kernelWitness9 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (9 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness9 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_9_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard9
end TightCycleC5.Bridge.Cover
