import ConditionalMean

/-! Splitting finite injections over an arbitrary finite vertex type.
This is used inside a previously conditioned root complement. -/
namespace TightCycleC5.Bridge
open Finset

noncomputable def disjointEmbeddingPairs (A : Type*) [Fintype A] (r f : ℕ) :
    Finset ((Fin r ↪ A) × (Fin f ↪ A)) :=
  open Classical in univ.filter (fun p => ∀ i j, p.1 i ≠ p.2 j)

noncomputable def complementEmbeddingPairEquiv {A : Type*} [Fintype A] {r f : ℕ} :
    (Σ root : Fin r ↪ A, Fin f ↪ Outside root) ≃ disjointEmbeddingPairs A r f := by
  classical
  exact {
    toFun := fun rf => ⟨(rf.1, rf.2.trans ⟨Subtype.val, Subtype.val_injective⟩), by
      simp only [disjointEmbeddingPairs, mem_filter, mem_univ, true_and]
      intro i j h
      exact (rf.2 j).property ⟨i, h⟩⟩
    invFun := fun p => ⟨p.val.1, ⟨fun j => ⟨p.val.2 j, by
      rintro ⟨i, hi⟩
      exact (mem_filter.mp p.property).2 i j hi⟩,
      fun i j h => p.val.2.injective (congrArg Subtype.val h)⟩⟩
    left_inv := fun _ => rfl
    right_inv := fun _ => rfl }

def splitFiniteSampleEquiv {A : Type*} {r f : ℕ} :
    (Fin (r + f) ↪ A) ≃ (Σ root : Fin r ↪ A, Fin f ↪ Outside root) :=
  (Equiv.embeddingCongr finSumFinEquiv.symm (Equiv.refl _)).trans splitEmbeddingEquiv

noncomputable def disjointEmbeddingEquiv {A : Type*} [Fintype A] {r f : ℕ} :
    (Fin (r + f) ↪ A) ≃ disjointEmbeddingPairs A r f :=
  splitFiniteSampleEquiv.trans complementEmbeddingPairEquiv

theorem disjointEmbeddingPairs_card {A : Type*} [Fintype A] (r f : ℕ) :
    (disjointEmbeddingPairs A r f).card =
      (Fintype.card A).descFactorial r * (Fintype.card A - r).descFactorial f := by
  classical
  have h := Fintype.card_congr (complementEmbeddingPairEquiv (A := A) (r := r) (f := f))
  simp only [Fintype.card_sigma, Fintype.card_coe, Fintype.card_embedding_eq,
    outside_card, Fintype.card_fin, sum_const, card_univ, nsmul_eq_mul] at h
  exact h.symm

noncomputable def disjointSampleProduct {A : Type*} [Fintype A] {r f : ℕ}
    (g : (Fin r ↪ A) → ℝ) (h : (Fin f ↪ A) → ℝ) (σ : Fin (r + f) ↪ A) : ℝ :=
  let p := disjointEmbeddingEquiv σ
  g p.val.1 * h p.val.2

theorem disjointSampleProduct_mean {A : Type*} [Fintype A] {r f : ℕ}
    (g : (Fin r ↪ A) → ℝ) (h : (Fin f ↪ A) → ℝ) :
    uniformMean (disjointSampleProduct g h) =
      uniformMean (fun p : disjointEmbeddingPairs A r f => g p.val.1 * h p.val.2) :=
  uniformMean_equiv_between (disjointEmbeddingEquiv (A := A) (r := r) (f := f))
    (fun p : disjointEmbeddingPairs A r f => g p.val.1 * h p.val.2)

/-- Restricting an independent product with nonnegative first mean and
nonnegative second factor loses at most the relative discarded count. -/
theorem disjointSampleProduct_lower {A : Type*} [Fintype A] [DecidableEq A] {r f : ℕ}
    [Nonempty (Fin r ↪ A)] [Nonempty (Fin f ↪ A)]
    (g : (Fin r ↪ A) → ℝ) (h : (Fin f ↪ A) → ℝ)
    (hg : ∀ t, |g t| ≤ 1) (hgm : 0 ≤ uniformMean g)
    (hh0 : ∀ t, 0 ≤ h t) (hh1 : ∀ t, h t ≤ 1) :
    -(((disjointEmbeddingPairs A r f)ᶜ).card : ℝ) /
        ((disjointEmbeddingPairs A r f).card : ℝ) ≤
      uniformMean (disjointSampleProduct g h) := by
  classical
  have hprod : ∀ p : (Fin r ↪ A) × (Fin f ↪ A), |g p.1 * h p.2| ≤ 1 := by
    intro p
    rw [abs_mul, abs_of_nonneg (hh0 p.2)]
    simpa using mul_le_mul (hg p.1) (hh1 p.2) (hh0 p.2) (by norm_num : (0 : ℝ) ≤ 1)
  obtain ⟨ε, he, hε⟩ := restricted_mean_decomposition (disjointEmbeddingPairs A r f)
    (fun p : (Fin r ↪ A) × (Fin f ↪ A) => g p.1 * h p.2) hprod
  rw [← disjointSampleProduct_mean g h, uniformMean_product g h] at he
  have hm : 0 ≤ uniformMean h := uniformMean_nonneg hh0
  have hc : 0 ≤ (Fintype.card ((Fin r ↪ A) × (Fin f ↪ A)) : ℝ) /
      ((disjointEmbeddingPairs A r f).card : ℝ) :=
    div_nonneg (Nat.cast_nonneg _) (Nat.cast_nonneg _)
  have hp := mul_nonneg hc (mul_nonneg hgm hm)
  have heps := (le_abs_self ε).trans hε
  rw [he]
  rw [neg_div]
  linarith

theorem disjointEmbeddingEquiv_coordinates {A : Type*} [Fintype A] {r f : ℕ}
    (σ : Fin (r + f) ↪ A) :
    (disjointEmbeddingEquiv σ).val =
      ((Fin.castAddEmb f).trans σ, (Fin.natAddEmb r).trans σ) := by
  apply Prod.ext <;> ext i <;> rfl

theorem disjointSampleProduct_coordinates {A : Type*} [Fintype A] {r f : ℕ}
    (g : (Fin r ↪ A) → ℝ) (h : (Fin f ↪ A) → ℝ) (σ : Fin (r + f) ↪ A) :
    disjointSampleProduct g h σ =
      g ((Fin.castAddEmb f).trans σ) * h ((Fin.natAddEmb r).trans σ) := by
  change g (disjointEmbeddingEquiv σ).val.1 * h (disjointEmbeddingEquiv σ).val.2 = _
  rw [disjointEmbeddingEquiv_coordinates]

#print axioms disjointEmbeddingEquiv_coordinates
#print axioms disjointSampleProduct_coordinates
#print axioms disjointSampleProduct_lower
#print axioms disjointEmbeddingPairs_card
#print axioms disjointSampleProduct_mean
end TightCycleC5.Bridge
