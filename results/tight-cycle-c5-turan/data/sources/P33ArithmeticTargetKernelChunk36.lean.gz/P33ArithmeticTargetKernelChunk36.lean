-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk144 :
    ∀ i : Fin (min 128 (40547 - 128 * 144)),
      targetCountsMatch (classAt (targetKernelClass ⟨144, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk144

theorem target_counts_kernel_chunk145 :
    ∀ i : Fin (min 128 (40547 - 128 * 145)),
      targetCountsMatch (classAt (targetKernelClass ⟨145, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk145

theorem target_counts_kernel_chunk146 :
    ∀ i : Fin (min 128 (40547 - 128 * 146)),
      targetCountsMatch (classAt (targetKernelClass ⟨146, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk146

theorem target_counts_kernel_chunk147 :
    ∀ i : Fin (min 128 (40547 - 128 * 147)),
      targetCountsMatch (classAt (targetKernelClass ⟨147, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk147


end TightCycleC5.Bridge.P33Arithmetic
