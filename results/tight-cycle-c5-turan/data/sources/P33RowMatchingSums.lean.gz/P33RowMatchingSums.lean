import P33RowMatchingAggregate

namespace TightCycleC5.Bridge.P33RowMatching
open Finset
set_option maxRecDepth 100000
set_option maxHeartbeats 2000000

/-- Exact partition, with no multiplicity grouping or row omissions. -/
theorem sum_row_partition (f : Fin 12847 → ℝ) :
    (∑ i, f i) = (∑ i : Fin 80, f ⟨i.val,by omega⟩) +
      (∑ i : Fin 8, f ⟨80+i.val,by omega⟩) +
      (∑ i : Fin 9, f ⟨88+i.val,by omega⟩) +
      (∑ i : Fin 12750, f ⟨97+i.val,by omega⟩) := by
  rw [Fin.sum_univ_add (a := 80) (b := 12767)]
  rw [Fin.sum_univ_add (a := 8) (b := 12759)]
  rw [Fin.sum_univ_add (a := 9) (b := 12750)]
  simp only [Fin.castAdd,Fin.natAdd,Fin.castLE,Fin.val_mk]
  simp only [show ∀ i : Fin 9, 80+(8+i.val)=88+i.val by intro i; omega,
    show ∀ i : Fin 12750, 80+(8+(9+i.val))=97+i.val by intro i; omega]
  ring

theorem actualNonPSD_eq_flat (G : LabelledStructure 6) :
    actualNonPSD G =
      (∑ i : Fin 12847, actualInequalityWeight i * actualInequalityRow G i) +
      ∑ r : Fin 120, P33Rows.regularWeight r * P33Rows.sourceRegularRow r G := by
  have hl (i : Fin 80) :
      actualInequalityWeight ⟨i.val,by omega⟩ * actualInequalityRow G ⟨i.val,by omega⟩ =
        P33Rows.localWeight i * P33Rows.sourceLocalRow i G := by
    simp only [actualInequalityWeight,actualInequalityRow,Fin.val_mk,
      show i.val < 97 by omega,show i.val < 80 from i.isLt,dif_pos]
    rfl
  have hc (i : Fin 8) :
      actualInequalityWeight ⟨80+i.val,by omega⟩ * actualInequalityRow G ⟨80+i.val,by omega⟩ =
        P33Rows.cutWeight i * P33Rows.sourceCutRow i G := by
    simp only [actualInequalityWeight,actualInequalityRow,Fin.val_mk,
      show 80+i.val < 97 by omega,show ¬80+i.val < 80 by omega,
      show 80+i.val < 88 by omega,dif_pos,dif_neg,Nat.add_sub_cancel_left]
    rfl
  have hd (i : Fin 9) :
      actualInequalityWeight ⟨88+i.val,by omega⟩ * actualInequalityRow G ⟨88+i.val,by omega⟩ =
        P33Rows.densityWeight i * P33Rows.sourceDensityRow i G := by
    simp only [actualInequalityWeight,actualInequalityRow,Fin.val_mk,
      show 88+i.val < 97 by omega,show ¬88+i.val < 80 by omega,
      show ¬88+i.val < 88 by omega,dif_pos,dif_neg,Nat.add_sub_cancel_left]
    rfl
  have hcl (i : Fin 12750) :
      actualInequalityWeight ⟨97+i.val,by omega⟩ * actualInequalityRow G ⟨97+i.val,by omega⟩ =
        CertificateDescriptors.p33CLWeight false i *
          CLCertificate.row (CertificateDescriptors.p33CL i) G := by
    simp only [actualInequalityWeight,actualInequalityRow,Fin.val_mk,
      show ¬97+i.val < 97 by omega,show ¬97+i.val < 80 by omega,
      show ¬97+i.val < 88 by omega,dif_neg,Nat.add_sub_cancel_left]
    simp only [↓reduceDIte]
  rw [sum_row_partition]
  simp_rw [hl,hc,hd,hcl]
  rfl

#print axioms sum_row_partition
#print axioms actualNonPSD_eq_flat
end TightCycleC5.Bridge.P33RowMatching
