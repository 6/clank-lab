import P33RowMatchingCore

namespace TightCycleC5.Bridge.P33RowMatching

abbrev edgeAt (K : P33Arithmetic.Class) (p : Fin 6 → Fin 6) (a b c : Fin 6) : Nat :=
  P33Arithmetic.edge K.mask (p a).val (p b).val (p c).val
abbrev colourAt (K : P33Arithmetic.Class) (p : Fin 6 → Fin 6) (a : Fin 6) : Nat :=
  P33Arithmetic.colour K.colours (p a).val

theorem features_localIndex (ls : Array (Array Nat)) (gs : Array Nat)
    (bs : Array P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Fin 6 → Fin 6) :
    (P33Arithmetic.featuresAt ls gs bs K p).localIndex =
      40 * colourAt K p 0 + P33Arithmetic.lookup ls[colourAt K p 0]!
        (P33Arithmetic.canonical K.mask K.colours [(p 0).val] [(p 3).val,(p 4).val,(p 5).val]) := by
  rfl

theorem features_localSign (ls : Array (Array Nat)) (gs : Array Nat)
    (bs : Array P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Fin 6 → Fin 6) :
    (P33Arithmetic.featuresAt ls gs bs K p).localSign =
      (edgeAt K p 0 1 2 : Int) *
        ((if colourAt K p 1 + colourAt K p 2 = 1 then 1 else 0) -
          (if colourAt K p 1 + colourAt K p 2 = 0 then 1 else 0)) *
        (if colourAt K p 0 = 0 then 1 else -1) := by
  rfl

theorem features_globalIndex (ls : Array (Array Nat)) (gs : Array Nat)
    (bs : Array P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Fin 6 → Fin 6) :
    (P33Arithmetic.featuresAt ls gs bs K p).globalIndex = P33Arithmetic.lookup gs
      (P33Arithmetic.canonical K.mask K.colours [] [(p 3).val,(p 4).val,(p 5).val]) := by
  rfl

theorem features_degreeDiff (ls : Array (Array Nat)) (gs : Array Nat)
    (bs : Array P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Fin 6 → Fin 6) :
    (P33Arithmetic.featuresAt ls gs bs K p).degreeDiff =
      (edgeAt K p 0 2 3 : Int) - edgeAt K p 1 2 3 := by
  rfl

theorem features_cutValue (ls : Array (Array Nat)) (gs : Array Nat)
    (bs : Array P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Fin 6 → Fin 6) :
    (P33Arithmetic.featuresAt ls gs bs K p).cutValue =
      5 * ((edgeAt K p 0 1 2 *
        (if colourAt K p 0 + colourAt K p 1 + colourAt K p 2 = 1 then 1 else 0) : Nat) : Int) - 2 := by
  rfl

theorem features_densityValue (ls : Array (Array Nat)) (gs : Array Nat)
    (bs : Array P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Fin 6 → Fin 6) :
    (P33Arithmetic.featuresAt ls gs bs K p).densityValue =
      1000000000 * (edgeAt K p 0 1 2 : Int) - 464101615 := by
  rfl

theorem features_tau (ls : Array (Array Nat)) (gs : Array Nat)
    (bs : Array P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Fin 6 → Fin 6) :
    (P33Arithmetic.featuresAt ls gs bs K p).tau =
      edgeAt K p 0 1 2 := by
  rfl

theorem features_rootColour (ls : Array (Array Nat)) (gs : Array Nat)
    (bs : Array P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Fin 6 → Fin 6) :
    (P33Arithmetic.featuresAt ls gs bs K p).rootColour =
      colourAt K p 0 + 2*colourAt K p 1 + 4*colourAt K p 2 := by
  rfl

theorem features_patterns (ls : Array (Array Nat)) (gs : Array Nat)
    (bs : Array P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Fin 6 → Fin 6) :
    (P33Arithmetic.featuresAt ls gs bs K p).patterns =
      #[4*edgeAt K p 0 1 3+2*edgeAt K p 0 2 3+edgeAt K p 1 2 3,
      4*edgeAt K p 0 1 4+2*edgeAt K p 0 2 4+edgeAt K p 1 2 4,
      4*edgeAt K p 0 1 5+2*edgeAt K p 0 2 5+edgeAt K p 1 2 5] := by
  rfl

theorem features_freeColours (ls : Array (Array Nat)) (gs : Array Nat)
    (bs : Array P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Fin 6 → Fin 6) :
    (P33Arithmetic.featuresAt ls gs bs K p).freeColours =
      #[colourAt K p 3,colourAt K p 4,colourAt K p 5] := by
  rfl

theorem features_clValue (ls : Array (Array Nat)) (gs : Array Nat)
    (bs : Array P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Fin 6 → Fin 6) :
    (P33Arithmetic.featuresAt ls gs bs K p).clValue =
      (edgeAt K p 0 3 4 : Int) * edgeAt K p 0 3 5 * (1-edgeAt K p 0 4 5) -
      (edgeAt K p 0 3 4 : Int) * edgeAt K p 0 3 5 * edgeAt K p 0 4 5 * edgeAt K p 3 4 5 := by
  rfl

#print axioms features_localIndex
#print axioms features_localSign
#print axioms features_globalIndex
#print axioms features_degreeDiff
#print axioms features_cutValue
#print axioms features_densityValue
#print axioms features_tau
#print axioms features_rootColour
#print axioms features_patterns
#print axioms features_freeColours
#print axioms features_clValue
end TightCycleC5.Bridge.P33RowMatching
