import P33ArithmeticData
import P33RowsFinite

namespace TightCycleC5.Bridge.P33RowMatching
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000

/-- Literal two-colour local lookup tables are well formed and injective. -/
theorem local_tables_checked : P33Arithmetic.localFlags.size = 2 ∧
    ∀ c : Fin 2, (P33Arithmetic.localFlags[c.val]!).size = 40 ∧
      (P33Arithmetic.localFlags[c.val]!).toList.Nodup := by decide +kernel

theorem local_tables_aligned : ∀ i : Fin 80,
    (P33Arithmetic.localFlags[i.val / 40]!)[i.val % 40]! = P33Rows.localFlags[i.val]! ∧
      P33Rows.localColors[i.val]!.toNat = i.val / 40 := by decide +kernel

theorem global_table_aligned : P33Arithmetic.globalFlags = P33Rows.globalFlags := by decide +kernel

theorem regular_tables_checked : ∀ b : Fin 3,
    (P33Arithmetic.blocks[b.val]!).n = 4 ∧ (P33Arithmetic.blocks[b.val]!).roots = 2 ∧
    (P33Arithmetic.blocks[b.val]!).typeCode = (#[0,2,3] : Array Nat)[b.val]! ∧
    (P33Arithmetic.blocks[b.val]!).flags.size = 40 ∧
    (P33Arithmetic.blocks[b.val]!).flags.toList.Nodup := by decide +kernel

theorem regular_tables_aligned : ∀ i : Fin 120,
    (P33Arithmetic.blocks[i.val / 40]!).flags[i.val % 40]! = P33Rows.regularFlags[i.val]! ∧
      (P33Arithmetic.blocks[i.val / 40]!).typeCode = P33Rows.regularTypes[i.val]! := by decide +kernel

/-- Raw weights are shared once; normalization introduces no second scale. -/
theorem source_scale_aligned : P33Arithmetic.sosScale = (P33Rows.sourceScale : Int) := by decide +kernel

theorem local_global_weights_aligned : ∀ i : Fin 97,
    P33Arithmetic.denseInequalities[i.val]! = P33Rows.rawInequalityWeights[i.val]! := by decide +kernel

theorem regular_weights_aligned : ∀ i : Fin 120,
    P33Arithmetic.denseRegularity[i.val]! = P33Rows.rawRegularWeights[i.val]! := by decide +kernel

#print axioms local_tables_checked
#print axioms local_tables_aligned
#print axioms global_table_aligned
#print axioms regular_tables_checked
#print axioms regular_tables_aligned
#print axioms source_scale_aligned
#print axioms local_global_weights_aligned
#print axioms regular_weights_aligned
end TightCycleC5.Bridge.P33RowMatching
