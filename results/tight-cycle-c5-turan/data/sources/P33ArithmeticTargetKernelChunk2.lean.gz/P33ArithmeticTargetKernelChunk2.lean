-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk8 :
    ∀ i : Fin (min 128 (40547 - 128 * 8)),
      targetCountsMatch (classAt (targetKernelClass ⟨8, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk8

theorem target_counts_kernel_chunk9 :
    ∀ i : Fin (min 128 (40547 - 128 * 9)),
      targetCountsMatch (classAt (targetKernelClass ⟨9, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk9

theorem target_counts_kernel_chunk10 :
    ∀ i : Fin (min 128 (40547 - 128 * 10)),
      targetCountsMatch (classAt (targetKernelClass ⟨10, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk10

theorem target_counts_kernel_chunk11 :
    ∀ i : Fin (min 128 (40547 - 128 * 11)),
      targetCountsMatch (classAt (targetKernelClass ⟨11, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk11


end TightCycleC5.Bridge.P33Arithmetic
