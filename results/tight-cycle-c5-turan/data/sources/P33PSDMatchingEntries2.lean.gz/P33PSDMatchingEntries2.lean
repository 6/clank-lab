-- Generated from the pinned P33 manifest; untrusted proof quotation.
import P33PSDMatchingCore
import P33FlagData
import P33ArithmeticBlocks0
import P33ArithmeticBlocks1
import P33ArithmeticBlocks2
import P33ArithmeticBlocks3
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000
namespace TightCycleC5.Bridge.P33PSDMatching
open Finset Matrix

theorem source_metadata2 :
    P33Arithmetic.block2.flags = P33Flag.basis2Data ∧
    P33Arithmetic.block2.roots = 2 ∧
    P33Arithmetic.block2.typeCode = P33Flag.type2 := by decide +kernel
theorem source_terms2 : ∀ k : Fin 5, ∀ i j : Fin 40,
    P33Arithmetic.termEntry P33Arithmetic.block2.terms[k.val]! i.val j.val =
      (P33PSD.weights2 k : ℤ) * P33PSD.terms2 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry2 : ∀ i j : Fin 40,
    P33Arithmetic.blockEntry P33Arithmetic.block2 i.val j.val = P33PSD.q2 i j :=
  blockEntry_eq_sos P33Arithmetic.block2 P33PSD.weights2 P33PSD.terms2 rfl source_terms2
#print axioms source_metadata2
#print axioms source_terms2
#print axioms source_entry2

theorem source_metadata8 :
    P33Arithmetic.block8.flags = P33Flag.basis8Data ∧
    P33Arithmetic.block8.roots = 4 ∧
    P33Arithmetic.block8.typeCode = P33Flag.type8 := by decide +kernel
theorem source_terms8 : ∀ k : Fin 8, ∀ i j : Fin 128,
    P33Arithmetic.termEntry P33Arithmetic.block8.terms[k.val]! i.val j.val =
      (P33PSD.weights8 k : ℤ) * P33PSD.terms8 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry8 : ∀ i j : Fin 128,
    P33Arithmetic.blockEntry P33Arithmetic.block8 i.val j.val = P33PSD.q8 i j :=
  blockEntry_eq_sos P33Arithmetic.block8 P33PSD.weights8 P33PSD.terms8 rfl source_terms8
#print axioms source_metadata8
#print axioms source_terms8
#print axioms source_entry8

theorem source_metadata14 :
    P33Arithmetic.block14.flags = P33Flag.basis14Data ∧
    P33Arithmetic.block14.roots = 4 ∧
    P33Arithmetic.block14.typeCode = P33Flag.type14 := by decide +kernel
theorem source_terms14 : ∀ k : Fin 11, ∀ i j : Fin 128,
    P33Arithmetic.termEntry P33Arithmetic.block14.terms[k.val]! i.val j.val =
      (P33PSD.weights14 k : ℤ) * P33PSD.terms14 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry14 : ∀ i j : Fin 128,
    P33Arithmetic.blockEntry P33Arithmetic.block14 i.val j.val = P33PSD.q14 i j :=
  blockEntry_eq_sos P33Arithmetic.block14 P33PSD.weights14 P33PSD.terms14 rfl source_terms14
#print axioms source_metadata14
#print axioms source_terms14
#print axioms source_entry14

theorem source_metadata20 :
    P33Arithmetic.block20.flags = P33Flag.basis20Data ∧
    P33Arithmetic.block20.roots = 4 ∧
    P33Arithmetic.block20.typeCode = P33Flag.type20 := by decide +kernel
theorem source_terms20 : ∀ k : Fin 18, ∀ i j : Fin 100,
    P33Arithmetic.termEntry P33Arithmetic.block20.terms[k.val]! i.val j.val =
      (P33PSD.weights20 k : ℤ) * P33PSD.terms20 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry20 : ∀ i j : Fin 100,
    P33Arithmetic.blockEntry P33Arithmetic.block20 i.val j.val = P33PSD.q20 i j :=
  blockEntry_eq_sos P33Arithmetic.block20 P33PSD.weights20 P33PSD.terms20 rfl source_terms20
#print axioms source_metadata20
#print axioms source_terms20
#print axioms source_entry20

theorem source_metadata26 :
    P33Arithmetic.block26.flags = P33Flag.basis26Data ∧
    P33Arithmetic.block26.roots = 4 ∧
    P33Arithmetic.block26.typeCode = P33Flag.type26 := by decide +kernel
theorem source_terms26 : ∀ k : Fin 8, ∀ i j : Fin 78,
    P33Arithmetic.termEntry P33Arithmetic.block26.terms[k.val]! i.val j.val =
      (P33PSD.weights26 k : ℤ) * P33PSD.terms26 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry26 : ∀ i j : Fin 78,
    P33Arithmetic.blockEntry P33Arithmetic.block26 i.val j.val = P33PSD.q26 i j :=
  blockEntry_eq_sos P33Arithmetic.block26 P33PSD.weights26 P33PSD.terms26 rfl source_terms26
#print axioms source_metadata26
#print axioms source_terms26
#print axioms source_entry26

theorem source_metadata32 :
    P33Arithmetic.block32.flags = P33Flag.basis32Data ∧
    P33Arithmetic.block32.roots = 4 ∧
    P33Arithmetic.block32.typeCode = P33Flag.type32 := by decide +kernel
theorem source_terms32 : ∀ k : Fin 0, ∀ i j : Fin 78,
    P33Arithmetic.termEntry P33Arithmetic.block32.terms[k.val]! i.val j.val =
      (P33PSD.weights32 k : ℤ) * P33PSD.terms32 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry32 : ∀ i j : Fin 78,
    P33Arithmetic.blockEntry P33Arithmetic.block32 i.val j.val = P33PSD.q32 i j :=
  blockEntry_eq_sos P33Arithmetic.block32 P33PSD.weights32 P33PSD.terms32 rfl source_terms32
#print axioms source_metadata32
#print axioms source_terms32
#print axioms source_entry32

end TightCycleC5.Bridge.P33PSDMatching
