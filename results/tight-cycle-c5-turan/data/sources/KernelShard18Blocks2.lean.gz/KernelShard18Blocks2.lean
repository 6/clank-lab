import KernelRowIndex
import KernelWitness18

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_18_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 64 * 256 + i.val))
      kernelWitness18Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_64

theorem kernelBlock_18_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 65 * 256 + i.val))
      kernelWitness18Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_65

theorem kernelBlock_18_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 66 * 256 + i.val))
      kernelWitness18Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_66

theorem kernelBlock_18_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 67 * 256 + i.val))
      kernelWitness18Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_67

theorem kernelBlock_18_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 68 * 256 + i.val))
      kernelWitness18Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_68

theorem kernelBlock_18_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 69 * 256 + i.val))
      kernelWitness18Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_69

theorem kernelBlock_18_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 70 * 256 + i.val))
      kernelWitness18Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_70

theorem kernelBlock_18_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 71 * 256 + i.val))
      kernelWitness18Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_71

theorem kernelBlock_18_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 72 * 256 + i.val))
      kernelWitness18Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_72

theorem kernelBlock_18_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 73 * 256 + i.val))
      kernelWitness18Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_73

theorem kernelBlock_18_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 74 * 256 + i.val))
      kernelWitness18Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_74

theorem kernelBlock_18_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 75 * 256 + i.val))
      kernelWitness18Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_75

theorem kernelBlock_18_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 76 * 256 + i.val))
      kernelWitness18Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_76

theorem kernelBlock_18_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 77 * 256 + i.val))
      kernelWitness18Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_77

theorem kernelBlock_18_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 78 * 256 + i.val))
      kernelWitness18Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_78

theorem kernelBlock_18_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 79 * 256 + i.val))
      kernelWitness18Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_79

theorem kernelBlock_18_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 80 * 256 + i.val))
      kernelWitness18Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_80

theorem kernelBlock_18_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 81 * 256 + i.val))
      kernelWitness18Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_81

theorem kernelBlock_18_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 82 * 256 + i.val))
      kernelWitness18Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_82

theorem kernelBlock_18_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 83 * 256 + i.val))
      kernelWitness18Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_83

theorem kernelBlock_18_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 84 * 256 + i.val))
      kernelWitness18Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_84

theorem kernelBlock_18_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 85 * 256 + i.val))
      kernelWitness18Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_85

theorem kernelBlock_18_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 86 * 256 + i.val))
      kernelWitness18Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_86

theorem kernelBlock_18_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 87 * 256 + i.val))
      kernelWitness18Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_87

theorem kernelBlock_18_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 88 * 256 + i.val))
      kernelWitness18Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_88

theorem kernelBlock_18_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 89 * 256 + i.val))
      kernelWitness18Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_89

theorem kernelBlock_18_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 90 * 256 + i.val))
      kernelWitness18Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_90

theorem kernelBlock_18_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 91 * 256 + i.val))
      kernelWitness18Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_91

theorem kernelBlock_18_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 92 * 256 + i.val))
      kernelWitness18Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_92

theorem kernelBlock_18_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 93 * 256 + i.val))
      kernelWitness18Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_93

theorem kernelBlock_18_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 94 * 256 + i.val))
      kernelWitness18Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_94

theorem kernelBlock_18_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 95 * 256 + i.val))
      kernelWitness18Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_95

end TightCycleC5.Bridge.Cover
