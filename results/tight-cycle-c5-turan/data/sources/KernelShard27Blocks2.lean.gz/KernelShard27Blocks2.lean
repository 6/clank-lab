import KernelRowIndex
import KernelWitness27

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_27_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 64 * 256 + i.val))
      kernelWitness27Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_64

theorem kernelBlock_27_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 65 * 256 + i.val))
      kernelWitness27Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_65

theorem kernelBlock_27_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 66 * 256 + i.val))
      kernelWitness27Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_66

theorem kernelBlock_27_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 67 * 256 + i.val))
      kernelWitness27Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_67

theorem kernelBlock_27_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 68 * 256 + i.val))
      kernelWitness27Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_68

theorem kernelBlock_27_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 69 * 256 + i.val))
      kernelWitness27Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_69

theorem kernelBlock_27_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 70 * 256 + i.val))
      kernelWitness27Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_70

theorem kernelBlock_27_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 71 * 256 + i.val))
      kernelWitness27Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_71

theorem kernelBlock_27_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 72 * 256 + i.val))
      kernelWitness27Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_72

theorem kernelBlock_27_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 73 * 256 + i.val))
      kernelWitness27Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_73

theorem kernelBlock_27_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 74 * 256 + i.val))
      kernelWitness27Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_74

theorem kernelBlock_27_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 75 * 256 + i.val))
      kernelWitness27Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_75

theorem kernelBlock_27_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 76 * 256 + i.val))
      kernelWitness27Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_76

theorem kernelBlock_27_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 77 * 256 + i.val))
      kernelWitness27Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_77

theorem kernelBlock_27_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 78 * 256 + i.val))
      kernelWitness27Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_78

theorem kernelBlock_27_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 79 * 256 + i.val))
      kernelWitness27Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_79

theorem kernelBlock_27_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 80 * 256 + i.val))
      kernelWitness27Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_80

theorem kernelBlock_27_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 81 * 256 + i.val))
      kernelWitness27Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_81

theorem kernelBlock_27_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 82 * 256 + i.val))
      kernelWitness27Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_82

theorem kernelBlock_27_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 83 * 256 + i.val))
      kernelWitness27Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_83

theorem kernelBlock_27_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 84 * 256 + i.val))
      kernelWitness27Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_84

theorem kernelBlock_27_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 85 * 256 + i.val))
      kernelWitness27Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_85

theorem kernelBlock_27_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 86 * 256 + i.val))
      kernelWitness27Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_86

theorem kernelBlock_27_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 87 * 256 + i.val))
      kernelWitness27Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_87

theorem kernelBlock_27_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 88 * 256 + i.val))
      kernelWitness27Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_88

theorem kernelBlock_27_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 89 * 256 + i.val))
      kernelWitness27Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_89

theorem kernelBlock_27_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 90 * 256 + i.val))
      kernelWitness27Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_90

theorem kernelBlock_27_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 91 * 256 + i.val))
      kernelWitness27Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_91

theorem kernelBlock_27_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 92 * 256 + i.val))
      kernelWitness27Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_92

theorem kernelBlock_27_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 93 * 256 + i.val))
      kernelWitness27Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_93

theorem kernelBlock_27_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 94 * 256 + i.val))
      kernelWitness27Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_94

theorem kernelBlock_27_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 95 * 256 + i.val))
      kernelWitness27Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_95

end TightCycleC5.Bridge.Cover
