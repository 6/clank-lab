-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk288 :
    ∀ i : Fin (min 128 (40547 - 128 * 288)),
      targetCountsMatch (classAt (targetKernelClass ⟨288, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk288

theorem target_counts_kernel_chunk289 :
    ∀ i : Fin (min 128 (40547 - 128 * 289)),
      targetCountsMatch (classAt (targetKernelClass ⟨289, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk289

theorem target_counts_kernel_chunk290 :
    ∀ i : Fin (min 128 (40547 - 128 * 290)),
      targetCountsMatch (classAt (targetKernelClass ⟨290, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk290

theorem target_counts_kernel_chunk291 :
    ∀ i : Fin (min 128 (40547 - 128 * 291)),
      targetCountsMatch (classAt (targetKernelClass ⟨291, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk291


end TightCycleC5.Bridge.P33Arithmetic
