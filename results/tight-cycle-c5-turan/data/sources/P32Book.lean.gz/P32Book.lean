import PairBookCertificate
import P32BookData

/-! Every exact weighted pair-book row uses weights in [0,1]. In
particular the denominator is the certificate's prob_scale. -/
namespace TightCycleC5.Bridge.P32Book
open Finset

set_option maxRecDepth 100000

def inputBounds (scale : Int) (roots : Array Int) (ws : Array (Array Int)) : Prop :=
  0 < scale ∧ roots.size = 25 ∧ ws.size = 25 ∧
    ∀ j : Fin 25, ws[j.val]!.size = 32 ∧ 0 ≤ roots[j.val]! ∧ roots[j.val]! < 16 ∧
      ∀ p : Fin 32, 0 ≤ (ws[j.val]!)[p.val]! ∧ (ws[j.val]!)[p.val]! ≤ scale

set_option maxHeartbeats 0 in
theorem checked_weight_data : inputBounds probabilityScale rootCodes weights := by
  unfold inputBounds
  decide +kernel

theorem probabilityScale_pos : 0 < probabilityScale := checked_weight_data.1

theorem numerator_bounds (j : Fin 25) (p : Fin 32) :
    0 ≤ (weights[j.val]!)[p.val]! ∧ (weights[j.val]!)[p.val]! ≤ probabilityScale :=
  (checked_weight_data.2.2.2 j).2.2.2 p

def rootType (j : Fin 25) : Fin 16 :=
  ⟨rootCodes[j.val]!.toNat, by
    have h0 := (checked_weight_data.2.2.2 j).2.1
    have h1 := (checked_weight_data.2.2.2 j).2.2.1
    omega⟩

theorem rootType_exact (j : Fin 25) : (rootType j).val = rootCodes[j.val]!.toNat := rfl

theorem rootType_int_exact (j : Fin 25) : ((rootType j).val : Int) = rootCodes[j.val]! := by
  have h0 := (checked_weight_data.2.2.2 j).2.1
  change (rootCodes[j.val]!.toNat : Int) = rootCodes[j.val]!
  omega

noncomputable def normalizedWeight (j : Fin 25) (p : Fin 32) : ℝ :=
  ((weights[j.val]!)[p.val]! : ℝ) / (probabilityScale : ℝ)

theorem normalized_weight_bounds (j : Fin 25) (p : Fin 32) :
    0 ≤ normalizedWeight j p ∧ normalizedWeight j p ≤ 1 := by
  have hP : (0 : ℝ) < probabilityScale := by exact_mod_cast probabilityScale_pos
  have h0 : (0 : ℝ) ≤ (weights[j.val]!)[p.val]! := by exact_mod_cast (numerator_bounds j p).1
  have h1 : ((weights[j.val]!)[p.val]! : ℝ) ≤ probabilityScale := by exact_mod_cast (numerator_bounds j p).2
  constructor
  · exact div_nonneg h0 hP.le
  · apply (div_le_iff₀ hP).2
    simpa using h1

noncomputable def descriptor (j : Fin 25) : PairBookCertificate.Descriptor :=
  ⟨rootType j, normalizedWeight j⟩

theorem row_mean_lower {n : Nat} (j : Fin 25) (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (hn : 12 ≤ n) (S : Finset (Fin n)) :
    -(1 / ((n : ℝ) - 5)) ≤ uniformMean (fun σ : Fin 6 ↪ Fin n =>
      PairBookCertificate.row (descriptor j) (sampleStructure σ H S)) :=
  PairBookCertificate.row_mean_lower (descriptor j)
    (fun p => (normalized_weight_bounds j p).1) (fun p => (normalized_weight_bounds j p).2)
    H hH hC hn S

set_option maxHeartbeats 0 in
theorem rejects_negative_weight :
    ¬ inputBounds probabilityScale rootCodes (weights.set! 0 (weights[0]!.set! 0 (-1))) := by
  unfold inputBounds
  decide +kernel

#print axioms checked_weight_data
#print axioms probabilityScale_pos
#print axioms numerator_bounds
#print axioms rootType_exact
#print axioms rootType_int_exact
#print axioms normalized_weight_bounds
#print axioms row_mean_lower
#print axioms rejects_negative_weight
end TightCycleC5.Bridge.P32Book
