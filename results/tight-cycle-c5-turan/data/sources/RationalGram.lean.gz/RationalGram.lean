import GramSoundness

/-! Uniform soundness for rational diagonal Gram certificates.
The finite equalities used by clients are separate from this kernel proof. -/
namespace TightCycleC5.Bridge
open Matrix Finset

noncomputable def ratMatrixReal {I J : Type*} (Q : Matrix I J ℚ) : Matrix I J ℝ :=
  fun i j => (Q i j : ℝ)

def rationalGram {I K : Type*} [Fintype K]
    (w : K → ℚ) (v : K → I → ℤ) : Matrix I I ℚ :=
  fun i j => ∑ k, w k * (v k i : ℚ) * (v k j : ℚ)

theorem int_outer_posSemidef {I : Type*} [Finite I] (v : I → ℤ) :
    (intMatrixReal (fun i j => v i * v j)).PosSemidef := by
  let U : Matrix I (Fin 1) ℤ := fun i _ => v i
  apply int_gram_posSemidef _ U
  ext i j
  simp [U, Matrix.mul_apply, Matrix.transpose_apply]

theorem rational_gram_posSemidef {I K : Type*} [Finite I] [Fintype K]
    (Q : Matrix I I ℤ) (w : K → ℚ) (v : K → I → ℤ)
    (hw : ∀ k, 0 ≤ w k)
    (he : (fun i j => (Q i j : ℚ)) = rationalGram w v) :
    (intMatrixReal Q).PosSemidef := by
  have heR : intMatrixReal Q =
      ∑ k, (w k : ℝ) • intMatrixReal (fun i j => v k i * v k j) := by
    ext i j
    have h := congrFun (congrFun he i) j
    have h' := congrArg (fun x : ℚ => (x : ℝ)) h
    simpa [intMatrixReal, rationalGram, Rat.cast_sum, Rat.cast_mul,
      Matrix.sum_apply, Matrix.smul_apply, smul_eq_mul, mul_assoc] using h'
  rw [heR]
  apply Matrix.posSemidef_sum
  intro k _
  exact (int_outer_posSemidef (v k)).smul (by exact_mod_cast hw k)

#print axioms int_outer_posSemidef
#print axioms rational_gram_posSemidef
end TightCycleC5.Bridge
