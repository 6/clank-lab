import KernelRowIndex
import KernelWitness14

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_14_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 64 * 256 + i.val))
      kernelWitness14Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_64

theorem kernelBlock_14_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 65 * 256 + i.val))
      kernelWitness14Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_65

theorem kernelBlock_14_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 66 * 256 + i.val))
      kernelWitness14Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_66

theorem kernelBlock_14_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 67 * 256 + i.val))
      kernelWitness14Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_67

theorem kernelBlock_14_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 68 * 256 + i.val))
      kernelWitness14Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_68

theorem kernelBlock_14_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 69 * 256 + i.val))
      kernelWitness14Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_69

theorem kernelBlock_14_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 70 * 256 + i.val))
      kernelWitness14Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_70

theorem kernelBlock_14_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 71 * 256 + i.val))
      kernelWitness14Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_71

theorem kernelBlock_14_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 72 * 256 + i.val))
      kernelWitness14Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_72

theorem kernelBlock_14_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 73 * 256 + i.val))
      kernelWitness14Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_73

theorem kernelBlock_14_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 74 * 256 + i.val))
      kernelWitness14Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_74

theorem kernelBlock_14_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 75 * 256 + i.val))
      kernelWitness14Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_75

theorem kernelBlock_14_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 76 * 256 + i.val))
      kernelWitness14Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_76

theorem kernelBlock_14_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 77 * 256 + i.val))
      kernelWitness14Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_77

theorem kernelBlock_14_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 78 * 256 + i.val))
      kernelWitness14Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_78

theorem kernelBlock_14_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 79 * 256 + i.val))
      kernelWitness14Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_79

theorem kernelBlock_14_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 80 * 256 + i.val))
      kernelWitness14Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_80

theorem kernelBlock_14_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 81 * 256 + i.val))
      kernelWitness14Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_81

theorem kernelBlock_14_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 82 * 256 + i.val))
      kernelWitness14Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_82

theorem kernelBlock_14_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 83 * 256 + i.val))
      kernelWitness14Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_83

theorem kernelBlock_14_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 84 * 256 + i.val))
      kernelWitness14Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_84

theorem kernelBlock_14_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 85 * 256 + i.val))
      kernelWitness14Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_85

theorem kernelBlock_14_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 86 * 256 + i.val))
      kernelWitness14Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_86

theorem kernelBlock_14_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 87 * 256 + i.val))
      kernelWitness14Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_87

theorem kernelBlock_14_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 88 * 256 + i.val))
      kernelWitness14Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_88

theorem kernelBlock_14_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 89 * 256 + i.val))
      kernelWitness14Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_89

theorem kernelBlock_14_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 90 * 256 + i.val))
      kernelWitness14Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_90

theorem kernelBlock_14_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 91 * 256 + i.val))
      kernelWitness14Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_91

theorem kernelBlock_14_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 92 * 256 + i.val))
      kernelWitness14Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_92

theorem kernelBlock_14_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 93 * 256 + i.val))
      kernelWitness14Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_93

theorem kernelBlock_14_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 94 * 256 + i.val))
      kernelWitness14Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_94

theorem kernelBlock_14_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (14 * 32768 + 95 * 256 + i.val))
      kernelWitness14Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_14_95

end TightCycleC5.Bridge.Cover
