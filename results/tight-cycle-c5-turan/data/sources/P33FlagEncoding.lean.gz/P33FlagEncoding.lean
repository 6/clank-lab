import ColouredFlags
import SixSampling
import TupleSampling

/-! Exact labelled P33 positions and compatibility of rooted codes with
actual graph samples. No flag-basis completeness hypothesis. -/
namespace TightCycleC5.Bridge.P33Flag
open Finset
open ColouredFlags

/-- Six labels are x,u,v,a,b,d, in that order. -/
def pairLeft : Fin 4 → Fin 6 := ![0,1,2,3]
def pairRight : Fin 4 → Fin 6 := ![0,1,4,5]
def fourRoot : Fin 4 → Fin 6 := ![0,1,2,3]
def fourLeft : Fin 5 → Fin 6 := ![0,1,2,3,4]
def fourRight : Fin 5 → Fin 6 := ![0,1,2,3,5]
def twoRoot : Fin 2 → Fin 6 := ![0,1]

theorem pairLeft_injective : Function.Injective pairLeft := by
  change ∀ a b, pairLeft a = pairLeft b → a = b
  decide +kernel
theorem pairRight_injective : Function.Injective pairRight := by
  change ∀ a b, pairRight a = pairRight b → a = b
  decide +kernel
theorem fourRoot_injective : Function.Injective fourRoot := by
  change ∀ a b, fourRoot a = fourRoot b → a = b
  decide +kernel
theorem fourLeft_injective : Function.Injective fourLeft := by
  change ∀ a b, fourLeft a = fourLeft b → a = b
  decide +kernel
theorem fourRight_injective : Function.Injective fourRight := by
  change ∀ a b, fourRight a = fourRight b → a = b
  decide +kernel
theorem twoRoot_injective : Function.Injective twoRoot := by
  change ∀ a b, twoRoot a = twoRoot b → a = b
  decide +kernel

def pairVertices {n : ℕ} (root : Fin 2 ↪ Fin n) (p : Outside root × Outside root) :
    Fin 4 → Fin n := ![root 0, root 1, p.1.val, p.2.val]
def fourVertices {n : ℕ} (root : Fin 4 ↪ Fin n) (a : Outside root) :
    Fin 5 → Fin n := ![root 0, root 1, root 2, root 3, a.val]

def pairKey {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (root : Fin 2 ↪ Fin n) (p : Outside root × Outside root) : ℕ :=
  canonical4 (raw4 (graphEdge H) (graphColour S) (pairVertices root p))
def fourKey {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (root : Fin 4 ↪ Fin n) (a : Outside root) : ℕ :=
  (raw5 (graphEdge H) (graphColour S) (fourVertices root a)).toNat

def pairType (G : LabelledStructure 6) : ℕ := root2 G.color twoRoot
def fourType (G : LabelledStructure 6) : ℕ := (raw4 G.edge G.color fourRoot).toNat

def pairIndicator {n : ℕ} (typ : ℕ) (S : Finset (Fin n))
    (root : Fin 2 ↪ Fin n) : ℝ :=
  if root2 (graphColour S) root = typ then 1 else 0

def fourIndicator {n : ℕ} (typ : ℕ) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (root : Fin 4 ↪ Fin n) : ℝ :=
  if (raw4 (graphEdge H) (graphColour S) root).toNat = typ then 1 else 0

theorem pairIndicator_zero_one {n : ℕ} (typ : ℕ) (S : Finset (Fin n))
    (root : Fin 2 ↪ Fin n) : pairIndicator typ S root = 0 ∨ pairIndicator typ S root = 1 := by
  unfold pairIndicator
  split_ifs <;> simp

theorem fourIndicator_zero_one {n : ℕ} (typ : ℕ) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (root : Fin 4 ↪ Fin n) :
    fourIndicator typ H S root = 0 ∨ fourIndicator typ H S root = 1 := by
  unfold fourIndicator
  split_ifs <;> simp

theorem raw4_sample {n : ℕ} (σ : Fin 6 ↪ Fin n) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (v : Fin 4 → Fin 6) :
    raw4 (sampleStructure σ H S).edge (sampleStructure σ H S).color v =
      raw4 (graphEdge H) (graphColour S) (σ ∘ v) := by
  apply congrArg pack
  funext i
  fin_cases i <;> simp [bits4, sampleStructure, graphEdge, graphColour]

theorem raw5_sample {n : ℕ} (σ : Fin 6 ↪ Fin n) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (v : Fin 5 → Fin 6) :
    raw5 (sampleStructure σ H S).edge (sampleStructure σ H S).color v =
      raw5 (graphEdge H) (graphColour S) (σ ∘ v) := by
  apply congrArg pack
  funext i
  fin_cases i <;> simp [bits5, sampleStructure, graphEdge, graphColour]

theorem split_root {r f n : ℕ} (σ : Fin (r+f) ↪ Fin n) (i : Fin r) :
    (splitSampleEquiv (r:=r) (f:=f) σ).1 i = σ (Fin.castAdd f i) := by
  have h := congrArg (fun e : Fin (r+f) ↪ Fin n => e (Fin.castAdd f i))
    (joinSample_split (r:=r) (f:=f) σ)
  simpa only [joinSample_root] using h

theorem split_free {r f n : ℕ} (σ : Fin (r+f) ↪ Fin n) (i : Fin f) :
    ((splitSampleEquiv (r:=r) (f:=f) σ).2 i).val = σ (Fin.natAdd r i) := by
  have h := congrArg (fun e : Fin (r+f) ↪ Fin n => e (Fin.natAdd r i))
    (joinSample_split (r:=r) (f:=f) σ)
  simpa only [joinSample_free] using h

theorem split_pair_left {n : ℕ} (σ : Fin 6 ↪ Fin n) :
    pairVertices (splitSampleEquiv (r:=2) (f:=4) σ).1
      ((splitSampleEquiv (r:=2) (f:=4) σ).2 0, (splitSampleEquiv (r:=2) (f:=4) σ).2 1) =
    σ ∘ pairLeft := by
  funext i
  fin_cases i <;> simp [pairVertices, pairLeft, Function.comp_def, split_root (r:=2) (f:=4) σ, split_free (r:=2) (f:=4) σ]

theorem split_pair_right {n : ℕ} (σ : Fin 6 ↪ Fin n) :
    pairVertices (splitSampleEquiv (r:=2) (f:=4) σ).1
      ((splitSampleEquiv (r:=2) (f:=4) σ).2 2, (splitSampleEquiv (r:=2) (f:=4) σ).2 3) =
    σ ∘ pairRight := by
  funext i
  fin_cases i <;> simp [pairVertices, pairRight, Function.comp_def, split_root (r:=2) (f:=4) σ, split_free (r:=2) (f:=4) σ]

theorem split_four_left {n : ℕ} (σ : Fin 6 ↪ Fin n) :
    fourVertices (splitSampleEquiv (r:=4) (f:=2) σ).1
      ((splitSampleEquiv (r:=4) (f:=2) σ).2 0) = σ ∘ fourLeft := by
  funext i
  fin_cases i <;> simp [fourVertices, fourLeft, Function.comp_def, split_root (r:=4) (f:=2) σ, split_free (r:=4) (f:=2) σ]

theorem split_four_right {n : ℕ} (σ : Fin 6 ↪ Fin n) :
    fourVertices (splitSampleEquiv (r:=4) (f:=2) σ).1
      ((splitSampleEquiv (r:=4) (f:=2) σ).2 1) = σ ∘ fourRight := by
  funext i
  fin_cases i <;> simp [fourVertices, fourRight, Function.comp_def, split_root (r:=4) (f:=2) σ, split_free (r:=4) (f:=2) σ]

theorem pairIndicator_sample {n : ℕ} (typ : ℕ) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) :
    pairIndicator typ S (splitSampleEquiv (r:=2) (f:=4) σ).1 =
      if pairType (sampleStructure σ H S) = typ then 1 else 0 := by
  simp [pairIndicator, pairType, root2, twoRoot, sampleStructure, graphColour, split_root (r:=2) (f:=4) σ]

theorem fourIndicator_sample {n : ℕ} (typ : ℕ) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) :
    fourIndicator typ H S (splitSampleEquiv (r:=4) (f:=2) σ).1 =
      if fourType (sampleStructure σ H S) = typ then 1 else 0 := by
  have h : ((splitSampleEquiv (r:=4) (f:=2) σ).1 : Fin 4 → Fin n) = σ ∘ fourRoot := by
    funext i
    fin_cases i <;> simp [fourRoot, Function.comp_def, split_root (r:=4) (f:=2) σ]
  simp only [fourIndicator, fourType, raw4_sample, h]

theorem pairKey_swap {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (root : Fin 2 ↪ Fin n) (p : Outside root × Outside root) :
    pairKey H S root (p.2,p.1) = pairKey H S root p := by
  have h : pairVertices root (p.2,p.1) = pairVertices root p ∘ swap4 := by
    funext i
    fin_cases i <;> rfl
  simp only [pairKey, h, canonical4_pair_swap]

#print axioms pairLeft_injective
#print axioms pairRight_injective
#print axioms fourRoot_injective
#print axioms fourLeft_injective
#print axioms fourRight_injective
#print axioms twoRoot_injective
#print axioms pairIndicator_zero_one
#print axioms fourIndicator_zero_one
#print axioms raw4_sample
#print axioms raw5_sample
#print axioms split_root
#print axioms split_free
#print axioms split_pair_left
#print axioms split_pair_right
#print axioms split_four_left
#print axioms split_four_right
#print axioms pairIndicator_sample
#print axioms fourIndicator_sample
#print axioms pairKey_swap
end TightCycleC5.Bridge.P33Flag
