import PermutationEnumerationRank

/-! Exact enumeration and averaging for the accepted kernel permutation table.
No row arithmetic or optimized row-table semantics are asserted here. -/
namespace TightCycleC5.Bridge.Cover.PermutationEnumeration

open Finset

/-- The checked rank left inverse separates the actual table entries. -/
theorem kernelPermutation_injective : Function.Injective kernelPermutation := by
  intro i j hij
  apply Fin.ext
  have h := congrArg lehmerRank hij
  simpa only [rank_kernelPermutation] using h

/-- Equal finite cardinalities turn the checked injection into a bijection. -/
theorem kernelPermutation_bijective : Function.Bijective kernelPermutation := by
  have hc : Fintype.card (Fin 720) = Fintype.card (Equiv.Perm (Fin 6)) := by
    rw [Fintype.card_fin, six_permutation_count]
  exact (Fintype.bijective_iff_injective_and_card kernelPermutation).2 ⟨kernelPermutation_injective, hc⟩

/-- This equivalence's forward function is the literal accepted table. -/
noncomputable def enumerationEquiv : Fin 720 ≃ Equiv.Perm (Fin 6) :=
  Equiv.ofBijective kernelPermutation kernelPermutation_bijective

@[simp] theorem enumerationEquiv_apply (j : Fin 720) :
    enumerationEquiv j = kernelPermutation j := rfl

/-- Reindex exact finite sums in any additive commutative monoid, including ℚ. -/
theorem sum_kernelPermutation {α : Type*} [AddCommMonoid α]
    (f : Equiv.Perm (Fin 6) → α) :
    (∑ j : Fin 720, f (kernelPermutation j)) = ∑ p : Equiv.Perm (Fin 6), f p := by
  change (∑ j : Fin 720, f (enumerationEquiv j)) = _
  rw [Equiv.sum_comp]

/-- Reindex any real-valued permutation statistic, without an enumeration premise. -/
theorem uniformMean_kernelPermutation (f : Equiv.Perm (Fin 6) → ℝ) :
    uniformMean (fun j : Fin 720 => f (kernelPermutation j)) = uniformMean f := by
  exact uniformMean_equiv_between enumerationEquiv f

/-- The explicit denominator needed by literal finite certificate arithmetic. -/
theorem uniformMean_eq_sum_div_720 (f : Equiv.Perm (Fin 6) → ℝ) :
    uniformMean f = (∑ j : Fin 720, f (kernelPermutation j)) / 720 := by
  rw [← uniformMean_kernelPermutation f]
  simp only [uniformMean, Fintype.card_fin, Nat.cast_ofNat]

/-- Rational literal arithmetic may be checked before casting its result to ℝ. -/
theorem uniformMean_rat_eq_sum_div_720 (f : Equiv.Perm (Fin 6) → ℚ) :
    uniformMean (fun p => (f p : ℝ)) =
      (((∑ j : Fin 720, f (kernelPermutation j)) / 720 : ℚ) : ℝ) := by
  rw [uniformMean_eq_sum_div_720]
  push_cast
  rfl

/-- In particular, averaging any literal row over these entries is the full
permutation average, for every labelled structure (without graph hypotheses). -/
theorem uniformMean_row (row : LabelledStructure 6 → ℝ) (G : LabelledStructure 6) :
    uniformMean (fun j : Fin 720 => row (kernelPermutation j • G)) =
      uniformMean (fun p : Equiv.Perm (Fin 6) => row (p • G)) :=
  uniformMean_kernelPermutation (fun p => row (p • G))

theorem uniformMean_row_eq_sum_div_720
    (row : LabelledStructure 6 → ℝ) (G : LabelledStructure 6) :
    uniformMean (fun p : Equiv.Perm (Fin 6) => row (p • G)) =
      (∑ j : Fin 720, row (kernelPermutation j • G)) / 720 :=
  uniformMean_eq_sum_div_720 (fun p => row (p • G))

/-- Corruption control: replacing entry one by entry zero violates precisely
injectivity, even though each entry still individually is a permutation. -/
def duplicatedEnumeration (j : Fin 720) : Equiv.Perm (Fin 6) :=
  if j = 1 then kernelPermutation 0 else kernelPermutation j

theorem duplicatedEnumeration_not_injective :
    ¬ Function.Injective duplicatedEnumeration := by
  intro hinj
  have he : duplicatedEnumeration 0 = duplicatedEnumeration 1 := by
    simp [duplicatedEnumeration]
  have h := hinj he
  have hn : (0 : Fin 720) ≠ 1 := by decide
  exact hn h

/-- The same duplicated table also fails the checked rank condition. -/
theorem duplicatedEnumeration_fails_rank :
    ¬ ∀ j : Fin 720, lehmerRank (duplicatedEnumeration j) = j.val := by
  intro h
  have h1 : lehmerRank (kernelPermutation 0) = 1 := by
    simpa [duplicatedEnumeration] using h (1 : Fin 720)
  have h0 := rank_kernelPermutation 0
  rw [h0] at h1
  norm_num at h1

#print axioms kernelPermutation_injective
#print axioms kernelPermutation_bijective
#print axioms enumerationEquiv_apply
#print axioms sum_kernelPermutation
#print axioms uniformMean_rat_eq_sum_div_720
#print axioms uniformMean_kernelPermutation
#print axioms uniformMean_eq_sum_div_720
#print axioms uniformMean_row
#print axioms uniformMean_row_eq_sum_div_720
#print axioms duplicatedEnumeration_not_injective
#print axioms duplicatedEnumeration_fails_rank

end TightCycleC5.Bridge.Cover.PermutationEnumeration
