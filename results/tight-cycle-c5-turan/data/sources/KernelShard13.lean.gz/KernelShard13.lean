import KernelShard13Blocks0
import KernelShard13Blocks1
import KernelShard13Blocks2
import KernelShard13Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard13 : kernelShardCheck 13 kernelWitness13 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (13 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness13 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_13_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard13
end TightCycleC5.Bridge.Cover
