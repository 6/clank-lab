import P33ArithmeticUnit
import P33ArithmeticEncoding

/-! Exact averaging and dense indexing of the quoted evaluator. This is
still PARTIAL: correspondence with the separately owned concrete source
rows and normalized matrices is not asserted by this module. -/
namespace TightCycleC5.Bridge.P33Arithmetic
open Finset

/-- The original full coefficient indexing, with signed regularity. -/
def denseNuisanceAt (K : Class) (p : Fin 6 → Fin 6) : Int :=
  let f := featuresAt localFlags globalFlags blocks K p
  psdAt blocks K p +
    (∑ i : Fin 12847, denseInequalities[i.val]! * inequalityRow f i.val) +
    (∑ i : Fin 120, denseRegularity[i.val]! * regularityRow f i.val)

/-- Sparse evaluation preserves all original coefficient positions. -/
theorem nuisanceInteger_eq_dense (K : Class) (j : Fin 720) :
    nuisanceInteger K j = denseNuisanceAt K (Cover.kernelPermutation j) := by
  simp only [nuisanceInteger, denseNuisanceAt, sparseValue_eq_full,
    sparse_inequalities_match, sparse_regularity_match, psdOrder, features,
    order_eq_kernelPermutation]

/-- Full ordered trace of one block at valid selected indices. -/
theorem block_full_trace (b : Block) (a z : Nat)
    (ha : a < b.flags.size) (hz : z < b.flags.size) :
    (∑ i : Fin b.flags.size, ∑ j : Fin b.flags.size,
      blockMatrix b i j * (if i.val = a then 1 else 0) *
        (if j.val = z then 1 else 0)) = blockEntry b a z := by
  simpa only [Fin.ext_iff, blockMatrix] using
    (full_trace_one_hot (blockMatrix b) (⟨a,ha⟩ : Fin b.flags.size) ⟨z,hz⟩)

/-- A literal dense rational mean over the genuine 720 kernel permutations.
The target has coefficient one and the nuisance scale is divided once. -/
def quotedDenseMean (K : Class) : ℚ :=
  (∑ j : Fin 720, ((targetNumerator K : ℚ) / 20 +
    (denseNuisanceAt K (Cover.kernelPermutation j) : ℚ) / 1000000000 /
      (sosScale : ℚ))) / 720

/-- Exact rational clearing, without a Python or C++ success premise. -/
theorem quotedDenseMean_eq (K : Class) (hs : sosScale ≠ 0) :
    quotedDenseMean K = rationalClassValue K := by
  have hs' : (sosScale : ℚ) ≠ 0 := Int.cast_ne_zero.mpr hs
  simp only [quotedDenseMean, ← nuisanceInteger_eq_dense, rationalClassValue,
    Finset.sum_add_distrib, Finset.sum_const, Finset.card_univ,
    Fintype.card_fin, nsmul_eq_mul]
  simp_rw [div_div]
  rw [← Finset.sum_div]
  field_simp
  <;> ring

/-- A checked class therefore has the dense actual-permutation mean bound.
Concrete source-row correspondence remains a separate obligation. -/
theorem classCheck_quotedDenseMean_nonpos (K : Class)
    (h : classCheck K = true) : quotedDenseMean K ≤ 0 := by
  rw [quotedDenseMean_eq K (ne_of_gt exact_scales_positive.1)]
  exact classCheck_rational_nonpos K exact_scales_positive.1 h

/-- Faithful real conversion retains exactly the same finite mean. -/
theorem classCheck_real_denseMean_nonpos (K : Class)
    (h : classCheck K = true) :
    (∑ j : Fin 720, ((targetNumerator K : ℝ) / 20 +
      (denseNuisanceAt K (Cover.kernelPermutation j) : ℝ) / 1000000000 /
        (sosScale : ℝ))) / 720 ≤ 0 := by
  have hc := (rat_real_nonpos_iff (quotedDenseMean K)).2
    (classCheck_quotedDenseMean_nonpos K h)
  dsimp only [quotedDenseMean] at hc
  push_cast at hc
  exact hc

#print axioms nuisanceInteger_eq_dense
#print axioms block_full_trace
#print axioms quotedDenseMean_eq
#print axioms classCheck_quotedDenseMean_nonpos
#print axioms classCheck_real_denseMean_nonpos
end TightCycleC5.Bridge.P33Arithmetic
