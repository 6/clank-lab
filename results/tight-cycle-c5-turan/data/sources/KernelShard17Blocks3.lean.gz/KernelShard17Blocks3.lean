import KernelRowIndex
import KernelWitness17

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_17_96 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 96 * 256 + i.val))
      kernelWitness17Row96[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_96

theorem kernelBlock_17_97 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 97 * 256 + i.val))
      kernelWitness17Row97[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_97

theorem kernelBlock_17_98 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 98 * 256 + i.val))
      kernelWitness17Row98[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_98

theorem kernelBlock_17_99 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 99 * 256 + i.val))
      kernelWitness17Row99[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_99

theorem kernelBlock_17_100 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 100 * 256 + i.val))
      kernelWitness17Row100[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_100

theorem kernelBlock_17_101 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 101 * 256 + i.val))
      kernelWitness17Row101[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_101

theorem kernelBlock_17_102 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 102 * 256 + i.val))
      kernelWitness17Row102[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_102

theorem kernelBlock_17_103 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 103 * 256 + i.val))
      kernelWitness17Row103[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_103

theorem kernelBlock_17_104 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 104 * 256 + i.val))
      kernelWitness17Row104[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_104

theorem kernelBlock_17_105 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 105 * 256 + i.val))
      kernelWitness17Row105[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_105

theorem kernelBlock_17_106 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 106 * 256 + i.val))
      kernelWitness17Row106[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_106

theorem kernelBlock_17_107 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 107 * 256 + i.val))
      kernelWitness17Row107[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_107

theorem kernelBlock_17_108 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 108 * 256 + i.val))
      kernelWitness17Row108[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_108

theorem kernelBlock_17_109 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 109 * 256 + i.val))
      kernelWitness17Row109[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_109

theorem kernelBlock_17_110 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 110 * 256 + i.val))
      kernelWitness17Row110[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_110

theorem kernelBlock_17_111 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 111 * 256 + i.val))
      kernelWitness17Row111[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_111

theorem kernelBlock_17_112 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 112 * 256 + i.val))
      kernelWitness17Row112[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_112

theorem kernelBlock_17_113 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 113 * 256 + i.val))
      kernelWitness17Row113[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_113

theorem kernelBlock_17_114 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 114 * 256 + i.val))
      kernelWitness17Row114[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_114

theorem kernelBlock_17_115 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 115 * 256 + i.val))
      kernelWitness17Row115[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_115

theorem kernelBlock_17_116 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 116 * 256 + i.val))
      kernelWitness17Row116[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_116

theorem kernelBlock_17_117 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 117 * 256 + i.val))
      kernelWitness17Row117[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_117

theorem kernelBlock_17_118 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 118 * 256 + i.val))
      kernelWitness17Row118[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_118

theorem kernelBlock_17_119 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 119 * 256 + i.val))
      kernelWitness17Row119[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_119

theorem kernelBlock_17_120 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 120 * 256 + i.val))
      kernelWitness17Row120[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_120

theorem kernelBlock_17_121 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 121 * 256 + i.val))
      kernelWitness17Row121[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_121

theorem kernelBlock_17_122 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 122 * 256 + i.val))
      kernelWitness17Row122[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_122

theorem kernelBlock_17_123 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 123 * 256 + i.val))
      kernelWitness17Row123[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_123

theorem kernelBlock_17_124 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 124 * 256 + i.val))
      kernelWitness17Row124[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_124

theorem kernelBlock_17_125 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 125 * 256 + i.val))
      kernelWitness17Row125[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_125

theorem kernelBlock_17_126 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 126 * 256 + i.val))
      kernelWitness17Row126[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_126

theorem kernelBlock_17_127 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 127 * 256 + i.val))
      kernelWitness17Row127[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_127

end TightCycleC5.Bridge.Cover
