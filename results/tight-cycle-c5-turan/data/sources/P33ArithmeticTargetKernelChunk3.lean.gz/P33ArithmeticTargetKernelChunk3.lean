-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk12 :
    ∀ i : Fin (min 128 (40547 - 128 * 12)),
      targetCountsMatch (classAt (targetKernelClass ⟨12, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk12

theorem target_counts_kernel_chunk13 :
    ∀ i : Fin (min 128 (40547 - 128 * 13)),
      targetCountsMatch (classAt (targetKernelClass ⟨13, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk13

theorem target_counts_kernel_chunk14 :
    ∀ i : Fin (min 128 (40547 - 128 * 14)),
      targetCountsMatch (classAt (targetKernelClass ⟨14, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk14

theorem target_counts_kernel_chunk15 :
    ∀ i : Fin (min 128 (40547 - 128 * 15)),
      targetCountsMatch (classAt (targetKernelClass ⟨15, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk15


end TightCycleC5.Bridge.P33Arithmetic
