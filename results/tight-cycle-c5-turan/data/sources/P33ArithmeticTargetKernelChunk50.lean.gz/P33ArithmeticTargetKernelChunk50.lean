-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk200 :
    ∀ i : Fin (min 128 (40547 - 128 * 200)),
      targetCountsMatch (classAt (targetKernelClass ⟨200, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk200

theorem target_counts_kernel_chunk201 :
    ∀ i : Fin (min 128 (40547 - 128 * 201)),
      targetCountsMatch (classAt (targetKernelClass ⟨201, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk201

theorem target_counts_kernel_chunk202 :
    ∀ i : Fin (min 128 (40547 - 128 * 202)),
      targetCountsMatch (classAt (targetKernelClass ⟨202, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk202

theorem target_counts_kernel_chunk203 :
    ∀ i : Fin (min 128 (40547 - 128 * 203)),
      targetCountsMatch (classAt (targetKernelClass ⟨203, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk203


end TightCycleC5.Bridge.P33Arithmetic
