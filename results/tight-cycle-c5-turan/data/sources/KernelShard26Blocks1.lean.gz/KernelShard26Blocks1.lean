import KernelRowIndex
import KernelWitness26

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_26_32 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 32 * 256 + i.val))
      kernelWitness26Row32[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_32

theorem kernelBlock_26_33 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 33 * 256 + i.val))
      kernelWitness26Row33[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_33

theorem kernelBlock_26_34 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 34 * 256 + i.val))
      kernelWitness26Row34[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_34

theorem kernelBlock_26_35 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 35 * 256 + i.val))
      kernelWitness26Row35[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_35

theorem kernelBlock_26_36 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 36 * 256 + i.val))
      kernelWitness26Row36[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_36

theorem kernelBlock_26_37 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 37 * 256 + i.val))
      kernelWitness26Row37[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_37

theorem kernelBlock_26_38 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 38 * 256 + i.val))
      kernelWitness26Row38[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_38

theorem kernelBlock_26_39 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 39 * 256 + i.val))
      kernelWitness26Row39[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_39

theorem kernelBlock_26_40 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 40 * 256 + i.val))
      kernelWitness26Row40[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_40

theorem kernelBlock_26_41 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 41 * 256 + i.val))
      kernelWitness26Row41[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_41

theorem kernelBlock_26_42 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 42 * 256 + i.val))
      kernelWitness26Row42[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_42

theorem kernelBlock_26_43 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 43 * 256 + i.val))
      kernelWitness26Row43[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_43

theorem kernelBlock_26_44 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 44 * 256 + i.val))
      kernelWitness26Row44[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_44

theorem kernelBlock_26_45 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 45 * 256 + i.val))
      kernelWitness26Row45[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_45

theorem kernelBlock_26_46 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 46 * 256 + i.val))
      kernelWitness26Row46[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_46

theorem kernelBlock_26_47 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 47 * 256 + i.val))
      kernelWitness26Row47[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_47

theorem kernelBlock_26_48 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 48 * 256 + i.val))
      kernelWitness26Row48[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_48

theorem kernelBlock_26_49 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 49 * 256 + i.val))
      kernelWitness26Row49[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_49

theorem kernelBlock_26_50 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 50 * 256 + i.val))
      kernelWitness26Row50[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_50

theorem kernelBlock_26_51 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 51 * 256 + i.val))
      kernelWitness26Row51[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_51

theorem kernelBlock_26_52 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 52 * 256 + i.val))
      kernelWitness26Row52[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_52

theorem kernelBlock_26_53 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 53 * 256 + i.val))
      kernelWitness26Row53[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_53

theorem kernelBlock_26_54 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 54 * 256 + i.val))
      kernelWitness26Row54[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_54

theorem kernelBlock_26_55 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 55 * 256 + i.val))
      kernelWitness26Row55[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_55

theorem kernelBlock_26_56 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 56 * 256 + i.val))
      kernelWitness26Row56[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_56

theorem kernelBlock_26_57 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 57 * 256 + i.val))
      kernelWitness26Row57[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_57

theorem kernelBlock_26_58 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 58 * 256 + i.val))
      kernelWitness26Row58[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_58

theorem kernelBlock_26_59 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 59 * 256 + i.val))
      kernelWitness26Row59[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_59

theorem kernelBlock_26_60 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 60 * 256 + i.val))
      kernelWitness26Row60[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_60

theorem kernelBlock_26_61 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 61 * 256 + i.val))
      kernelWitness26Row61[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_61

theorem kernelBlock_26_62 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 62 * 256 + i.val))
      kernelWitness26Row62[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_62

theorem kernelBlock_26_63 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 63 * 256 + i.val))
      kernelWitness26Row63[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_63

end TightCycleC5.Bridge.Cover
