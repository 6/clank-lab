import KernelRowIndex
import KernelWitness30

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_30_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 64 * 256 + i.val))
      kernelWitness30Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_64

theorem kernelBlock_30_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 65 * 256 + i.val))
      kernelWitness30Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_65

theorem kernelBlock_30_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 66 * 256 + i.val))
      kernelWitness30Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_66

theorem kernelBlock_30_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 67 * 256 + i.val))
      kernelWitness30Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_67

theorem kernelBlock_30_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 68 * 256 + i.val))
      kernelWitness30Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_68

theorem kernelBlock_30_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 69 * 256 + i.val))
      kernelWitness30Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_69

theorem kernelBlock_30_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 70 * 256 + i.val))
      kernelWitness30Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_70

theorem kernelBlock_30_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 71 * 256 + i.val))
      kernelWitness30Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_71

theorem kernelBlock_30_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 72 * 256 + i.val))
      kernelWitness30Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_72

theorem kernelBlock_30_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 73 * 256 + i.val))
      kernelWitness30Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_73

theorem kernelBlock_30_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 74 * 256 + i.val))
      kernelWitness30Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_74

theorem kernelBlock_30_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 75 * 256 + i.val))
      kernelWitness30Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_75

theorem kernelBlock_30_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 76 * 256 + i.val))
      kernelWitness30Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_76

theorem kernelBlock_30_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 77 * 256 + i.val))
      kernelWitness30Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_77

theorem kernelBlock_30_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 78 * 256 + i.val))
      kernelWitness30Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_78

theorem kernelBlock_30_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 79 * 256 + i.val))
      kernelWitness30Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_79

theorem kernelBlock_30_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 80 * 256 + i.val))
      kernelWitness30Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_80

theorem kernelBlock_30_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 81 * 256 + i.val))
      kernelWitness30Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_81

theorem kernelBlock_30_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 82 * 256 + i.val))
      kernelWitness30Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_82

theorem kernelBlock_30_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 83 * 256 + i.val))
      kernelWitness30Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_83

theorem kernelBlock_30_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 84 * 256 + i.val))
      kernelWitness30Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_84

theorem kernelBlock_30_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 85 * 256 + i.val))
      kernelWitness30Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_85

theorem kernelBlock_30_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 86 * 256 + i.val))
      kernelWitness30Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_86

theorem kernelBlock_30_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 87 * 256 + i.val))
      kernelWitness30Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_87

theorem kernelBlock_30_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 88 * 256 + i.val))
      kernelWitness30Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_88

theorem kernelBlock_30_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 89 * 256 + i.val))
      kernelWitness30Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_89

theorem kernelBlock_30_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 90 * 256 + i.val))
      kernelWitness30Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_90

theorem kernelBlock_30_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 91 * 256 + i.val))
      kernelWitness30Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_91

theorem kernelBlock_30_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 92 * 256 + i.val))
      kernelWitness30Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_92

theorem kernelBlock_30_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 93 * 256 + i.val))
      kernelWitness30Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_93

theorem kernelBlock_30_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 94 * 256 + i.val))
      kernelWitness30Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_94

theorem kernelBlock_30_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (30 * 32768 + 95 * 256 + i.val))
      kernelWitness30Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_30_95

end TightCycleC5.Bridge.Cover
