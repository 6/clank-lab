-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk192 :
    ∀ i : Fin (min 128 (40547 - 128 * 192)),
      targetCountsMatch (classAt (targetKernelClass ⟨192, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk192

theorem target_counts_kernel_chunk193 :
    ∀ i : Fin (min 128 (40547 - 128 * 193)),
      targetCountsMatch (classAt (targetKernelClass ⟨193, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk193

theorem target_counts_kernel_chunk194 :
    ∀ i : Fin (min 128 (40547 - 128 * 194)),
      targetCountsMatch (classAt (targetKernelClass ⟨194, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk194

theorem target_counts_kernel_chunk195 :
    ∀ i : Fin (min 128 (40547 - 128 * 195)),
      targetCountsMatch (classAt (targetKernelClass ⟨195, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk195


end TightCycleC5.Bridge.P33Arithmetic
