import ColoredCoverSemantics

namespace TightCycleC5.Bridge.ColoredCover
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def coloredWitness128 : Array Nat := #[3885840, 3886560, 3887280, 3888000, 3887304, 3888024, 3888720, 3889440, 3890160, 3890880, 3891600, 3892320, 3891624, 3892344, 3893040, 3893760, 3894480, 3895200, 3895920, 3896640, 3895944, 3896664, 3897360, 3898080, 3898800, 3899520, 3900240, 3900960, 3900264, 3900984, 3901680, 3902400, 3894481, 3895201, 3895921, 3896641, 3895945, 3896665, 3897361, 3898081, 3898801, 3899521, 3900241, 3900961, 3900265, 3900985, 3901681, 3902401, 3903120, 3903840, 3904560, 3905280, 3904584, 3905304, 3906000, 3906720, 3907440, 3908160, 3908880, 3909600, 3908904, 3909624, 3910320, 3911040]

theorem colored_row128 : ∀ c : Fin 64,
    readRow witnessRows (128 * 64 + c.val) = coloredWitness128[c.val]! := by
  decide +kernel
#print axioms colored_row128

theorem colored_check128 : ∀ c : Fin 64,
    checkColored 128 (BitVec.ofNat 6 c.val) (coloredWitness128[c.val]!) = true := by
  decide +kernel
#print axioms colored_check128

theorem colored_family128 : ∀ c : Fin 64,
    checkColored 128 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (128 * 64 + c.val)) = true := by
  intro c
  rw [colored_row128]
  exact colored_check128 c
#print axioms colored_family128

def coloredWitness129 : Array Nat := #[3911760, 3912480, 3913200, 3913920, 3913224, 3913944, 3914640, 3915360, 3916080, 3916800, 3917520, 3918240, 3917544, 3918264, 3918960, 3919680, 3920400, 3921120, 3921840, 3922560, 3921864, 3922584, 3923280, 3924000, 3924720, 3925440, 3926160, 3926880, 3926184, 3926904, 3927600, 3928320, 3920401, 3921121, 3921841, 3922561, 3921865, 3922585, 3923281, 3924001, 3924721, 3925441, 3926161, 3926881, 3926185, 3926905, 3927601, 3928321, 3929040, 3929760, 3930480, 3931200, 3930504, 3931224, 3931920, 3932640, 3933360, 3934080, 3934800, 3935520, 3934824, 3935544, 3936240, 3936960]

theorem colored_row129 : ∀ c : Fin 64,
    readRow witnessRows (129 * 64 + c.val) = coloredWitness129[c.val]! := by
  decide +kernel
#print axioms colored_row129

theorem colored_check129 : ∀ c : Fin 64,
    checkColored 129 (BitVec.ofNat 6 c.val) (coloredWitness129[c.val]!) = true := by
  decide +kernel
#print axioms colored_check129

theorem colored_family129 : ∀ c : Fin 64,
    checkColored 129 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (129 * 64 + c.val)) = true := by
  intro c
  rw [colored_row129]
  exact colored_check129 c
#print axioms colored_family129

def coloredWitness130 : Array Nat := #[3937680, 3938400, 3939120, 3939840, 3940560, 3941280, 3942000, 3942720, 3943440, 3944160, 3944880, 3945600, 3946320, 3947040, 3947760, 3948480, 3949200, 3949920, 3950640, 3951360, 3952080, 3952800, 3953520, 3954240, 3954960, 3955680, 3956400, 3957120, 3957840, 3958560, 3959280, 3960000, 3949201, 3949921, 3950641, 3951361, 3952081, 3952801, 3953521, 3954241, 3954961, 3955681, 3956401, 3957121, 3957841, 3958561, 3959281, 3960001, 3960720, 3961440, 3962160, 3962880, 3963600, 3964320, 3965040, 3965760, 3966480, 3967200, 3967920, 3968640, 3969360, 3970080, 3970800, 3971520]

theorem colored_row130 : ∀ c : Fin 64,
    readRow witnessRows (130 * 64 + c.val) = coloredWitness130[c.val]! := by
  decide +kernel
#print axioms colored_row130

theorem colored_check130 : ∀ c : Fin 64,
    checkColored 130 (BitVec.ofNat 6 c.val) (coloredWitness130[c.val]!) = true := by
  decide +kernel
#print axioms colored_check130

theorem colored_family130 : ∀ c : Fin 64,
    checkColored 130 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (130 * 64 + c.val)) = true := by
  intro c
  rw [colored_row130]
  exact colored_check130 c
#print axioms colored_family130

def coloredWitness131 : Array Nat := #[3972240, 3972960, 3973680, 3974400, 3975120, 3975840, 3976560, 3977280, 3978000, 3978720, 3979440, 3980160, 3980880, 3981600, 3982320, 3983040, 3983760, 3984480, 3985200, 3985920, 3986640, 3987360, 3988080, 3988800, 3989520, 3990240, 3990960, 3991680, 3992400, 3993120, 3993840, 3994560, 3983761, 3984481, 3985201, 3985921, 3986641, 3987361, 3988081, 3988801, 3989521, 3990241, 3990961, 3991681, 3992401, 3993121, 3993841, 3994561, 3995280, 3996000, 3996720, 3997440, 3998160, 3998880, 3999600, 4000320, 4001040, 4001760, 4002480, 4003200, 4003920, 4004640, 4005360, 4006080]

theorem colored_row131 : ∀ c : Fin 64,
    readRow witnessRows (131 * 64 + c.val) = coloredWitness131[c.val]! := by
  decide +kernel
#print axioms colored_row131

theorem colored_check131 : ∀ c : Fin 64,
    checkColored 131 (BitVec.ofNat 6 c.val) (coloredWitness131[c.val]!) = true := by
  decide +kernel
#print axioms colored_check131

theorem colored_family131 : ∀ c : Fin 64,
    checkColored 131 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (131 * 64 + c.val)) = true := by
  intro c
  rw [colored_row131]
  exact colored_check131 c
#print axioms colored_family131

def coloredWitness132 : Array Nat := #[4006800, 4007520, 4008240, 4008960, 4008264, 4008984, 4009680, 4010400, 4011120, 4011840, 4012560, 4013280, 4012584, 4013304, 4014000, 4014720, 4015440, 4016160, 4016880, 4017600, 4016904, 4017624, 4018320, 4019040, 4019760, 4020480, 4021200, 4021920, 4021224, 4021944, 4022640, 4023360, 4015441, 4016161, 4016881, 4017601, 4016905, 4017625, 4018321, 4019041, 4019761, 4020481, 4021201, 4021921, 4021225, 4021945, 4022641, 4023361, 4024080, 4024800, 4025520, 4026240, 4025544, 4026264, 4026960, 4027680, 4028400, 4029120, 4029840, 4030560, 4029864, 4030584, 4031280, 4032000]

theorem colored_row132 : ∀ c : Fin 64,
    readRow witnessRows (132 * 64 + c.val) = coloredWitness132[c.val]! := by
  decide +kernel
#print axioms colored_row132

theorem colored_check132 : ∀ c : Fin 64,
    checkColored 132 (BitVec.ofNat 6 c.val) (coloredWitness132[c.val]!) = true := by
  decide +kernel
#print axioms colored_check132

theorem colored_family132 : ∀ c : Fin 64,
    checkColored 132 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (132 * 64 + c.val)) = true := by
  intro c
  rw [colored_row132]
  exact colored_check132 c
#print axioms colored_family132

def coloredWitness133 : Array Nat := #[4032720, 4033440, 4034160, 4034880, 4034184, 4034904, 4035600, 4036320, 4037040, 4037760, 4038480, 4039200, 4038504, 4039224, 4039920, 4040640, 4041360, 4042080, 4042800, 4043520, 4042824, 4043544, 4044240, 4044960, 4045680, 4046400, 4047120, 4047840, 4047144, 4047864, 4048560, 4049280, 4041361, 4042081, 4042801, 4043521, 4042825, 4043545, 4044241, 4044961, 4045681, 4046401, 4047121, 4047841, 4047145, 4047865, 4048561, 4049281, 4050000, 4050720, 4051440, 4052160, 4051464, 4052184, 4052880, 4053600, 4054320, 4055040, 4055760, 4056480, 4055784, 4056504, 4057200, 4057920]

theorem colored_row133 : ∀ c : Fin 64,
    readRow witnessRows (133 * 64 + c.val) = coloredWitness133[c.val]! := by
  decide +kernel
#print axioms colored_row133

theorem colored_check133 : ∀ c : Fin 64,
    checkColored 133 (BitVec.ofNat 6 c.val) (coloredWitness133[c.val]!) = true := by
  decide +kernel
#print axioms colored_check133

theorem colored_family133 : ∀ c : Fin 64,
    checkColored 133 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (133 * 64 + c.val)) = true := by
  intro c
  rw [colored_row133]
  exact colored_check133 c
#print axioms colored_family133

def coloredWitness134 : Array Nat := #[4058640, 4059360, 4060080, 4060800, 4060104, 4060824, 4061520, 4062240, 4060128, 4060848, 4061526, 4062246, 4061550, 4062270, 4062960, 4063680, 4059872, 4064400, 4061312, 4065120, 4061336, 4065144, 4062752, 4065840, 4061360, 4065168, 4062758, 4065846, 4062782, 4065870, 4064192, 4066560, 4067280, 4068000, 4068720, 4069440, 4068744, 4069464, 4070160, 4070880, 4068768, 4069488, 4070166, 4070886, 4070190, 4070910, 4071600, 4072320, 4068512, 4073040, 4069952, 4073760, 4069976, 4073784, 4071392, 4074480, 4070000, 4073808, 4071398, 4074486, 4071422, 4074510, 4072832, 4075200]

theorem colored_row134 : ∀ c : Fin 64,
    readRow witnessRows (134 * 64 + c.val) = coloredWitness134[c.val]! := by
  decide +kernel
#print axioms colored_row134

theorem colored_check134 : ∀ c : Fin 64,
    checkColored 134 (BitVec.ofNat 6 c.val) (coloredWitness134[c.val]!) = true := by
  decide +kernel
#print axioms colored_check134

theorem colored_family134 : ∀ c : Fin 64,
    checkColored 134 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (134 * 64 + c.val)) = true := by
  intro c
  rw [colored_row134]
  exact colored_check134 c
#print axioms colored_family134

def coloredWitness135 : Array Nat := #[4075920, 4076640, 4077360, 4078080, 4077384, 4078104, 4078800, 4079520, 4080240, 4080960, 4081680, 4082400, 4081704, 4082424, 4083120, 4083840, 4084560, 4085280, 4086000, 4086720, 4086024, 4086744, 4087440, 4088160, 4088880, 4089600, 4090320, 4091040, 4090344, 4091064, 4091760, 4092480, 4093200, 4093920, 4094640, 4095360, 4094664, 4095384, 4096080, 4096800, 4097520, 4098240, 4098960, 4099680, 4098984, 4099704, 4100400, 4101120, 4101840, 4102560, 4103280, 4104000, 4103304, 4104024, 4104720, 4105440, 4106160, 4106880, 4107600, 4108320, 4107624, 4108344, 4109040, 4109760]

theorem colored_row135 : ∀ c : Fin 64,
    readRow witnessRows (135 * 64 + c.val) = coloredWitness135[c.val]! := by
  decide +kernel
#print axioms colored_row135

theorem colored_check135 : ∀ c : Fin 64,
    checkColored 135 (BitVec.ofNat 6 c.val) (coloredWitness135[c.val]!) = true := by
  decide +kernel
#print axioms colored_check135

theorem colored_family135 : ∀ c : Fin 64,
    checkColored 135 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (135 * 64 + c.val)) = true := by
  intro c
  rw [colored_row135]
  exact colored_check135 c
#print axioms colored_family135

def coloredWitness136 : Array Nat := #[4110480, 4111200, 4111920, 4112640, 4113360, 4114080, 4114800, 4115520, 4113366, 4114086, 4114806, 4115526, 4116240, 4116960, 4117680, 4118400, 4119120, 4119840, 4120560, 4121280, 4122000, 4122720, 4123440, 4124160, 4122006, 4122726, 4123446, 4124166, 4124880, 4125600, 4126320, 4127040, 4127760, 4128480, 4129200, 4129920, 4130640, 4131360, 4132080, 4132800, 4130646, 4131366, 4132086, 4132806, 4133520, 4134240, 4134960, 4135680, 4136400, 4137120, 4137840, 4138560, 4139280, 4140000, 4140720, 4141440, 4139286, 4140006, 4140726, 4141446, 4142160, 4142880, 4143600, 4144320]

theorem colored_row136 : ∀ c : Fin 64,
    readRow witnessRows (136 * 64 + c.val) = coloredWitness136[c.val]! := by
  decide +kernel
#print axioms colored_row136

theorem colored_check136 : ∀ c : Fin 64,
    checkColored 136 (BitVec.ofNat 6 c.val) (coloredWitness136[c.val]!) = true := by
  decide +kernel
#print axioms colored_check136

theorem colored_family136 : ∀ c : Fin 64,
    checkColored 136 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (136 * 64 + c.val)) = true := by
  intro c
  rw [colored_row136]
  exact colored_check136 c
#print axioms colored_family136

def coloredWitness137 : Array Nat := #[4145040, 4145760, 4146480, 4147200, 4147920, 4148640, 4149360, 4150080, 4147926, 4148646, 4149366, 4150086, 4150800, 4151520, 4152240, 4152960, 4153680, 4154400, 4155120, 4155840, 4156560, 4157280, 4158000, 4158720, 4156566, 4157286, 4158006, 4158726, 4159440, 4160160, 4160880, 4161600, 4162320, 4163040, 4163760, 4164480, 4165200, 4165920, 4166640, 4167360, 4165206, 4165926, 4166646, 4167366, 4168080, 4168800, 4169520, 4170240, 4170960, 4171680, 4172400, 4173120, 4173840, 4174560, 4175280, 4176000, 4173846, 4174566, 4175286, 4176006, 4176720, 4177440, 4178160, 4178880]

theorem colored_row137 : ∀ c : Fin 64,
    readRow witnessRows (137 * 64 + c.val) = coloredWitness137[c.val]! := by
  decide +kernel
#print axioms colored_row137

theorem colored_check137 : ∀ c : Fin 64,
    checkColored 137 (BitVec.ofNat 6 c.val) (coloredWitness137[c.val]!) = true := by
  decide +kernel
#print axioms colored_check137

theorem colored_family137 : ∀ c : Fin 64,
    checkColored 137 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (137 * 64 + c.val)) = true := by
  intro c
  rw [colored_row137]
  exact colored_check137 c
#print axioms colored_family137

def coloredWitness138 : Array Nat := #[4179600, 4180320, 4181040, 4181760, 4182480, 4183200, 4183920, 4184640, 4185360, 4186080, 4186800, 4187520, 4188240, 4188960, 4189680, 4190400, 4191120, 4191840, 4192560, 4193280, 4194000, 4194720, 4195440, 4196160, 4196880, 4197600, 4198320, 4199040, 4199760, 4200480, 4201200, 4201920, 4202640, 4203360, 4204080, 4204800, 4205520, 4206240, 4206960, 4207680, 4208400, 4209120, 4209840, 4210560, 4211280, 4212000, 4212720, 4213440, 4214160, 4214880, 4215600, 4216320, 4217040, 4217760, 4218480, 4219200, 4219920, 4220640, 4221360, 4222080, 4222800, 4223520, 4224240, 4224960]

theorem colored_row138 : ∀ c : Fin 64,
    readRow witnessRows (138 * 64 + c.val) = coloredWitness138[c.val]! := by
  decide +kernel
#print axioms colored_row138

theorem colored_check138 : ∀ c : Fin 64,
    checkColored 138 (BitVec.ofNat 6 c.val) (coloredWitness138[c.val]!) = true := by
  decide +kernel
#print axioms colored_check138

theorem colored_family138 : ∀ c : Fin 64,
    checkColored 138 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (138 * 64 + c.val)) = true := by
  intro c
  rw [colored_row138]
  exact colored_check138 c
#print axioms colored_family138

def coloredWitness139 : Array Nat := #[4225680, 4226400, 4227120, 4227840, 4228560, 4229280, 4230000, 4230720, 4228566, 4229286, 4230006, 4230726, 4231440, 4232160, 4232880, 4233600, 4234320, 4235040, 4235760, 4236480, 4237200, 4237920, 4238640, 4239360, 4237206, 4237926, 4238646, 4239366, 4240080, 4240800, 4241520, 4242240, 4242960, 4243680, 4244400, 4245120, 4245840, 4246560, 4247280, 4248000, 4245846, 4246566, 4247286, 4248006, 4248720, 4249440, 4250160, 4250880, 4251600, 4252320, 4253040, 4253760, 4254480, 4255200, 4255920, 4256640, 4254486, 4255206, 4255926, 4256646, 4257360, 4258080, 4258800, 4259520]

theorem colored_row139 : ∀ c : Fin 64,
    readRow witnessRows (139 * 64 + c.val) = coloredWitness139[c.val]! := by
  decide +kernel
#print axioms colored_row139

theorem colored_check139 : ∀ c : Fin 64,
    checkColored 139 (BitVec.ofNat 6 c.val) (coloredWitness139[c.val]!) = true := by
  decide +kernel
#print axioms colored_check139

theorem colored_family139 : ∀ c : Fin 64,
    checkColored 139 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (139 * 64 + c.val)) = true := by
  intro c
  rw [colored_row139]
  exact colored_check139 c
#print axioms colored_family139

def coloredWitness140 : Array Nat := #[4260240, 4260960, 4261680, 4262400, 4263120, 4263840, 4264560, 4265280, 4263126, 4263846, 4264566, 4265286, 4266000, 4266720, 4267440, 4268160, 4268880, 4269600, 4270320, 4271040, 4271760, 4272480, 4273200, 4273920, 4271766, 4272486, 4273206, 4273926, 4274640, 4275360, 4276080, 4276800, 4277520, 4278240, 4278960, 4279680, 4280400, 4281120, 4281840, 4282560, 4280406, 4281126, 4281846, 4282566, 4283280, 4284000, 4284720, 4285440, 4286160, 4286880, 4287600, 4288320, 4289040, 4289760, 4290480, 4291200, 4289046, 4289766, 4290486, 4291206, 4291920, 4292640, 4293360, 4294080]

theorem colored_row140 : ∀ c : Fin 64,
    readRow witnessRows (140 * 64 + c.val) = coloredWitness140[c.val]! := by
  decide +kernel
#print axioms colored_row140

theorem colored_check140 : ∀ c : Fin 64,
    checkColored 140 (BitVec.ofNat 6 c.val) (coloredWitness140[c.val]!) = true := by
  decide +kernel
#print axioms colored_check140

theorem colored_family140 : ∀ c : Fin 64,
    checkColored 140 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (140 * 64 + c.val)) = true := by
  intro c
  rw [colored_row140]
  exact colored_check140 c
#print axioms colored_family140

def coloredWitness141 : Array Nat := #[4294800, 4295520, 4296240, 4296960, 4297680, 4298400, 4299120, 4299840, 4300560, 4301280, 4302000, 4302720, 4303440, 4304160, 4304880, 4305600, 4306320, 4307040, 4307760, 4308480, 4309200, 4309920, 4310640, 4311360, 4312080, 4312800, 4313520, 4314240, 4314960, 4315680, 4316400, 4317120, 4317840, 4318560, 4319280, 4320000, 4320720, 4321440, 4322160, 4322880, 4323600, 4324320, 4325040, 4325760, 4326480, 4327200, 4327920, 4328640, 4329360, 4330080, 4330800, 4331520, 4332240, 4332960, 4333680, 4334400, 4335120, 4335840, 4336560, 4337280, 4338000, 4338720, 4339440, 4340160]

theorem colored_row141 : ∀ c : Fin 64,
    readRow witnessRows (141 * 64 + c.val) = coloredWitness141[c.val]! := by
  decide +kernel
#print axioms colored_row141

theorem colored_check141 : ∀ c : Fin 64,
    checkColored 141 (BitVec.ofNat 6 c.val) (coloredWitness141[c.val]!) = true := by
  decide +kernel
#print axioms colored_check141

theorem colored_family141 : ∀ c : Fin 64,
    checkColored 141 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (141 * 64 + c.val)) = true := by
  intro c
  rw [colored_row141]
  exact colored_check141 c
#print axioms colored_family141

def coloredWitness142 : Array Nat := #[4340880, 4341600, 4342320, 4343040, 4343760, 4344480, 4345200, 4345920, 4343766, 4344486, 4345206, 4345926, 4346640, 4347360, 4348080, 4348800, 4349520, 4350240, 4350960, 4351680, 4352400, 4353120, 4353840, 4354560, 4352406, 4353126, 4353846, 4354566, 4355280, 4356000, 4356720, 4357440, 4358160, 4358880, 4359600, 4360320, 4361040, 4361760, 4362480, 4363200, 4361046, 4361766, 4362486, 4363206, 4363920, 4364640, 4365360, 4366080, 4366800, 4367520, 4368240, 4368960, 4369680, 4370400, 4371120, 4371840, 4369686, 4370406, 4371126, 4371846, 4372560, 4373280, 4374000, 4374720]

theorem colored_row142 : ∀ c : Fin 64,
    readRow witnessRows (142 * 64 + c.val) = coloredWitness142[c.val]! := by
  decide +kernel
#print axioms colored_row142

theorem colored_check142 : ∀ c : Fin 64,
    checkColored 142 (BitVec.ofNat 6 c.val) (coloredWitness142[c.val]!) = true := by
  decide +kernel
#print axioms colored_check142

theorem colored_family142 : ∀ c : Fin 64,
    checkColored 142 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (142 * 64 + c.val)) = true := by
  intro c
  rw [colored_row142]
  exact colored_check142 c
#print axioms colored_family142

def coloredWitness143 : Array Nat := #[4375440, 4376160, 4376880, 4377600, 4376904, 4377624, 4378320, 4379040, 4376928, 4377648, 4378326, 4379046, 4378350, 4379070, 4379760, 4380480, 4381200, 4381920, 4382640, 4383360, 4382664, 4383384, 4384080, 4384800, 4382688, 4383408, 4384086, 4384806, 4384110, 4384830, 4385520, 4386240, 4386960, 4387680, 4388400, 4389120, 4388424, 4389144, 4389840, 4390560, 4388448, 4389168, 4389846, 4390566, 4389870, 4390590, 4391280, 4392000, 4392720, 4393440, 4394160, 4394880, 4394184, 4394904, 4395600, 4396320, 4394208, 4394928, 4395606, 4396326, 4395630, 4396350, 4397040, 4397760]

theorem colored_row143 : ∀ c : Fin 64,
    readRow witnessRows (143 * 64 + c.val) = coloredWitness143[c.val]! := by
  decide +kernel
#print axioms colored_row143

theorem colored_check143 : ∀ c : Fin 64,
    checkColored 143 (BitVec.ofNat 6 c.val) (coloredWitness143[c.val]!) = true := by
  decide +kernel
#print axioms colored_check143

theorem colored_family143 : ∀ c : Fin 64,
    checkColored 143 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (143 * 64 + c.val)) = true := by
  intro c
  rw [colored_row143]
  exact colored_check143 c
#print axioms colored_family143

def coloredWitness144 : Array Nat := #[4398480, 4399200, 4399920, 4400640, 4401360, 4402080, 4402800, 4403520, 4401366, 4402086, 4402806, 4403526, 4404240, 4404960, 4405680, 4406400, 4407120, 4407840, 4408560, 4409280, 4410000, 4410720, 4411440, 4412160, 4410006, 4410726, 4411446, 4412166, 4412880, 4413600, 4414320, 4415040, 4415760, 4416480, 4417200, 4417920, 4418640, 4419360, 4420080, 4420800, 4418646, 4419366, 4420086, 4420806, 4421520, 4422240, 4422960, 4423680, 4424400, 4425120, 4425840, 4426560, 4427280, 4428000, 4428720, 4429440, 4427286, 4428006, 4428726, 4429446, 4430160, 4430880, 4431600, 4432320]

theorem colored_row144 : ∀ c : Fin 64,
    readRow witnessRows (144 * 64 + c.val) = coloredWitness144[c.val]! := by
  decide +kernel
#print axioms colored_row144

theorem colored_check144 : ∀ c : Fin 64,
    checkColored 144 (BitVec.ofNat 6 c.val) (coloredWitness144[c.val]!) = true := by
  decide +kernel
#print axioms colored_check144

theorem colored_family144 : ∀ c : Fin 64,
    checkColored 144 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (144 * 64 + c.val)) = true := by
  intro c
  rw [colored_row144]
  exact colored_check144 c
#print axioms colored_family144

def coloredWitness145 : Array Nat := #[4433040, 4433760, 4434480, 4435200, 4435920, 4436640, 4437360, 4438080, 4438800, 4439520, 4440240, 4440960, 4441680, 4442400, 4443120, 4443840, 4444560, 4445280, 4446000, 4446720, 4447440, 4448160, 4448880, 4449600, 4450320, 4451040, 4451760, 4452480, 4453200, 4453920, 4454640, 4455360, 4456080, 4456800, 4457520, 4458240, 4458960, 4459680, 4460400, 4461120, 4461840, 4462560, 4463280, 4464000, 4464720, 4465440, 4466160, 4466880, 4467600, 4468320, 4469040, 4469760, 4470480, 4471200, 4471920, 4472640, 4473360, 4474080, 4474800, 4475520, 4476240, 4476960, 4477680, 4478400]

theorem colored_row145 : ∀ c : Fin 64,
    readRow witnessRows (145 * 64 + c.val) = coloredWitness145[c.val]! := by
  decide +kernel
#print axioms colored_row145

theorem colored_check145 : ∀ c : Fin 64,
    checkColored 145 (BitVec.ofNat 6 c.val) (coloredWitness145[c.val]!) = true := by
  decide +kernel
#print axioms colored_check145

theorem colored_family145 : ∀ c : Fin 64,
    checkColored 145 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (145 * 64 + c.val)) = true := by
  intro c
  rw [colored_row145]
  exact colored_check145 c
#print axioms colored_family145

def coloredWitness146 : Array Nat := #[4479120, 4479840, 4480560, 4481280, 4482000, 4482720, 4483440, 4484160, 4482006, 4482726, 4483446, 4484166, 4484880, 4485600, 4486320, 4487040, 4487760, 4488480, 4489200, 4489920, 4490640, 4491360, 4492080, 4492800, 4490646, 4491366, 4492086, 4492806, 4493520, 4494240, 4494960, 4495680, 4496400, 4497120, 4497840, 4498560, 4499280, 4500000, 4500720, 4501440, 4499286, 4500006, 4500726, 4501446, 4502160, 4502880, 4503600, 4504320, 4505040, 4505760, 4506480, 4507200, 4507920, 4508640, 4509360, 4510080, 4507926, 4508646, 4509366, 4510086, 4510800, 4511520, 4512240, 4512960]

theorem colored_row146 : ∀ c : Fin 64,
    readRow witnessRows (146 * 64 + c.val) = coloredWitness146[c.val]! := by
  decide +kernel
#print axioms colored_row146

theorem colored_check146 : ∀ c : Fin 64,
    checkColored 146 (BitVec.ofNat 6 c.val) (coloredWitness146[c.val]!) = true := by
  decide +kernel
#print axioms colored_check146

theorem colored_family146 : ∀ c : Fin 64,
    checkColored 146 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (146 * 64 + c.val)) = true := by
  intro c
  rw [colored_row146]
  exact colored_check146 c
#print axioms colored_family146

def coloredWitness147 : Array Nat := #[4513680, 4514400, 4515120, 4515840, 4516560, 4517280, 4518000, 4518720, 4516566, 4517286, 4518006, 4518726, 4519440, 4520160, 4520880, 4521600, 4522320, 4523040, 4523760, 4524480, 4525200, 4525920, 4526640, 4527360, 4525206, 4525926, 4526646, 4527366, 4528080, 4528800, 4529520, 4530240, 4530960, 4531680, 4532400, 4533120, 4533840, 4534560, 4535280, 4536000, 4533846, 4534566, 4535286, 4536006, 4536720, 4537440, 4538160, 4538880, 4539600, 4540320, 4541040, 4541760, 4542480, 4543200, 4543920, 4544640, 4542486, 4543206, 4543926, 4544646, 4545360, 4546080, 4546800, 4547520]

theorem colored_row147 : ∀ c : Fin 64,
    readRow witnessRows (147 * 64 + c.val) = coloredWitness147[c.val]! := by
  decide +kernel
#print axioms colored_row147

theorem colored_check147 : ∀ c : Fin 64,
    checkColored 147 (BitVec.ofNat 6 c.val) (coloredWitness147[c.val]!) = true := by
  decide +kernel
#print axioms colored_check147

theorem colored_family147 : ∀ c : Fin 64,
    checkColored 147 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (147 * 64 + c.val)) = true := by
  intro c
  rw [colored_row147]
  exact colored_check147 c
#print axioms colored_family147

def coloredWitness148 : Array Nat := #[4548240, 4548960, 4549680, 4550400, 4551120, 4551840, 4552560, 4553280, 4554000, 4554720, 4555440, 4556160, 4556880, 4557600, 4558320, 4559040, 4559760, 4560480, 4561200, 4561920, 4562640, 4563360, 4564080, 4564800, 4565520, 4566240, 4566960, 4567680, 4568400, 4569120, 4569840, 4570560, 4571280, 4572000, 4572720, 4573440, 4574160, 4574880, 4575600, 4576320, 4577040, 4577760, 4578480, 4579200, 4579920, 4580640, 4581360, 4582080, 4582800, 4583520, 4584240, 4584960, 4585680, 4586400, 4587120, 4587840, 4588560, 4589280, 4590000, 4590720, 4591440, 4592160, 4592880, 4593600]

theorem colored_row148 : ∀ c : Fin 64,
    readRow witnessRows (148 * 64 + c.val) = coloredWitness148[c.val]! := by
  decide +kernel
#print axioms colored_row148

theorem colored_check148 : ∀ c : Fin 64,
    checkColored 148 (BitVec.ofNat 6 c.val) (coloredWitness148[c.val]!) = true := by
  decide +kernel
#print axioms colored_check148

theorem colored_family148 : ∀ c : Fin 64,
    checkColored 148 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (148 * 64 + c.val)) = true := by
  intro c
  rw [colored_row148]
  exact colored_check148 c
#print axioms colored_family148

def coloredWitness149 : Array Nat := #[4594320, 4595040, 4595760, 4596480, 4597200, 4597920, 4598640, 4599360, 4597206, 4597926, 4598646, 4599366, 4600080, 4600800, 4601520, 4602240, 4602960, 4603680, 4604400, 4605120, 4605840, 4606560, 4607280, 4608000, 4605846, 4606566, 4607286, 4608006, 4608720, 4609440, 4610160, 4610880, 4611600, 4612320, 4613040, 4613760, 4614480, 4615200, 4615920, 4616640, 4614486, 4615206, 4615926, 4616646, 4617360, 4618080, 4618800, 4619520, 4620240, 4620960, 4621680, 4622400, 4623120, 4623840, 4624560, 4625280, 4623126, 4623846, 4624566, 4625286, 4626000, 4626720, 4627440, 4628160]

theorem colored_row149 : ∀ c : Fin 64,
    readRow witnessRows (149 * 64 + c.val) = coloredWitness149[c.val]! := by
  decide +kernel
#print axioms colored_row149

theorem colored_check149 : ∀ c : Fin 64,
    checkColored 149 (BitVec.ofNat 6 c.val) (coloredWitness149[c.val]!) = true := by
  decide +kernel
#print axioms colored_check149

theorem colored_family149 : ∀ c : Fin 64,
    checkColored 149 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (149 * 64 + c.val)) = true := by
  intro c
  rw [colored_row149]
  exact colored_check149 c
#print axioms colored_family149

def coloredWitness150 : Array Nat := #[4628880, 4629600, 4630320, 4631040, 4631760, 4632480, 4633200, 4633920, 4631767, 4632487, 4633207, 4633927, 4634640, 4635360, 4636080, 4636800, 4637520, 4638240, 4638960, 4639680, 4640400, 4641120, 4641840, 4642560, 4643280, 4644000, 4644720, 4645440, 4646160, 4646880, 4647600, 4648320, 4637527, 4638247, 4638967, 4639687, 4643287, 4644007, 4644727, 4645447, 4640407, 4641127, 4641847, 4642567, 4646167, 4646887, 4647607, 4648327, 4649040, 4649760, 4650480, 4651200, 4651920, 4652640, 4653360, 4654080, 4651927, 4652647, 4653367, 4654087, 4654800, 4655520, 4656240, 4656960]

theorem colored_row150 : ∀ c : Fin 64,
    readRow witnessRows (150 * 64 + c.val) = coloredWitness150[c.val]! := by
  decide +kernel
#print axioms colored_row150

theorem colored_check150 : ∀ c : Fin 64,
    checkColored 150 (BitVec.ofNat 6 c.val) (coloredWitness150[c.val]!) = true := by
  decide +kernel
#print axioms colored_check150

theorem colored_family150 : ∀ c : Fin 64,
    checkColored 150 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (150 * 64 + c.val)) = true := by
  intro c
  rw [colored_row150]
  exact colored_check150 c
#print axioms colored_family150

def coloredWitness151 : Array Nat := #[4657680, 4658400, 4659120, 4659840, 4660560, 4661280, 4662000, 4662720, 4663440, 4664160, 4664880, 4665600, 4666320, 4667040, 4667760, 4668480, 4669200, 4669920, 4670640, 4671360, 4672080, 4672800, 4673520, 4674240, 4674960, 4675680, 4676400, 4677120, 4677840, 4678560, 4679280, 4680000, 4680720, 4681440, 4682160, 4682880, 4683600, 4684320, 4685040, 4685760, 4686480, 4687200, 4687920, 4688640, 4689360, 4690080, 4690800, 4691520, 4692240, 4692960, 4693680, 4694400, 4695120, 4695840, 4696560, 4697280, 4698000, 4698720, 4699440, 4700160, 4700880, 4701600, 4702320, 4703040]

theorem colored_row151 : ∀ c : Fin 64,
    readRow witnessRows (151 * 64 + c.val) = coloredWitness151[c.val]! := by
  decide +kernel
#print axioms colored_row151

theorem colored_check151 : ∀ c : Fin 64,
    checkColored 151 (BitVec.ofNat 6 c.val) (coloredWitness151[c.val]!) = true := by
  decide +kernel
#print axioms colored_check151

theorem colored_family151 : ∀ c : Fin 64,
    checkColored 151 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (151 * 64 + c.val)) = true := by
  intro c
  rw [colored_row151]
  exact colored_check151 c
#print axioms colored_family151

def coloredWitness152 : Array Nat := #[4703760, 4704480, 4705200, 4705920, 4706640, 4707360, 4708080, 4708800, 4706647, 4707367, 4708087, 4708807, 4709520, 4710240, 4710960, 4711680, 4712400, 4713120, 4713840, 4714560, 4715280, 4716000, 4716720, 4717440, 4718160, 4718880, 4719600, 4720320, 4721040, 4721760, 4722480, 4723200, 4712407, 4713127, 4713847, 4714567, 4718167, 4718887, 4719607, 4720327, 4715287, 4716007, 4716727, 4717447, 4721047, 4721767, 4722487, 4723207, 4723920, 4724640, 4725360, 4726080, 4726800, 4727520, 4728240, 4728960, 4726807, 4727527, 4728247, 4728967, 4729680, 4730400, 4731120, 4731840]

theorem colored_row152 : ∀ c : Fin 64,
    readRow witnessRows (152 * 64 + c.val) = coloredWitness152[c.val]! := by
  decide +kernel
#print axioms colored_row152

theorem colored_check152 : ∀ c : Fin 64,
    checkColored 152 (BitVec.ofNat 6 c.val) (coloredWitness152[c.val]!) = true := by
  decide +kernel
#print axioms colored_check152

theorem colored_family152 : ∀ c : Fin 64,
    checkColored 152 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (152 * 64 + c.val)) = true := by
  intro c
  rw [colored_row152]
  exact colored_check152 c
#print axioms colored_family152

def coloredWitness153 : Array Nat := #[4732560, 4733280, 4734000, 4734720, 4735440, 4736160, 4736880, 4737600, 4735447, 4736167, 4736887, 4737607, 4738320, 4739040, 4739760, 4740480, 4741200, 4741920, 4742640, 4743360, 4744080, 4744800, 4745520, 4746240, 4746960, 4747680, 4748400, 4749120, 4749840, 4750560, 4751280, 4752000, 4741207, 4741927, 4742647, 4743367, 4746967, 4747687, 4748407, 4749127, 4744087, 4744807, 4745527, 4746247, 4749847, 4750567, 4751287, 4752007, 4752720, 4753440, 4754160, 4754880, 4755600, 4756320, 4757040, 4757760, 4755607, 4756327, 4757047, 4757767, 4758480, 4759200, 4759920, 4760640]

theorem colored_row153 : ∀ c : Fin 64,
    readRow witnessRows (153 * 64 + c.val) = coloredWitness153[c.val]! := by
  decide +kernel
#print axioms colored_row153

theorem colored_check153 : ∀ c : Fin 64,
    checkColored 153 (BitVec.ofNat 6 c.val) (coloredWitness153[c.val]!) = true := by
  decide +kernel
#print axioms colored_check153

theorem colored_family153 : ∀ c : Fin 64,
    checkColored 153 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (153 * 64 + c.val)) = true := by
  intro c
  rw [colored_row153]
  exact colored_check153 c
#print axioms colored_family153

def coloredWitness154 : Array Nat := #[4761360, 4762080, 4762800, 4763520, 4764240, 4764960, 4765680, 4766400, 4767120, 4767840, 4768560, 4769280, 4770000, 4770720, 4771440, 4772160, 4772880, 4773600, 4774320, 4775040, 4775760, 4776480, 4777200, 4777920, 4778640, 4779360, 4780080, 4780800, 4781520, 4782240, 4782960, 4783680, 4784400, 4785120, 4785840, 4786560, 4787280, 4788000, 4788720, 4789440, 4790160, 4790880, 4791600, 4792320, 4793040, 4793760, 4794480, 4795200, 4795920, 4796640, 4797360, 4798080, 4798800, 4799520, 4800240, 4800960, 4801680, 4802400, 4803120, 4803840, 4804560, 4805280, 4806000, 4806720]

theorem colored_row154 : ∀ c : Fin 64,
    readRow witnessRows (154 * 64 + c.val) = coloredWitness154[c.val]! := by
  decide +kernel
#print axioms colored_row154

theorem colored_check154 : ∀ c : Fin 64,
    checkColored 154 (BitVec.ofNat 6 c.val) (coloredWitness154[c.val]!) = true := by
  decide +kernel
#print axioms colored_check154

theorem colored_family154 : ∀ c : Fin 64,
    checkColored 154 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (154 * 64 + c.val)) = true := by
  intro c
  rw [colored_row154]
  exact colored_check154 c
#print axioms colored_family154

def coloredWitness155 : Array Nat := #[4807440, 4808160, 4808880, 4809600, 4810320, 4811040, 4811760, 4812480, 4810327, 4811047, 4811767, 4812487, 4813200, 4813920, 4814640, 4815360, 4816080, 4816800, 4817520, 4818240, 4818960, 4819680, 4820400, 4821120, 4821840, 4822560, 4823280, 4824000, 4824720, 4825440, 4826160, 4826880, 4816087, 4816807, 4817527, 4818247, 4821847, 4822567, 4823287, 4824007, 4818967, 4819687, 4820407, 4821127, 4824727, 4825447, 4826167, 4826887, 4827600, 4828320, 4829040, 4829760, 4830480, 4831200, 4831920, 4832640, 4830487, 4831207, 4831927, 4832647, 4833360, 4834080, 4834800, 4835520]

theorem colored_row155 : ∀ c : Fin 64,
    readRow witnessRows (155 * 64 + c.val) = coloredWitness155[c.val]! := by
  decide +kernel
#print axioms colored_row155

theorem colored_check155 : ∀ c : Fin 64,
    checkColored 155 (BitVec.ofNat 6 c.val) (coloredWitness155[c.val]!) = true := by
  decide +kernel
#print axioms colored_check155

theorem colored_family155 : ∀ c : Fin 64,
    checkColored 155 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (155 * 64 + c.val)) = true := by
  intro c
  rw [colored_row155]
  exact colored_check155 c
#print axioms colored_family155

def coloredWitness156 : Array Nat := #[4836240, 4836960, 4837680, 4838400, 4837704, 4838424, 4839120, 4839840, 4840560, 4841280, 4842000, 4842720, 4842024, 4842744, 4843440, 4844160, 4844880, 4845600, 4846320, 4847040, 4846344, 4847064, 4847760, 4848480, 4849200, 4849920, 4850640, 4851360, 4850664, 4851384, 4852080, 4852800, 4853520, 4854240, 4854960, 4855680, 4854984, 4855704, 4856400, 4857120, 4857840, 4858560, 4859280, 4860000, 4859304, 4860024, 4860720, 4861440, 4862160, 4862880, 4863600, 4864320, 4863624, 4864344, 4865040, 4865760, 4866480, 4867200, 4867920, 4868640, 4867944, 4868664, 4869360, 4870080]

theorem colored_row156 : ∀ c : Fin 64,
    readRow witnessRows (156 * 64 + c.val) = coloredWitness156[c.val]! := by
  decide +kernel
#print axioms colored_row156

theorem colored_check156 : ∀ c : Fin 64,
    checkColored 156 (BitVec.ofNat 6 c.val) (coloredWitness156[c.val]!) = true := by
  decide +kernel
#print axioms colored_check156

theorem colored_family156 : ∀ c : Fin 64,
    checkColored 156 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (156 * 64 + c.val)) = true := by
  intro c
  rw [colored_row156]
  exact colored_check156 c
#print axioms colored_family156

def coloredWitness157 : Array Nat := #[4870800, 4871520, 4872240, 4872960, 4872264, 4872984, 4873680, 4874400, 4875120, 4875840, 4876560, 4877280, 4876584, 4877304, 4878000, 4878720, 4879440, 4880160, 4880880, 4881600, 4880904, 4881624, 4882320, 4883040, 4883760, 4884480, 4885200, 4885920, 4885224, 4885944, 4886640, 4887360, 4888080, 4888800, 4889520, 4890240, 4889544, 4890264, 4890960, 4891680, 4892400, 4893120, 4893840, 4894560, 4893864, 4894584, 4895280, 4896000, 4896720, 4897440, 4898160, 4898880, 4898184, 4898904, 4899600, 4900320, 4901040, 4901760, 4902480, 4903200, 4902504, 4903224, 4903920, 4904640]

theorem colored_row157 : ∀ c : Fin 64,
    readRow witnessRows (157 * 64 + c.val) = coloredWitness157[c.val]! := by
  decide +kernel
#print axioms colored_row157

theorem colored_check157 : ∀ c : Fin 64,
    checkColored 157 (BitVec.ofNat 6 c.val) (coloredWitness157[c.val]!) = true := by
  decide +kernel
#print axioms colored_check157

theorem colored_family157 : ∀ c : Fin 64,
    checkColored 157 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (157 * 64 + c.val)) = true := by
  intro c
  rw [colored_row157]
  exact colored_check157 c
#print axioms colored_family157

def coloredWitness158 : Array Nat := #[4905360, 4906080, 4906800, 4907520, 4908240, 4908960, 4909680, 4910400, 4911120, 4911840, 4912560, 4913280, 4914000, 4914720, 4915440, 4916160, 4916880, 4917600, 4918320, 4919040, 4919760, 4920480, 4921200, 4921920, 4922640, 4923360, 4924080, 4924800, 4925520, 4926240, 4926960, 4927680, 4928400, 4929120, 4929840, 4930560, 4931280, 4932000, 4932720, 4933440, 4934160, 4934880, 4935600, 4936320, 4937040, 4937760, 4938480, 4939200, 4939920, 4940640, 4941360, 4942080, 4942800, 4943520, 4944240, 4944960, 4945680, 4946400, 4947120, 4947840, 4948560, 4949280, 4950000, 4950720]

theorem colored_row158 : ∀ c : Fin 64,
    readRow witnessRows (158 * 64 + c.val) = coloredWitness158[c.val]! := by
  decide +kernel
#print axioms colored_row158

theorem colored_check158 : ∀ c : Fin 64,
    checkColored 158 (BitVec.ofNat 6 c.val) (coloredWitness158[c.val]!) = true := by
  decide +kernel
#print axioms colored_check158

theorem colored_family158 : ∀ c : Fin 64,
    checkColored 158 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (158 * 64 + c.val)) = true := by
  intro c
  rw [colored_row158]
  exact colored_check158 c
#print axioms colored_family158

def coloredWitness159 : Array Nat := #[4951440, 4952160, 4952880, 4953600, 4954320, 4955040, 4955760, 4956480, 4957200, 4957920, 4958640, 4959360, 4960080, 4960800, 4961520, 4962240, 4962960, 4963680, 4964400, 4965120, 4965840, 4966560, 4967280, 4968000, 4968720, 4969440, 4970160, 4970880, 4971600, 4972320, 4973040, 4973760, 4974480, 4975200, 4975920, 4976640, 4977360, 4978080, 4978800, 4979520, 4980240, 4980960, 4981680, 4982400, 4983120, 4983840, 4984560, 4985280, 4986000, 4986720, 4987440, 4988160, 4988880, 4989600, 4990320, 4991040, 4991760, 4992480, 4993200, 4993920, 4994640, 4995360, 4996080, 4996800]

theorem colored_row159 : ∀ c : Fin 64,
    readRow witnessRows (159 * 64 + c.val) = coloredWitness159[c.val]! := by
  decide +kernel
#print axioms colored_row159

theorem colored_check159 : ∀ c : Fin 64,
    checkColored 159 (BitVec.ofNat 6 c.val) (coloredWitness159[c.val]!) = true := by
  decide +kernel
#print axioms colored_check159

theorem colored_family159 : ∀ c : Fin 64,
    checkColored 159 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (159 * 64 + c.val)) = true := by
  intro c
  rw [colored_row159]
  exact colored_check159 c
#print axioms colored_family159

end TightCycleC5.Bridge.ColoredCover
