import KernelRowIndex
import KernelWitness26

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_26_0 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 0 * 256 + i.val))
      kernelWitness26Row0[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_0

theorem kernelBlock_26_1 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 1 * 256 + i.val))
      kernelWitness26Row1[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_1

theorem kernelBlock_26_2 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 2 * 256 + i.val))
      kernelWitness26Row2[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_2

theorem kernelBlock_26_3 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 3 * 256 + i.val))
      kernelWitness26Row3[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_3

theorem kernelBlock_26_4 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 4 * 256 + i.val))
      kernelWitness26Row4[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_4

theorem kernelBlock_26_5 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 5 * 256 + i.val))
      kernelWitness26Row5[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_5

theorem kernelBlock_26_6 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 6 * 256 + i.val))
      kernelWitness26Row6[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_6

theorem kernelBlock_26_7 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 7 * 256 + i.val))
      kernelWitness26Row7[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_7

theorem kernelBlock_26_8 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 8 * 256 + i.val))
      kernelWitness26Row8[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_8

theorem kernelBlock_26_9 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 9 * 256 + i.val))
      kernelWitness26Row9[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_9

theorem kernelBlock_26_10 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 10 * 256 + i.val))
      kernelWitness26Row10[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_10

theorem kernelBlock_26_11 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 11 * 256 + i.val))
      kernelWitness26Row11[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_11

theorem kernelBlock_26_12 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 12 * 256 + i.val))
      kernelWitness26Row12[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_12

theorem kernelBlock_26_13 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 13 * 256 + i.val))
      kernelWitness26Row13[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_13

theorem kernelBlock_26_14 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 14 * 256 + i.val))
      kernelWitness26Row14[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_14

theorem kernelBlock_26_15 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 15 * 256 + i.val))
      kernelWitness26Row15[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_15

theorem kernelBlock_26_16 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 16 * 256 + i.val))
      kernelWitness26Row16[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_16

theorem kernelBlock_26_17 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 17 * 256 + i.val))
      kernelWitness26Row17[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_17

theorem kernelBlock_26_18 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 18 * 256 + i.val))
      kernelWitness26Row18[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_18

theorem kernelBlock_26_19 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 19 * 256 + i.val))
      kernelWitness26Row19[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_19

theorem kernelBlock_26_20 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 20 * 256 + i.val))
      kernelWitness26Row20[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_20

theorem kernelBlock_26_21 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 21 * 256 + i.val))
      kernelWitness26Row21[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_21

theorem kernelBlock_26_22 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 22 * 256 + i.val))
      kernelWitness26Row22[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_22

theorem kernelBlock_26_23 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 23 * 256 + i.val))
      kernelWitness26Row23[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_23

theorem kernelBlock_26_24 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 24 * 256 + i.val))
      kernelWitness26Row24[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_24

theorem kernelBlock_26_25 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 25 * 256 + i.val))
      kernelWitness26Row25[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_25

theorem kernelBlock_26_26 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 26 * 256 + i.val))
      kernelWitness26Row26[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_26

theorem kernelBlock_26_27 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 27 * 256 + i.val))
      kernelWitness26Row27[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_27

theorem kernelBlock_26_28 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 28 * 256 + i.val))
      kernelWitness26Row28[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_28

theorem kernelBlock_26_29 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 29 * 256 + i.val))
      kernelWitness26Row29[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_29

theorem kernelBlock_26_30 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 30 * 256 + i.val))
      kernelWitness26Row30[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_30

theorem kernelBlock_26_31 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 31 * 256 + i.val))
      kernelWitness26Row31[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_31

end TightCycleC5.Bridge.Cover
