import CertificateDescriptorsBook
import CertificateDescriptorsDensity
import P32Book
import P32FlagBounds
import FiniteErrors

/-! The actual P32 nuisance rows have a single explicit O(1/n) bound.
No certificate evaluator identity or class inequality is a premise here. -/
namespace TightCycleC5.Bridge.P32RowBounds
set_option maxRecDepth 100000
open Finset

noncomputable def weightedBookWeight (j : Fin 25) : ℝ :=
  CertificateDescriptors.p32Weight ⟨9484 + j.val, by omega⟩
noncomputable def weightedBookMass : ℝ := ∑ j : Fin 25, weightedBookWeight j
noncomputable def densityMass : ℝ := ∑ hit : Bool, CertificateDescriptors.densityWeight hit
noncomputable def psdErrorConstant : ℝ :=
  2 * (P32PSD.bound0 + P32PSD.bound1 + P32PSD.bound2 + P32PSD.bound3 + P32PSD.bound4) +
    16 * P32PSD.bound5
noncomputable def errorConstant : ℝ :=
  2 * CertificateDescriptors.p32CLMass + 2 * CertificateDescriptors.p32BookMass + 2 * weightedBookMass +
    72 * densityMass + psdErrorConstant

noncomputable def weightedBooks (G : LabelledStructure 6) : ℝ :=
  ∑ j : Fin 25, weightedBookWeight j *
    PairBookCertificate.row (P32Book.descriptor j) G
noncomputable def densityRows (G : LabelledStructure 6) : ℝ :=
  ∑ hit : Bool, CertificateDescriptors.densityWeight hit * CertificateDescriptors.densityRow hit G
noncomputable def clRows (G : LabelledStructure 6) : ℝ :=
  ∑ i : Fin 1020, CertificateDescriptors.p32CLWeight i * CLCertificate.row (CertificateDescriptors.p32CL i) G
noncomputable def indicatorBooks (G : LabelledStructure 6) : ℝ :=
  ∑ i : Fin 8464, CertificateDescriptors.p32BookWeight i *
    PairBookCertificate.row (CertificateDescriptors.p32BookDescriptor i) G
noncomputable def psdRows {n : Nat} (H : Finset (Finset (Fin n)))
    (σ : Fin 6 ↪ Fin n) : ℝ :=
  P32Flag.row0 H σ + P32Flag.row1 H σ + P32Flag.row2 H σ +
    P32Flag.row3 H σ + P32Flag.row4 H σ + P32Flag.row5 H σ
noncomputable def nuisanceRows {n : Nat} (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) : ℝ :=
  clRows (sampleStructure σ H S) + indicatorBooks (sampleStructure σ H S) +
    weightedBooks (sampleStructure σ H S) + densityRows (sampleStructure σ H S) +
    psdRows H σ

theorem weighted_book_weight_nonneg (j : Fin 25) : 0 ≤ weightedBookWeight j :=
  CertificateDescriptors.p32_weight_nonneg _
theorem weighted_book_mass_nonneg : 0 ≤ weightedBookMass :=
  Finset.sum_nonneg (fun j _ => weighted_book_weight_nonneg j)
theorem density_mass_nonneg : 0 ≤ densityMass :=
  Finset.sum_nonneg (fun hit _ => CertificateDescriptors.density_weight_nonneg hit)
theorem psd_error_constant_nonneg : 0 ≤ psdErrorConstant := by
  unfold psdErrorConstant
  have h0 := P32PSD.normalized_nonneg0
  have h1 := P32PSD.normalized_nonneg1
  have h2 := P32PSD.normalized_nonneg2
  have h3 := P32PSD.normalized_nonneg3
  have h4 := P32PSD.normalized_nonneg4
  have h5 := P32PSD.normalized_nonneg5
  positivity
theorem error_constant_nonneg : 0 ≤ errorConstant := by
  unfold errorConstant
  have hc := CertificateDescriptors.p32_cl_mass_nonneg
  have hb := CertificateDescriptors.p32_book_mass_nonneg
  have hw := weighted_book_mass_nonneg
  have hd := density_mass_nonneg
  have hp := psd_error_constant_nonneg
  linarith only [hc, hb, hw, hd, hp]

theorem mean_weighted_sum {I Ω : Type*} [Fintype I] [Fintype Ω]
    (w : I → ℝ) (row : I → Ω → ℝ) :
    uniformMean (fun σ => ∑ i, w i * row i σ) = ∑ i, w i * uniformMean (row i) := by
  unfold uniformMean
  rw [Finset.sum_comm, Finset.sum_div]
  apply Finset.sum_congr rfl
  intro i _
  rw [← Finset.mul_sum]
  ring

theorem weighted_mean_lower {I Ω : Type*} [Fintype I] [Fintype Ω]
    (w : I → ℝ) (row : I → Ω → ℝ) (a : ℝ)
    (hw : ∀ i, 0 ≤ w i) (hr : ∀ i, -a ≤ uniformMean (row i)) :
    -(∑ i, w i) * a ≤ uniformMean (fun σ => ∑ i, w i * row i σ) := by
  rw [mean_weighted_sum]
  calc
    _ = ∑ i, w i * (-a) := by rw [← Finset.sum_mul]; ring
    _ ≤ _ := Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_left (hr i) (hw i))

theorem common_mass_lower {x m r : ℝ} (hx : 12 ≤ x) (hm : 0 ≤ m)
    (hr : -m / (x - 5) ≤ r) : -(2 * m / x) ≤ r := by
  have he : m / (x - 5) ≤ 2 * m / x := by
    calc
      _ = m * (1 / (x - 5)) := by ring
      _ ≤ m * (2 / x) := mul_le_mul_of_nonneg_left (common_set_error_le hx) hm
      _ = _ := by ring
  rw [neg_div] at hr
  exact le_trans (neg_le_neg he) hr

theorem cl_mean_lower {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (hn : 12 ≤ n) (S : Finset (Fin n)) :
    -(2 * CertificateDescriptors.p32CLMass / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => clRows (sampleStructure σ H S)) :=
  common_mass_lower (by exact_mod_cast hn) CertificateDescriptors.p32_cl_mass_nonneg
    (CertificateDescriptors.p32_cl_mean_lower H hH hC hn S)

theorem indicator_books_mean_lower {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (hn : 12 ≤ n) (S : Finset (Fin n)) :
    -(2 * CertificateDescriptors.p32BookMass / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => indicatorBooks (sampleStructure σ H S)) :=
  common_mass_lower (by exact_mod_cast hn) CertificateDescriptors.p32_book_mass_nonneg
    (CertificateDescriptors.p32_book_mean_lower H hH hC hn S)

theorem weighted_books_mean_lower {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (hn : 12 ≤ n) (S : Finset (Fin n)) :
    -(2 * weightedBookMass / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => weightedBooks (sampleStructure σ H S)) := by
  apply common_mass_lower (by exact_mod_cast hn) weighted_book_mass_nonneg
  have h := weighted_mean_lower weightedBookWeight
    (fun j σ => PairBookCertificate.row (P32Book.descriptor j) (sampleStructure σ H S))
    (1 / ((n : ℝ) - 5)) weighted_book_weight_nonneg
    (fun j => P32Book.row_mean_lower j H hH hC hn S)
  simpa only [weightedBooks, weightedBookMass, neg_mul, mul_one_div] using h

theorem density_mean_lower {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hn : 12 ≤ n) (S : Finset (Fin n))
    (hd : CertificateDescriptors.densityBeta * (n.choose 3 : ℝ) ≤ (H.card : ℝ)) :
    -(72 * densityMass / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => densityRows (sampleStructure σ H S)) := by
  have h := weighted_mean_lower CertificateDescriptors.densityWeight
    (fun hit σ => CertificateDescriptors.densityRow hit (sampleStructure σ H S))
    (CertificateDescriptors.densityEta n) CertificateDescriptors.density_weight_nonneg
    (fun hit => CertificateDescriptors.density_row_mean_lower hit H hH hn S hd)
  have he := mul_le_mul_of_nonneg_left (triple_error_le (x := (n : ℝ)) (by exact_mod_cast hn)) density_mass_nonneg
  change densityMass * CertificateDescriptors.densityEta n ≤ densityMass * (72 / (n : ℝ)) at he
  change -densityMass * CertificateDescriptors.densityEta n ≤ _ at h
  calc
    _ = -(densityMass * (72 / (n : ℝ))) := by ring
    _ ≤ -(densityMass * CertificateDescriptors.densityEta n) := neg_le_neg he
    _ ≤ _ := by simpa only [densityRows, neg_mul] using h

theorem psd_mean_lower {n : Nat} (H : Finset (Finset (Fin n))) (hn : 12 ≤ n) :
    -(psdErrorConstant / (n : ℝ)) ≤ uniformMean (psdRows H) := by
  have hnR : (12 : ℝ) ≤ n := by exact_mod_cast hn
  have h0 := common_mass_lower hnR P32PSD.normalized_nonneg0 (P32Flag.row0_lower hn H)
  have h1 := common_mass_lower hnR P32PSD.normalized_nonneg1 (P32Flag.row1_lower hn H)
  have h2 := common_mass_lower hnR P32PSD.normalized_nonneg2 (P32Flag.row2_lower hn H)
  have h3 := common_mass_lower hnR P32PSD.normalized_nonneg3 (P32Flag.row3_lower hn H)
  have h4 := common_mass_lower hnR P32PSD.normalized_nonneg4 (P32Flag.row4_lower hn H)
  have h5 := P32Flag.row5_lower hn H
  have he : (4 * (n : ℝ) - 14) * P32PSD.bound5 /
      (((n : ℝ) - 4) * ((n : ℝ) - 5)) ≤ 16 * P32PSD.bound5 / (n : ℝ) := by
    calc
      _ = ((4 * (n : ℝ) - 14) / (((n : ℝ) - 4) * ((n : ℝ) - 5))) * P32PSD.bound5 := by ring
      _ ≤ (16 / (n : ℝ)) * P32PSD.bound5 :=
        mul_le_mul_of_nonneg_right (pair_collision_error_le hnR) P32PSD.normalized_nonneg5
      _ = _ := by ring
  have hmean : uniformMean (psdRows H) = uniformMean (P32Flag.row0 H) +
      uniformMean (P32Flag.row1 H) + uniformMean (P32Flag.row2 H) +
      uniformMean (P32Flag.row3 H) + uniformMean (P32Flag.row4 H) +
      uniformMean (P32Flag.row5 H) := by
    simp only [psdRows, uniformMean, Finset.sum_add_distrib, add_div]
  rw [hmean]
  unfold psdErrorConstant
  simp only [add_div, mul_add] at *
  linarith

theorem nuisance_mean_lower {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (hn : 12 ≤ n) (S : Finset (Fin n))
    (hd : CertificateDescriptors.densityBeta * (n.choose 3 : ℝ) ≤ (H.card : ℝ)) :
    -(errorConstant / (n : ℝ)) ≤ uniformMean (nuisanceRows H S) := by
  have hcl := cl_mean_lower H hH hC hn S
  have hib := indicator_books_mean_lower H hH hC hn S
  have hwb := weighted_books_mean_lower H hH hC hn S
  have hdens := density_mean_lower H hH hn S hd
  have hpsd := psd_mean_lower H hn
  have hmean : uniformMean (nuisanceRows H S) =
      uniformMean (fun σ : Fin 6 ↪ Fin n => clRows (sampleStructure σ H S)) +
      uniformMean (fun σ : Fin 6 ↪ Fin n => indicatorBooks (sampleStructure σ H S)) +
      uniformMean (fun σ : Fin 6 ↪ Fin n => weightedBooks (sampleStructure σ H S)) +
      uniformMean (fun σ : Fin 6 ↪ Fin n => densityRows (sampleStructure σ H S)) +
      uniformMean (psdRows H) := by
    simp only [nuisanceRows, uniformMean, Finset.sum_add_distrib, add_div]
  rw [hmean]
  unfold errorConstant
  simp only [add_div]
  linarith

#print axioms weighted_book_weight_nonneg
#print axioms weighted_book_mass_nonneg
#print axioms density_mass_nonneg
#print axioms psd_error_constant_nonneg
#print axioms error_constant_nonneg
#print axioms mean_weighted_sum
#print axioms weighted_mean_lower
#print axioms common_mass_lower
#print axioms cl_mean_lower
#print axioms indicator_books_mean_lower
#print axioms weighted_books_mean_lower
#print axioms density_mean_lower
#print axioms psd_mean_lower
#print axioms nuisance_mean_lower
end TightCycleC5.Bridge.P32RowBounds
