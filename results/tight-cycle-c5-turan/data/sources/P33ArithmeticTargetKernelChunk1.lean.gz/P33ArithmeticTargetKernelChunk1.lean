-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk4 :
    ∀ i : Fin (min 128 (40547 - 128 * 4)),
      targetCountsMatch (classAt (targetKernelClass ⟨4, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk4

theorem target_counts_kernel_chunk5 :
    ∀ i : Fin (min 128 (40547 - 128 * 5)),
      targetCountsMatch (classAt (targetKernelClass ⟨5, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk5

theorem target_counts_kernel_chunk6 :
    ∀ i : Fin (min 128 (40547 - 128 * 6)),
      targetCountsMatch (classAt (targetKernelClass ⟨6, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk6

theorem target_counts_kernel_chunk7 :
    ∀ i : Fin (min 128 (40547 - 128 * 7)),
      targetCountsMatch (classAt (targetKernelClass ⟨7, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk7


end TightCycleC5.Bridge.P33Arithmetic
