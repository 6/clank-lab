import KernelRowIndex
import KernelWitness17

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_17_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 64 * 256 + i.val))
      kernelWitness17Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_64

theorem kernelBlock_17_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 65 * 256 + i.val))
      kernelWitness17Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_65

theorem kernelBlock_17_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 66 * 256 + i.val))
      kernelWitness17Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_66

theorem kernelBlock_17_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 67 * 256 + i.val))
      kernelWitness17Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_67

theorem kernelBlock_17_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 68 * 256 + i.val))
      kernelWitness17Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_68

theorem kernelBlock_17_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 69 * 256 + i.val))
      kernelWitness17Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_69

theorem kernelBlock_17_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 70 * 256 + i.val))
      kernelWitness17Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_70

theorem kernelBlock_17_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 71 * 256 + i.val))
      kernelWitness17Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_71

theorem kernelBlock_17_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 72 * 256 + i.val))
      kernelWitness17Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_72

theorem kernelBlock_17_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 73 * 256 + i.val))
      kernelWitness17Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_73

theorem kernelBlock_17_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 74 * 256 + i.val))
      kernelWitness17Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_74

theorem kernelBlock_17_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 75 * 256 + i.val))
      kernelWitness17Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_75

theorem kernelBlock_17_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 76 * 256 + i.val))
      kernelWitness17Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_76

theorem kernelBlock_17_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 77 * 256 + i.val))
      kernelWitness17Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_77

theorem kernelBlock_17_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 78 * 256 + i.val))
      kernelWitness17Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_78

theorem kernelBlock_17_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 79 * 256 + i.val))
      kernelWitness17Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_79

theorem kernelBlock_17_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 80 * 256 + i.val))
      kernelWitness17Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_80

theorem kernelBlock_17_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 81 * 256 + i.val))
      kernelWitness17Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_81

theorem kernelBlock_17_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 82 * 256 + i.val))
      kernelWitness17Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_82

theorem kernelBlock_17_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 83 * 256 + i.val))
      kernelWitness17Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_83

theorem kernelBlock_17_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 84 * 256 + i.val))
      kernelWitness17Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_84

theorem kernelBlock_17_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 85 * 256 + i.val))
      kernelWitness17Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_85

theorem kernelBlock_17_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 86 * 256 + i.val))
      kernelWitness17Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_86

theorem kernelBlock_17_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 87 * 256 + i.val))
      kernelWitness17Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_87

theorem kernelBlock_17_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 88 * 256 + i.val))
      kernelWitness17Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_88

theorem kernelBlock_17_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 89 * 256 + i.val))
      kernelWitness17Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_89

theorem kernelBlock_17_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 90 * 256 + i.val))
      kernelWitness17Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_90

theorem kernelBlock_17_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 91 * 256 + i.val))
      kernelWitness17Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_91

theorem kernelBlock_17_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 92 * 256 + i.val))
      kernelWitness17Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_92

theorem kernelBlock_17_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 93 * 256 + i.val))
      kernelWitness17Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_93

theorem kernelBlock_17_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 94 * 256 + i.val))
      kernelWitness17Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_94

theorem kernelBlock_17_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (17 * 32768 + 95 * 256 + i.val))
      kernelWitness17Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_17_95

end TightCycleC5.Bridge.Cover
