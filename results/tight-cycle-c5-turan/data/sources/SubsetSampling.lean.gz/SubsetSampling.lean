import RestrictionSampling

/-! A k-set has exactly k! orderings; injective ordered samples induce
uniform k-subsets. These identities hold for arbitrary real set weights. -/
namespace TightCycleC5.Bridge
open Finset

noncomputable def embeddingSet {A : Type*} [DecidableEq A] {k : ℕ} (σ : Fin k ↪ A) : Finset A :=
  univ.map σ

theorem embeddingSet_card {A : Type*} [DecidableEq A] {k : ℕ} (σ : Fin k ↪ A) :
    (embeddingSet σ).card = k := by simp [embeddingSet]

noncomputable def subsetOrderingEquiv {A : Type*} [Fintype A] [DecidableEq A]
    {k : ℕ} (e : Finset A) (he : e.card = k) :
    {σ : Fin k ↪ A // embeddingSet σ = e} ≃ (Fin k ≃ e) := by
  classical
  let forward : {σ : Fin k ↪ A // embeddingSet σ = e} → (Fin k ≃ e) := fun σ =>
    Equiv.ofBijective (fun i => ⟨σ.val i, by
      exact Eq.mp (congrArg (fun s : Finset A => σ.val i ∈ s) σ.property)
        (mem_map.mpr ⟨i, mem_univ _, rfl⟩)⟩)
      ((Fintype.bijective_iff_injective_and_card _).mpr ⟨
        fun i j h => σ.val.injective (congrArg Subtype.val h), by simp [he]⟩)
  let backward : (Fin k ≃ e) → {σ : Fin k ↪ A // embeddingSet σ = e} := fun p =>
    ⟨p.toEmbedding.trans ⟨Subtype.val, Subtype.val_injective⟩, by
      ext a
      constructor
      · rintro h
        obtain ⟨i, _, hi⟩ := mem_map.mp h
        exact hi ▸ (p i).property
      · intro ha
        obtain ⟨i, hi⟩ := p.surjective ⟨a, ha⟩
        exact mem_map.mpr ⟨i, mem_univ _, congrArg Subtype.val hi⟩⟩
  exact {
    toFun := forward
    invFun := backward
    left_inv := fun _ => by apply Subtype.ext; apply Function.Embedding.ext; intro i; rfl
    right_inv := fun _ => by apply Equiv.ext; intro i; rfl }

theorem subsetOrdering_card {A : Type*} [Fintype A] [DecidableEq A]
    {k : ℕ} (e : Finset A) (he : e.card = k) :
    Fintype.card {σ : Fin k ↪ A // embeddingSet σ = e} = k.factorial := by
  classical
  rw [Fintype.card_congr (subsetOrderingEquiv e he),
    Fintype.card_equiv (Fintype.equivOfCardEq (by simp [he])), Fintype.card_fin]

/-- Exact factorial multiplicity without assuming that a weight is a graph
predicate, positive or symmetric under a chosen set ordering. -/
theorem embeddingSet_sum {A : Type*} [Fintype A] [DecidableEq A]
    (k : ℕ) (w : Finset A → ℝ) :
    (∑ σ : Fin k ↪ A, w (embeddingSet σ)) =
      (k.factorial : ℝ) * ∑ e ∈ (univ : Finset A).powersetCard k, w e := by
  classical
  have hp : ∀ σ : Fin k ↪ A, w (embeddingSet σ) =
      ∑ e ∈ (univ : Finset A).powersetCard k, if embeddingSet σ = e then w e else 0 := by
    intro σ
    have hm : embeddingSet σ ∈ (univ : Finset A).powersetCard k := by
      simp [mem_powersetCard, embeddingSet_card]
    simp [eq_comm, hm]
  simp_rw [hp]
  rw [sum_comm, mul_sum]
  apply sum_congr rfl
  intro e he
  have hc : e.card = k := (mem_powersetCard.mp he).2
  have hf : (∑ σ : Fin k ↪ A, if embeddingSet σ = e then w e else 0) =
      (Fintype.card {σ : Fin k ↪ A // embeddingSet σ = e} : ℝ) * w e := by
    rw [← Finset.sum_filter, Finset.sum_const, nsmul_eq_mul, Fintype.card_subtype]
  rw [hf, subsetOrdering_card e hc]

/-- Normalization by C(|A|,k), including the empty sampling case. -/
theorem embeddingSet_mean {A : Type*} [Fintype A] [DecidableEq A]
    (k : ℕ) (w : Finset A → ℝ) :
    uniformMean (fun σ : Fin k ↪ A => w (embeddingSet σ)) =
      (∑ e ∈ (univ : Finset A).powersetCard k, w e) /
        ((Fintype.card A).choose k : ℝ) := by
  classical
  rw [uniformMean, embeddingSet_sum, Fintype.card_embedding_eq, Fintype.card_fin,
    Nat.descFactorial_eq_factorial_mul_choose, Nat.cast_mul]
  have hf : (k.factorial : ℝ) ≠ 0 := by exact_mod_cast Nat.factorial_ne_zero k
  field_simp

#print axioms embeddingSet_card
#print axioms subsetOrdering_card
#print axioms embeddingSet_sum
#print axioms embeddingSet_mean
end TightCycleC5.Bridge
