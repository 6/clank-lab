-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk248 :
    ∀ i : Fin (min 128 (40547 - 128 * 248)),
      targetCountsMatch (classAt (targetKernelClass ⟨248, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk248

theorem target_counts_kernel_chunk249 :
    ∀ i : Fin (min 128 (40547 - 128 * 249)),
      targetCountsMatch (classAt (targetKernelClass ⟨249, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk249

theorem target_counts_kernel_chunk250 :
    ∀ i : Fin (min 128 (40547 - 128 * 250)),
      targetCountsMatch (classAt (targetKernelClass ⟨250, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk250

theorem target_counts_kernel_chunk251 :
    ∀ i : Fin (min 128 (40547 - 128 * 251)),
      targetCountsMatch (classAt (targetKernelClass ⟨251, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk251


end TightCycleC5.Bridge.P33Arithmetic
