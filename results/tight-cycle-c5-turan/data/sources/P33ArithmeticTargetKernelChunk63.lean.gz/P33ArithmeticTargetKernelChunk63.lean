-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk252 :
    ∀ i : Fin (min 128 (40547 - 128 * 252)),
      targetCountsMatch (classAt (targetKernelClass ⟨252, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk252

theorem target_counts_kernel_chunk253 :
    ∀ i : Fin (min 128 (40547 - 128 * 253)),
      targetCountsMatch (classAt (targetKernelClass ⟨253, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk253

theorem target_counts_kernel_chunk254 :
    ∀ i : Fin (min 128 (40547 - 128 * 254)),
      targetCountsMatch (classAt (targetKernelClass ⟨254, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk254

theorem target_counts_kernel_chunk255 :
    ∀ i : Fin (min 128 (40547 - 128 * 255)),
      targetCountsMatch (classAt (targetKernelClass ⟨255, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk255


end TightCycleC5.Bridge.P33Arithmetic
