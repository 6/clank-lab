import KernelRowIndex
import KernelWitness23

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_23_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 64 * 256 + i.val))
      kernelWitness23Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_64

theorem kernelBlock_23_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 65 * 256 + i.val))
      kernelWitness23Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_65

theorem kernelBlock_23_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 66 * 256 + i.val))
      kernelWitness23Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_66

theorem kernelBlock_23_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 67 * 256 + i.val))
      kernelWitness23Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_67

theorem kernelBlock_23_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 68 * 256 + i.val))
      kernelWitness23Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_68

theorem kernelBlock_23_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 69 * 256 + i.val))
      kernelWitness23Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_69

theorem kernelBlock_23_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 70 * 256 + i.val))
      kernelWitness23Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_70

theorem kernelBlock_23_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 71 * 256 + i.val))
      kernelWitness23Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_71

theorem kernelBlock_23_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 72 * 256 + i.val))
      kernelWitness23Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_72

theorem kernelBlock_23_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 73 * 256 + i.val))
      kernelWitness23Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_73

theorem kernelBlock_23_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 74 * 256 + i.val))
      kernelWitness23Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_74

theorem kernelBlock_23_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 75 * 256 + i.val))
      kernelWitness23Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_75

theorem kernelBlock_23_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 76 * 256 + i.val))
      kernelWitness23Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_76

theorem kernelBlock_23_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 77 * 256 + i.val))
      kernelWitness23Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_77

theorem kernelBlock_23_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 78 * 256 + i.val))
      kernelWitness23Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_78

theorem kernelBlock_23_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 79 * 256 + i.val))
      kernelWitness23Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_79

theorem kernelBlock_23_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 80 * 256 + i.val))
      kernelWitness23Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_80

theorem kernelBlock_23_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 81 * 256 + i.val))
      kernelWitness23Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_81

theorem kernelBlock_23_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 82 * 256 + i.val))
      kernelWitness23Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_82

theorem kernelBlock_23_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 83 * 256 + i.val))
      kernelWitness23Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_83

theorem kernelBlock_23_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 84 * 256 + i.val))
      kernelWitness23Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_84

theorem kernelBlock_23_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 85 * 256 + i.val))
      kernelWitness23Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_85

theorem kernelBlock_23_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 86 * 256 + i.val))
      kernelWitness23Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_86

theorem kernelBlock_23_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 87 * 256 + i.val))
      kernelWitness23Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_87

theorem kernelBlock_23_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 88 * 256 + i.val))
      kernelWitness23Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_88

theorem kernelBlock_23_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 89 * 256 + i.val))
      kernelWitness23Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_89

theorem kernelBlock_23_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 90 * 256 + i.val))
      kernelWitness23Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_90

theorem kernelBlock_23_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 91 * 256 + i.val))
      kernelWitness23Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_91

theorem kernelBlock_23_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 92 * 256 + i.val))
      kernelWitness23Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_92

theorem kernelBlock_23_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 93 * 256 + i.val))
      kernelWitness23Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_93

theorem kernelBlock_23_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 94 * 256 + i.val))
      kernelWitness23Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_94

theorem kernelBlock_23_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (23 * 32768 + 95 * 256 + i.val))
      kernelWitness23Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_23_95

end TightCycleC5.Bridge.Cover
