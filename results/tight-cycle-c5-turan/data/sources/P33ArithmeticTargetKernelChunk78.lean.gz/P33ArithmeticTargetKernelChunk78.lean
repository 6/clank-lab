-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk312 :
    ∀ i : Fin (min 128 (40547 - 128 * 312)),
      targetCountsMatch (classAt (targetKernelClass ⟨312, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk312

theorem target_counts_kernel_chunk313 :
    ∀ i : Fin (min 128 (40547 - 128 * 313)),
      targetCountsMatch (classAt (targetKernelClass ⟨313, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk313

theorem target_counts_kernel_chunk314 :
    ∀ i : Fin (min 128 (40547 - 128 * 314)),
      targetCountsMatch (classAt (targetKernelClass ⟨314, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk314

theorem target_counts_kernel_chunk315 :
    ∀ i : Fin (min 128 (40547 - 128 * 315)),
      targetCountsMatch (classAt (targetKernelClass ⟨315, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk315


end TightCycleC5.Bridge.P33Arithmetic
