import P33FlagData
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace TightCycleC5.Bridge.P33Flag
open ColouredFlags

theorem basis2_size : basis2Data.size = 40 := by decide +kernel
theorem basis2_psd_data : ∀ i, basis2 i = P33PSD.flags2[i.val]! := by decide +kernel
theorem basis2_steps : ∀ i : Fin 39,
    basis2 i.castSucc < basis2 i.succ := by decide +kernel
theorem basis2_injective : Function.Injective basis2 :=
  (Fin.strictMono_iff_lt_succ.mpr basis2_steps).injective
theorem basis2_range : ∀ i, basis2 i < 256 := by decide +kernel
theorem basis2_canonical : ∀ i, canonical4 (BitVec.ofNat 8 (basis2 i)) = basis2 i := by decide +kernel
theorem basis2_root : ∀ i, basis2 i % 4 = type2 := by decide +kernel
#print axioms basis2_size
#print axioms basis2_psd_data
#print axioms basis2_steps
#print axioms basis2_injective
#print axioms basis2_range
#print axioms basis2_canonical
#print axioms basis2_root

theorem basis8_size : basis8Data.size = 128 := by decide +kernel
theorem basis8_psd_data : ∀ i, basis8 i = P33PSD.flags8[i.val]! := by decide +kernel
theorem basis8_steps : ∀ i : Fin 127,
    basis8 i.castSucc < basis8 i.succ := by decide +kernel
theorem basis8_injective : Function.Injective basis8 :=
  (Fin.strictMono_iff_lt_succ.mpr basis8_steps).injective
theorem basis8_range : ∀ i, basis8 i < 32768 := by decide +kernel
theorem basis8_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis8 i))).toNat = type8 := by decide +kernel
#print axioms basis8_size
#print axioms basis8_psd_data
#print axioms basis8_steps
#print axioms basis8_injective
#print axioms basis8_range
#print axioms basis8_root

theorem basis14_size : basis14Data.size = 128 := by decide +kernel
theorem basis14_psd_data : ∀ i, basis14 i = P33PSD.flags14[i.val]! := by decide +kernel
theorem basis14_steps : ∀ i : Fin 127,
    basis14 i.castSucc < basis14 i.succ := by decide +kernel
theorem basis14_injective : Function.Injective basis14 :=
  (Fin.strictMono_iff_lt_succ.mpr basis14_steps).injective
theorem basis14_range : ∀ i, basis14 i < 32768 := by decide +kernel
theorem basis14_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis14 i))).toNat = type14 := by decide +kernel
#print axioms basis14_size
#print axioms basis14_psd_data
#print axioms basis14_steps
#print axioms basis14_injective
#print axioms basis14_range
#print axioms basis14_root

theorem basis20_size : basis20Data.size = 100 := by decide +kernel
theorem basis20_psd_data : ∀ i, basis20 i = P33PSD.flags20[i.val]! := by decide +kernel
theorem basis20_steps : ∀ i : Fin 99,
    basis20 i.castSucc < basis20 i.succ := by decide +kernel
theorem basis20_injective : Function.Injective basis20 :=
  (Fin.strictMono_iff_lt_succ.mpr basis20_steps).injective
theorem basis20_range : ∀ i, basis20 i < 32768 := by decide +kernel
theorem basis20_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis20 i))).toNat = type20 := by decide +kernel
#print axioms basis20_size
#print axioms basis20_psd_data
#print axioms basis20_steps
#print axioms basis20_injective
#print axioms basis20_range
#print axioms basis20_root

theorem basis26_size : basis26Data.size = 78 := by decide +kernel
theorem basis26_psd_data : ∀ i, basis26 i = P33PSD.flags26[i.val]! := by decide +kernel
theorem basis26_steps : ∀ i : Fin 77,
    basis26 i.castSucc < basis26 i.succ := by decide +kernel
theorem basis26_injective : Function.Injective basis26 :=
  (Fin.strictMono_iff_lt_succ.mpr basis26_steps).injective
theorem basis26_range : ∀ i, basis26 i < 32768 := by decide +kernel
theorem basis26_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis26 i))).toNat = type26 := by decide +kernel
#print axioms basis26_size
#print axioms basis26_psd_data
#print axioms basis26_steps
#print axioms basis26_injective
#print axioms basis26_range
#print axioms basis26_root

theorem basis32_size : basis32Data.size = 78 := by decide +kernel
theorem basis32_psd_data : ∀ i, basis32 i = P33PSD.flags32[i.val]! := by decide +kernel
theorem basis32_steps : ∀ i : Fin 77,
    basis32 i.castSucc < basis32 i.succ := by decide +kernel
theorem basis32_injective : Function.Injective basis32 :=
  (Fin.strictMono_iff_lt_succ.mpr basis32_steps).injective
theorem basis32_range : ∀ i, basis32 i < 32768 := by decide +kernel
theorem basis32_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis32 i))).toNat = type32 := by decide +kernel
#print axioms basis32_size
#print axioms basis32_psd_data
#print axioms basis32_steps
#print axioms basis32_injective
#print axioms basis32_range
#print axioms basis32_root

end TightCycleC5.Bridge.P33Flag
