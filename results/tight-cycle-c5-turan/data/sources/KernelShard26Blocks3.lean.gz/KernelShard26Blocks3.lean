import KernelRowIndex
import KernelWitness26

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_26_96 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 96 * 256 + i.val))
      kernelWitness26Row96[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_96

theorem kernelBlock_26_97 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 97 * 256 + i.val))
      kernelWitness26Row97[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_97

theorem kernelBlock_26_98 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 98 * 256 + i.val))
      kernelWitness26Row98[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_98

theorem kernelBlock_26_99 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 99 * 256 + i.val))
      kernelWitness26Row99[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_99

theorem kernelBlock_26_100 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 100 * 256 + i.val))
      kernelWitness26Row100[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_100

theorem kernelBlock_26_101 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 101 * 256 + i.val))
      kernelWitness26Row101[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_101

theorem kernelBlock_26_102 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 102 * 256 + i.val))
      kernelWitness26Row102[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_102

theorem kernelBlock_26_103 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 103 * 256 + i.val))
      kernelWitness26Row103[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_103

theorem kernelBlock_26_104 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 104 * 256 + i.val))
      kernelWitness26Row104[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_104

theorem kernelBlock_26_105 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 105 * 256 + i.val))
      kernelWitness26Row105[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_105

theorem kernelBlock_26_106 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 106 * 256 + i.val))
      kernelWitness26Row106[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_106

theorem kernelBlock_26_107 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 107 * 256 + i.val))
      kernelWitness26Row107[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_107

theorem kernelBlock_26_108 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 108 * 256 + i.val))
      kernelWitness26Row108[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_108

theorem kernelBlock_26_109 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 109 * 256 + i.val))
      kernelWitness26Row109[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_109

theorem kernelBlock_26_110 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 110 * 256 + i.val))
      kernelWitness26Row110[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_110

theorem kernelBlock_26_111 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 111 * 256 + i.val))
      kernelWitness26Row111[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_111

theorem kernelBlock_26_112 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 112 * 256 + i.val))
      kernelWitness26Row112[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_112

theorem kernelBlock_26_113 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 113 * 256 + i.val))
      kernelWitness26Row113[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_113

theorem kernelBlock_26_114 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 114 * 256 + i.val))
      kernelWitness26Row114[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_114

theorem kernelBlock_26_115 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 115 * 256 + i.val))
      kernelWitness26Row115[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_115

theorem kernelBlock_26_116 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 116 * 256 + i.val))
      kernelWitness26Row116[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_116

theorem kernelBlock_26_117 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 117 * 256 + i.val))
      kernelWitness26Row117[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_117

theorem kernelBlock_26_118 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 118 * 256 + i.val))
      kernelWitness26Row118[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_118

theorem kernelBlock_26_119 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 119 * 256 + i.val))
      kernelWitness26Row119[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_119

theorem kernelBlock_26_120 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 120 * 256 + i.val))
      kernelWitness26Row120[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_120

theorem kernelBlock_26_121 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 121 * 256 + i.val))
      kernelWitness26Row121[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_121

theorem kernelBlock_26_122 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 122 * 256 + i.val))
      kernelWitness26Row122[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_122

theorem kernelBlock_26_123 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 123 * 256 + i.val))
      kernelWitness26Row123[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_123

theorem kernelBlock_26_124 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 124 * 256 + i.val))
      kernelWitness26Row124[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_124

theorem kernelBlock_26_125 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 125 * 256 + i.val))
      kernelWitness26Row125[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_125

theorem kernelBlock_26_126 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 126 * 256 + i.val))
      kernelWitness26Row126[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_126

theorem kernelBlock_26_127 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (26 * 32768 + 127 * 256 + i.val))
      kernelWitness26Row127[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_26_127

end TightCycleC5.Bridge.Cover
