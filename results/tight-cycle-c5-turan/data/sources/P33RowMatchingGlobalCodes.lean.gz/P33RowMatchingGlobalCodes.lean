import P33RowMatchingCodes
import P33RowsGlobal

namespace TightCycleC5.Bridge.P33RowMatching
open Finset

/-- Two root colours have their original labelled order, with no edge bit. -/
theorem encoded_two (m c x u : Nat) :
    P33Arithmetic.encoded m c [x,u] = P33Arithmetic.colour c x + 2*P33Arithmetic.colour c u := by
  simp [P33Arithmetic.encoded, P33Arithmetic.triples, List.range_succ, Nat.shiftLeft_eq, Nat.mul_comm]

theorem encoded_three (m c a b d : Nat) :
    P33Arithmetic.encoded m c [a,b,d] =
      P33Arithmetic.colour c a + 2*P33Arithmetic.colour c b + 4*P33Arithmetic.colour c d +
        8*P33Arithmetic.edge m a b d := by
  simp [P33Arithmetic.encoded, P33Arithmetic.triples, List.range_succ, Nat.shiftLeft_eq]
  omega

theorem canonical_free_three (m c a b d : Nat) :
    P33Arithmetic.canonical m c [] [a,b,d] =
      min (P33Arithmetic.encoded m c [a,b,d])
        (min (P33Arithmetic.encoded m c [a,d,b])
          (min (P33Arithmetic.encoded m c [b,a,d])
            (min (P33Arithmetic.encoded m c [b,d,a])
              (min (P33Arithmetic.encoded m c [d,a,b])
                (P33Arithmetic.encoded m c [d,b,a]))))) := by
  have hp : ([a,b,d] : List Nat).permutations =
      [[a,b,d],[b,a,d],[d,b,a],[b,d,a],[d,a,b],[a,d,b]] := by
    simp [List.permutations, List.permutationsAux_cons, List.permutationsAux_nil, List.permutationsAux2]
  rw [P33Arithmetic.canonical, hp]
  simp
  ac_rfl

theorem encoded_raw3 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (a b c : Fin 6) (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c) :
    P33Arithmetic.encoded K.mask K.colours [(p a).val,(p b).val,(p c).val] =
      ((structureAt K p).color a).toNat + 2*((structureAt K p).color b).toNat +
        4*((structureAt K p).color c).toNat + 8*((structureAt K p).edge {a,b,c}).toNat := by
  rw [encoded_three, edge_at K p a b c hab hac hbc]
  simp only [colour_at]

/-- The minimum raw three-code is precisely the source's outside-count code. -/
theorem canonical_global (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) :
    P33Arithmetic.canonical K.mask K.colours [] [(p 3).val,(p 4).val,(p 5).val] =
      P33Rows.globalCode (fun x u v => (structureAt K p).edge {x,u,v})
        (structureAt K p).color 3 4 5 := by
  rw [canonical_free_three]
  rw [encoded_raw3 K p 3 4 5 (by decide) (by decide) (by decide),
    encoded_raw3 K p 3 5 4 (by decide) (by decide) (by decide),
    encoded_raw3 K p 4 3 5 (by decide) (by decide) (by decide),
    encoded_raw3 K p 4 5 3 (by decide) (by decide) (by decide),
    encoded_raw3 K p 5 3 4 (by decide) (by decide) (by decide),
    encoded_raw3 K p 5 4 3 (by decide) (by decide) (by decide)]
  rw [show ({3,5,4} : Finset (Fin 6)) = {3,4,5} by decide +kernel,
    show ({4,3,5} : Finset (Fin 6)) = {3,4,5} by decide +kernel,
    show ({4,5,3} : Finset (Fin 6)) = {3,4,5} by decide +kernel,
    show ({5,3,4} : Finset (Fin 6)) = {3,4,5} by decide +kernel,
    show ({5,4,3} : Finset (Fin 6)) = {3,4,5} by decide +kernel]
  cases h3 : (structureAt K p).color 3 <;>
    cases h4 : (structureAt K p).color 4 <;>
    cases h5 : (structureAt K p).color 5 <;>
    cases he : (structureAt K p).edge {3,4,5} <;>
    norm_num [P33Rows.globalCode, h3, h4, h5, he]

#print axioms encoded_two
#print axioms encoded_three
#print axioms canonical_free_three
#print axioms encoded_raw3
#print axioms canonical_global
end TightCycleC5.Bridge.P33RowMatching
