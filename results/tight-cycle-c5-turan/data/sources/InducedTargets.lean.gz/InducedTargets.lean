import TargetNormalization

/-! The six-vertex P33 target is literally the bad/missing count of the
induced graph and induced cut, not an assumed row correspondence. -/
namespace TightCycleC5.Bridge
open Finset
variable {k n : ℕ}

def inducedGraph (σ : Fin k ↪ Fin n) (H : Finset (Finset (Fin n))) : Finset (Finset (Fin k)) :=
  univ.filter (fun e => e.map σ ∈ H)

def inducedCut (σ : Fin k ↪ Fin n) (S : Finset (Fin n)) : Finset (Fin k) :=
  univ.filter (fun i => σ i ∈ S)

theorem inducedGraph_three (σ : Fin k ↪ Fin n) (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) : IsThreeGraph (inducedGraph σ H) := by
  intro e he
  have h := hH _ (mem_filter.mp he).2
  simpa using h

theorem inducedCut_inter_map (σ : Fin k ↪ Fin n) (S : Finset (Fin n)) (e : Finset (Fin k)) :
    (e ∩ inducedCut σ S).map σ = e.map σ ∩ S := by
  ext a
  simp only [mem_map, mem_inter, inducedCut, mem_filter, mem_univ, true_and]
  constructor
  · rintro ⟨i, ⟨hi, hS⟩, rfl⟩
    exact ⟨⟨i, hi, rfl⟩, hS⟩
  · rintro ⟨⟨i, hi, rfl⟩, hS⟩
    exact ⟨i, ⟨hi, hS⟩, rfl⟩

theorem inducedCut_inter_card (σ : Fin k ↪ Fin n) (S : Finset (Fin n)) (e : Finset (Fin k)) :
    (e ∩ inducedCut σ S).card = (e.map σ ∩ S).card := by
  rw [← inducedCut_inter_map, card_map]

theorem tripleTarget_induced (σ : Fin k ↪ Fin n) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (c : ℝ) (e : Finset (Fin k)) :
    tripleTarget (inducedGraph σ H) (inducedCut σ S) c e = tripleTarget H S c (e.map σ) := by
  simp only [tripleTarget, inducedCut_inter_card, inducedGraph,
    mem_filter, mem_univ, true_and]

theorem sixSubsetMean_induced (σ : Fin 6 ↪ Fin n) (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (S : Finset (Fin n)) (c : ℝ) :
    sixSubsetMean (tripleTarget H S c) σ =
      ((badCount (inducedGraph σ H) (inducedCut σ S) : ℝ) -
        c * (missCount (inducedGraph σ H) (inducedCut σ S) : ℝ)) / 20 := by
  rw [← tripleTarget_sum _ (inducedGraph_three σ H hH) (inducedCut σ S) c]
  unfold sixSubsetMean
  simp only [tripleTarget_induced]

/-- The exact target count of the induced labelled six-graph, averaged
uniformly, is the global target divided by C(n,3). -/
theorem p33_induced_target_normalization (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (S : Finset (Fin n)) (c : ℝ) (hn : 6 ≤ n) :
    uniformMean (fun σ : Fin 6 ↪ Fin n =>
      ((badCount (inducedGraph σ H) (inducedCut σ S) : ℝ) -
        c * (missCount (inducedGraph σ H) (inducedCut σ S) : ℝ)) / 20) =
      ((badCount H S : ℝ) - c * (missCount H S : ℝ)) / (n.choose 3 : ℝ) := by
  have he : (fun σ : Fin 6 ↪ Fin n =>
      ((badCount (inducedGraph σ H) (inducedCut σ S) : ℝ) -
        c * (missCount (inducedGraph σ H) (inducedCut σ S) : ℝ)) / 20) =
      sixSubsetMean (tripleTarget H S c) := by
    funext σ
    exact (sixSubsetMean_induced σ H hH S c).symm
  rw [he]
  exact p33_target_normalization H hH S c hn

#print axioms inducedGraph_three
#print axioms inducedCut_inter_map
#print axioms inducedCut_inter_card
#print axioms tripleTarget_induced
#print axioms sixSubsetMean_induced
#print axioms p33_induced_target_normalization
end TightCycleC5.Bridge
