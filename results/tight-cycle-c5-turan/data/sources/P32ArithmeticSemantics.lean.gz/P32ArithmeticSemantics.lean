import P32ArithmeticCore

/-! Common-denominator and genuine-permutation semantics of the literal
recomputation. This does not identify these expressions with the parent's
row descriptors or discharge any global sampling/asymptotic obligation. -/
namespace TightCycleC5.Bridge.P32Arithmetic
open Finset
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-- The signed raw numerators carry precisely the frozen proof's rational
normalizations, including Q/factorScale² and both probability/weight scales. -/
def literalResidual (G : LabelledStructure 6) : ℚ :=
  let f := features G
  (selectorNumerator f : ℚ) / (5 * (probScale : ℚ)^3 * weightScale) -
    (clNumerator f : ℚ) / weightScale -
    (bookNumerator f : ℚ) / ((weightScale : ℚ) * probScale^2) -
    (densityNumerator f : ℚ) / (10000 * (weightScale : ℚ)) -
    ((psdNumerator f).getD 0 : ℚ) / (factorScale : ℚ)^2

def literalRow (G : LabelledStructure 6) : ℝ := (literalResidual G : ℝ)

/-- Literal selector mixture, normalized by 5 P³ W. This name does not
assert equality to P32Selector.margin; that is a separate semantic obligation. -/
def selectorMargin (G : LabelledStructure 6) : ℝ :=
  (((selectorNumerator (features G) : ℚ) /
    (5 * (probScale : ℚ)^3 * weightScale) : ℚ) : ℝ)

/-- The 510 CL3 and 510 CL4 rows, with multiplier y/W. -/
def clContribution (G : LabelledStructure 6) : ℝ :=
  (((clNumerator (features G) : ℚ) / weightScale : ℚ) : ℝ)

/-- The 8464 indicator rows and 25 weighted rows, with probabilities /P
and multiplier /W; the indicator part carries the compensating P². -/
def bookContribution (G : LabelledStructure 6) : ℝ :=
  (((bookNumerator (features G) : ℚ) /
    ((weightScale : ℚ) * probScale^2) : ℚ) : ℝ)

/-- Both target-edge density rows, with threshold exactly 4641/10000. -/
def densityContribution (G : LabelledStructure 6) : ℝ :=
  (((densityNumerator (features G) : ℚ) / (10000 * (weightScale : ℚ)) : ℚ) : ℝ)

/-- The six signed matrix rows Q/F². ClassStatement separately checks that
all required flag lookups succeed, before any default value can be used. -/
def psdContribution (G : LabelledStructure 6) : ℝ :=
  ((((psdNumerator (features G)).getD 0 : ℚ) / (factorScale : ℚ)^2 : ℚ) : ℝ)

theorem literalRow_decomposition (G : LabelledStructure 6) :
    literalRow G = selectorMargin G - clContribution G - bookContribution G -
      densityContribution G - psdContribution G := by
  simp only [literalRow, literalResidual, selectorMargin, clContribution,
    bookContribution, densityContribution, psdContribution, Rat.cast_sub]

/-- Literal class masks are exactly the accepted class-cover masks. -/
theorem classes_eq_family : classes.toArray = Family.classes := by rfl

theorem classStructure_eq_representative (i : Fin 835) :
    classStructure i = MaskEncoding.decodeStructure (Cover.representative i) 0 := by
  unfold classStructure Cover.representative
  rw [← classes_eq_family]
  apply congrArg (fun m : ℕ => MaskEncoding.decodeStructure (BitVec.ofNat 20 m) 0)
  change classes.toArray[i.val] = classes.toArray[i.val]!
  exact (getElem!_pos _ _ (by rw [classes.size_toArray]; exact i.isLt)).symm

theorem signed_scaling (a b c d e : ℤ) :
    ((selectorScale*a - (clScale*b + bookScale*c + densityScale*d + psdScale*e) : ℤ) : ℚ) /
      (scale : ℚ) =
    (a : ℚ) / (5 * (probScale : ℚ)^3 * weightScale) -
      (b : ℚ) / weightScale - (c : ℚ) / ((weightScale : ℚ)*probScale^2) -
      (d : ℚ) / (10000*(weightScale : ℚ)) - (e : ℚ)/(factorScale : ℚ)^2 := by
  norm_num [selectorScale, clScale, bookScale, densityScale, psdScale,
    probScale, weightScale, factorScale, scale]
  ring

theorem evaluate_scaled (G : LabelledStructure 6) :
    (((evaluate G).left - (evaluate G).right : ℤ) : ℚ) / scale = literalResidual G := by
  exact signed_scaling (selectorNumerator (features G)) (clNumerator (features G))
    (bookNumerator (features G)) (densityNumerator (features G))
    ((psdNumerator (features G)).getD 0)

theorem classValues_get (i : Fin 835) (j : Fin 720) :
    (classValues i).get j = evaluate (Cover.kernelPermutation j • classStructure i) := by
  simp [classValues]

/-- Checked lookup success is part of the condition, not a zero-default assumption. -/
theorem lookups_succeed_of_check (i : Fin 835) (h : ClassStatement i) (j : Fin 720) :
    (psdNumerator (features (Cover.kernelPermutation j • classStructure i))).isSome = true := by
  have hv := h.1 j
  simpa only [classValues_get, evaluate] using hv

/-- Exact literal residual identity before casting to the real uniform mean. -/
theorem rational_class_identity_of_check (i : Fin 835) (h : ClassStatement i) :
    (∑ j : Fin 720, literalResidual (Cover.kernelPermutation j • classStructure i)) / 720 =
      1/10000 + (slacks.get i : ℚ) / (720 * (scale : ℚ)) := by
  have hs : (∑ j : Fin 720,
      ((evaluate (Cover.kernelPermutation j • classStructure i)).left -
        (evaluate (Cover.kernelPermutation j • classStructure i)).right)) =
      720*margin + slacks.get i := by
    simpa only [classValues_get] using h.2.2.1
  have hsQ : (∑ j : Fin 720,
      (((evaluate (Cover.kernelPermutation j • classStructure i)).left -
        (evaluate (Cover.kernelPermutation j • classStructure i)).right : ℤ) : ℚ)) =
      ((720*margin + slacks.get i : ℤ) : ℚ) := by exact_mod_cast hs
  simp_rw [← evaluate_scaled]
  rw [← Finset.sum_div, hsQ]
  norm_num [scale, margin]
  ring

/-- Reindex by the actual accepted equivalence, not a table enumeration premise. -/
theorem class_mean_identity_of_check (i : Fin 835) (h : ClassStatement i) :
    uniformMean (fun p : Equiv.Perm (Fin 6) => literalRow (p • classStructure i)) =
      1/10000 + (slacks.get i : ℝ) / (720 * (scale : ℝ)) := by
  unfold literalRow
  rw [Cover.PermutationEnumeration.uniformMean_rat_eq_sum_div_720]
  rw [rational_class_identity_of_check i h]
  push_cast
  rfl

theorem class_mean_lower_of_check (i : Fin 835) (h : ClassStatement i) :
    (1 : ℝ)/10000 ≤
      uniformMean (fun p : Equiv.Perm (Fin 6) => literalRow (p • classStructure i)) := by
  rw [class_mean_identity_of_check i h]
  have hs : (0 : ℝ) ≤ (slacks.get i : ℝ) := by exact_mod_cast h.2.2.2
  have hd : (0 : ℝ) ≤ 720 * (scale : ℝ) := by norm_num [scale]
  exact le_add_of_nonneg_right (div_nonneg hs hd)

/-- Selector-side class inequality in the real normalization required by
Theorem A. Identifying these five literal functions with the parent's row
interfaces remains a separate, explicit semantic step. -/
theorem class_margin_bound_of_check (i : Fin 835) (h : ClassStatement i) :
    (1 : ℝ)/10000 +
      uniformMean (fun p : Equiv.Perm (Fin 6) => clContribution (p • classStructure i)) +
      uniformMean (fun p : Equiv.Perm (Fin 6) => bookContribution (p • classStructure i)) +
      uniformMean (fun p : Equiv.Perm (Fin 6) => densityContribution (p • classStructure i)) +
      uniformMean (fun p : Equiv.Perm (Fin 6) => psdContribution (p • classStructure i)) ≤
      uniformMean (fun p : Equiv.Perm (Fin 6) => selectorMargin (p • classStructure i)) := by
  have hbound := class_mean_lower_of_check i h
  simp only [literalRow_decomposition, uniformMean, Finset.sum_sub_distrib,
    sub_div] at hbound
  dsimp [uniformMean]
  linarith

/-- Perturbing the checked coefficient by one contradicts the actual sum. -/
theorem rejects_changed_coefficient_of_check (i : Fin 835) (h : ClassStatement i) :
    ¬ (∑ j : Fin 720, ((classValues i).get j).left) = coefficients.get i + 1 := by
  have hc := h.2.1
  omega

/-- Perturbing the stored slack by one violates the same checked identity. -/
theorem rejects_changed_slack_of_check (i : Fin 835) (h : ClassStatement i) :
    ¬ (∑ j : Fin 720, (((classValues i).get j).left - ((classValues i).get j).right)) =
      720*margin + slacks.get i + 1 := by
  have hc := h.2.2.1
  omega

/-- A missing flag is rejected rather than silently interpreted as Q entry zero. -/
theorem rejects_unsupported_flag : matrixLookup (blocks.get 2) 44 0 = none := by
  decide +kernel

#print axioms literalRow_decomposition
#print axioms classes_eq_family
#print axioms classStructure_eq_representative
#print axioms class_margin_bound_of_check
#print axioms signed_scaling
#print axioms evaluate_scaled
#print axioms classValues_get
#print axioms lookups_succeed_of_check
#print axioms rational_class_identity_of_check
#print axioms class_mean_identity_of_check
#print axioms class_mean_lower_of_check
#print axioms rejects_changed_coefficient_of_check
#print axioms rejects_changed_slack_of_check
#print axioms rejects_unsupported_flag
end TightCycleC5.Bridge.P32Arithmetic
