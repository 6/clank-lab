-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk280 :
    ∀ i : Fin (min 128 (40547 - 128 * 280)),
      targetCountsMatch (classAt (targetKernelClass ⟨280, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk280

theorem target_counts_kernel_chunk281 :
    ∀ i : Fin (min 128 (40547 - 128 * 281)),
      targetCountsMatch (classAt (targetKernelClass ⟨281, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk281

theorem target_counts_kernel_chunk282 :
    ∀ i : Fin (min 128 (40547 - 128 * 282)),
      targetCountsMatch (classAt (targetKernelClass ⟨282, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk282

theorem target_counts_kernel_chunk283 :
    ∀ i : Fin (min 128 (40547 - 128 * 283)),
      targetCountsMatch (classAt (targetKernelClass ⟨283, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk283


end TightCycleC5.Bridge.P33Arithmetic
