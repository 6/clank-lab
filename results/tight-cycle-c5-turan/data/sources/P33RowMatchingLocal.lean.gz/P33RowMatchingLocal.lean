import P33RowMatchingCodes
import P33RowMatchingData
import P33RowMatchingLookup
import P33RowMatchingFeatures
import P33Rows

namespace TightCycleC5.Bridge.P33RowMatching
open Finset

/-- The exact local query made by the arithmetic evaluator. -/
def localKey (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) : Nat :=
  P33Arithmetic.canonical K.mask K.colours [(p 0).val] [(p 3).val,(p 4).val,(p 5).val]

def localQueryValid (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) : Prop :=
  P33Arithmetic.lookup P33Arithmetic.localFlags[colourAt K p 0]! (localKey K p) <
    P33Arithmetic.localFlags[colourAt K p 0]!.size

theorem local_index_iff (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (i : Fin 80) (hv : localQueryValid K p) :
    i.val = (P33Arithmetic.featuresAt P33Arithmetic.localFlags P33Arithmetic.globalFlags
      P33Arithmetic.blocks K p).localIndex ↔
    (structureAt K p).color 0 = P33Rows.localColors[i.val]! ∧
      P33Rows.canonicalLocal (fun x u v => (structureAt K p).edge {x,u,v})
        (structureAt K p).color 0 3 4 5 = P33Rows.localFlags[i.val]! := by
  rw [features_localIndex]
  change (i.val = 40 * colourAt K p 0 + P33Arithmetic.lookup
    P33Arithmetic.localFlags[colourAt K p 0]! (localKey K p)) ↔ _
  have hc : colourAt K p 0 < 2 := by
    rw [colourAt, colour_at]
    have := Bool.toNat_le ((structureAt K p).color 0)
    omega
  have hs := (local_tables_checked.2 ⟨colourAt K p 0, hc⟩).1
  have hn := (local_tables_checked.2 ⟨colourAt K p 0, hc⟩).2
  have hli : P33Arithmetic.lookup P33Arithmetic.localFlags[colourAt K p 0]!
      (localKey K p) < 40 := by simpa only [localQueryValid, hs] using hv
  have ha := local_tables_aligned i
  constructor
  · intro hi
    have hq : i.val / 40 = colourAt K p 0 := by omega
    have hm : i.val % 40 = P33Arithmetic.lookup
        P33Arithmetic.localFlags[colourAt K p 0]! (localKey K p) := by omega
    have hk : P33Rows.localFlags[i.val]! = localKey K p := by
      rw [← ha.1, hq, hm]
      exact lookup_read _ _ hv
    have hroot : ((structureAt K p).color 0).toNat = P33Rows.localColors[i.val]!.toNat := by
      rw [ha.2, hq]
      exact (colour_at K p 0).symm
    constructor
    · exact (show Function.Injective Bool.toNat by decide +kernel) hroot
    · exact (canonical_local K p).symm.trans hk.symm
  · rintro ⟨hroot,hflag⟩
    have hq : colourAt K p 0 = i.val / 40 := by
      rw [colourAt, colour_at, hroot, ha.2]
    have hkey : localKey K p = (P33Arithmetic.localFlags[colourAt K p 0]!)[i.val % 40]! := by
      rw [localKey, canonical_local, hflag, ← ha.1, hq]
    have hm : P33Arithmetic.lookup P33Arithmetic.localFlags[colourAt K p 0]!
        (localKey K p) = i.val % 40 :=
      (lookup_eq_iff _ hn _ _ (by rw [hs]; omega) hv).2 hkey
    change i.val = 40 * colourAt K p 0 + P33Arithmetic.lookup
      P33Arithmetic.localFlags[colourAt K p 0]! (localKey K p)
    omega

theorem localSign_real (ls : Array (Array Nat)) (gs : Array Nat)
    (bs : Array P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) :
    ((P33Arithmetic.featuresAt ls gs bs K p).localSign : ℝ) =
      P33Rows.literalEll (fun x u v => (structureAt K p).edge {x,u,v})
        (structureAt K p).color 0 1 2 := by
  rw [features_localSign]
  simp only [edgeAt, colourAt, edge_at K p 0 1 2 (by decide) (by decide) (by decide), colour_at]
  cases h0 : (structureAt K p).color 0 <;>
    cases h1 : (structureAt K p).color 1 <;>
    cases h2 : (structureAt K p).color 2 <;>
    cases he : (structureAt K p).edge {0,1,2} <;>
    norm_num [P33Rows.literalEll, h0, h1, h2, he]

/-- All eighty literal local rows, including the exact 10^9 normalization. -/
theorem local_row_match (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (i : Fin 80) (hv : localQueryValid K p) :
    (P33Arithmetic.inequalityRow (P33Arithmetic.featuresAt P33Arithmetic.localFlags
      P33Arithmetic.globalFlags P33Arithmetic.blocks K p) i.val : ℝ) / 1000000000 =
      P33Rows.sourceLocalRow i (structureAt K p) := by
  rw [P33Arithmetic.inequalityRow, if_pos i.isLt]
  change _ = P33Rows.literalEll _ _ 0 1 2 *
    (if (structureAt K p).color 0 = P33Rows.localColors[i.val]! ∧
      P33Rows.canonicalLocal (fun x u v => (structureAt K p).edge {x,u,v})
        (structureAt K p).color 0 3 4 5 = P33Rows.localFlags[i.val]! then 1 else 0)
  have hcond := local_index_iff K p i hv
  by_cases hi : i.val = (P33Arithmetic.featuresAt P33Arithmetic.localFlags P33Arithmetic.globalFlags
      P33Arithmetic.blocks K p).localIndex
  · rw [if_pos hi, if_pos (hcond.mp hi)]
    push_cast
    rw [localSign_real]
    ring
  · rw [if_neg hi, if_neg (fun h => hi (hcond.mpr h))]
    norm_num

#print axioms local_index_iff
#print axioms localSign_real
#print axioms local_row_match
end TightCycleC5.Bridge.P33RowMatching
