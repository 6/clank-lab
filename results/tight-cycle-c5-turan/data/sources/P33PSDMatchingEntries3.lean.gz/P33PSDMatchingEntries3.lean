-- Generated from the pinned P33 manifest; untrusted proof quotation.
import P33PSDMatchingCore
import P33FlagData
import P33ArithmeticBlocks0
import P33ArithmeticBlocks1
import P33ArithmeticBlocks2
import P33ArithmeticBlocks3
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000
namespace TightCycleC5.Bridge.P33PSDMatching
open Finset Matrix

theorem source_metadata3 :
    P33Arithmetic.block3.flags = P33Flag.basis3Data ∧
    P33Arithmetic.block3.roots = 4 ∧
    P33Arithmetic.block3.typeCode = P33Flag.type3 := by decide +kernel
theorem source_terms3 : ∀ k : Fin 1, ∀ i j : Fin 128,
    P33Arithmetic.termEntry P33Arithmetic.block3.terms[k.val]! i.val j.val =
      (P33PSD.weights3 k : ℤ) * P33PSD.terms3 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry3 : ∀ i j : Fin 128,
    P33Arithmetic.blockEntry P33Arithmetic.block3 i.val j.val = P33PSD.q3 i j :=
  blockEntry_eq_sos P33Arithmetic.block3 P33PSD.weights3 P33PSD.terms3 rfl source_terms3
#print axioms source_metadata3
#print axioms source_terms3
#print axioms source_entry3

theorem source_metadata9 :
    P33Arithmetic.block9.flags = P33Flag.basis9Data ∧
    P33Arithmetic.block9.roots = 4 ∧
    P33Arithmetic.block9.typeCode = P33Flag.type9 := by decide +kernel
theorem source_terms9 : ∀ k : Fin 14, ∀ i j : Fin 128,
    P33Arithmetic.termEntry P33Arithmetic.block9.terms[k.val]! i.val j.val =
      (P33PSD.weights9 k : ℤ) * P33PSD.terms9 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry9 : ∀ i j : Fin 128,
    P33Arithmetic.blockEntry P33Arithmetic.block9 i.val j.val = P33PSD.q9 i j :=
  blockEntry_eq_sos P33Arithmetic.block9 P33PSD.weights9 P33PSD.terms9 rfl source_terms9
#print axioms source_metadata9
#print axioms source_terms9
#print axioms source_entry9

theorem source_metadata15 :
    P33Arithmetic.block15.flags = P33Flag.basis15Data ∧
    P33Arithmetic.block15.roots = 4 ∧
    P33Arithmetic.block15.typeCode = P33Flag.type15 := by decide +kernel
theorem source_terms15 : ∀ k : Fin 0, ∀ i j : Fin 128,
    P33Arithmetic.termEntry P33Arithmetic.block15.terms[k.val]! i.val j.val =
      (P33PSD.weights15 k : ℤ) * P33PSD.terms15 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry15 : ∀ i j : Fin 128,
    P33Arithmetic.blockEntry P33Arithmetic.block15 i.val j.val = P33PSD.q15 i j :=
  blockEntry_eq_sos P33Arithmetic.block15 P33PSD.weights15 P33PSD.terms15 rfl source_terms15
#print axioms source_metadata15
#print axioms source_terms15
#print axioms source_entry15

theorem source_metadata21 :
    P33Arithmetic.block21.flags = P33Flag.basis21Data ∧
    P33Arithmetic.block21.roots = 4 ∧
    P33Arithmetic.block21.typeCode = P33Flag.type21 := by decide +kernel
theorem source_terms21 : ∀ k : Fin 10, ∀ i j : Fin 100,
    P33Arithmetic.termEntry P33Arithmetic.block21.terms[k.val]! i.val j.val =
      (P33PSD.weights21 k : ℤ) * P33PSD.terms21 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry21 : ∀ i j : Fin 100,
    P33Arithmetic.blockEntry P33Arithmetic.block21 i.val j.val = P33PSD.q21 i j :=
  blockEntry_eq_sos P33Arithmetic.block21 P33PSD.weights21 P33PSD.terms21 rfl source_terms21
#print axioms source_metadata21
#print axioms source_terms21
#print axioms source_entry21

theorem source_metadata27 :
    P33Arithmetic.block27.flags = P33Flag.basis27Data ∧
    P33Arithmetic.block27.roots = 4 ∧
    P33Arithmetic.block27.typeCode = P33Flag.type27 := by decide +kernel
theorem source_terms27 : ∀ k : Fin 13, ∀ i j : Fin 78,
    P33Arithmetic.termEntry P33Arithmetic.block27.terms[k.val]! i.val j.val =
      (P33PSD.weights27 k : ℤ) * P33PSD.terms27 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry27 : ∀ i j : Fin 78,
    P33Arithmetic.blockEntry P33Arithmetic.block27 i.val j.val = P33PSD.q27 i j :=
  blockEntry_eq_sos P33Arithmetic.block27 P33PSD.weights27 P33PSD.terms27 rfl source_terms27
#print axioms source_metadata27
#print axioms source_terms27
#print axioms source_entry27

theorem source_metadata33 :
    P33Arithmetic.block33.flags = P33Flag.basis33Data ∧
    P33Arithmetic.block33.roots = 4 ∧
    P33Arithmetic.block33.typeCode = P33Flag.type33 := by decide +kernel
theorem source_terms33 : ∀ k : Fin 4, ∀ i j : Fin 60,
    P33Arithmetic.termEntry P33Arithmetic.block33.terms[k.val]! i.val j.val =
      (P33PSD.weights33 k : ℤ) * P33PSD.terms33 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry33 : ∀ i j : Fin 60,
    P33Arithmetic.blockEntry P33Arithmetic.block33 i.val j.val = P33PSD.q33 i j :=
  blockEntry_eq_sos P33Arithmetic.block33 P33PSD.weights33 P33PSD.terms33 rfl source_terms33
#print axioms source_metadata33
#print axioms source_terms33
#print axioms source_entry33

end TightCycleC5.Bridge.P33PSDMatching
