import Mathlib
set_option maxHeartbeats 1000000

/-! Literal coloured rooted codes. Vertex bits precede lexicographic edge bits;
true is colour 1 (outside S). Maps may repeat vertices, so the auxiliary PSD
keys are total even on overlapping free pairs. -/
namespace TightCycleC5.Bridge.ColouredFlags
open Finset

variable {V : Type*} [DecidableEq V]

def bits4 (E : Finset V → Bool) (C : V → Bool) (v : Fin 4 → V) : Fin 8 → Bool :=
  ![C (v 0), C (v 1), C (v 2), C (v 3),
    E {v 0, v 1, v 2}, E {v 0, v 1, v 3},
    E {v 0, v 2, v 3}, E {v 1, v 2, v 3}]

def bits5 (E : Finset V → Bool) (C : V → Bool) (v : Fin 5 → V) : Fin 15 → Bool :=
  ![C (v 0), C (v 1), C (v 2), C (v 3), C (v 4),
    E {v 0, v 1, v 2}, E {v 0, v 1, v 3}, E {v 0, v 1, v 4},
    E {v 0, v 2, v 3}, E {v 0, v 2, v 4}, E {v 0, v 3, v 4},
    E {v 1, v 2, v 3}, E {v 1, v 2, v 4}, E {v 1, v 3, v 4},
    E {v 2, v 3, v 4}]

def pack {k : ℕ} (bits : Fin k → Bool) : BitVec k :=
  (BitVec.ofBoolListLE (List.ofFn bits)).cast List.length_ofFn

theorem pack_bit {k : ℕ} (bits : Fin k → Bool) (i : Fin k) :
    (pack bits).getLsbD i.val = bits i := by
  simp only [pack, BitVec.getLsbD_cast, BitVec.getLsbD_ofBoolListLE]
  rw [List.getD_eq_getElem?_getD, List.getElem?_ofFn]
  simp [i.isLt]

/-- Numeric interpretation of the same little-endian bit sequence. -/
def littleEndianNat : List Bool → ℕ
  | [] => 0
  | b :: bs => b.toNat + 2 * littleEndianNat bs

theorem ofBoolListLE_toNat (bs : List Bool) :
    (BitVec.ofBoolListLE bs).toNat = littleEndianNat bs := by
  induction bs with
  | nil => rfl
  | cons b bs ih =>
    simp only [BitVec.ofBoolListLE, BitVec.toNat_concat, littleEndianNat, ih]
    omega

theorem pack_toNat {k : ℕ} (bits : Fin k → Bool) :
    (pack bits).toNat = littleEndianNat (List.ofFn bits) := by
  simpa only [pack, BitVec.toNat_cast] using ofBoolListLE_toNat (List.ofFn bits)

/-- Natural-index spelling lets finite table proofs reduce concrete bits. -/
theorem pack_bit_nat {k : ℕ} (bits : Fin k → Bool) (i : ℕ) (hi : i < k) :
    (pack bits).getLsbD i = bits ⟨i,hi⟩ := pack_bit bits ⟨i,hi⟩

def raw4 (E : Finset V → Bool) (C : V → Bool) (v : Fin 4 → V) : BitVec 8 :=
  pack (bits4 E C v)
def raw5 (E : Finset V → Bool) (C : V → Bool) (v : Fin 5 → V) : BitVec 15 :=
  pack (bits5 E C v)

/-- Explicit numeric ordered-tuple code, with colour bits below edge bits. -/
theorem raw4_toNat (E : Finset V → Bool) (C : V → Bool) (v : Fin 4 → V) :
    (raw4 E C v).toNat =
      (C (v 0)).toNat + 2 * ((C (v 1)).toNat + 2 * ((C (v 2)).toNat +
      2 * ((C (v 3)).toNat + 2 * ((E {v 0,v 1,v 2}).toNat +
      2 * ((E {v 0,v 1,v 3}).toNat + 2 * ((E {v 0,v 2,v 3}).toNat +
      2 * (E {v 1,v 2,v 3}).toNat)))))) := by
  rw [raw4, pack_toNat]
  rfl

def swap4 : Fin 4 → Fin 4 := ![0,1,3,2]
def swapBits4 : Fin 8 → Fin 8 := ![0,1,3,2,5,4,6,7]
def swapCode4 (a : BitVec 8) : BitVec 8 := pack (fun i => a.getLsbD (swapBits4 i).val)
def canonical4 (a : BitVec 8) : ℕ := min a.toNat (swapCode4 a).toNat

theorem swap4_roots : swap4 0 = 0 ∧ swap4 1 = 1 := by decide +kernel
theorem swap4_involutive : Function.Involutive swap4 := by
  change ∀ i, swap4 (swap4 i) = i
  decide +kernel
theorem swapBits4_involutive : Function.Involutive swapBits4 := by
  change ∀ i, swapBits4 (swapBits4 i) = i
  decide +kernel

theorem raw4_bit (E : Finset V → Bool) (C : V → Bool) (v : Fin 4 → V) (i : Fin 8) :
    (raw4 E C v).getLsbD i.val = bits4 E C v i := pack_bit _ _
theorem raw5_bit (E : Finset V → Bool) (C : V → Bool) (v : Fin 5 → V) (i : Fin 15) :
    (raw5 E C v).getLsbD i.val = bits5 E C v i := pack_bit _ _

theorem raw4_swap (E : Finset V → Bool) (C : V → Bool) (v : Fin 4 → V) :
    raw4 E C (v ∘ swap4) = swapCode4 (raw4 E C v) := by
  apply BitVec.eq_of_getLsbD_eq
  intro i hi
  change (raw4 E C (v ∘ swap4)).getLsbD (⟨i,hi⟩ : Fin 8).val = _
  rw [raw4_bit]
  change _ = (pack _).getLsbD (⟨i,hi⟩ : Fin 8).val
  rw [pack_bit, raw4_bit]
  generalize (⟨i,hi⟩ : Fin 8) = j
  fin_cases j <;> simp [bits4, swap4, swapBits4, Finset.pair_comm]

theorem swapCode4_involutive : Function.Involutive swapCode4 := by
  intro a
  apply BitVec.eq_of_getLsbD_eq
  intro i hi
  change (pack _).getLsbD (⟨i,hi⟩ : Fin 8).val = _
  rw [pack_bit]
  change (pack _).getLsbD (swapBits4 ⟨i,hi⟩).val = _
  rw [pack_bit, swapBits4_involutive]

theorem canonical4_swap (a : BitVec 8) : canonical4 (swapCode4 a) = canonical4 a := by
  unfold canonical4
  rw [swapCode4_involutive a, min_comm]

/-- Canonicalizing free vertices preserves the two fixed root-colour bits. -/
theorem canonical4_root_bits : ∀ a : BitVec 8, canonical4 a % 4 = a.toNat % 4 := by
  decide +kernel

theorem canonical4_pair_swap (E : Finset V → Bool) (C : V → Bool) (v : Fin 4 → V) :
    canonical4 (raw4 E C (v ∘ swap4)) = canonical4 (raw4 E C v) := by
  rw [raw4_swap, canonical4_swap]

/-- Exhaust the two permutations fixing the labelled roots, without a
certificate-table or a completeness assumption about any flag basis. -/
theorem rootfixed4_functions : ∀ f : Fin 4 → Fin 4,
    (∀ i j, f i = f j → i = j) → f 0 = 0 → f 1 = 1 →
    (∀ i, f i = i) ∨ (∀ i, f i = swap4 i) := by decide +kernel

theorem canonical4_rootfixed (E : Finset V → Bool) (C : V → Bool)
    (v : Fin 4 → V) (p : Equiv.Perm (Fin 4)) (h0 : p 0 = 0) (h1 : p 1 = 1) :
    canonical4 (raw4 E C (v ∘ p)) = canonical4 (raw4 E C v) := by
  rcases rootfixed4_functions p p.injective h0 h1 with h | h
  · have he : v ∘ p = v := by funext i; simp [h i]
    rw [he]
  · have he : v ∘ p = v ∘ swap4 := by funext i; simp [h i]
    rw [he, canonical4_pair_swap]

/-- The checker compresses a five-vertex flag into the rooted raw type
and the six extension edges plus the free colour bit. -/
def rootPositions5 : Fin 8 → Fin 15 := ![0,1,2,3,5,6,8,11]
def extensionPositions5 : Fin 7 → Fin 15 := ![7,9,10,12,13,14,4]
def rootCode5 (a : BitVec 15) : BitVec 8 :=
  pack (fun i => a.getLsbD (rootPositions5 i).val)
def extensionCode5 (a : BitVec 15) : BitVec 7 :=
  pack (fun i => a.getLsbD (extensionPositions5 i).val)
def mergeCode5 (t : BitVec 8) (u : BitVec 7) : BitVec 15 :=
  pack ![t.getLsbD 0,t.getLsbD 1,t.getLsbD 2,t.getLsbD 3,u.getLsbD 6,
    t.getLsbD 4,t.getLsbD 5,u.getLsbD 0,t.getLsbD 6,u.getLsbD 1,u.getLsbD 2,
    t.getLsbD 7,u.getLsbD 3,u.getLsbD 4,u.getLsbD 5]

theorem rootCode5_bit (a : BitVec 15) (i : ℕ) (hi : i < 8) :
    (rootCode5 a).getLsbD i = a.getLsbD (rootPositions5 ⟨i,hi⟩).val :=
  pack_bit_nat _ i hi

theorem extensionCode5_bit (a : BitVec 15) (i : ℕ) (hi : i < 7) :
    (extensionCode5 a).getLsbD i = a.getLsbD (extensionPositions5 ⟨i,hi⟩).val :=
  pack_bit_nat _ i hi

theorem mergeCode5_projections (a : BitVec 15) :
    mergeCode5 (rootCode5 a) (extensionCode5 a) = a := by
  apply BitVec.eq_of_getLsbD_eq
  intro i hi
  change (pack _).getLsbD (⟨i,hi⟩ : Fin 15).val = _
  rw [pack_bit]
  change _ = a.getLsbD (⟨i,hi⟩ : Fin 15).val
  generalize (⟨i,hi⟩ : Fin 15) = j
  fin_cases j <;>
    simp only [Matrix.cons_val_zero, Matrix.cons_val_succ]
  · exact rootCode5_bit a 0 (by decide)
  · exact rootCode5_bit a 1 (by decide)
  · exact rootCode5_bit a 2 (by decide)
  · exact rootCode5_bit a 3 (by decide)
  · exact extensionCode5_bit a 6 (by decide)
  · exact rootCode5_bit a 4 (by decide)
  · exact rootCode5_bit a 5 (by decide)
  · exact extensionCode5_bit a 0 (by decide)
  · exact rootCode5_bit a 6 (by decide)
  · exact extensionCode5_bit a 1 (by decide)
  · exact extensionCode5_bit a 2 (by decide)
  · exact rootCode5_bit a 7 (by decide)
  · exact extensionCode5_bit a 3 (by decide)
  · exact extensionCode5_bit a 4 (by decide)
  · exact extensionCode5_bit a 5 (by decide)

theorem raw5_eq_iff_root_extension (a b : BitVec 15) :
    a = b ↔ rootCode5 a = rootCode5 b ∧ extensionCode5 a = extensionCode5 b := by
  constructor
  · intro h; simp [h]
  · rintro ⟨hr,he⟩
    rw [← mergeCode5_projections a, ← mergeCode5_projections b, hr, he]

theorem rootCode5_raw5 (E : Finset V → Bool) (C : V → Bool) (v : Fin 5 → V) :
    rootCode5 (raw5 E C v) = raw4 E C (fun i => v (Fin.castSucc i)) := by
  apply BitVec.eq_of_getLsbD_eq
  intro i hi
  change (pack _).getLsbD (⟨i,hi⟩ : Fin 8).val = _
  rw [pack_bit, raw5_bit]
  change _ = (raw4 E C _).getLsbD (⟨i,hi⟩ : Fin 8).val
  rw [raw4_bit]
  generalize (⟨i,hi⟩ : Fin 8) = j
  fin_cases j <;> rfl

/-- Low two colour bits, exactly the rooted two-vertex type. -/
def root2 (C : V → Bool) (v : Fin 2 → V) : ℕ :=
  (if C (v 0) then 1 else 0) + 2 * (if C (v 1) then 1 else 0)

theorem raw4_root_bits (E : Finset V → Bool) (C : V → Bool) (v : Fin 4 → V) :
    (raw4 E C v).toNat % 4 = root2 C (fun i => v (Fin.castAdd 2 i)) := by
  rw [raw4_toNat]
  cases h0 : C (v 0) <;> cases h1 : C (v 1) <;>
    simp [root2, h0, h1] <;> omega

theorem canonical4_raw4_root_bits (E : Finset V → Bool) (C : V → Bool) (v : Fin 4 → V) :
    canonical4 (raw4 E C v) % 4 = root2 C (fun i => v (Fin.castAdd 2 i)) := by
  rw [canonical4_root_bits, raw4_root_bits]

def graphEdge {n : ℕ} (H : Finset (Finset (Fin n))) (e : Finset (Fin n)) : Bool := decide (e ∈ H)
def graphColour {n : ℕ} (S : Finset (Fin n)) (v : Fin n) : Bool := decide (v ∉ S)

theorem graphColour_one {n : ℕ} (S : Finset (Fin n)) (v : Fin n) :
    graphColour S v = true ↔ v ∉ S := by simp [graphColour]
theorem graphColour_zero {n : ℕ} (S : Finset (Fin n)) (v : Fin n) :
    graphColour S v = false ↔ v ∈ S := by simp [graphColour]

#print axioms rootfixed4_functions
#print axioms canonical4_rootfixed
#print axioms rootCode5_bit
#print axioms extensionCode5_bit
#print axioms mergeCode5_projections
#print axioms raw5_eq_iff_root_extension
#print axioms rootCode5_raw5
#print axioms pack_bit
#print axioms ofBoolListLE_toNat
#print axioms pack_toNat
#print axioms pack_bit_nat
#print axioms swap4_roots
#print axioms swap4_involutive
#print axioms swapBits4_involutive
#print axioms raw4_toNat
#print axioms raw4_root_bits
#print axioms canonical4_raw4_root_bits
#print axioms raw4_bit
#print axioms raw5_bit
#print axioms raw4_swap
#print axioms swapCode4_involutive
#print axioms canonical4_swap
#print axioms canonical4_root_bits
#print axioms canonical4_pair_swap
#print axioms graphColour_one
#print axioms graphColour_zero
end TightCycleC5.Bridge.ColouredFlags
