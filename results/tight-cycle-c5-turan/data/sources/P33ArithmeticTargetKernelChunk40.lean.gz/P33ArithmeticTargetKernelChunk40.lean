-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk160 :
    ∀ i : Fin (min 128 (40547 - 128 * 160)),
      targetCountsMatch (classAt (targetKernelClass ⟨160, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk160

theorem target_counts_kernel_chunk161 :
    ∀ i : Fin (min 128 (40547 - 128 * 161)),
      targetCountsMatch (classAt (targetKernelClass ⟨161, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk161

theorem target_counts_kernel_chunk162 :
    ∀ i : Fin (min 128 (40547 - 128 * 162)),
      targetCountsMatch (classAt (targetKernelClass ⟨162, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk162

theorem target_counts_kernel_chunk163 :
    ∀ i : Fin (min 128 (40547 - 128 * 163)),
      targetCountsMatch (classAt (targetKernelClass ⟨163, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk163


end TightCycleC5.Bridge.P33Arithmetic
