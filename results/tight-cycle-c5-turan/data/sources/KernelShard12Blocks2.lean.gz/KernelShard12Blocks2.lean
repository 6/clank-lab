import KernelRowIndex
import KernelWitness12

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_12_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 64 * 256 + i.val))
      kernelWitness12Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_64

theorem kernelBlock_12_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 65 * 256 + i.val))
      kernelWitness12Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_65

theorem kernelBlock_12_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 66 * 256 + i.val))
      kernelWitness12Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_66

theorem kernelBlock_12_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 67 * 256 + i.val))
      kernelWitness12Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_67

theorem kernelBlock_12_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 68 * 256 + i.val))
      kernelWitness12Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_68

theorem kernelBlock_12_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 69 * 256 + i.val))
      kernelWitness12Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_69

theorem kernelBlock_12_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 70 * 256 + i.val))
      kernelWitness12Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_70

theorem kernelBlock_12_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 71 * 256 + i.val))
      kernelWitness12Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_71

theorem kernelBlock_12_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 72 * 256 + i.val))
      kernelWitness12Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_72

theorem kernelBlock_12_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 73 * 256 + i.val))
      kernelWitness12Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_73

theorem kernelBlock_12_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 74 * 256 + i.val))
      kernelWitness12Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_74

theorem kernelBlock_12_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 75 * 256 + i.val))
      kernelWitness12Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_75

theorem kernelBlock_12_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 76 * 256 + i.val))
      kernelWitness12Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_76

theorem kernelBlock_12_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 77 * 256 + i.val))
      kernelWitness12Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_77

theorem kernelBlock_12_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 78 * 256 + i.val))
      kernelWitness12Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_78

theorem kernelBlock_12_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 79 * 256 + i.val))
      kernelWitness12Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_79

theorem kernelBlock_12_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 80 * 256 + i.val))
      kernelWitness12Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_80

theorem kernelBlock_12_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 81 * 256 + i.val))
      kernelWitness12Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_81

theorem kernelBlock_12_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 82 * 256 + i.val))
      kernelWitness12Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_82

theorem kernelBlock_12_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 83 * 256 + i.val))
      kernelWitness12Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_83

theorem kernelBlock_12_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 84 * 256 + i.val))
      kernelWitness12Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_84

theorem kernelBlock_12_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 85 * 256 + i.val))
      kernelWitness12Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_85

theorem kernelBlock_12_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 86 * 256 + i.val))
      kernelWitness12Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_86

theorem kernelBlock_12_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 87 * 256 + i.val))
      kernelWitness12Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_87

theorem kernelBlock_12_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 88 * 256 + i.val))
      kernelWitness12Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_88

theorem kernelBlock_12_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 89 * 256 + i.val))
      kernelWitness12Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_89

theorem kernelBlock_12_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 90 * 256 + i.val))
      kernelWitness12Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_90

theorem kernelBlock_12_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 91 * 256 + i.val))
      kernelWitness12Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_91

theorem kernelBlock_12_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 92 * 256 + i.val))
      kernelWitness12Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_92

theorem kernelBlock_12_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 93 * 256 + i.val))
      kernelWitness12Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_93

theorem kernelBlock_12_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 94 * 256 + i.val))
      kernelWitness12Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_94

theorem kernelBlock_12_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 95 * 256 + i.val))
      kernelWitness12Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_95

end TightCycleC5.Bridge.Cover
