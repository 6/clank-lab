import CLRows
import SixSampling

/-! PROOF §3a: the certificate's literal CL pattern, root and colour
conditions instantiate the common-subset CL bound. This does not yet
identify an optimized arithmetic table with a sum of descriptor rows. -/
namespace TightCycleC5.Bridge.CLCertificate
open Finset

structure Descriptor where
  strong : Bool
  rootEdge : Bool
  patternMask : BitVec 8
  rootColors : Option (BitVec 3)
  freeColors : Finset Bool

def pattern {V : Type*} (e : V → V → V → Bool) (x u v z : V) : Nat :=
  4 * (e x u z).toNat + 2 * (e x v z).toNat + (e u v z).toNat

def rootColorCode {V : Type*} (c : V → Bool) (x u v : V) : Nat :=
  (c x).toNat + 2 * (c u).toNat + 4 * (c v).toNat

theorem pattern_lt {V : Type*} (e : V → V → V → Bool) (x u v z : V) :
    pattern e x u v z < 8 := by
  have := Bool.toNat_le (e x u z)
  have := Bool.toNat_le (e x v z)
  have := Bool.toNat_le (e u v z)
  unfold pattern
  omega

theorem rootColorCode_lt {V : Type*} (c : V → Bool) (x u v : V) :
    rootColorCode c x u v < 8 := by
  have := Bool.toNat_le (c x)
  have := Bool.toNat_le (c u)
  have := Bool.toNat_le (c v)
  unfold rootColorCode
  omega

def rootColorPass {V : Type*} (d : Descriptor) (c : V → Bool) (x u v : V) : Bool :=
  match d.rootColors with
  | none => true
  | some rc => decide (rootColorCode c x u v = rc.toNat)

def rootPass {V : Type*} (d : Descriptor) (e : V → V → V → Bool)
    (c : V → Bool) (x u v : V) : Prop :=
  e x u v = d.rootEdge ∧ rootColorPass d c x u v = true

instance {V : Type*} (d : Descriptor) (e : V → V → V → Bool)
    (c : V → Bool) (x u v : V) : Decidable (rootPass d e c x u v) := by
  unfold rootPass
  infer_instance

def freePass {V : Type*} (d : Descriptor) (e : V → V → V → Bool)
    (c : V → Bool) (x u v z : V) : Prop :=
  d.patternMask.getLsbD (pattern e x u v z) = true ∧ c z ∈ d.freeColors

instance {V : Type*} (d : Descriptor) (e : V → V → V → Bool)
    (c : V → Bool) (x u v z : V) : Decidable (freePass d e c x u v z) := by
  unfold freePass
  infer_instance

def cherry {V : Type*} (strong : Bool) (e : V → V → V → Bool) (x a b d : V) : Prop :=
  if strong then
    e x a b = true ∧ e x a d = true ∧ ¬ e x b d = true ∧ ¬ e a b d = true
  else e x a b = true ∧ e x a d = true ∧ ¬ e x b d = true

instance {V : Type*} (strong : Bool) (e : V → V → V → Bool) (x a b d : V) :
    Decidable (cherry strong e x a b d) := by
  unfold cherry
  infer_instance

def tetrahedron {V : Type*} (e : V → V → V → Bool) (x a b d : V) : Prop :=
  e a b d = true ∧ e x a b = true ∧ e x a d = true ∧ e x b d = true

instance {V : Type*} (e : V → V → V → Bool) (x a b d : V) :
    Decidable (tetrahedron e x a b d) := by
  unfold tetrahedron
  infer_instance

/-- x,u,v,a,b,d are the six labels, in exactly the frozen proof's order. -/
def evaluate {V : Type*} (d : Descriptor) (e : V → V → V → Bool) (c : V → Bool)
    (x u v a b z : V) : ℝ :=
  (if rootPass d e c x u v then 1 else 0) *
    (if freePass d e c x u v a then 1 else 0) *
    (if freePass d e c x u v b then 1 else 0) *
    (if freePass d e c x u v z then 1 else 0) *
    ((if cherry d.strong e x a b z then 1 else 0) -
      (if tetrahedron e x a b z then 1 else 0))

def row (d : Descriptor) (G : LabelledStructure 6) : ℝ :=
  evaluate d (fun a b c => G.edge {a, b, c}) G.color 0 1 2 3 4 5

def actualEdge {n : Nat} (H : Finset (Finset (Fin n))) (x a b : Fin n) : Bool :=
  decide (({x, a, b} : Finset (Fin n)) ∈ H)
def actualColor {n : Nat} (S : Finset (Fin n)) (z : Fin n) : Bool := decide (z ∉ S)

noncomputable def commonSet {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (root : Fin 3 ↪ Fin n) : Finset (Fin n) := by
  classical
  exact univ.filter (fun z => z ∉ Set.range root ∧
    freePass d (actualEdge H) (actualColor S) (root 0) (root 1) (root 2) z)

def rootIndicator {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (root : Fin 3 ↪ Fin n) : ℝ :=
  if rootPass d (actualEdge H) (actualColor S) (root 0) (root 1) (root 2) then 1 else 0

theorem commonSet_support {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (root : Fin 3 ↪ Fin n) (z : Fin n) :
    z ∈ commonSet d H S root → z ∉ Set.range root := by
  classical
  intro h
  exact (mem_filter.mp h).2.1

theorem rootIndicator_zero_one {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (root : Fin 3 ↪ Fin n) :
    rootIndicator d H S root = 0 ∨ rootIndicator d H S root = 1 := by
  unfold rootIndicator
  split_ifs <;> simp

theorem commonWeight {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (root : Fin 3 ↪ Fin n) (z : Outside root) :
    clWeight (commonSet d H S root) z.val =
      if freePass d (actualEdge H) (actualColor S) (root 0) (root 1) (root 2) z.val then 1 else 0 := by
  classical
  simp only [clWeight, commonSet, mem_filter, mem_univ, true_and, z.property, not_false_eq_true]

theorem cherry_actual {n : Nat} (strong : Bool) (H : Finset (Finset (Fin n)))
    (x a b c : Fin n) : cherry strong (actualEdge H) x a b c ↔ clCherry strong H x a b c := by
  cases strong <;> simp [cherry, actualEdge, clCherry, HelperD.Lk]

theorem tetrahedron_actual {n : Nat} (H : Finset (Finset (Fin n))) (x a b c : Fin n) :
    tetrahedron (actualEdge H) x a b c ↔ HelperD.K4 H x a b c := by
  simp [tetrahedron, actualEdge, HelperD.K4, HelperD.Lk]

theorem indicator_factor (g a b c : ℝ) (P Q : Prop) [Decidable P] [Decidable Q] :
    g * a * b * c * ((if P then 1 else 0) - (if Q then 1 else 0)) =
      g * ((if P then a * b * c else 0) - (if Q then a * b * c else 0)) := by
  by_cases hP : P <;> by_cases hQ : Q <;> simp [hP, hQ] <;> ring

theorem evaluate_commonSet {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (root : Fin 3 ↪ Fin n) (free : Fin 3 ↪ Outside root) :
    evaluate d (actualEdge H) (actualColor S) (root 0) (root 1) (root 2)
      (free 0).val (free 1).val (free 2).val =
      rootIndicator d H S root * clRow d.strong H (root 0) (commonSet d H S root)
        (free 0).val (free 1).val (free 2).val := by
  classical
  simp only [evaluate, ← commonWeight, cherry_actual, tetrahedron_actual]
  exact indicator_factor (rootIndicator d H S root)
    (clWeight (commonSet d H S root) (free 0).val)
    (clWeight (commonSet d H S root) (free 1).val)
    (clWeight (commonSet d H S root) (free 2).val) _ _

theorem row_sample {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) :
    row d (sampleStructure σ H S) = evaluate d (actualEdge H) (actualColor S)
      (σ 0) (σ 1) (σ 2) (σ 3) (σ 4) (σ 5) := by
  have he : (fun a b c => (sampleStructure σ H S).edge {a, b, c}) =
      (fun a b c => actualEdge H (σ a) (σ b) (σ c)) := by
    funext a b c
    simp [sampleStructure, actualEdge]
  unfold row
  rw [he]
  rfl

theorem row_join {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (root : Fin 3 ↪ Fin n) (free : Fin 3 ↪ Outside root) :
    row d (sampleStructure (joinSample root free) H S) =
      rootIndicator d H S root * clRow d.strong H (root 0) (commonSet d H S root)
        (free 0).val (free 1).val (free 2).val := by
  rw [row_sample]
  change evaluate d (actualEdge H) (actualColor S)
    (joinSample root free (Fin.castAdd 3 (0 : Fin 3)))
    (joinSample root free (Fin.castAdd 3 (1 : Fin 3)))
    (joinSample root free (Fin.castAdd 3 (2 : Fin 3)))
    (joinSample root free (Fin.natAdd 3 (0 : Fin 3)))
    (joinSample root free (Fin.natAdd 3 (1 : Fin 3)))
    (joinSample root free (Fin.natAdd 3 (2 : Fin 3))) = _
  simp only [joinSample_root, joinSample_free]
  exact evaluate_commonSet d H S root free

set_option maxHeartbeats 1000000 in
theorem row_as_clSixRow {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) :
    row d (sampleStructure σ H S) = clSixRow d.strong H (commonSet d H S) (rootIndicator d H S) σ := by
  have h := row_join d H S (splitSampleEquiv (r := 3) (f := 3) σ).1 (splitSampleEquiv (r := 3) (f := 3) σ).2
  rw [joinSample_split] at h
  exact h

/-- Every literal CL row in §3a has this finite bound. P32 takes no root
colour condition and both free colours; P33 also permits a fixed root
colour code and any of the three nonempty colour sets. No hypothesis
about a precomputed coefficient table is present. -/
theorem row_mean_lower {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (hn : 12 ≤ n) (S : Finset (Fin n)) :
    -(1 / ((n : ℝ) - 5)) ≤ uniformMean (fun σ : Fin 6 ↪ Fin n => row d (sampleStructure σ H S)) := by
  have he : (fun σ : Fin 6 ↪ Fin n => row d (sampleStructure σ H S)) =
      clSixRow d.strong H (commonSet d H S) (rootIndicator d H S) :=
    funext (row_as_clSixRow d H S)
  rw [he]
  exact cl_six_row_lower d.strong H hH hC hn (commonSet d H S)
    (commonSet_support d H S) (rootIndicator d H S) (rootIndicator_zero_one d H S)

/-- Nonnegative certificate coefficients preserve the literal row bound;
no precomputed family sum is assumed. -/
theorem weighted_row_mean_lower {I : Type*} [Fintype I] {n : Nat}
    (d : I → Descriptor) (w : I → ℝ) (hw : ∀ i, 0 ≤ w i)
    (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H)
    (hn : 12 ≤ n) (S : Finset (Fin n)) :
    -(∑ i, w i) / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => ∑ i, w i * row (d i) (sampleStructure σ H S)) := by
  classical
  have he : uniformMean (fun σ : Fin 6 ↪ Fin n => ∑ i, w i * row (d i) (sampleStructure σ H S)) =
      ∑ i, w i * uniformMean (fun σ : Fin 6 ↪ Fin n => row (d i) (sampleStructure σ H S)) := by
    unfold uniformMean
    rw [Finset.sum_comm, Finset.sum_div]
    apply Finset.sum_congr rfl
    intro i _
    rw [← Finset.mul_sum]
    ring
  rw [he]
  calc
    -(∑ i, w i) / ((n : ℝ) - 5) = ∑ i, w i * (-(1 / ((n : ℝ) - 5))) := by
      rw [← Finset.sum_mul]
      ring
    _ ≤ _ := Finset.sum_le_sum (fun i _ =>
      mul_le_mul_of_nonneg_left (row_mean_lower (d i) H hH hC hn S) (hw i))

#print axioms pattern_lt
#print axioms rootColorCode_lt
#print axioms commonSet_support
#print axioms rootIndicator_zero_one
#print axioms commonWeight
#print axioms cherry_actual
#print axioms tetrahedron_actual
#print axioms indicator_factor
#print axioms evaluate_commonSet
#print axioms row_sample
#print axioms row_join
#print axioms row_as_clSixRow
#print axioms row_mean_lower
#print axioms weighted_row_mean_lower
end TightCycleC5.Bridge.CLCertificate
