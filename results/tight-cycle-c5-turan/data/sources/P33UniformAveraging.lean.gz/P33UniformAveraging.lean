import P33NonPSDRowBounds
import P33PSDRowBounds
import P33ArithmeticTarget
import KernelColoredCover
import TheoremB

/-! Uniform graph transport for Theorem B. The literal class inequalities
are an explicit finite prerequisite until the complete replay is applied. -/
namespace TightCycleC5.Bridge.P33UniformAveraging
open Finset
set_option maxRecDepth 100000
set_option maxHeartbeats 2000000

noncomputable def nuisanceRows (G : LabelledStructure 6) : ℝ :=
  P33NonPSDRowBounds.rows G + P33PSDRowBounds.rows G

noncomputable def errorConstant : ℝ :=
  P33NonPSDRowBounds.errorConstant + P33PSDRowBounds.errorConstant

theorem error_constant_nonneg : 0 ≤ errorConstant :=
  add_nonneg P33NonPSDRowBounds.constants_nonneg.2.2
    P33PSDRowBounds.error_constant_nonneg

theorem mean_add {ι : Type*} [Fintype ι] (f g : ι → ℝ) :
    uniformMean (fun i => f i + g i) = uniformMean f + uniformMean g := by
  simp only [uniformMean, sum_add_distrib, add_div]

theorem nuisance_mean_lower {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (S : Finset (Fin n))
    (hS : LocallyMaximal H S) (hn : 12 ≤ n) (δ : ℝ) (hδ : 0 ≤ δ)
    (hreg : ∀ x u, (deg H x : ℝ) ≤ deg H u + δ * (n : ℝ)^2)
    (hcut : (2/5-δ) * (n.choose 3 : ℝ) ≤ cutCount H S)
    (hd : (P33Rows.densityBound-δ) * (n.choose 3 : ℝ) ≤ H.card) :
    -((P33NonPSDRowBounds.deltaConstant +
        P33NonPSDRowBounds.deltaErrorConstant / (n : ℝ)) * δ +
        errorConstant / (n : ℝ)) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => nuisanceRows (sampleStructure σ H S)) := by
  have ha := P33NonPSDRowBounds.rows_mean_lower H hH hC S hS hn δ hδ hreg hcut hd
  have hb := P33PSDRowBounds.rows_mean_lower H S hn
  simp only [nuisanceRows, mean_add, errorConstant, add_div]
  linarith

/-- The only finite prerequisite is the displayed literal full-class mean
inequality. It is neither a row-bound nor a graph-level certificate axiom. -/
theorem certificate_mean_nonpos
    (hclasses : ∀ k : Fin 40547,
      uniformMean (fun p : Equiv.Perm (Fin 6) =>
        P33Arithmetic.literalTarget (p • ColoredCover.classRep k) +
        nuisanceRows (p • ColoredCover.classRep k)) ≤ 0)
    {n : Nat} (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (hC : ¬ ContainsC5 H) (S : Finset (Fin n)) (hn : 6 ≤ n) :
    uniformMean (fun σ : Fin 6 ↪ Fin n =>
      P33Arithmetic.literalTarget (sampleStructure σ H S) +
        nuisanceRows (sampleStructure σ H S)) ≤ 0 := by
  rw [KernelColoredCover.p33_class_expansion hH hC S
    (fun G => P33Arithmetic.literalTarget G + nuisanceRows G)]
  have hmass := (KernelColoredCover.p33_class_probability hn hH hC S).1
  exact Finset.sum_nonpos (fun k _ =>
    mul_nonpos_of_nonneg_of_nonpos (hmass k) (hclasses k))

theorem normalized_target_bound
    (hclasses : ∀ k : Fin 40547,
      uniformMean (fun p : Equiv.Perm (Fin 6) =>
        P33Arithmetic.literalTarget (p • ColoredCover.classRep k) +
        nuisanceRows (p • ColoredCover.classRep k)) ≤ 0)
    {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (S : Finset (Fin n))
    (hS : LocallyMaximal H S) (hn : 12 ≤ n) (δ : ℝ) (hδ : 0 ≤ δ)
    (hreg : ∀ x u, (deg H x : ℝ) ≤ deg H u + δ * (n : ℝ)^2)
    (hcut : (2/5-δ) * (n.choose 3 : ℝ) ≤ cutCount H S)
    (hd : (P33Rows.densityBound-δ) * (n.choose 3 : ℝ) ≤ H.card) :
    ((badCount H S : ℝ) - missCount H S) / (n.choose 3 : ℝ) ≤
      (P33NonPSDRowBounds.deltaConstant +
        P33NonPSDRowBounds.deltaErrorConstant / (n : ℝ)) * δ +
        errorConstant / (n : ℝ) := by
  have hc := certificate_mean_nonpos hclasses H hH hC S (by omega : 6 ≤ n)
  rw [mean_add, P33Arithmetic.literalTarget_normalization H hH S (by omega)] at hc
  have hr := nuisance_mean_lower H hH hC S hS hn δ hδ hreg hcut hd
  linarith

/-- PARTIAL until the finite literal class means are discharged. All
asymptotic choices and all original graph hypotheses are retained. -/
theorem p33_of_literal_class_means
    (hclasses : ∀ k : Fin 40547,
      uniformMean (fun p : Equiv.Perm (Fin 6) =>
        P33Arithmetic.literalTarget (p • ColoredCover.classRep k) +
        nuisanceRows (p • ColoredCover.classRep k)) ≤ 0) : P33Statement := by
  apply p33_of_uniform_normalized_bound
  refine ⟨P33NonPSDRowBounds.deltaConstant,
    P33NonPSDRowBounds.deltaErrorConstant, errorConstant,
    P33NonPSDRowBounds.constants_nonneg.1,
    P33NonPSDRowBounds.constants_nonneg.2.1,
    error_constant_nonneg, 12, ?_⟩
  intro n hn δ hδ H S hH hC hS hreg hcut hd
  apply normalized_target_bound hclasses H hH hC S hS hn δ hδ.le hreg hcut
  convert hd using 1 <;> norm_num [P33Rows.densityBound]

#print axioms error_constant_nonneg
#print axioms mean_add
#print axioms nuisance_mean_lower
#print axioms certificate_mean_nonpos
#print axioms normalized_target_bound
#print axioms p33_of_literal_class_means
end TightCycleC5.Bridge.P33UniformAveraging
