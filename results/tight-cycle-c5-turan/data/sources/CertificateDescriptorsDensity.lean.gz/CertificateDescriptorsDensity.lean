import CertificateDescriptorsCL
import TargetNormalization
import TripleProducts

/-! The last two P32 inequalities, without a C5-free hypothesis. -/
namespace TightCycleC5.Bridge.CertificateDescriptors
open Finset

noncomputable def densityBeta : ℝ := 4641 / 10000
noncomputable def densityEta (n : Nat) : ℝ :=
  (9 * (n : ℝ)^2 - 45 * (n : ℝ) + 60) /
    (((n : ℝ) - 3) * ((n : ℝ) - 4) * ((n : ℝ) - 5))

noncomputable def edgeTriple {n : Nat} (H : Finset (Finset (Fin n))) (t : Triple n) : ℝ :=
  if embeddingSet t ∈ H then 1 else 0
noncomputable def centeredTriple {n : Nat} (H : Finset (Finset (Fin n))) (t : Triple n) : ℝ :=
  edgeTriple H t - densityBeta
noncomputable def freeTriple {n : Nat} (hit : Bool) (H : Finset (Finset (Fin n)))
    (t : Triple n) : ℝ := if hit then edgeTriple H t else 1 - edgeTriple H t

noncomputable def densityRow (hit : Bool) (G : LabelledStructure 6) : ℝ :=
  ((if G.edge {0, 1, 2} then 1 else 0) - densityBeta) *
    (if hit then (if G.edge {3, 4, 5} then 1 else 0)
      else 1 - (if G.edge {3, 4, 5} then 1 else 0))

theorem density_beta_bounds : 0 ≤ densityBeta ∧ densityBeta ≤ 1 := by
  norm_num [densityBeta]

theorem edge_triple_mean {n : Nat} (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H) :
    uniformMean (edgeTriple H) = (H.card : ℝ) / (n.choose 3 : ℝ) := by
  classical
  change uniformMean (fun t : Fin 3 ↪ Fin n => if embeddingSet t ∈ H then (1 : ℝ) else 0) = _
  rw [embeddingSet_mean 3 (fun e : Finset (Fin n) => if e ∈ H then (1 : ℝ) else 0)]
  simp only [Fintype.card_fin]
  rw [← sum_filter, filter_all_triples H hH]
  simp

theorem centered_triple_abs {n : Nat} (H : Finset (Finset (Fin n))) (t : Triple n) :
    |centeredTriple H t| ≤ 1 := by
  unfold centeredTriple edgeTriple densityBeta
  split_ifs <;> norm_num

theorem free_triple_bounds {n : Nat} (hit : Bool) (H : Finset (Finset (Fin n)))
    (t : Triple n) : 0 ≤ freeTriple hit H t ∧ |freeTriple hit H t| ≤ 1 := by
  cases hit <;> unfold freeTriple edgeTriple <;> split_ifs <;> norm_num

theorem density_row_sample {n : Nat} (hit : Bool) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) :
    densityRow hit (sampleStructure σ H S) =
      sixTripleProduct (centeredTriple H) (freeTriple hit H) σ := by
  obtain ⟨⟨root, free⟩, rfl⟩ := (splitSampleEquiv (r := 3) (f := 3) (n := n)).symm.surjective σ
  change densityRow hit (sampleStructure (joinSample root free) H S) =
    sixTripleProduct (centeredTriple H) (freeTriple hit H) (joinSample root free)
  rw [sixTripleProduct_join]
  have hu : (univ : Finset (Fin 3)) = {0, 1, 2} := by decide +kernel
  have h0 : joinSample root free 0 = root 0 := joinSample_root root free 0
  have h1 : joinSample root free 1 = root 1 := joinSample_root root free 1
  have h2 : joinSample root free 2 = root 2 := joinSample_root root free 2
  have h3 : joinSample root free 3 = (free 0).val := joinSample_free root free 0
  have h4 : joinSample root free 4 = (free 1).val := joinSample_free root free 1
  have h5 : joinSample root free 5 = (free 2).val := joinSample_free root free 2
  simp [densityRow, centeredTriple, freeTriple, edgeTriple, sampleStructure,
    embeddingSet, hu, h0, h1, h2, h3, h4, h5]

theorem centered_triple_mean_nonneg {n : Nat} (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hn : 12 ≤ n)
    (hd : densityBeta * (n.choose 3 : ℝ) ≤ (H.card : ℝ)) :
    0 ≤ uniformMean (centeredTriple H) := by
  letI : Nonempty (Triple n) := ⟨Fin.castLEEmb (by omega : 3 ≤ n)⟩
  have hc : (0 : ℝ) < (n.choose 3 : ℝ) := by
    exact_mod_cast Nat.choose_pos (by omega : 3 ≤ n)
  have he : uniformMean (centeredTriple H) = uniformMean (edgeTriple H) - densityBeta := by
    calc
      _ = uniformMean (edgeTriple H) - uniformMean (fun _ : Triple n => densityBeta) := by
        simp only [uniformMean, centeredTriple, sum_sub_distrib, sub_div]
      _ = _ := by rw [uniformMean_const]
  rw [he, edge_triple_mean H hH]
  exact sub_nonneg.mpr ((le_div_iff₀ hc).mpr hd)

/-- Both actual P32 density rows have the full finite disjoint-triple error. -/
theorem density_row_mean_lower {n : Nat} (hit : Bool) (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hn : 12 ≤ n) (S : Finset (Fin n))
    (hd : densityBeta * (n.choose 3 : ℝ) ≤ (H.card : ℝ)) :
    -densityEta n ≤ uniformMean (fun σ : Fin 6 ↪ Fin n =>
      densityRow hit (sampleStructure σ H S)) := by
  have hg := centered_triple_mean_nonneg H hH hn hd
  have hf : 0 ≤ uniformMean (freeTriple hit H) :=
    uniformMean_nonneg (fun t => (free_triple_bounds hit H t).1)
  obtain ⟨ε, he, hε⟩ := disjoint_triple_product hn (centeredTriple H) (freeTriple hit H)
    (centered_triple_abs H) (fun t => (free_triple_bounds hit H t).2)
  have hnR : (12 : ℝ) ≤ n := by exact_mod_cast hn
  have hρ : 0 < (n : ℝ) * ((n : ℝ) - 1) * ((n : ℝ) - 2) /
      (((n : ℝ) - 3) * ((n : ℝ) - 4) * ((n : ℝ) - 5)) := by
    apply div_pos
    · exact mul_pos (mul_pos (by linarith) (by linarith)) (by linarith)
    · exact mul_pos (mul_pos (by linarith) (by linarith)) (by linarith)
  have hp := mul_nonneg (mul_nonneg hρ.le hg) hf
  have hε' : ε ≤ densityEta n := le_trans (le_abs_self ε) hε
  simp_rw [density_row_sample]
  rw [he]
  linarith

def densitySourceIndex (hit : Bool) : Fin 9511 :=
  if hit then ⟨9509, by decide⟩ else ⟨9510, by decide⟩
noncomputable def densityWeight (hit : Bool) : ℝ := p32Weight (densitySourceIndex hit)

theorem density_source_indices : (densitySourceIndex true).val = 9509 ∧
    (densitySourceIndex false).val = 9510 := by decide +kernel

theorem density_weight_nonneg (hit : Bool) : 0 ≤ densityWeight hit := p32_weight_nonneg _

#print axioms density_beta_bounds
#print axioms edge_triple_mean
#print axioms centered_triple_abs
#print axioms free_triple_bounds
#print axioms density_row_sample
#print axioms centered_triple_mean_nonneg
#print axioms density_row_mean_lower
#print axioms density_source_indices
#print axioms density_weight_nonneg
end TightCycleC5.Bridge.CertificateDescriptors
