import KernelShard17Blocks0
import KernelShard17Blocks1
import KernelShard17Blocks2
import KernelShard17Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard17 : kernelShardCheck 17 kernelWitness17 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (17 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness17 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_17_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard17
end TightCycleC5.Bridge.Cover
