import P32ArithmeticSemantics
import P32FlagRows

/-! Pointwise PSD arithmetic matches optional indices, including absent codes. -/
namespace TightCycleC5.Bridge.P32RowMatching
open Finset

set_option maxRecDepth 100000
set_option maxHeartbeats 4000000

def blockCode (b : P32Arithmetic.Block) (i : Fin b.n) : Nat := (b.flags.get i).val

theorem finite_lookup_eq (b : P32Arithmetic.Block) (a : Fin 64) :
    (List.finRange b.n).find? (fun i => b.flags.get i == a) =
      flagLookup (blockCode b) a.val := by
  unfold flagLookup
  congr 1
  funext i
  apply Bool.eq_iff_iff.mpr
  simp [blockCode, Fin.ext_iff]

/-- No support or injectivity is needed to compare the two optional entries. -/
theorem matrixLookup_normalized (b : P32Arithmetic.Block) (a c : Fin 64) :
    ((P32Arithmetic.matrixLookup b a c).getD 0 : ℝ) / (P32Arithmetic.factorScale : ℝ)^2 =
      zeroExtend (normalizedIntMatrix b.q P32Arithmetic.factorScale)
        (flagLookup (blockCode b) a.val) (flagLookup (blockCode b) c.val) := by
  simp only [P32Arithmetic.matrixLookup, finite_lookup_eq]
  cases ha : flagLookup (blockCode b) a.val <;>
    cases hc : flagLookup (blockCode b) c.val <;>
    simp [zeroExtend, normalizedIntMatrix, ha, hc]

/-- Validity of the combined Option is precisely what permits splitting its sum. -/
theorem option_add_getD (a b : Option Int)
    (h : (do let x ← a; let y ← b; pure (x+y)).isSome = true) :
    (do let x ← a; let y ← b; pure (x+y)).getD 0 = a.getD 0 + b.getD 0 := by
  cases a <;> cases b <;> simp_all

def fourOption (f : P32Arithmetic.Features) : Option Int :=
  match P32Arithmetic.fourRootBlock f.root4 with
  | none => some 0
  | some b => P32Arithmetic.matrixLookup (P32Arithmetic.blocks.get b) f.fourA f.fourB

theorem psd_numerator_split (f : P32Arithmetic.Features) (h : (P32Arithmetic.psdNumerator f).isSome = true) :
    (P32Arithmetic.psdNumerator f).getD 0 = (fourOption f).getD 0 +
      (P32Arithmetic.matrixLookup (P32Arithmetic.blocks.get 5) f.twoA f.twoB).getD 0 :=
  by
    unfold P32Arithmetic.psdNumerator at h ⊢
    unfold fourOption
    cases hr : P32Arithmetic.fourRootBlock f.root4 <;> simp only [hr] at h ⊢
    · simpa using option_add_getD (some 0)
        (P32Arithmetic.matrixLookup (P32Arithmetic.blocks.get 5) f.twoA f.twoB) h
    · exact option_add_getD _ _ h

theorem psd_contribution_cast (G : LabelledStructure 6) :
    P32Arithmetic.psdContribution G = ((P32Arithmetic.psdNumerator (P32Arithmetic.features G)).getD 0 : ℝ) /
      (P32Arithmetic.factorScale : ℝ)^2 := by
  simp [P32Arithmetic.psdContribution]

theorem block_code0 : ∀ i : Fin 64, blockCode (P32Arithmetic.blocks.get 0) i = P32Flag.code0 i := by
  decide +kernel

theorem matrix_lookup0_eq (a c : Fin 64) :
    ((P32Arithmetic.matrixLookup (P32Arithmetic.blocks.get 0) a c).getD 0 : ℝ) / (P32Arithmetic.factorScale : ℝ)^2 =
      zeroExtend P32PSD.matrix0 (flagLookup P32Flag.code0 a.val) (flagLookup P32Flag.code0 c.val) := by
  have hc : blockCode (P32Arithmetic.blocks.get 0) = P32Flag.code0 := funext block_code0
  have hm : normalizedIntMatrix (P32Arithmetic.blocks.get 0).q P32Arithmetic.factorScale = P32PSD.matrix0 := rfl
  have ht := matrixLookup_normalized (P32Arithmetic.blocks.get 0) a c
  simp only [hc, hm] at ht
  convert ht using 1 <;> rfl

theorem block_code1 : ∀ i : Fin 64, blockCode (P32Arithmetic.blocks.get 1) i = P32Flag.code1 i := by
  decide +kernel

theorem matrix_lookup1_eq (a c : Fin 64) :
    ((P32Arithmetic.matrixLookup (P32Arithmetic.blocks.get 1) a c).getD 0 : ℝ) / (P32Arithmetic.factorScale : ℝ)^2 =
      zeroExtend P32PSD.matrix1 (flagLookup P32Flag.code1 a.val) (flagLookup P32Flag.code1 c.val) := by
  have hc : blockCode (P32Arithmetic.blocks.get 1) = P32Flag.code1 := funext block_code1
  have hm : normalizedIntMatrix (P32Arithmetic.blocks.get 1).q P32Arithmetic.factorScale = P32PSD.matrix1 := rfl
  have ht := matrixLookup_normalized (P32Arithmetic.blocks.get 1) a c
  simp only [hc, hm] at ht
  convert ht using 1 <;> rfl

theorem block_code2 : ∀ i : Fin 50, blockCode (P32Arithmetic.blocks.get 2) i = P32Flag.code2 i := by
  decide +kernel

theorem matrix_lookup2_eq (a c : Fin 64) :
    ((P32Arithmetic.matrixLookup (P32Arithmetic.blocks.get 2) a c).getD 0 : ℝ) / (P32Arithmetic.factorScale : ℝ)^2 =
      zeroExtend P32PSD.matrix2 (flagLookup P32Flag.code2 a.val) (flagLookup P32Flag.code2 c.val) := by
  have hc : blockCode (P32Arithmetic.blocks.get 2) = P32Flag.code2 := funext block_code2
  have hm : normalizedIntMatrix (P32Arithmetic.blocks.get 2).q P32Arithmetic.factorScale = P32PSD.matrix2 := rfl
  have ht := matrixLookup_normalized (P32Arithmetic.blocks.get 2) a c
  simp only [hc, hm] at ht
  convert ht using 1 <;> rfl

theorem block_code3 : ∀ i : Fin 39, blockCode (P32Arithmetic.blocks.get 3) i = P32Flag.code3 i := by
  decide +kernel

theorem matrix_lookup3_eq (a c : Fin 64) :
    ((P32Arithmetic.matrixLookup (P32Arithmetic.blocks.get 3) a c).getD 0 : ℝ) / (P32Arithmetic.factorScale : ℝ)^2 =
      zeroExtend P32PSD.matrix3 (flagLookup P32Flag.code3 a.val) (flagLookup P32Flag.code3 c.val) := by
  have hc : blockCode (P32Arithmetic.blocks.get 3) = P32Flag.code3 := funext block_code3
  have hm : normalizedIntMatrix (P32Arithmetic.blocks.get 3).q P32Arithmetic.factorScale = P32PSD.matrix3 := rfl
  have ht := matrixLookup_normalized (P32Arithmetic.blocks.get 3) a c
  simp only [hc, hm] at ht
  convert ht using 1 <;> rfl

theorem block_code4 : ∀ i : Fin 30, blockCode (P32Arithmetic.blocks.get 4) i = P32Flag.code4 i := by
  decide +kernel

theorem matrix_lookup4_eq (a c : Fin 64) :
    ((P32Arithmetic.matrixLookup (P32Arithmetic.blocks.get 4) a c).getD 0 : ℝ) / (P32Arithmetic.factorScale : ℝ)^2 =
      zeroExtend P32PSD.matrix4 (flagLookup P32Flag.code4 a.val) (flagLookup P32Flag.code4 c.val) := by
  have hc : blockCode (P32Arithmetic.blocks.get 4) = P32Flag.code4 := funext block_code4
  have hm : normalizedIntMatrix (P32Arithmetic.blocks.get 4).q P32Arithmetic.factorScale = P32PSD.matrix4 := rfl
  have ht := matrixLookup_normalized (P32Arithmetic.blocks.get 4) a c
  simp only [hc, hm] at ht
  convert ht using 1 <;> rfl

theorem block_code5 : ∀ i : Fin 12, blockCode (P32Arithmetic.blocks.get 5) i = P32Flag.code5 i := by
  decide +kernel

theorem matrix_lookup5_eq (a c : Fin 64) :
    ((P32Arithmetic.matrixLookup (P32Arithmetic.blocks.get 5) a c).getD 0 : ℝ) / (P32Arithmetic.factorScale : ℝ)^2 =
      zeroExtend P32PSD.matrix5 (flagLookup P32Flag.code5 a.val) (flagLookup P32Flag.code5 c.val) := by
  have hc : blockCode (P32Arithmetic.blocks.get 5) = P32Flag.code5 := funext block_code5
  have hm : normalizedIntMatrix (P32Arithmetic.blocks.get 5).q P32Arithmetic.factorScale = P32PSD.matrix5 := rfl
  have ht := matrixLookup_normalized (P32Arithmetic.blocks.get 5) a c
  simp only [hc, hm] at ht
  convert ht using 1 <;> rfl

#print axioms finite_lookup_eq
#print axioms matrixLookup_normalized
#print axioms option_add_getD
#print axioms psd_numerator_split
#print axioms psd_contribution_cast
#print axioms block_code0
#print axioms matrix_lookup0_eq
#print axioms block_code1
#print axioms matrix_lookup1_eq
#print axioms block_code2
#print axioms matrix_lookup2_eq
#print axioms block_code3
#print axioms matrix_lookup3_eq
#print axioms block_code4
#print axioms matrix_lookup4_eq
#print axioms block_code5
#print axioms matrix_lookup5_eq
end TightCycleC5.Bridge.P32RowMatching
