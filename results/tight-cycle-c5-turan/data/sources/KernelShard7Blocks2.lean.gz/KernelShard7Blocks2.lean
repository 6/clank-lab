import KernelRowIndex
import KernelWitness7

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_7_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 64 * 256 + i.val))
      kernelWitness7Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_64

theorem kernelBlock_7_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 65 * 256 + i.val))
      kernelWitness7Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_65

theorem kernelBlock_7_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 66 * 256 + i.val))
      kernelWitness7Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_66

theorem kernelBlock_7_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 67 * 256 + i.val))
      kernelWitness7Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_67

theorem kernelBlock_7_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 68 * 256 + i.val))
      kernelWitness7Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_68

theorem kernelBlock_7_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 69 * 256 + i.val))
      kernelWitness7Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_69

theorem kernelBlock_7_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 70 * 256 + i.val))
      kernelWitness7Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_70

theorem kernelBlock_7_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 71 * 256 + i.val))
      kernelWitness7Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_71

theorem kernelBlock_7_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 72 * 256 + i.val))
      kernelWitness7Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_72

theorem kernelBlock_7_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 73 * 256 + i.val))
      kernelWitness7Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_73

theorem kernelBlock_7_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 74 * 256 + i.val))
      kernelWitness7Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_74

theorem kernelBlock_7_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 75 * 256 + i.val))
      kernelWitness7Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_75

theorem kernelBlock_7_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 76 * 256 + i.val))
      kernelWitness7Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_76

theorem kernelBlock_7_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 77 * 256 + i.val))
      kernelWitness7Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_77

theorem kernelBlock_7_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 78 * 256 + i.val))
      kernelWitness7Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_78

theorem kernelBlock_7_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 79 * 256 + i.val))
      kernelWitness7Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_79

theorem kernelBlock_7_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 80 * 256 + i.val))
      kernelWitness7Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_80

theorem kernelBlock_7_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 81 * 256 + i.val))
      kernelWitness7Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_81

theorem kernelBlock_7_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 82 * 256 + i.val))
      kernelWitness7Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_82

theorem kernelBlock_7_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 83 * 256 + i.val))
      kernelWitness7Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_83

theorem kernelBlock_7_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 84 * 256 + i.val))
      kernelWitness7Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_84

theorem kernelBlock_7_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 85 * 256 + i.val))
      kernelWitness7Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_85

theorem kernelBlock_7_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 86 * 256 + i.val))
      kernelWitness7Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_86

theorem kernelBlock_7_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 87 * 256 + i.val))
      kernelWitness7Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_87

theorem kernelBlock_7_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 88 * 256 + i.val))
      kernelWitness7Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_88

theorem kernelBlock_7_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 89 * 256 + i.val))
      kernelWitness7Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_89

theorem kernelBlock_7_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 90 * 256 + i.val))
      kernelWitness7Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_90

theorem kernelBlock_7_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 91 * 256 + i.val))
      kernelWitness7Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_91

theorem kernelBlock_7_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 92 * 256 + i.val))
      kernelWitness7Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_92

theorem kernelBlock_7_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 93 * 256 + i.val))
      kernelWitness7Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_93

theorem kernelBlock_7_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 94 * 256 + i.val))
      kernelWitness7Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_94

theorem kernelBlock_7_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (7 * 32768 + 95 * 256 + i.val))
      kernelWitness7Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_7_95

end TightCycleC5.Bridge.Cover
