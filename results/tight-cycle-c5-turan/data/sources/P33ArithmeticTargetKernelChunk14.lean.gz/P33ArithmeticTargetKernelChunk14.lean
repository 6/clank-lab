-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk56 :
    ∀ i : Fin (min 128 (40547 - 128 * 56)),
      targetCountsMatch (classAt (targetKernelClass ⟨56, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk56

theorem target_counts_kernel_chunk57 :
    ∀ i : Fin (min 128 (40547 - 128 * 57)),
      targetCountsMatch (classAt (targetKernelClass ⟨57, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk57

theorem target_counts_kernel_chunk58 :
    ∀ i : Fin (min 128 (40547 - 128 * 58)),
      targetCountsMatch (classAt (targetKernelClass ⟨58, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk58

theorem target_counts_kernel_chunk59 :
    ∀ i : Fin (min 128 (40547 - 128 * 59)),
      targetCountsMatch (classAt (targetKernelClass ⟨59, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk59


end TightCycleC5.Bridge.P33Arithmetic
