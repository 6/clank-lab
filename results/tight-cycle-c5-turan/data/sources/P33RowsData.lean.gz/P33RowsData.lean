-- Untrusted quotation from coefficient-1 certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799
import P33RowsCore

namespace TightCycleC5.Bridge.P33Rows

def regularTypes : Array Nat := #[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3]
def regularFlags : Array Nat := #[0, 4, 12, 16, 20, 24, 28, 48, 52, 60, 64, 68, 76, 80, 84, 88, 92, 112, 116, 124, 128, 132, 140, 144, 148, 152, 156, 176, 180, 188, 192, 196, 204, 208, 212, 216, 220, 240, 244, 252, 2, 6, 14, 18, 22, 26, 30, 50, 54, 62, 66, 70, 78, 82, 86, 90, 94, 114, 118, 126, 130, 134, 142, 146, 150, 154, 158, 178, 182, 190, 194, 198, 206, 210, 214, 218, 222, 242, 246, 254, 3, 7, 15, 19, 23, 27, 31, 51, 55, 63, 67, 71, 79, 83, 87, 91, 95, 115, 119, 127, 131, 135, 143, 147, 151, 155, 159, 179, 183, 191, 195, 199, 207, 211, 215, 219, 223, 243, 247, 255]
def localColors : Array Bool := #[false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true]
def localFlags : Array Nat := #[0, 2, 6, 14, 16, 18, 22, 24, 26, 30, 48, 50, 52, 54, 60, 62, 112, 114, 118, 126, 128, 130, 134, 142, 144, 146, 150, 152, 154, 158, 176, 178, 180, 182, 188, 190, 240, 242, 246, 254, 1, 3, 7, 15, 17, 19, 23, 25, 27, 31, 49, 51, 53, 55, 61, 63, 113, 115, 119, 127, 129, 131, 135, 143, 145, 147, 151, 153, 155, 159, 177, 179, 181, 183, 189, 191, 241, 243, 247, 255]
def globalFlags : Array Nat := #[0, 1, 3, 7, 8, 9, 11, 15]

def localDescriptor (i : Fin 80) : LocalDescriptor := ⟨localColors[i.val]!, localFlags[i.val]!⟩
def regularDescriptor (i : Fin 120) : RegularDescriptor := ⟨regularTypes[i.val]!, regularFlags[i.val]!⟩
def cutDescriptor (i : Fin 8) : Nat := globalFlags[i.val]!
def densityDescriptor (i : Fin 9) : Option Nat :=
  if i.val < 8 then some globalFlags[i.val]! else none

end TightCycleC5.Bridge.P33Rows
