import KernelRowIndex
import KernelWitness1

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_1_32 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 32 * 256 + i.val))
      kernelWitness1Row32[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_32

theorem kernelBlock_1_33 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 33 * 256 + i.val))
      kernelWitness1Row33[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_33

theorem kernelBlock_1_34 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 34 * 256 + i.val))
      kernelWitness1Row34[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_34

theorem kernelBlock_1_35 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 35 * 256 + i.val))
      kernelWitness1Row35[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_35

theorem kernelBlock_1_36 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 36 * 256 + i.val))
      kernelWitness1Row36[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_36

theorem kernelBlock_1_37 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 37 * 256 + i.val))
      kernelWitness1Row37[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_37

theorem kernelBlock_1_38 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 38 * 256 + i.val))
      kernelWitness1Row38[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_38

theorem kernelBlock_1_39 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 39 * 256 + i.val))
      kernelWitness1Row39[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_39

theorem kernelBlock_1_40 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 40 * 256 + i.val))
      kernelWitness1Row40[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_40

theorem kernelBlock_1_41 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 41 * 256 + i.val))
      kernelWitness1Row41[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_41

theorem kernelBlock_1_42 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 42 * 256 + i.val))
      kernelWitness1Row42[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_42

theorem kernelBlock_1_43 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 43 * 256 + i.val))
      kernelWitness1Row43[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_43

theorem kernelBlock_1_44 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 44 * 256 + i.val))
      kernelWitness1Row44[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_44

theorem kernelBlock_1_45 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 45 * 256 + i.val))
      kernelWitness1Row45[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_45

theorem kernelBlock_1_46 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 46 * 256 + i.val))
      kernelWitness1Row46[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_46

theorem kernelBlock_1_47 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 47 * 256 + i.val))
      kernelWitness1Row47[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_47

theorem kernelBlock_1_48 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 48 * 256 + i.val))
      kernelWitness1Row48[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_48

theorem kernelBlock_1_49 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 49 * 256 + i.val))
      kernelWitness1Row49[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_49

theorem kernelBlock_1_50 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 50 * 256 + i.val))
      kernelWitness1Row50[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_50

theorem kernelBlock_1_51 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 51 * 256 + i.val))
      kernelWitness1Row51[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_51

theorem kernelBlock_1_52 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 52 * 256 + i.val))
      kernelWitness1Row52[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_52

theorem kernelBlock_1_53 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 53 * 256 + i.val))
      kernelWitness1Row53[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_53

theorem kernelBlock_1_54 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 54 * 256 + i.val))
      kernelWitness1Row54[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_54

theorem kernelBlock_1_55 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 55 * 256 + i.val))
      kernelWitness1Row55[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_55

theorem kernelBlock_1_56 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 56 * 256 + i.val))
      kernelWitness1Row56[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_56

theorem kernelBlock_1_57 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 57 * 256 + i.val))
      kernelWitness1Row57[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_57

theorem kernelBlock_1_58 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 58 * 256 + i.val))
      kernelWitness1Row58[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_58

theorem kernelBlock_1_59 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 59 * 256 + i.val))
      kernelWitness1Row59[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_59

theorem kernelBlock_1_60 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 60 * 256 + i.val))
      kernelWitness1Row60[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_60

theorem kernelBlock_1_61 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 61 * 256 + i.val))
      kernelWitness1Row61[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_61

theorem kernelBlock_1_62 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 62 * 256 + i.val))
      kernelWitness1Row62[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_62

theorem kernelBlock_1_63 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 63 * 256 + i.val))
      kernelWitness1Row63[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_63

end TightCycleC5.Bridge.Cover
