import KernelShard6Blocks0
import KernelShard6Blocks1
import KernelShard6Blocks2
import KernelShard6Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard6 : kernelShardCheck 6 kernelWitness6 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (6 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness6 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_6_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard6
end TightCycleC5.Bridge.Cover
