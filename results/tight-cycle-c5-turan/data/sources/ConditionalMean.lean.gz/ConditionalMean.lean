import TupleSampling

/-! Exact restriction of a uniform mean and its bounded discarded part. -/
namespace TightCycleC5.Bridge
open Finset

theorem uniformMean_product {A B : Type*} [Fintype A] [Fintype B]
    (g : A → ℝ) (h : B → ℝ) :
    uniformMean (fun p : A × B => g p.1 * h p.2) = uniformMean g * uniformMean h := by
  simp only [uniformMean, Fintype.card_prod, Nat.cast_mul, Fintype.sum_prod_type,
    div_mul_div_comm, Finset.sum_mul, Finset.mul_sum]
  rw [Finset.sum_comm]

/-- The error is the signed sum on the complement, divided by the number
of retained outcomes. No independence or asymptotic estimate is assumed. -/
theorem restricted_mean_decomposition {Ω : Type*} [Fintype Ω] [Nonempty Ω] [DecidableEq Ω]
    (s : Finset Ω) (f : Ω → ℝ) (hf : ∀ x, |f x| ≤ 1) :
    ∃ ε : ℝ,
      uniformMean (fun x : s => f x.val) =
        (Fintype.card Ω : ℝ) / (s.card : ℝ) * uniformMean f - ε ∧
      |ε| ≤ ((sᶜ).card : ℝ) / (s.card : ℝ) := by
  classical
  refine ⟨(∑ x ∈ sᶜ, f x) / (s.card : ℝ), ?_, ?_⟩
  · rw [uniformMean_finset]
    have hsum := s.sum_add_sum_compl f
    have hcard : (Fintype.card Ω : ℝ) ≠ 0 := by exact_mod_cast Fintype.card_ne_zero
    unfold uniformMean
    rw [mul_comm ((Fintype.card Ω : ℝ) / (s.card : ℝ)), div_mul_div_cancel₀ hcard]
    rw [← hsum]
    ring
  · rw [abs_div, abs_of_nonneg (Nat.cast_nonneg s.card : (0 : ℝ) ≤ s.card)]
    apply div_le_div_of_nonneg_right _ (Nat.cast_nonneg _)
    calc
      _ ≤ ∑ x ∈ sᶜ, |f x| := abs_sum_le_sum_abs f _
      _ ≤ ∑ _x ∈ sᶜ, (1 : ℝ) := sum_le_sum fun x _ => hf x
      _ = _ := by simp

#print axioms uniformMean_product
#print axioms restricted_mean_decomposition
end TightCycleC5.Bridge
