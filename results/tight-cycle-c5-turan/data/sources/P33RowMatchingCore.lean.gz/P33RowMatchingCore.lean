import P33ArithmeticEncoding
import P33RowsCodes

namespace TightCycleC5.Bridge.P33RowMatching
open Finset

/-- Forward arithmetic orders correspond to the inverse of the existing action. -/
def structureAt (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) : LabelledStructure 6 :=
  p.symm • MaskEncoding.decodeStructure (BitVec.ofNat 20 K.mask) (BitVec.ofNat 6 K.colours)

theorem structureAt_inverse (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) :
    structureAt K p.symm = p • MaskEncoding.decodeStructure
      (BitVec.ofNat 20 K.mask) (BitVec.ofNat 6 K.colours) := rfl

theorem structureAt_edge (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) (a b c : Fin 6) :
    (structureAt K p).edge {a,b,c} =
      (MaskEncoding.decodeStructure (BitVec.ofNat 20 K.mask)
        (BitVec.ofNat 6 K.colours)).edge {p a,p b,p c} := by
  change (MaskEncoding.decodeStructure (BitVec.ofNat 20 K.mask)
    (BitVec.ofNat 6 K.colours)).edge (({a,b,c} : Finset (Fin 6)).map p.toEmbedding) = _
  simp

theorem edge_at (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) (a b c : Fin 6)
    (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c) :
    P33Arithmetic.edge K.mask (p a).val (p b).val (p c).val =
      ((structureAt K p).edge {a,b,c}).toNat := by
  rw [structureAt_edge]
  exact P33Arithmetic.edge_eq_decoded K.mask K.colours _ _ _
    (p.injective.ne hab) (p.injective.ne hac) (p.injective.ne hbc)

theorem colour_at (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) (a : Fin 6) :
    P33Arithmetic.colour K.colours (p a).val = ((structureAt K p).color a).toNat :=
  P33Arithmetic.colour_eq_decoded K.mask K.colours (p a)

/-- Exact four-position expansion, before any canonical minimum. -/
theorem encoded_four (m c a b d z : Nat) :
    P33Arithmetic.encoded m c [a,b,d,z] =
      P33Arithmetic.colour c a + 2*P33Arithmetic.colour c b + 4*P33Arithmetic.colour c d + 8*P33Arithmetic.colour c z +
      16*(P33Arithmetic.edge m a b d + 2*P33Arithmetic.edge m a b z + 4*P33Arithmetic.edge m a d z + 8*P33Arithmetic.edge m b d z) := by
  simp [P33Arithmetic.encoded, P33Arithmetic.triples, List.range_succ, Nat.shiftLeft_eq]
  omega

#print axioms structureAt_inverse
#print axioms structureAt_edge
#print axioms edge_at
#print axioms colour_at
#print axioms encoded_four
end TightCycleC5.Bridge.P33RowMatching
