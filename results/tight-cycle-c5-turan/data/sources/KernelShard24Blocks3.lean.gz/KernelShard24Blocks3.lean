import KernelRowIndex
import KernelWitness24

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_24_96 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 96 * 256 + i.val))
      kernelWitness24Row96[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_96

theorem kernelBlock_24_97 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 97 * 256 + i.val))
      kernelWitness24Row97[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_97

theorem kernelBlock_24_98 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 98 * 256 + i.val))
      kernelWitness24Row98[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_98

theorem kernelBlock_24_99 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 99 * 256 + i.val))
      kernelWitness24Row99[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_99

theorem kernelBlock_24_100 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 100 * 256 + i.val))
      kernelWitness24Row100[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_100

theorem kernelBlock_24_101 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 101 * 256 + i.val))
      kernelWitness24Row101[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_101

theorem kernelBlock_24_102 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 102 * 256 + i.val))
      kernelWitness24Row102[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_102

theorem kernelBlock_24_103 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 103 * 256 + i.val))
      kernelWitness24Row103[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_103

theorem kernelBlock_24_104 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 104 * 256 + i.val))
      kernelWitness24Row104[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_104

theorem kernelBlock_24_105 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 105 * 256 + i.val))
      kernelWitness24Row105[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_105

theorem kernelBlock_24_106 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 106 * 256 + i.val))
      kernelWitness24Row106[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_106

theorem kernelBlock_24_107 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 107 * 256 + i.val))
      kernelWitness24Row107[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_107

theorem kernelBlock_24_108 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 108 * 256 + i.val))
      kernelWitness24Row108[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_108

theorem kernelBlock_24_109 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 109 * 256 + i.val))
      kernelWitness24Row109[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_109

theorem kernelBlock_24_110 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 110 * 256 + i.val))
      kernelWitness24Row110[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_110

theorem kernelBlock_24_111 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 111 * 256 + i.val))
      kernelWitness24Row111[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_111

theorem kernelBlock_24_112 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 112 * 256 + i.val))
      kernelWitness24Row112[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_112

theorem kernelBlock_24_113 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 113 * 256 + i.val))
      kernelWitness24Row113[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_113

theorem kernelBlock_24_114 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 114 * 256 + i.val))
      kernelWitness24Row114[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_114

theorem kernelBlock_24_115 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 115 * 256 + i.val))
      kernelWitness24Row115[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_115

theorem kernelBlock_24_116 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 116 * 256 + i.val))
      kernelWitness24Row116[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_116

theorem kernelBlock_24_117 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 117 * 256 + i.val))
      kernelWitness24Row117[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_117

theorem kernelBlock_24_118 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 118 * 256 + i.val))
      kernelWitness24Row118[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_118

theorem kernelBlock_24_119 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 119 * 256 + i.val))
      kernelWitness24Row119[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_119

theorem kernelBlock_24_120 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 120 * 256 + i.val))
      kernelWitness24Row120[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_120

theorem kernelBlock_24_121 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 121 * 256 + i.val))
      kernelWitness24Row121[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_121

theorem kernelBlock_24_122 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 122 * 256 + i.val))
      kernelWitness24Row122[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_122

theorem kernelBlock_24_123 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 123 * 256 + i.val))
      kernelWitness24Row123[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_123

theorem kernelBlock_24_124 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 124 * 256 + i.val))
      kernelWitness24Row124[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_124

theorem kernelBlock_24_125 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 125 * 256 + i.val))
      kernelWitness24Row125[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_125

theorem kernelBlock_24_126 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 126 * 256 + i.val))
      kernelWitness24Row126[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_126

theorem kernelBlock_24_127 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 127 * 256 + i.val))
      kernelWitness24Row127[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_127

end TightCycleC5.Bridge.Cover
