import KernelRowIndex
import KernelWitness10

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_10_32 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 32 * 256 + i.val))
      kernelWitness10Row32[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_32

theorem kernelBlock_10_33 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 33 * 256 + i.val))
      kernelWitness10Row33[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_33

theorem kernelBlock_10_34 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 34 * 256 + i.val))
      kernelWitness10Row34[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_34

theorem kernelBlock_10_35 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 35 * 256 + i.val))
      kernelWitness10Row35[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_35

theorem kernelBlock_10_36 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 36 * 256 + i.val))
      kernelWitness10Row36[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_36

theorem kernelBlock_10_37 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 37 * 256 + i.val))
      kernelWitness10Row37[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_37

theorem kernelBlock_10_38 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 38 * 256 + i.val))
      kernelWitness10Row38[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_38

theorem kernelBlock_10_39 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 39 * 256 + i.val))
      kernelWitness10Row39[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_39

theorem kernelBlock_10_40 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 40 * 256 + i.val))
      kernelWitness10Row40[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_40

theorem kernelBlock_10_41 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 41 * 256 + i.val))
      kernelWitness10Row41[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_41

theorem kernelBlock_10_42 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 42 * 256 + i.val))
      kernelWitness10Row42[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_42

theorem kernelBlock_10_43 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 43 * 256 + i.val))
      kernelWitness10Row43[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_43

theorem kernelBlock_10_44 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 44 * 256 + i.val))
      kernelWitness10Row44[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_44

theorem kernelBlock_10_45 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 45 * 256 + i.val))
      kernelWitness10Row45[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_45

theorem kernelBlock_10_46 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 46 * 256 + i.val))
      kernelWitness10Row46[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_46

theorem kernelBlock_10_47 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 47 * 256 + i.val))
      kernelWitness10Row47[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_47

theorem kernelBlock_10_48 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 48 * 256 + i.val))
      kernelWitness10Row48[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_48

theorem kernelBlock_10_49 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 49 * 256 + i.val))
      kernelWitness10Row49[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_49

theorem kernelBlock_10_50 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 50 * 256 + i.val))
      kernelWitness10Row50[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_50

theorem kernelBlock_10_51 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 51 * 256 + i.val))
      kernelWitness10Row51[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_51

theorem kernelBlock_10_52 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 52 * 256 + i.val))
      kernelWitness10Row52[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_52

theorem kernelBlock_10_53 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 53 * 256 + i.val))
      kernelWitness10Row53[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_53

theorem kernelBlock_10_54 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 54 * 256 + i.val))
      kernelWitness10Row54[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_54

theorem kernelBlock_10_55 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 55 * 256 + i.val))
      kernelWitness10Row55[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_55

theorem kernelBlock_10_56 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 56 * 256 + i.val))
      kernelWitness10Row56[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_56

theorem kernelBlock_10_57 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 57 * 256 + i.val))
      kernelWitness10Row57[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_57

theorem kernelBlock_10_58 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 58 * 256 + i.val))
      kernelWitness10Row58[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_58

theorem kernelBlock_10_59 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 59 * 256 + i.val))
      kernelWitness10Row59[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_59

theorem kernelBlock_10_60 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 60 * 256 + i.val))
      kernelWitness10Row60[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_60

theorem kernelBlock_10_61 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 61 * 256 + i.val))
      kernelWitness10Row61[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_61

theorem kernelBlock_10_62 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 62 * 256 + i.val))
      kernelWitness10Row62[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_62

theorem kernelBlock_10_63 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 63 * 256 + i.val))
      kernelWitness10Row63[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_63

end TightCycleC5.Bridge.Cover
