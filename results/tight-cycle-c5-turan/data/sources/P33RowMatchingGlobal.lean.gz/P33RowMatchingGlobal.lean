import P33RowMatchingGlobalCodes
import P33RowMatchingData
import P33RowMatchingLookup
import P33RowMatchingFeatures
import P33Rows

namespace TightCycleC5.Bridge.P33RowMatching
open Finset

def globalKey (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) : Nat :=
  P33Arithmetic.canonical K.mask K.colours [] [(p 3).val,(p 4).val,(p 5).val]
def globalQueryValid (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) : Prop :=
  P33Arithmetic.lookup P33Arithmetic.globalFlags (globalKey K p) < P33Arithmetic.globalFlags.size

theorem global_index_iff (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (i : Fin 8) (hv : globalQueryValid K p) :
    i.val = (P33Arithmetic.featuresAt P33Arithmetic.localFlags P33Arithmetic.globalFlags
      P33Arithmetic.blocks K p).globalIndex ↔
    P33Rows.globalCode (fun x u v => (structureAt K p).edge {x,u,v})
      (structureAt K p).color 3 4 5 = P33Rows.globalFlags[i.val]! := by
  rw [features_globalIndex]
  change (i.val = P33Arithmetic.lookup P33Arithmetic.globalFlags (globalKey K p)) ↔ _
  have hn : P33Arithmetic.globalFlags.toList.Nodup := by
    rw [global_table_aligned]
    exact P33Rows.source_bases_no_duplicates.2.2
  have hs : P33Arithmetic.globalFlags.size = 8 := by decide +kernel
  rw [eq_comm, lookup_eq_iff _ hn _ i.val (by rw [hs]; exact i.isLt) hv]
  rw [globalKey, canonical_global, global_table_aligned]

theorem globalFlag_eq_index (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (i : Fin 8) (hv : globalQueryValid K p) :
    P33Rows.globalFlag (P33Rows.cutDescriptor i) (fun x u v => (structureAt K p).edge {x,u,v})
      (structureAt K p).color 3 4 5 =
    if i.val = (P33Arithmetic.featuresAt P33Arithmetic.localFlags P33Arithmetic.globalFlags
      P33Arithmetic.blocks K p).globalIndex then 1 else 0 := by
  unfold P33Rows.globalFlag P33Rows.cutDescriptor
  have hc := global_index_iff K p i hv
  by_cases hi : i.val = (P33Arithmetic.featuresAt P33Arithmetic.localFlags P33Arithmetic.globalFlags
      P33Arithmetic.blocks K p).globalIndex
  · rw [if_pos hi, if_pos (hc.mp hi)]
  · rw [if_neg hi, if_neg (fun h => hi (hc.mpr h))]

theorem cutValue_real (ls : Array (Array Nat)) (gs : Array Nat)
    (bs : Array P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) :
    ((P33Arithmetic.featuresAt ls gs bs K p).cutValue : ℝ) / 5 =
      P33Rows.cutValue (fun x u v => (structureAt K p).edge {x,u,v})
        (structureAt K p).color 0 1 2 - 2/5 := by
  rw [features_cutValue]
  simp only [edgeAt, colourAt, edge_at K p 0 1 2 (by decide) (by decide) (by decide), colour_at]
  cases h0 : (structureAt K p).color 0 <;>
    cases h1 : (structureAt K p).color 1 <;>
    cases h2 : (structureAt K p).color 2 <;>
    cases he : (structureAt K p).edge {0,1,2} <;>
    norm_num [P33Rows.cutValue, h0, h1, h2, he]

theorem densityValue_real (ls : Array (Array Nat)) (gs : Array Nat)
    (bs : Array P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) :
    ((P33Arithmetic.featuresAt ls gs bs K p).densityValue : ℝ) / 1000000000 =
      P33Rows.edgeValue (fun x u v => (structureAt K p).edge {x,u,v}) 0 1 2 - P33Rows.densityBound := by
  rw [features_densityValue]
  simp only [edgeAt, edge_at K p 0 1 2 (by decide) (by decide) (by decide)]
  cases he : (structureAt K p).edge {0,1,2} <;>
    norm_num [P33Rows.edgeValue, P33Rows.densityBound, he]

theorem cut_row_match (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (i : Fin 8) (hv : globalQueryValid K p) :
    (P33Arithmetic.inequalityRow (P33Arithmetic.featuresAt P33Arithmetic.localFlags
      P33Arithmetic.globalFlags P33Arithmetic.blocks K p) (80+i.val) : ℝ) / 1000000000 =
      P33Rows.sourceCutRow i (structureAt K p) := by
  rw [P33Arithmetic.inequalityRow, if_neg (by omega), if_pos (by omega)]
  have hi : 80+i.val-80 = i.val := by omega
  rw [hi]
  change _ = (P33Rows.cutValue _ _ 0 1 2 - 2/5) * P33Rows.globalFlag _ _ _ 3 4 5
  rw [globalFlag_eq_index K p i hv]
  split_ifs with h
  · push_cast
    simp only [mul_one]
    calc
      200000000 * ((P33Arithmetic.featuresAt P33Arithmetic.localFlags P33Arithmetic.globalFlags
        P33Arithmetic.blocks K p).cutValue : ℝ) / 1000000000 =
        ((P33Arithmetic.featuresAt P33Arithmetic.localFlags P33Arithmetic.globalFlags
          P33Arithmetic.blocks K p).cutValue : ℝ) / 5 := by ring
      _ = _ := cutValue_real _ _ _ K p
  · norm_num

theorem densityFlag_eq_index (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (i : Fin 9) (hv : globalQueryValid K p) :
    P33Rows.densityFlag (P33Rows.densityDescriptor i) (fun x u v => (structureAt K p).edge {x,u,v})
      (structureAt K p).color 3 4 5 =
    if i.val = 8 ∨ i.val = (P33Arithmetic.featuresAt P33Arithmetic.localFlags P33Arithmetic.globalFlags
      P33Arithmetic.blocks K p).globalIndex then 1 else 0 := by
  by_cases hi : i.val < 8
  · have hne : i.val ≠ 8 := by omega
    simp only [P33Rows.densityDescriptor, if_pos hi, P33Rows.densityFlag, hne, false_or]
    exact globalFlag_eq_index K p ⟨i.val,hi⟩ hv
  · have he : i = 8 := Fin.ext (by omega)
    subst i
    norm_num [P33Rows.densityDescriptor, P33Rows.densityFlag]

theorem density_row_match (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (i : Fin 9) (hv : globalQueryValid K p) :
    (P33Arithmetic.inequalityRow (P33Arithmetic.featuresAt P33Arithmetic.localFlags
      P33Arithmetic.globalFlags P33Arithmetic.blocks K p) (88+i.val) : ℝ) / 1000000000 =
      P33Rows.sourceDensityRow i (structureAt K p) := by
  rw [P33Arithmetic.inequalityRow, if_neg (by omega), if_neg (by omega), if_pos (by omega)]
  have hc : (88+i.val=96 ∨ 88+i.val-88 =
      (P33Arithmetic.featuresAt P33Arithmetic.localFlags P33Arithmetic.globalFlags P33Arithmetic.blocks K p).globalIndex) ↔
      (i.val=8 ∨ i.val = (P33Arithmetic.featuresAt P33Arithmetic.localFlags P33Arithmetic.globalFlags
        P33Arithmetic.blocks K p).globalIndex) := by omega
  simp only [hc]
  change _ = (P33Rows.edgeValue _ 0 1 2 - P33Rows.densityBound) * P33Rows.densityFlag _ _ _ 3 4 5
  rw [densityFlag_eq_index K p i hv]
  split_ifs with h
  · simp only [mul_one]
    exact densityValue_real _ _ _ K p
  · norm_num

#print axioms global_index_iff
#print axioms globalFlag_eq_index
#print axioms cutValue_real
#print axioms densityValue_real
#print axioms cut_row_match
#print axioms densityFlag_eq_index
#print axioms density_row_match
end TightCycleC5.Bridge.P33RowMatching
