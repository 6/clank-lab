import KernelQuarterIndex
import KernelWitness8

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_8_96 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 96 * 256 + i.val))
      kernelWitness8Row96[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_96

theorem kernelQuarter_8_97_0 : ∀ i : Fin 64,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 97 * 256 + (0 * 64 + i.val)))
      kernelWitness8Row97[0 * 64 + i.val]! = true := by
  decide +kernel

#print axioms kernelQuarter_8_97_0

theorem kernelQuarter_8_97_1 : ∀ i : Fin 64,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 97 * 256 + (1 * 64 + i.val)))
      kernelWitness8Row97[1 * 64 + i.val]! = true := by
  decide +kernel

#print axioms kernelQuarter_8_97_1

theorem kernelQuarter_8_97_2 : ∀ i : Fin 64,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 97 * 256 + (2 * 64 + i.val)))
      kernelWitness8Row97[2 * 64 + i.val]! = true := by
  decide +kernel

#print axioms kernelQuarter_8_97_2

theorem kernelQuarter_8_97_3 : ∀ i : Fin 64,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 97 * 256 + (3 * 64 + i.val)))
      kernelWitness8Row97[3 * 64 + i.val]! = true := by
  decide +kernel

#print axioms kernelQuarter_8_97_3

theorem kernelBlock_8_97 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 97 * 256 + i.val))
      kernelWitness8Row97[i.val]! = true := by
  apply kernelBlockFromQuarters (fun j =>
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 97 * 256 + j))
      kernelWitness8Row97[j]! = true)
  intro b
  fin_cases b
  · exact kernelQuarter_8_97_0
  · exact kernelQuarter_8_97_1
  · exact kernelQuarter_8_97_2
  · exact kernelQuarter_8_97_3

#print axioms kernelBlock_8_97

theorem kernelBlock_8_98 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 98 * 256 + i.val))
      kernelWitness8Row98[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_98

theorem kernelBlock_8_99 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 99 * 256 + i.val))
      kernelWitness8Row99[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_99

theorem kernelBlock_8_100 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 100 * 256 + i.val))
      kernelWitness8Row100[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_100

theorem kernelBlock_8_101 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 101 * 256 + i.val))
      kernelWitness8Row101[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_101

theorem kernelBlock_8_102 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 102 * 256 + i.val))
      kernelWitness8Row102[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_102

theorem kernelBlock_8_103 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 103 * 256 + i.val))
      kernelWitness8Row103[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_103

theorem kernelBlock_8_104 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 104 * 256 + i.val))
      kernelWitness8Row104[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_104

theorem kernelBlock_8_105 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 105 * 256 + i.val))
      kernelWitness8Row105[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_105

theorem kernelBlock_8_106 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 106 * 256 + i.val))
      kernelWitness8Row106[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_106

theorem kernelBlock_8_107 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 107 * 256 + i.val))
      kernelWitness8Row107[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_107

theorem kernelBlock_8_108 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 108 * 256 + i.val))
      kernelWitness8Row108[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_108

theorem kernelBlock_8_109 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 109 * 256 + i.val))
      kernelWitness8Row109[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_109

theorem kernelBlock_8_110 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 110 * 256 + i.val))
      kernelWitness8Row110[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_110

theorem kernelBlock_8_111 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 111 * 256 + i.val))
      kernelWitness8Row111[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_111

theorem kernelBlock_8_112 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 112 * 256 + i.val))
      kernelWitness8Row112[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_112

theorem kernelBlock_8_113 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 113 * 256 + i.val))
      kernelWitness8Row113[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_113

theorem kernelBlock_8_114 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 114 * 256 + i.val))
      kernelWitness8Row114[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_114

theorem kernelBlock_8_115 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 115 * 256 + i.val))
      kernelWitness8Row115[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_115

theorem kernelBlock_8_116 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 116 * 256 + i.val))
      kernelWitness8Row116[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_116

theorem kernelBlock_8_117 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 117 * 256 + i.val))
      kernelWitness8Row117[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_117

theorem kernelBlock_8_118 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 118 * 256 + i.val))
      kernelWitness8Row118[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_118

theorem kernelBlock_8_119 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 119 * 256 + i.val))
      kernelWitness8Row119[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_119

theorem kernelBlock_8_120 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 120 * 256 + i.val))
      kernelWitness8Row120[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_120

theorem kernelBlock_8_121 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 121 * 256 + i.val))
      kernelWitness8Row121[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_121

theorem kernelBlock_8_122 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 122 * 256 + i.val))
      kernelWitness8Row122[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_122

theorem kernelBlock_8_123 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 123 * 256 + i.val))
      kernelWitness8Row123[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_123

theorem kernelBlock_8_124 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 124 * 256 + i.val))
      kernelWitness8Row124[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_124

theorem kernelBlock_8_125 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 125 * 256 + i.val))
      kernelWitness8Row125[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_125

theorem kernelBlock_8_126 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 126 * 256 + i.val))
      kernelWitness8Row126[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_126

theorem kernelBlock_8_127 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 127 * 256 + i.val))
      kernelWitness8Row127[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_127

end TightCycleC5.Bridge.Cover
