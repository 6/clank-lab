import Upper
import Lower

/-!
# The endpoint, conditional on M4

`mubayi_rodl_of_m4 : M4Statement → (ex n / C(n,3) → 2√3 − 3)`.
The upper bound `ex n ≤ α n³ / 6` is `m4_implies_bound`; the lower bound
`ex n ≥ L n³ − 2n²` is the Mubayi–Rödl construction (`ex_ge`). Both are
`α n³/(6 C(n,3))` up to a factor `1 − 12/(α n)`, and `n³/(6 C(n,3)) → 1`.
-/

namespace TightCycleC5

open Filter Topology

/-- `6 C(n,3) = n (n − 1) (n − 2)` over the reals. -/
theorem six_choose_three (n : ℕ) :
    6 * (n.choose 3 : ℝ) = (n : ℝ) * ((n : ℝ) - 1) * ((n : ℝ) - 2) := by
  induction n with
  | zero => simp
  | succ k ih =>
    rw [Nat.choose_succ_succ', Nat.cast_add, Nat.cast_choose_two]
    push_cast
    linear_combination ih

/-- The upper bound on `ex n`, given M4. -/
theorem ex_le (h : M4Statement) (n : ℕ) :
    (ex n : ℝ) ≤ (2 * Real.sqrt 3 - 3) * (n : ℝ) ^ 3 / 6 := by
  classical
  have hmem : (∅ : Finset (Finset (Fin n))) ∈ (Finset.univ : Finset (Finset (Finset (Fin n)))).filter
      (fun H => IsThreeGraph H ∧ ¬ ContainsC5 H) := by
    simp only [Finset.mem_filter, Finset.mem_univ, true_and]
    refine ⟨fun e he => absurd he (Finset.notMem_empty e), ?_⟩
    rintro ⟨f, hf⟩
    exact Finset.notMem_empty _ (hf 0)
  obtain ⟨H, hH, hsup⟩ := Finset.exists_mem_eq_sup _ ⟨_, hmem⟩ Finset.card
  have hex : ex n = H.card := by
    unfold ex
    convert hsup
  simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hH
  rw [hex]
  exact m4_implies_bound h n H hH.1 hH.2

/-- `n³ / (6 C(n,3)) → 1`. -/
theorem tendsto_ratio :
    Tendsto (fun n : ℕ => (n : ℝ) ^ 3 / (6 * (n.choose 3 : ℝ))) atTop (𝓝 1) := by
  have h1 : Tendsto (fun n : ℕ => (1 - 1 / (n : ℝ)) * (1 - 2 / (n : ℝ))) atTop (𝓝 1) := by
    have a1 := (tendsto_const_nhds (x := (1 : ℝ))).sub
      (tendsto_const_div_atTop_nhds_zero_nat (𝕜 := ℝ) 1)
    have a2 := (tendsto_const_nhds (x := (1 : ℝ))).sub
      (tendsto_const_div_atTop_nhds_zero_nat (𝕜 := ℝ) 2)
    simpa using a1.mul a2
  have h2 := h1.inv₀ (by norm_num)
  rw [inv_one] at h2
  refine h2.congr' ?_
  filter_upwards [eventually_ge_atTop 3] with n hn
  have hn' : (3 : ℝ) ≤ n := by exact_mod_cast hn
  rw [six_choose_three]
  have hn0 : (n : ℝ) ≠ 0 := by positivity
  have hn1 : (n : ℝ) - 1 ≠ 0 := by linarith
  have hn2 : (n : ℝ) - 2 ≠ 0 := by linarith
  field_simp

/-- **The endpoint, conditional on M4.** -/
theorem mubayi_rodl_of_m4 (h : M4Statement) :
    Tendsto (fun n : ℕ => (ex n : ℝ) / (n.choose 3 : ℝ)) atTop
      (𝓝 (2 * Real.sqrt 3 - 3)) := by
  set α := 2 * Real.sqrt 3 - 3 with hα
  have hlow : Tendsto (fun n : ℕ => (α - 12 / (n : ℝ)) * ((n : ℝ) ^ 3 / (6 * (n.choose 3 : ℝ))))
      atTop (𝓝 α) := by
    have : Tendsto (fun n : ℕ => α - 12 / (n : ℝ)) atTop (𝓝 α) := by
      simpa using (tendsto_const_nhds (x := α)).sub
        (tendsto_const_div_atTop_nhds_zero_nat (𝕜 := ℝ) 12)
    simpa using this.mul tendsto_ratio
  have hup : Tendsto (fun n : ℕ => α * ((n : ℝ) ^ 3 / (6 * (n.choose 3 : ℝ)))) atTop (𝓝 α) := by
    simpa using tendsto_ratio.const_mul α
  refine tendsto_of_tendsto_of_tendsto_of_le_of_le' hlow hup ?_ ?_
  · filter_upwards [eventually_ge_atTop 3] with n hn
    have hn' : (3 : ℝ) ≤ n := by exact_mod_cast hn
    have hC : 0 < (n.choose 3 : ℝ) := by
      have := six_choose_three n
      have : 0 < (n : ℝ) * ((n : ℝ) - 1) * ((n : ℝ) - 2) := by
        apply mul_pos; apply mul_pos <;> linarith
        linarith
      linarith
    have heq : (α - 12 / (n : ℝ)) * ((n : ℝ) ^ 3 / (6 * (n.choose 3 : ℝ))) =
        (turanL * (n : ℝ) ^ 3 - 2 * (n : ℝ) ^ 2) / (n.choose 3 : ℝ) := by
      unfold turanL
      rw [← hα]
      have hn0 : (n : ℝ) ≠ 0 := by positivity
      field_simp
      ring
    rw [heq]
    exact div_le_div_of_nonneg_right (ex_ge n) hC.le
  · filter_upwards [eventually_ge_atTop 3] with n hn
    have hn' : (3 : ℝ) ≤ n := by exact_mod_cast hn
    have hC : 0 < (n.choose 3 : ℝ) := by
      have := six_choose_three n
      have : 0 < (n : ℝ) * ((n : ℝ) - 1) * ((n : ℝ) - 2) := by
        apply mul_pos; apply mul_pos <;> linarith
        linarith
      linarith
    have heq : α * ((n : ℝ) ^ 3 / (6 * (n.choose 3 : ℝ))) =
        (α * (n : ℝ) ^ 3 / 6) / (n.choose 3 : ℝ) := by
      field_simp
    rw [heq]
    exact div_le_div_of_nonneg_right (ex_le h n) hC.le

end TightCycleC5
