import SixSampling
import FamilyCheck

/-! Faithful six-vertex mask encoding, in the frozen certificates' lexicographic
triple order. Colour bit true is outside the chosen cut. -/
namespace TightCycleC5.Bridge.MaskEncoding
open Finset

def triples : List (Finset (Fin 6)) := [
  {0, 1, 2},
  {0, 1, 3},
  {0, 1, 4},
  {0, 1, 5},
  {0, 2, 3},
  {0, 2, 4},
  {0, 2, 5},
  {0, 3, 4},
  {0, 3, 5},
  {0, 4, 5},
  {1, 2, 3},
  {1, 2, 4},
  {1, 2, 5},
  {1, 3, 4},
  {1, 3, 5},
  {1, 4, 5},
  {2, 3, 4},
  {2, 3, 5},
  {2, 4, 5},
  {3, 4, 5}]

def tripleAt (i : Fin 20) : Finset (Fin 6) := triples[i.val]!
def tripleIndex (e : Finset (Fin 6)) : ℕ := triples.idxOf e

theorem tripleAt_card : ∀ i, (tripleAt i).card = 3 := by decide

theorem tripleIndex_tripleAt : ∀ i, tripleIndex (tripleAt i) = i.val := by decide

theorem triples_complete : ∀ e : Finset (Fin 6), e.card = 3 →
    ∃ i : Fin 20, tripleAt i = e := by decide

def graphCode (G : LabelledStructure 6) : BitVec 20 :=
  (BitVec.ofBoolListLE (List.ofFn (fun i : Fin 20 => G.edge (tripleAt i)))).cast
    List.length_ofFn

def colorCode (G : LabelledStructure 6) : BitVec 6 :=
  (BitVec.ofBoolListLE (List.ofFn G.color)).cast List.length_ofFn

def decodeStructure (m : BitVec 20) (c : BitVec 6) : LabelledStructure 6 :=
  ⟨fun e => if e.card = 3 then m.getLsbD (tripleIndex e) else false,
   fun i => c.getLsbD i.val⟩

theorem graphCode_bit (G : LabelledStructure 6) (i : Fin 20) :
    (graphCode G).getLsbD i.val = G.edge (tripleAt i) := by
  simp only [graphCode, BitVec.getLsbD_cast, BitVec.getLsbD_ofBoolListLE]
  rw [List.getD_eq_getElem?_getD, List.getElem?_ofFn]
  simp [i.isLt]

theorem colorCode_bit (G : LabelledStructure 6) (i : Fin 6) :
    (colorCode G).getLsbD i.val = G.color i := by
  simp only [colorCode, BitVec.getLsbD_cast, BitVec.getLsbD_ofBoolListLE]
  rw [List.getD_eq_getElem?_getD, List.getElem?_ofFn]
  simp [i.isLt]

/-- Off-triple edges must vanish; no graph or colouring assumption is hidden. -/
theorem decode_encode (G : LabelledStructure 6)
    (hthree : ∀ e, G.edge e = true → e.card = 3) :
    decodeStructure (graphCode G) (colorCode G) = G := by
  apply LabelledStructure.ext
  · funext e
    by_cases he : e.card = 3
    · obtain ⟨i, rfl⟩ := triples_complete e he
      simp only [decodeStructure, tripleAt_card, ↓reduceIte, tripleIndex_tripleAt]
      exact graphCode_bit G i
    · have hfalse : G.edge e = false := by
        cases hb : G.edge e
        · rfl
        · exact False.elim (he (hthree e hb))
      simp only [decodeStructure, he, ↓reduceIte, hfalse]
  · funext i
    exact colorCode_bit G i

theorem encode_sample {n : ℕ} (σ : Fin 6 ↪ Fin n)
    {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H) (S : Finset (Fin n)) :
    decodeStructure (graphCode (sampleStructure σ H S))
      (colorCode (sampleStructure σ H S)) = sampleStructure σ H S :=
  decode_encode _ (sampleStructure_three σ hH S)

def decodeGraph (m : BitVec 20) : Finset (Finset (Fin 6)) :=
  univ.filter (fun e => e.card = 3 ∧ m.getLsbD (tripleIndex e) = true)

theorem decodeGraph_three (m : BitVec 20) : IsThreeGraph (decodeGraph m) := by
  intro e he
  exact (mem_filter.mp he).2.1

theorem decodeGraph_edge (m : BitVec 20) (c : BitVec 6) (e : Finset (Fin 6)) :
    e ∈ decodeGraph m ↔ (decodeStructure m c).edge e = true := by
  simp only [decodeGraph, mem_filter, mem_univ, true_and, decodeStructure]
  by_cases he : e.card = 3 <;> simp [he]

def CodeContainsC5 (m : BitVec 20) : Prop :=
  ∃ f : Fin 5 ↪ Fin 6, ∀ i : Fin 5,
    m.getLsbD (tripleIndex {f i, f (i + 1), f (i + 2)}) = true

theorem cycle_triple_card (f : Fin 5 ↪ Fin 6) (i : Fin 5) :
    ({f i, f (i + 1), f (i + 2)} : Finset (Fin 6)).card = 3 := by
  have h : ∀ i : Fin 5, ({i, i + 1, i + 2} : Finset (Fin 5)).card = 3 := by decide
  simpa only [map_insert, map_singleton, card_map] using
    (show (({i, i + 1, i + 2} : Finset (Fin 5)).map f).card = 3 by
      simpa only [card_map] using h i)

theorem codeContainsC5_iff (m : BitVec 20) :
    CodeContainsC5 m ↔ ContainsC5 (decodeGraph m) := by
  constructor
  · rintro ⟨f, hf⟩
    refine ⟨f, fun i => ?_⟩
    exact mem_filter.mpr ⟨mem_univ _, cycle_triple_card f i, hf i⟩
  · rintro ⟨f, hf⟩
    exact ⟨f, fun i => (mem_filter.mp (hf i)).2.2⟩

theorem sample_code_c5free {n : ℕ} (σ : Fin 6 ↪ Fin n)
    {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H)
    (S : Finset (Fin n)) : ¬ CodeContainsC5 (graphCode (sampleStructure σ H S)) := by
  intro h
  obtain ⟨f, hf⟩ := (codeContainsC5_iff _).mp h
  apply sampleStructure_c5free σ hC S
  refine ⟨f, fun i => ?_⟩
  have he := (decodeGraph_edge _ (colorCode (sampleStructure σ H S)) _).mp (hf i)
  simpa only [encode_sample σ hH S] using he

theorem graphCode_decode (m : BitVec 20) (c : BitVec 6) :
    graphCode (decodeStructure m c) = m := by
  apply BitVec.eq_of_getLsbD_eq
  intro i hi
  rw [graphCode_bit _ ⟨i, hi⟩]
  simp only [decodeStructure, tripleAt_card, ↓reduceIte, tripleIndex_tripleAt]

theorem colorCode_decode (m : BitVec 20) (c : BitVec 6) :
    colorCode (decodeStructure m c) = c := by
  apply BitVec.eq_of_getLsbD_eq
  intro i hi
  exact colorCode_bit _ ⟨i, hi⟩

theorem decodeStructure_three (m : BitVec 20) (c : BitVec 6) :
    ∀ e, (decodeStructure m c).edge e = true → e.card = 3 := by
  intro e he
  by_cases hc : e.card = 3
  · exact hc
  · simp [decodeStructure, hc] at he

def permuteMask (p : Equiv.Perm (Fin 6)) (m : BitVec 20) : BitVec 20 :=
  graphCode (p • decodeStructure m 0)

def permuteColor (p : Equiv.Perm (Fin 6)) (c : BitVec 6) : BitVec 6 :=
  colorCode (p • decodeStructure 0 c)

/-- Bit relabelling agrees with the actual action on all subsets and colours. -/
theorem decode_permute (p : Equiv.Perm (Fin 6)) (m : BitVec 20) (c : BitVec 6) :
    decodeStructure (permuteMask p m) (permuteColor p c) = p • decodeStructure m c := by
  have hg : permuteMask p m = graphCode (p • decodeStructure m c) := rfl
  have hc : permuteColor p c = colorCode (p • decodeStructure m c) := rfl
  rw [hg, hc]
  apply decode_encode
  intro e he
  change (decodeStructure m c).edge (e.map p.symm.toEmbedding) = true at he
  simpa only [card_map] using decodeStructure_three m c _ he

/-- The arithmetic index used in the first exact-family checker has the
same lexicographic meaning, on every distinct vertex triple. -/
theorem family_tripleIndex_eq : ∀ a b c : Fin 6, a ≠ b → a ≠ c → b ≠ c →
    Family.tripleIndex a.val b.val c.val = tripleIndex {a, b, c} := by decide

#print axioms tripleAt_card
#print axioms tripleIndex_tripleAt
#print axioms triples_complete
#print axioms graphCode_bit
#print axioms colorCode_bit
#print axioms decode_encode
#print axioms encode_sample
#print axioms decodeGraph_three
#print axioms decodeGraph_edge
#print axioms cycle_triple_card
#print axioms codeContainsC5_iff
#print axioms sample_code_c5free
#print axioms graphCode_decode
#print axioms colorCode_decode
#print axioms decodeStructure_three
#print axioms decode_permute
#print axioms family_tripleIndex_eq
end TightCycleC5.Bridge.MaskEncoding
