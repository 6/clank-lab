import KernelRowIndex
import KernelWitness28

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_28_32 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 32 * 256 + i.val))
      kernelWitness28Row32[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_32

theorem kernelBlock_28_33 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 33 * 256 + i.val))
      kernelWitness28Row33[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_33

theorem kernelBlock_28_34 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 34 * 256 + i.val))
      kernelWitness28Row34[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_34

theorem kernelBlock_28_35 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 35 * 256 + i.val))
      kernelWitness28Row35[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_35

theorem kernelBlock_28_36 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 36 * 256 + i.val))
      kernelWitness28Row36[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_36

theorem kernelBlock_28_37 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 37 * 256 + i.val))
      kernelWitness28Row37[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_37

theorem kernelBlock_28_38 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 38 * 256 + i.val))
      kernelWitness28Row38[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_38

theorem kernelBlock_28_39 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 39 * 256 + i.val))
      kernelWitness28Row39[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_39

theorem kernelBlock_28_40 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 40 * 256 + i.val))
      kernelWitness28Row40[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_40

theorem kernelBlock_28_41 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 41 * 256 + i.val))
      kernelWitness28Row41[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_41

theorem kernelBlock_28_42 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 42 * 256 + i.val))
      kernelWitness28Row42[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_42

theorem kernelBlock_28_43 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 43 * 256 + i.val))
      kernelWitness28Row43[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_43

theorem kernelBlock_28_44 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 44 * 256 + i.val))
      kernelWitness28Row44[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_44

theorem kernelBlock_28_45 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 45 * 256 + i.val))
      kernelWitness28Row45[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_45

theorem kernelBlock_28_46 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 46 * 256 + i.val))
      kernelWitness28Row46[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_46

theorem kernelBlock_28_47 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 47 * 256 + i.val))
      kernelWitness28Row47[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_47

theorem kernelBlock_28_48 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 48 * 256 + i.val))
      kernelWitness28Row48[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_48

theorem kernelBlock_28_49 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 49 * 256 + i.val))
      kernelWitness28Row49[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_49

theorem kernelBlock_28_50 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 50 * 256 + i.val))
      kernelWitness28Row50[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_50

theorem kernelBlock_28_51 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 51 * 256 + i.val))
      kernelWitness28Row51[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_51

theorem kernelBlock_28_52 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 52 * 256 + i.val))
      kernelWitness28Row52[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_52

theorem kernelBlock_28_53 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 53 * 256 + i.val))
      kernelWitness28Row53[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_53

theorem kernelBlock_28_54 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 54 * 256 + i.val))
      kernelWitness28Row54[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_54

theorem kernelBlock_28_55 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 55 * 256 + i.val))
      kernelWitness28Row55[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_55

theorem kernelBlock_28_56 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 56 * 256 + i.val))
      kernelWitness28Row56[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_56

theorem kernelBlock_28_57 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 57 * 256 + i.val))
      kernelWitness28Row57[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_57

theorem kernelBlock_28_58 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 58 * 256 + i.val))
      kernelWitness28Row58[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_58

theorem kernelBlock_28_59 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 59 * 256 + i.val))
      kernelWitness28Row59[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_59

theorem kernelBlock_28_60 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 60 * 256 + i.val))
      kernelWitness28Row60[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_60

theorem kernelBlock_28_61 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 61 * 256 + i.val))
      kernelWitness28Row61[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_61

theorem kernelBlock_28_62 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 62 * 256 + i.val))
      kernelWitness28Row62[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_62

theorem kernelBlock_28_63 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 63 * 256 + i.val))
      kernelWitness28Row63[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_63

end TightCycleC5.Bridge.Cover
