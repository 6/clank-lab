import P33RowMatchingNormalize

namespace TightCycleC5.Bridge.P33RowMatching
open Finset

/-- The sparse non-PSD integer is exactly the remainder of the accepted
nuisance evaluator after its PSD term, with no scale or sign alteration. -/
theorem nuisanceInteger_decomposition (K : P33Arithmetic.Class) (j : Fin 720) :
    P33Arithmetic.nuisanceInteger K j = P33Arithmetic.psdOrder P33Arithmetic.blocks K j +
      nonPSDIntegerAt K (Cover.kernelPermutation j) := by
  simp only [P33Arithmetic.nuisanceInteger,nonPSDIntegerAt,P33Arithmetic.features,
    P33Arithmetic.order_eq_kernelPermutation]
  exact add_assoc _ _ _

/-- Same five source families in the parent's finite-error assembly order. -/
theorem actualNonPSD_source_sum (G : LabelledStructure 6) : actualNonPSD G =
    (∑ i : Fin 80, P33Rows.localWeight i * P33Rows.sourceLocalRow i G) +
    (∑ i : Fin 8, P33Rows.cutWeight i * P33Rows.sourceCutRow i G) +
    (∑ i : Fin 9, P33Rows.densityWeight i * P33Rows.sourceDensityRow i G) +
    (∑ i : Fin 120, P33Rows.regularWeight i * P33Rows.sourceRegularRow i G) +
    (∑ j : Fin 12750, CertificateDescriptors.p33CLWeight false j *
      CLCertificate.row (CertificateDescriptors.p33CL j) G) := by
  unfold actualNonPSD
  ring

#print axioms nuisanceInteger_decomposition
#print axioms actualNonPSD_source_sum
end TightCycleC5.Bridge.P33RowMatching
