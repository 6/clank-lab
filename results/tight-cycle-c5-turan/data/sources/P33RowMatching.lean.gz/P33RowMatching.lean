import P33RowMatchingNormalize
import P33RowMatchingAssembly
import P33RowMatchingActions
import P33RowMatchingBlocks
import P33RowMatchingChecker
import P33RowMatchingRegularBounds
import P33PSDMatchingLookups
import PermutationEnumeration

namespace TightCycleC5.Bridge.P33RowMatching
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000

/-- Bounds use exactly the accepted finite predicate's 38-block loop. -/
theorem regularQuery_of_lookups (K : P33Arithmetic.Class) (j : Fin 720)
    (h : P33Arithmetic.lookupsValid K j = true) : regularQueryValid K (Cover.kernelPermutation j) := by
  apply regularQuery_of_blockBounds
  intro b
  have hs : P33Arithmetic.blocks.size = 38 := by decide +kernel
  have hb : b.val < P33Arithmetic.blocks.size := by rw [hs]; omega
  have hv := P33PSDMatching.lookupsValid_bounds K j h ⟨b.val,hb⟩
  simpa only [P33Arithmetic.order_eq_kernelPermutation] using hv

/-- No separate flag-cover or lookup-completeness premise is used. -/
theorem checked_inequality_rows (K : P33Arithmetic.Class) (h : P33Arithmetic.classCheck K = true)
    (j : Fin 720) (i : Fin 12847) :
    (P33Arithmetic.inequalityRow (P33Arithmetic.features P33Arithmetic.localFlags
      P33Arithmetic.globalFlags P33Arithmetic.blocks K j) i.val : ℝ) / 1000000000 =
      actualInequalityRow (structureAt K (Cover.kernelPermutation j)) i := by
  have hv := classCheck_lookups K h j
  exact inequality_row_match K (Cover.kernelPermutation j)
    (localQuery_of_lookups K j hv) (globalQuery_of_lookups K j hv) i

theorem checked_regularity_rows (K : P33Arithmetic.Class) (h : P33Arithmetic.classCheck K = true)
    (j : Fin 720) (i : Fin 120) :
    (P33Arithmetic.regularityRow (P33Arithmetic.features P33Arithmetic.localFlags
      P33Arithmetic.globalFlags P33Arithmetic.blocks K j) i.val : ℝ) / 1000000000 =
      P33Rows.sourceRegularRow i (structureAt K (Cover.kernelPermutation j)) := by
  exact regular_row_match K (Cover.kernelPermutation j) i
    (regularQuery_of_lookups K j (classCheck_lookups K h j))

/-- Checked source queries, signed coefficients, one SOS division. -/
theorem checked_nonPSD_match (K : P33Arithmetic.Class) (h : P33Arithmetic.classCheck K = true)
    (j : Fin 720) :
    (nonPSDIntegerAt K (Cover.kernelPermutation j) : ℝ) / 1000000000 /
        (P33Arithmetic.sosScale : ℝ) = actualNonPSD (structureAt K (Cover.kernelPermutation j)) := by
  have hv := classCheck_lookups K h j
  exact normalized_nonPSD_match K (Cover.kernelPermutation j)
    (localQuery_of_lookups K j hv) (globalQuery_of_lookups K j hv) (regularQuery_of_lookups K j hv)

/-- Genuine permutation transport includes the proved inverse change of variables. -/
theorem checked_nonPSD_mean (K : P33Arithmetic.Class) (h : P33Arithmetic.classCheck K = true) :
    uniformMean (fun j : Fin 720 => (nonPSDIntegerAt K (Cover.kernelPermutation j) : ℝ) /
      1000000000 / (P33Arithmetic.sosScale : ℝ)) =
    uniformMean (fun p : Equiv.Perm (Fin 6) => actualNonPSD (p • MaskEncoding.decodeStructure
      (BitVec.ofNat 20 K.mask) (BitVec.ofNat 6 K.colours))) := by
  calc
    _ = uniformMean (fun j : Fin 720 => actualNonPSD (structureAt K (Cover.kernelPermutation j))) := by
      congr 1
      funext j
      exact checked_nonPSD_match K h j
    _ = uniformMean (fun p : Equiv.Perm (Fin 6) => actualNonPSD (structureAt K p)) :=
      Cover.PermutationEnumeration.uniformMean_kernelPermutation
        (fun p : Equiv.Perm (Fin 6) => actualNonPSD (structureAt K p))
    _ = _ := mean_inverse (fun p : Equiv.Perm (Fin 6) => actualNonPSD
      (p • MaskEncoding.decodeStructure (BitVec.ofNat 20 K.mask) (BitVec.ofNat 6 K.colours)))

#print axioms regularQuery_of_lookups
#print axioms checked_inequality_rows
#print axioms checked_regularity_rows
#print axioms checked_nonPSD_match
#print axioms checked_nonPSD_mean
end TightCycleC5.Bridge.P33RowMatching
