import P33PSDMatching
import P33PSDMatchingLookups
set_option maxRecDepth 100000

namespace TightCycleC5.Bridge.P33PSDMatching

/-- The actual class predicate checks the actual lookups for every checked
permutation index, not merely an optimized auxiliary table. -/
theorem classCheck_lookupsValid (K : P33Arithmetic.Class)
    (h : P33Arithmetic.classCheck K = true) (j : Fin 720) :
    P33Arithmetic.lookupsValid K j = true := by
  simp only [P33Arithmetic.classCheck, Bool.and_eq_true] at h
  have hall : (List.finRange 720).all (P33Arithmetic.lookupsValid K) = true := by tauto
  exact List.all_eq_true.mp hall j (List.mem_finRange j)

/-- Every actual checked class supplies every actual block lookup bound.
The root gate is built into ValidLookups; no basis completeness is assumed. -/
theorem classCheck_validLookups (K : P33Arithmetic.Class)
    (h : P33Arithmetic.classCheck K = true) (j : Fin 720) (b : Fin 38) :
    ValidLookups P33Arithmetic.blocks[b.val]! K (Cover.kernelPermutation j) :=
  lookupsValid_bounds K j (classCheck_lookupsValid K h j) b

/-- The actual successful lookup predicate discharges every bound in the
38-block matching theorem, on the actual source permutation. -/
theorem lookupsValid_psdOrder (K : P33Arithmetic.Class) (j : Fin 720)
    (h : P33Arithmetic.lookupsValid K j = true) :
    (P33Arithmetic.psdOrder P33Arithmetic.blocks K j : ℝ) /
      (1000000000 * (P33Arithmetic.sosScale : ℝ)) =
      totalRows ((Cover.kernelPermutation j).symm • decoded K.mask K.colours) := by
  apply psdOrder_eq_totalRows
  intro b
  exact lookupsValid_bounds K j h b

/-- Each actual checked class has the exact normalized full PSD trace sum.
No separate lookup, matrix, or flag-completeness premise remains. -/
theorem classCheck_psdOrder (K : P33Arithmetic.Class)
    (h : P33Arithmetic.classCheck K = true) (j : Fin 720) :
    (P33Arithmetic.psdOrder P33Arithmetic.blocks K j : ℝ) /
      (1000000000 * (P33Arithmetic.sosScale : ℝ)) =
      totalRows ((Cover.kernelPermutation j).symm • decoded K.mask K.colours) :=
  lookupsValid_psdOrder K j (classCheck_lookupsValid K h j)

theorem classCheck_source_row (K : P33Arithmetic.Class)
    (h : P33Arithmetic.classCheck K = true) (j : Fin 720) (b : Fin 38) :
    (sourceContribution P33Arithmetic.blocks[b.val]! K (P33Arithmetic.order j) : ℝ) /
      (1000000000 * (P33PSD.scale : ℝ)) =
      literalRow b ((Cover.kernelPermutation j).symm • decoded K.mask K.colours) :=
  source_row b K (Cover.kernelPermutation j)
    (classCheck_validLookups K h j b)

#print axioms classCheck_lookupsValid
#print axioms classCheck_validLookups
#print axioms lookupsValid_psdOrder
#print axioms classCheck_psdOrder
#print axioms classCheck_source_row
end TightCycleC5.Bridge.P33PSDMatching
