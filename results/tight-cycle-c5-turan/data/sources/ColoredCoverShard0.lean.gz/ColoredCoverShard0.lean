import ColoredCoverSemantics

namespace TightCycleC5.Bridge.ColoredCover
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def coloredWitness0 : Array Nat := #[0, 720, 840, 1440, 960, 1464, 1584, 2160, 1080, 1488, 1608, 2166, 1728, 2190, 2310, 2880, 1200, 1512, 1632, 2172, 1752, 2196, 2316, 2882, 1872, 2220, 2340, 2888, 2460, 2912, 3032, 3600, 1320, 1536, 1656, 2178, 1776, 2202, 2322, 2884, 1896, 2226, 2346, 2890, 2466, 2914, 3034, 3601, 2016, 2250, 2370, 2896, 2490, 2920, 3040, 3603, 2610, 2944, 3064, 3609, 3184, 3633, 3753, 4320]

theorem colored_row0 : ∀ c : Fin 64,
    readRow witnessRows (0 * 64 + c.val) = coloredWitness0[c.val]! := by
  decide +kernel
#print axioms colored_row0

theorem colored_check0 : ∀ c : Fin 64,
    checkColored 0 (BitVec.ofNat 6 c.val) (coloredWitness0[c.val]!) = true := by
  decide +kernel
#print axioms colored_check0

theorem colored_family0 : ∀ c : Fin 64,
    checkColored 0 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (0 * 64 + c.val)) = true := by
  intro c
  rw [colored_row0]
  exact colored_check0 c
#print axioms colored_family0

def coloredWitness1 : Array Nat := #[5040, 5760, 5880, 6480, 6000, 6504, 6624, 7200, 7920, 8640, 8760, 9360, 8880, 9384, 9504, 10080, 7922, 8642, 8762, 9362, 8882, 9386, 9506, 10082, 10800, 11520, 11640, 12240, 11760, 12264, 12384, 12960, 7924, 8644, 8764, 9364, 8884, 9388, 9508, 10084, 10801, 11521, 11641, 12241, 11761, 12265, 12385, 12961, 10803, 11523, 11643, 12243, 11763, 12267, 12387, 12963, 13680, 14400, 14520, 15120, 14640, 15144, 15264, 15840]

theorem colored_row1 : ∀ c : Fin 64,
    readRow witnessRows (1 * 64 + c.val) = coloredWitness1[c.val]! := by
  decide +kernel
#print axioms colored_row1

theorem colored_check1 : ∀ c : Fin 64,
    checkColored 1 (BitVec.ofNat 6 c.val) (coloredWitness1[c.val]!) = true := by
  decide +kernel
#print axioms colored_check1

theorem colored_family1 : ∀ c : Fin 64,
    checkColored 1 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (1 * 64 + c.val)) = true := by
  intro c
  rw [colored_row1]
  exact colored_check1 c
#print axioms colored_family1

def coloredWitness2 : Array Nat := #[16560, 17280, 17400, 18000, 18720, 19440, 19560, 20160, 18726, 19446, 19566, 20166, 20880, 21600, 21720, 22320, 23040, 23760, 23880, 24480, 25200, 25920, 26040, 26640, 25206, 25926, 26046, 26646, 27360, 28080, 28200, 28800, 23041, 23761, 23881, 24481, 25201, 25921, 26041, 26641, 25207, 25927, 26047, 26647, 27361, 28081, 28201, 28801, 29520, 30240, 30360, 30960, 31680, 32400, 32520, 33120, 31686, 32406, 32526, 33126, 33840, 34560, 34680, 35280]

theorem colored_row2 : ∀ c : Fin 64,
    readRow witnessRows (2 * 64 + c.val) = coloredWitness2[c.val]! := by
  decide +kernel
#print axioms colored_row2

theorem colored_check2 : ∀ c : Fin 64,
    checkColored 2 (BitVec.ofNat 6 c.val) (coloredWitness2[c.val]!) = true := by
  decide +kernel
#print axioms colored_check2

theorem colored_family2 : ∀ c : Fin 64,
    checkColored 2 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (2 * 64 + c.val)) = true := by
  intro c
  rw [colored_row2]
  exact colored_check2 c
#print axioms colored_family2

def coloredWitness3 : Array Nat := #[36000, 36720, 36840, 37440, 38160, 38880, 39000, 39600, 38166, 38886, 39006, 39606, 40320, 41040, 41160, 41760, 38172, 38892, 39012, 39612, 40322, 41042, 41162, 41762, 40328, 41048, 41168, 41768, 42480, 43200, 43320, 43920, 44640, 45360, 45480, 46080, 46800, 47520, 47640, 48240, 46806, 47526, 47646, 48246, 48960, 49680, 49800, 50400, 46812, 47532, 47652, 48252, 48962, 49682, 49802, 50402, 48968, 49688, 49808, 50408, 51120, 51840, 51960, 52560]

theorem colored_row3 : ∀ c : Fin 64,
    readRow witnessRows (3 * 64 + c.val) = coloredWitness3[c.val]! := by
  decide +kernel
#print axioms colored_row3

theorem colored_check3 : ∀ c : Fin 64,
    checkColored 3 (BitVec.ofNat 6 c.val) (coloredWitness3[c.val]!) = true := by
  decide +kernel
#print axioms colored_check3

theorem colored_family3 : ∀ c : Fin 64,
    checkColored 3 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (3 * 64 + c.val)) = true := by
  intro c
  rw [colored_row3]
  exact colored_check3 c
#print axioms colored_family3

def coloredWitness4 : Array Nat := #[53280, 54000, 54120, 54720, 55440, 56160, 56280, 56880, 55446, 56166, 56286, 56886, 57600, 58320, 58440, 59040, 55452, 56172, 56292, 56892, 57602, 58322, 58442, 59042, 57608, 58328, 58448, 59048, 59760, 60480, 60600, 61200, 55458, 56178, 56298, 56898, 57604, 58324, 58444, 59044, 57610, 58330, 58450, 59050, 59761, 60481, 60601, 61201, 57616, 58336, 58456, 59056, 59763, 60483, 60603, 61203, 59769, 60489, 60609, 61209, 61920, 62640, 62760, 63360]

theorem colored_row4 : ∀ c : Fin 64,
    readRow witnessRows (4 * 64 + c.val) = coloredWitness4[c.val]! := by
  decide +kernel
#print axioms colored_row4

theorem colored_check4 : ∀ c : Fin 64,
    checkColored 4 (BitVec.ofNat 6 c.val) (coloredWitness4[c.val]!) = true := by
  decide +kernel
#print axioms colored_check4

theorem colored_family4 : ∀ c : Fin 64,
    checkColored 4 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (4 * 64 + c.val)) = true := by
  intro c
  rw [colored_row4]
  exact colored_check4 c
#print axioms colored_family4

def coloredWitness5 : Array Nat := #[64080, 64800, 65520, 66240, 65544, 66264, 66960, 67680, 65568, 66288, 66966, 67686, 66990, 67710, 68400, 69120, 69840, 70560, 71280, 72000, 71304, 72024, 72720, 73440, 71328, 72048, 72726, 73446, 72750, 73470, 74160, 74880, 69841, 70561, 71281, 72001, 71305, 72025, 72721, 73441, 71329, 72049, 72727, 73447, 72751, 73471, 74161, 74881, 75600, 76320, 77040, 77760, 77064, 77784, 78480, 79200, 77088, 77808, 78486, 79206, 78510, 79230, 79920, 80640]

theorem colored_row5 : ∀ c : Fin 64,
    readRow witnessRows (5 * 64 + c.val) = coloredWitness5[c.val]! := by
  decide +kernel
#print axioms colored_row5

theorem colored_check5 : ∀ c : Fin 64,
    checkColored 5 (BitVec.ofNat 6 c.val) (coloredWitness5[c.val]!) = true := by
  decide +kernel
#print axioms colored_check5

theorem colored_family5 : ∀ c : Fin 64,
    checkColored 5 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (5 * 64 + c.val)) = true := by
  intro c
  rw [colored_row5]
  exact colored_check5 c
#print axioms colored_family5

def coloredWitness6 : Array Nat := #[81360, 82080, 82800, 83520, 82826, 83546, 84240, 84960, 82850, 83570, 84246, 84966, 85680, 86400, 87120, 87840, 82880, 83600, 85706, 86426, 84276, 84996, 87146, 87866, 84300, 85020, 87170, 87890, 87200, 87920, 88560, 89280, 90000, 90720, 91440, 92160, 91466, 92186, 92880, 93600, 91490, 92210, 92886, 93606, 94320, 95040, 95760, 96480, 91520, 92240, 94346, 95066, 92916, 93636, 95786, 96506, 92940, 93660, 95810, 96530, 95840, 96560, 97200, 97920]

theorem colored_row6 : ∀ c : Fin 64,
    readRow witnessRows (6 * 64 + c.val) = coloredWitness6[c.val]! := by
  decide +kernel
#print axioms colored_row6

theorem colored_check6 : ∀ c : Fin 64,
    checkColored 6 (BitVec.ofNat 6 c.val) (coloredWitness6[c.val]!) = true := by
  decide +kernel
#print axioms colored_check6

theorem colored_family6 : ∀ c : Fin 64,
    checkColored 6 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (6 * 64 + c.val)) = true := by
  intro c
  rw [colored_row6]
  exact colored_check6 c
#print axioms colored_family6

def coloredWitness7 : Array Nat := #[98640, 99360, 100080, 100800, 100106, 100826, 101520, 102240, 102960, 103680, 104400, 105120, 105840, 106560, 107280, 108000, 102986, 103706, 105866, 106586, 104426, 105146, 107306, 108026, 108720, 109440, 110160, 110880, 110186, 110906, 111600, 112320, 113040, 113760, 114480, 115200, 114506, 115226, 115920, 116640, 117360, 118080, 118800, 119520, 120240, 120960, 121680, 122400, 117386, 118106, 120266, 120986, 118826, 119546, 121706, 122426, 123120, 123840, 124560, 125280, 124586, 125306, 126000, 126720]

theorem colored_row7 : ∀ c : Fin 64,
    readRow witnessRows (7 * 64 + c.val) = coloredWitness7[c.val]! := by
  decide +kernel
#print axioms colored_row7

theorem colored_check7 : ∀ c : Fin 64,
    checkColored 7 (BitVec.ofNat 6 c.val) (coloredWitness7[c.val]!) = true := by
  decide +kernel
#print axioms colored_check7

theorem colored_family7 : ∀ c : Fin 64,
    checkColored 7 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (7 * 64 + c.val)) = true := by
  intro c
  rw [colored_row7]
  exact colored_check7 c
#print axioms colored_family7

def coloredWitness8 : Array Nat := #[127440, 128160, 128880, 129600, 130320, 131040, 131760, 132480, 130326, 131046, 131766, 132486, 133200, 133920, 134640, 135360, 136080, 136800, 137520, 138240, 138960, 139680, 140400, 141120, 138966, 139686, 140406, 141126, 141840, 142560, 143280, 144000, 144720, 145440, 146160, 146880, 147600, 148320, 149040, 149760, 147606, 148326, 149046, 149766, 150480, 151200, 151920, 152640, 153360, 154080, 154800, 155520, 156240, 156960, 157680, 158400, 156246, 156966, 157686, 158406, 159120, 159840, 160560, 161280]

theorem colored_row8 : ∀ c : Fin 64,
    readRow witnessRows (8 * 64 + c.val) = coloredWitness8[c.val]! := by
  decide +kernel
#print axioms colored_row8

theorem colored_check8 : ∀ c : Fin 64,
    checkColored 8 (BitVec.ofNat 6 c.val) (coloredWitness8[c.val]!) = true := by
  decide +kernel
#print axioms colored_check8

theorem colored_family8 : ∀ c : Fin 64,
    checkColored 8 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (8 * 64 + c.val)) = true := by
  intro c
  rw [colored_row8]
  exact colored_check8 c
#print axioms colored_family8

def coloredWitness9 : Array Nat := #[162000, 162720, 163440, 164160, 164880, 165600, 166320, 167040, 164886, 165606, 166326, 167046, 167760, 168480, 169200, 169920, 170640, 171360, 172080, 172800, 173520, 174240, 174960, 175680, 173526, 174246, 174966, 175686, 176400, 177120, 177840, 178560, 170641, 171361, 172081, 172801, 173521, 174241, 174961, 175681, 173527, 174247, 174967, 175687, 176401, 177121, 177841, 178561, 179280, 180000, 180720, 181440, 182160, 182880, 183600, 184320, 182166, 182886, 183606, 184326, 185040, 185760, 186480, 187200]

theorem colored_row9 : ∀ c : Fin 64,
    readRow witnessRows (9 * 64 + c.val) = coloredWitness9[c.val]! := by
  decide +kernel
#print axioms colored_row9

theorem colored_check9 : ∀ c : Fin 64,
    checkColored 9 (BitVec.ofNat 6 c.val) (coloredWitness9[c.val]!) = true := by
  decide +kernel
#print axioms colored_check9

theorem colored_family9 : ∀ c : Fin 64,
    checkColored 9 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (9 * 64 + c.val)) = true := by
  intro c
  rw [colored_row9]
  exact colored_check9 c
#print axioms colored_family9

def coloredWitness10 : Array Nat := #[187920, 188640, 189360, 190080, 190800, 191520, 192240, 192960, 193680, 194400, 195120, 195840, 196560, 197280, 198000, 198720, 199440, 200160, 200880, 201600, 202320, 203040, 203760, 204480, 205200, 205920, 206640, 207360, 208080, 208800, 209520, 210240, 199441, 200161, 200881, 201601, 202321, 203041, 203761, 204481, 205201, 205921, 206641, 207361, 208081, 208801, 209521, 210241, 210960, 211680, 212400, 213120, 213840, 214560, 215280, 216000, 216720, 217440, 218160, 218880, 219600, 220320, 221040, 221760]

theorem colored_row10 : ∀ c : Fin 64,
    readRow witnessRows (10 * 64 + c.val) = coloredWitness10[c.val]! := by
  decide +kernel
#print axioms colored_row10

theorem colored_check10 : ∀ c : Fin 64,
    checkColored 10 (BitVec.ofNat 6 c.val) (coloredWitness10[c.val]!) = true := by
  decide +kernel
#print axioms colored_check10

theorem colored_family10 : ∀ c : Fin 64,
    checkColored 10 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (10 * 64 + c.val)) = true := by
  intro c
  rw [colored_row10]
  exact colored_check10 c
#print axioms colored_family10

def coloredWitness11 : Array Nat := #[222480, 223200, 223920, 224640, 225360, 226080, 226800, 227520, 225366, 226086, 226806, 227526, 228240, 228960, 229680, 230400, 231120, 231840, 232560, 233280, 234000, 234720, 235440, 236160, 234006, 234726, 235446, 236166, 236880, 237600, 238320, 239040, 231121, 231841, 232561, 233281, 234001, 234721, 235441, 236161, 234007, 234727, 235447, 236167, 236881, 237601, 238321, 239041, 239760, 240480, 241200, 241920, 242640, 243360, 244080, 244800, 242646, 243366, 244086, 244806, 245520, 246240, 246960, 247680]

theorem colored_row11 : ∀ c : Fin 64,
    readRow witnessRows (11 * 64 + c.val) = coloredWitness11[c.val]! := by
  decide +kernel
#print axioms colored_row11

theorem colored_check11 : ∀ c : Fin 64,
    checkColored 11 (BitVec.ofNat 6 c.val) (coloredWitness11[c.val]!) = true := by
  decide +kernel
#print axioms colored_check11

theorem colored_family11 : ∀ c : Fin 64,
    checkColored 11 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (11 * 64 + c.val)) = true := by
  intro c
  rw [colored_row11]
  exact colored_check11 c
#print axioms colored_family11

def coloredWitness12 : Array Nat := #[248400, 249120, 249840, 250560, 249864, 250584, 251280, 252000, 249900, 250620, 252720, 253440, 252744, 253464, 254160, 254880, 249924, 250644, 252722, 253442, 252746, 253466, 254162, 254882, 251340, 252060, 254220, 254940, 254222, 254942, 255600, 256320, 257040, 257760, 258480, 259200, 258504, 259224, 259920, 260640, 258540, 259260, 261360, 262080, 261384, 262104, 262800, 263520, 258564, 259284, 261362, 262082, 261386, 262106, 262802, 263522, 259980, 260700, 262860, 263580, 262862, 263582, 264240, 264960]

theorem colored_row12 : ∀ c : Fin 64,
    readRow witnessRows (12 * 64 + c.val) = coloredWitness12[c.val]! := by
  decide +kernel
#print axioms colored_row12

theorem colored_check12 : ∀ c : Fin 64,
    checkColored 12 (BitVec.ofNat 6 c.val) (coloredWitness12[c.val]!) = true := by
  decide +kernel
#print axioms colored_check12

theorem colored_family12 : ∀ c : Fin 64,
    checkColored 12 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (12 * 64 + c.val)) = true := by
  intro c
  rw [colored_row12]
  exact colored_check12 c
#print axioms colored_family12

def coloredWitness13 : Array Nat := #[265680, 266400, 267120, 267840, 267144, 267864, 268560, 269280, 270000, 270720, 271440, 272160, 271464, 272184, 272880, 273600, 270002, 270722, 271442, 272162, 271466, 272186, 272882, 273602, 274320, 275040, 275760, 276480, 275784, 276504, 277200, 277920, 278640, 279360, 280080, 280800, 280104, 280824, 281520, 282240, 282960, 283680, 284400, 285120, 284424, 285144, 285840, 286560, 282962, 283682, 284402, 285122, 284426, 285146, 285842, 286562, 287280, 288000, 288720, 289440, 288744, 289464, 290160, 290880]

theorem colored_row13 : ∀ c : Fin 64,
    readRow witnessRows (13 * 64 + c.val) = coloredWitness13[c.val]! := by
  decide +kernel
#print axioms colored_row13

theorem colored_check13 : ∀ c : Fin 64,
    checkColored 13 (BitVec.ofNat 6 c.val) (coloredWitness13[c.val]!) = true := by
  decide +kernel
#print axioms colored_check13

theorem colored_family13 : ∀ c : Fin 64,
    checkColored 13 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (13 * 64 + c.val)) = true := by
  intro c
  rw [colored_row13]
  exact colored_check13 c
#print axioms colored_family13

def coloredWitness14 : Array Nat := #[291600, 292320, 293040, 293760, 293065, 293785, 294480, 295200, 295920, 296640, 297360, 298080, 297385, 298105, 298800, 299520, 300240, 300960, 301680, 302400, 303120, 303840, 304560, 305280, 306000, 306720, 307440, 308160, 308880, 309600, 310320, 311040, 300265, 300985, 303145, 303865, 301705, 302425, 304585, 305305, 306025, 306745, 308905, 309625, 307465, 308185, 310345, 311065, 311760, 312480, 313200, 313920, 313225, 313945, 314640, 315360, 316080, 316800, 317520, 318240, 317545, 318265, 318960, 319680]

theorem colored_row14 : ∀ c : Fin 64,
    readRow witnessRows (14 * 64 + c.val) = coloredWitness14[c.val]! := by
  decide +kernel
#print axioms colored_row14

theorem colored_check14 : ∀ c : Fin 64,
    checkColored 14 (BitVec.ofNat 6 c.val) (coloredWitness14[c.val]!) = true := by
  decide +kernel
#print axioms colored_check14

theorem colored_family14 : ∀ c : Fin 64,
    checkColored 14 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (14 * 64 + c.val)) = true := by
  intro c
  rw [colored_row14]
  exact colored_check14 c
#print axioms colored_family14

def coloredWitness15 : Array Nat := #[320400, 321120, 321840, 322560, 321865, 322585, 323280, 324000, 324720, 325440, 326160, 326880, 326185, 326905, 327600, 328320, 329040, 329760, 330480, 331200, 331920, 332640, 333360, 334080, 334800, 335520, 336240, 336960, 337680, 338400, 339120, 339840, 329065, 329785, 331945, 332665, 330505, 331225, 333385, 334105, 334825, 335545, 337705, 338425, 336265, 336985, 339145, 339865, 340560, 341280, 342000, 342720, 342025, 342745, 343440, 344160, 344880, 345600, 346320, 347040, 346345, 347065, 347760, 348480]

theorem colored_row15 : ∀ c : Fin 64,
    readRow witnessRows (15 * 64 + c.val) = coloredWitness15[c.val]! := by
  decide +kernel
#print axioms colored_row15

theorem colored_check15 : ∀ c : Fin 64,
    checkColored 15 (BitVec.ofNat 6 c.val) (coloredWitness15[c.val]!) = true := by
  decide +kernel
#print axioms colored_check15

theorem colored_family15 : ∀ c : Fin 64,
    checkColored 15 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (15 * 64 + c.val)) = true := by
  intro c
  rw [colored_row15]
  exact colored_check15 c
#print axioms colored_family15

def coloredWitness16 : Array Nat := #[349200, 349920, 350640, 351360, 352080, 352800, 353520, 354240, 354960, 355680, 356400, 357120, 357840, 358560, 359280, 360000, 354962, 355682, 356402, 357122, 357842, 358562, 359282, 360002, 360720, 361440, 362160, 362880, 363600, 364320, 365040, 365760, 366480, 367200, 367920, 368640, 369360, 370080, 370800, 371520, 372240, 372960, 373680, 374400, 375120, 375840, 376560, 377280, 372242, 372962, 373682, 374402, 375122, 375842, 376562, 377282, 378000, 378720, 379440, 380160, 380880, 381600, 382320, 383040]

theorem colored_row16 : ∀ c : Fin 64,
    readRow witnessRows (16 * 64 + c.val) = coloredWitness16[c.val]! := by
  decide +kernel
#print axioms colored_row16

theorem colored_check16 : ∀ c : Fin 64,
    checkColored 16 (BitVec.ofNat 6 c.val) (coloredWitness16[c.val]!) = true := by
  decide +kernel
#print axioms colored_check16

theorem colored_family16 : ∀ c : Fin 64,
    checkColored 16 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (16 * 64 + c.val)) = true := by
  intro c
  rw [colored_row16]
  exact colored_check16 c
#print axioms colored_family16

def coloredWitness17 : Array Nat := #[383760, 384480, 385200, 385920, 386640, 387360, 388080, 388800, 389520, 390240, 390960, 391680, 392400, 393120, 393840, 394560, 389522, 390242, 390962, 391682, 392402, 393122, 393842, 394562, 395280, 396000, 396720, 397440, 398160, 398880, 399600, 400320, 401040, 401760, 402480, 403200, 403920, 404640, 405360, 406080, 406800, 407520, 408240, 408960, 409680, 410400, 411120, 411840, 406802, 407522, 408242, 408962, 409682, 410402, 411122, 411842, 412560, 413280, 414000, 414720, 415440, 416160, 416880, 417600]

theorem colored_row17 : ∀ c : Fin 64,
    readRow witnessRows (17 * 64 + c.val) = coloredWitness17[c.val]! := by
  decide +kernel
#print axioms colored_row17

theorem colored_check17 : ∀ c : Fin 64,
    checkColored 17 (BitVec.ofNat 6 c.val) (coloredWitness17[c.val]!) = true := by
  decide +kernel
#print axioms colored_check17

theorem colored_family17 : ∀ c : Fin 64,
    checkColored 17 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (17 * 64 + c.val)) = true := by
  intro c
  rw [colored_row17]
  exact colored_check17 c
#print axioms colored_family17

def coloredWitness18 : Array Nat := #[418320, 419040, 419760, 420480, 419784, 420504, 421200, 421920, 422640, 423360, 424080, 424800, 424104, 424824, 425520, 426240, 422642, 423362, 424082, 424802, 424106, 424826, 425522, 426242, 426960, 427680, 428400, 429120, 428424, 429144, 429840, 430560, 422644, 423364, 424084, 424804, 424108, 424828, 425524, 426244, 426961, 427681, 428401, 429121, 428425, 429145, 429841, 430561, 426963, 427683, 428403, 429123, 428427, 429147, 429843, 430563, 431280, 432000, 432720, 433440, 432744, 433464, 434160, 434880]

theorem colored_row18 : ∀ c : Fin 64,
    readRow witnessRows (18 * 64 + c.val) = coloredWitness18[c.val]! := by
  decide +kernel
#print axioms colored_row18

theorem colored_check18 : ∀ c : Fin 64,
    checkColored 18 (BitVec.ofNat 6 c.val) (coloredWitness18[c.val]!) = true := by
  decide +kernel
#print axioms colored_check18

theorem colored_family18 : ∀ c : Fin 64,
    checkColored 18 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (18 * 64 + c.val)) = true := by
  intro c
  rw [colored_row18]
  exact colored_check18 c
#print axioms colored_family18

def coloredWitness19 : Array Nat := #[435600, 436320, 437040, 437760, 437064, 437784, 438480, 439200, 439920, 440640, 441360, 442080, 441384, 442104, 442800, 443520, 439922, 440642, 441362, 442082, 441386, 442106, 442802, 443522, 444240, 444960, 445680, 446400, 445704, 446424, 447120, 447840, 439924, 440644, 441364, 442084, 441388, 442108, 442804, 443524, 444241, 444961, 445681, 446401, 445705, 446425, 447121, 447841, 444243, 444963, 445683, 446403, 445707, 446427, 447123, 447843, 448560, 449280, 450000, 450720, 450024, 450744, 451440, 452160]

theorem colored_row19 : ∀ c : Fin 64,
    readRow witnessRows (19 * 64 + c.val) = coloredWitness19[c.val]! := by
  decide +kernel
#print axioms colored_row19

theorem colored_check19 : ∀ c : Fin 64,
    checkColored 19 (BitVec.ofNat 6 c.val) (coloredWitness19[c.val]!) = true := by
  decide +kernel
#print axioms colored_check19

theorem colored_family19 : ∀ c : Fin 64,
    checkColored 19 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (19 * 64 + c.val)) = true := by
  intro c
  rw [colored_row19]
  exact colored_check19 c
#print axioms colored_family19

def coloredWitness20 : Array Nat := #[452880, 453600, 454320, 455040, 454344, 455064, 455760, 456480, 454368, 455088, 455766, 456486, 455790, 456510, 457200, 457920, 454392, 455112, 455772, 456492, 455796, 456516, 457202, 457922, 455820, 456540, 457208, 457928, 457232, 457952, 458640, 459360, 460080, 460800, 461520, 462240, 461544, 462264, 462960, 463680, 461568, 462288, 462966, 463686, 462990, 463710, 464400, 465120, 461592, 462312, 462972, 463692, 462996, 463716, 464402, 465122, 463020, 463740, 464408, 465128, 464432, 465152, 465840, 466560]

theorem colored_row20 : ∀ c : Fin 64,
    readRow witnessRows (20 * 64 + c.val) = coloredWitness20[c.val]! := by
  decide +kernel
#print axioms colored_row20

theorem colored_check20 : ∀ c : Fin 64,
    checkColored 20 (BitVec.ofNat 6 c.val) (coloredWitness20[c.val]!) = true := by
  decide +kernel
#print axioms colored_check20

theorem colored_family20 : ∀ c : Fin 64,
    checkColored 20 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (20 * 64 + c.val)) = true := by
  intro c
  rw [colored_row20]
  exact colored_check20 c
#print axioms colored_family20

def coloredWitness21 : Array Nat := #[467280, 468000, 468720, 469440, 470160, 470880, 471600, 472320, 470166, 470886, 471606, 472326, 473040, 473760, 474480, 475200, 470172, 470892, 471612, 472332, 473042, 473762, 474482, 475202, 473048, 473768, 474488, 475208, 475920, 476640, 477360, 478080, 468825, 469545, 478800, 479520, 471705, 472425, 480240, 480960, 471711, 472431, 480246, 480966, 474585, 475305, 481680, 482400, 471717, 472437, 480252, 480972, 474587, 475307, 481682, 482402, 474593, 475313, 481688, 482408, 477465, 478185, 483120, 483840]

theorem colored_row21 : ∀ c : Fin 64,
    readRow witnessRows (21 * 64 + c.val) = coloredWitness21[c.val]! := by
  decide +kernel
#print axioms colored_row21

theorem colored_check21 : ∀ c : Fin 64,
    checkColored 21 (BitVec.ofNat 6 c.val) (coloredWitness21[c.val]!) = true := by
  decide +kernel
#print axioms colored_check21

theorem colored_family21 : ∀ c : Fin 64,
    checkColored 21 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (21 * 64 + c.val)) = true := by
  intro c
  rw [colored_row21]
  exact colored_check21 c
#print axioms colored_family21

def coloredWitness22 : Array Nat := #[484560, 485280, 486000, 486720, 487440, 488160, 488880, 489600, 490320, 491040, 491760, 492480, 493200, 493920, 494640, 495360, 490322, 491042, 491762, 492482, 493202, 493922, 494642, 495362, 496080, 496800, 497520, 498240, 498960, 499680, 500400, 501120, 501840, 502560, 503280, 504000, 504720, 505440, 506160, 506880, 507600, 508320, 509040, 509760, 510480, 511200, 511920, 512640, 507602, 508322, 509042, 509762, 510482, 511202, 511922, 512642, 513360, 514080, 514800, 515520, 516240, 516960, 517680, 518400]

theorem colored_row22 : ∀ c : Fin 64,
    readRow witnessRows (22 * 64 + c.val) = coloredWitness22[c.val]! := by
  decide +kernel
#print axioms colored_row22

theorem colored_check22 : ∀ c : Fin 64,
    checkColored 22 (BitVec.ofNat 6 c.val) (coloredWitness22[c.val]!) = true := by
  decide +kernel
#print axioms colored_check22

theorem colored_family22 : ∀ c : Fin 64,
    checkColored 22 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (22 * 64 + c.val)) = true := by
  intro c
  rw [colored_row22]
  exact colored_check22 c
#print axioms colored_family22

def coloredWitness23 : Array Nat := #[519120, 519840, 520560, 521280, 522000, 522720, 523440, 524160, 522006, 522726, 523446, 524166, 524880, 525600, 526320, 527040, 527760, 528480, 529200, 529920, 530640, 531360, 532080, 532800, 530646, 531366, 532086, 532806, 533520, 534240, 534960, 535680, 536400, 537120, 537840, 538560, 539280, 540000, 540720, 541440, 539286, 540006, 540726, 541446, 542160, 542880, 543600, 544320, 545040, 545760, 546480, 547200, 547920, 548640, 549360, 550080, 547926, 548646, 549366, 550086, 550800, 551520, 552240, 552960]

theorem colored_row23 : ∀ c : Fin 64,
    readRow witnessRows (23 * 64 + c.val) = coloredWitness23[c.val]! := by
  decide +kernel
#print axioms colored_row23

theorem colored_check23 : ∀ c : Fin 64,
    checkColored 23 (BitVec.ofNat 6 c.val) (coloredWitness23[c.val]!) = true := by
  decide +kernel
#print axioms colored_check23

theorem colored_family23 : ∀ c : Fin 64,
    checkColored 23 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (23 * 64 + c.val)) = true := by
  intro c
  rw [colored_row23]
  exact colored_check23 c
#print axioms colored_family23

def coloredWitness24 : Array Nat := #[553680, 554400, 555120, 555840, 556560, 557280, 558000, 558720, 556566, 557286, 558006, 558726, 559440, 560160, 560880, 561600, 556572, 557292, 558012, 558732, 559442, 560162, 560882, 561602, 559448, 560168, 560888, 561608, 562320, 563040, 563760, 564480, 565200, 565920, 566640, 567360, 568080, 568800, 569520, 570240, 568086, 568806, 569526, 570246, 570960, 571680, 572400, 573120, 568092, 568812, 569532, 570252, 570962, 571682, 572402, 573122, 570968, 571688, 572408, 573128, 573840, 574560, 575280, 576000]

theorem colored_row24 : ∀ c : Fin 64,
    readRow witnessRows (24 * 64 + c.val) = coloredWitness24[c.val]! := by
  decide +kernel
#print axioms colored_row24

theorem colored_check24 : ∀ c : Fin 64,
    checkColored 24 (BitVec.ofNat 6 c.val) (coloredWitness24[c.val]!) = true := by
  decide +kernel
#print axioms colored_check24

theorem colored_family24 : ∀ c : Fin 64,
    checkColored 24 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (24 * 64 + c.val)) = true := by
  intro c
  rw [colored_row24]
  exact colored_check24 c
#print axioms colored_family24

def coloredWitness25 : Array Nat := #[576720, 577440, 578160, 578880, 579600, 580320, 581040, 581760, 579607, 580327, 581047, 581767, 582480, 583200, 583920, 584640, 579613, 580333, 581053, 581773, 582482, 583202, 583922, 584642, 585360, 586080, 586800, 587520, 588240, 588960, 589680, 590400, 579621, 580341, 581061, 581781, 585367, 586087, 586807, 587527, 582490, 583210, 583930, 584650, 588247, 588967, 589687, 590407, 582496, 583216, 583936, 584656, 588253, 588973, 589693, 590413, 588261, 588981, 589701, 590421, 591120, 591840, 592560, 593280]

theorem colored_row25 : ∀ c : Fin 64,
    readRow witnessRows (25 * 64 + c.val) = coloredWitness25[c.val]! := by
  decide +kernel
#print axioms colored_row25

theorem colored_check25 : ∀ c : Fin 64,
    checkColored 25 (BitVec.ofNat 6 c.val) (coloredWitness25[c.val]!) = true := by
  decide +kernel
#print axioms colored_check25

theorem colored_family25 : ∀ c : Fin 64,
    checkColored 25 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (25 * 64 + c.val)) = true := by
  intro c
  rw [colored_row25]
  exact colored_check25 c
#print axioms colored_family25

def coloredWitness26 : Array Nat := #[594000, 594720, 595440, 596160, 595466, 596186, 596880, 597600, 595492, 596212, 596887, 597607, 598320, 599040, 599760, 600480, 595522, 596242, 598346, 599066, 596917, 597637, 599786, 600506, 598432, 599152, 601200, 601920, 601226, 601946, 602640, 603360, 595552, 596272, 598372, 599092, 598402, 599122, 601207, 601927, 596947, 597667, 599812, 600532, 601252, 601972, 602647, 603367, 596973, 597693, 601282, 602002, 599842, 600562, 602677, 603397, 599872, 600592, 602707, 603427, 602733, 603453, 604080, 604800]

theorem colored_row26 : ∀ c : Fin 64,
    readRow witnessRows (26 * 64 + c.val) = coloredWitness26[c.val]! := by
  decide +kernel
#print axioms colored_row26

theorem colored_check26 : ∀ c : Fin 64,
    checkColored 26 (BitVec.ofNat 6 c.val) (coloredWitness26[c.val]!) = true := by
  decide +kernel
#print axioms colored_check26

theorem colored_family26 : ∀ c : Fin 64,
    checkColored 26 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (26 * 64 + c.val)) = true := by
  intro c
  rw [colored_row26]
  exact colored_check26 c
#print axioms colored_family26

def coloredWitness27 : Array Nat := #[605520, 606240, 606960, 607680, 606986, 607706, 608400, 609120, 609840, 610560, 611280, 612000, 612720, 613440, 614160, 614880, 609866, 610586, 612746, 613466, 611306, 612026, 614186, 614906, 615600, 616320, 617040, 617760, 617066, 617786, 618480, 619200, 619920, 620640, 621360, 622080, 621386, 622106, 622800, 623520, 624240, 624960, 625680, 626400, 627120, 627840, 628560, 629280, 624266, 624986, 627146, 627866, 625706, 626426, 628586, 629306, 630000, 630720, 631440, 632160, 631466, 632186, 632880, 633600]

theorem colored_row27 : ∀ c : Fin 64,
    readRow witnessRows (27 * 64 + c.val) = coloredWitness27[c.val]! := by
  decide +kernel
#print axioms colored_row27

theorem colored_check27 : ∀ c : Fin 64,
    checkColored 27 (BitVec.ofNat 6 c.val) (coloredWitness27[c.val]!) = true := by
  decide +kernel
#print axioms colored_check27

theorem colored_family27 : ∀ c : Fin 64,
    checkColored 27 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (27 * 64 + c.val)) = true := by
  intro c
  rw [colored_row27]
  exact colored_check27 c
#print axioms colored_family27

def coloredWitness28 : Array Nat := #[634320, 635040, 635760, 636480, 637200, 637920, 638640, 639360, 637207, 637927, 638647, 639367, 640080, 640800, 641520, 642240, 642960, 643680, 644400, 645120, 645840, 646560, 647280, 648000, 648720, 649440, 650160, 650880, 651600, 652320, 653040, 653760, 642967, 643687, 644407, 645127, 648727, 649447, 650167, 650887, 645847, 646567, 647287, 648007, 651607, 652327, 653047, 653767, 654480, 655200, 655920, 656640, 657360, 658080, 658800, 659520, 657367, 658087, 658807, 659527, 660240, 660960, 661680, 662400]

theorem colored_row28 : ∀ c : Fin 64,
    readRow witnessRows (28 * 64 + c.val) = coloredWitness28[c.val]! := by
  decide +kernel
#print axioms colored_row28

theorem colored_check28 : ∀ c : Fin 64,
    checkColored 28 (BitVec.ofNat 6 c.val) (coloredWitness28[c.val]!) = true := by
  decide +kernel
#print axioms colored_check28

theorem colored_family28 : ∀ c : Fin 64,
    checkColored 28 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (28 * 64 + c.val)) = true := by
  intro c
  rw [colored_row28]
  exact colored_check28 c
#print axioms colored_family28

def coloredWitness29 : Array Nat := #[663120, 663840, 664560, 665280, 664584, 665304, 666000, 666720, 667440, 668160, 668880, 669600, 668904, 669624, 670320, 671040, 667442, 668162, 668882, 669602, 668906, 669626, 670322, 671042, 671760, 672480, 673200, 673920, 673224, 673944, 674640, 675360, 676080, 676800, 677520, 678240, 677544, 678264, 678960, 679680, 680400, 681120, 681840, 682560, 681864, 682584, 683280, 684000, 680402, 681122, 681842, 682562, 681866, 682586, 683282, 684002, 684720, 685440, 686160, 686880, 686184, 686904, 687600, 688320]

theorem colored_row29 : ∀ c : Fin 64,
    readRow witnessRows (29 * 64 + c.val) = coloredWitness29[c.val]! := by
  decide +kernel
#print axioms colored_row29

theorem colored_check29 : ∀ c : Fin 64,
    checkColored 29 (BitVec.ofNat 6 c.val) (coloredWitness29[c.val]!) = true := by
  decide +kernel
#print axioms colored_check29

theorem colored_family29 : ∀ c : Fin 64,
    checkColored 29 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (29 * 64 + c.val)) = true := by
  intro c
  rw [colored_row29]
  exact colored_check29 c
#print axioms colored_family29

def coloredWitness30 : Array Nat := #[689040, 689760, 690480, 691200, 690504, 691224, 691920, 692640, 693360, 694080, 694800, 695520, 694824, 695544, 696240, 696960, 693362, 694082, 694802, 695522, 694826, 695546, 696242, 696962, 697680, 698400, 699120, 699840, 699144, 699864, 700560, 701280, 702000, 702720, 703440, 704160, 703464, 704184, 704880, 705600, 706320, 707040, 707760, 708480, 707784, 708504, 709200, 709920, 706322, 707042, 707762, 708482, 707786, 708506, 709202, 709922, 710640, 711360, 712080, 712800, 712104, 712824, 713520, 714240]

theorem colored_row30 : ∀ c : Fin 64,
    readRow witnessRows (30 * 64 + c.val) = coloredWitness30[c.val]! := by
  decide +kernel
#print axioms colored_row30

theorem colored_check30 : ∀ c : Fin 64,
    checkColored 30 (BitVec.ofNat 6 c.val) (coloredWitness30[c.val]!) = true := by
  decide +kernel
#print axioms colored_check30

theorem colored_family30 : ∀ c : Fin 64,
    checkColored 30 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (30 * 64 + c.val)) = true := by
  intro c
  rw [colored_row30]
  exact colored_check30 c
#print axioms colored_family30

def coloredWitness31 : Array Nat := #[714960, 715680, 716400, 717120, 717840, 718560, 719280, 720000, 717846, 718566, 719286, 720006, 720720, 721440, 722160, 722880, 717856, 718576, 719296, 720016, 723600, 724320, 725040, 725760, 723606, 724326, 725046, 725766, 726480, 727200, 727920, 728640, 717862, 718582, 719302, 720022, 723601, 724321, 725041, 725761, 723607, 724327, 725047, 725767, 726481, 727201, 727921, 728641, 720736, 721456, 722176, 722896, 726496, 727216, 727936, 728656, 726497, 727217, 727937, 728657, 729360, 730080, 730800, 731520]

theorem colored_row31 : ∀ c : Fin 64,
    readRow witnessRows (31 * 64 + c.val) = coloredWitness31[c.val]! := by
  decide +kernel
#print axioms colored_row31

theorem colored_check31 : ∀ c : Fin 64,
    checkColored 31 (BitVec.ofNat 6 c.val) (coloredWitness31[c.val]!) = true := by
  decide +kernel
#print axioms colored_check31

theorem colored_family31 : ∀ c : Fin 64,
    checkColored 31 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (31 * 64 + c.val)) = true := by
  intro c
  rw [colored_row31]
  exact colored_check31 c
#print axioms colored_family31

end TightCycleC5.Bridge.ColoredCover
