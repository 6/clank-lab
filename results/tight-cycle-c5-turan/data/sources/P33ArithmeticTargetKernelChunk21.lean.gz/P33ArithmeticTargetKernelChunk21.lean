-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk84 :
    ∀ i : Fin (min 128 (40547 - 128 * 84)),
      targetCountsMatch (classAt (targetKernelClass ⟨84, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk84

theorem target_counts_kernel_chunk85 :
    ∀ i : Fin (min 128 (40547 - 128 * 85)),
      targetCountsMatch (classAt (targetKernelClass ⟨85, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk85

theorem target_counts_kernel_chunk86 :
    ∀ i : Fin (min 128 (40547 - 128 * 86)),
      targetCountsMatch (classAt (targetKernelClass ⟨86, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk86

theorem target_counts_kernel_chunk87 :
    ∀ i : Fin (min 128 (40547 - 128 * 87)),
      targetCountsMatch (classAt (targetKernelClass ⟨87, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk87


end TightCycleC5.Bridge.P33Arithmetic
