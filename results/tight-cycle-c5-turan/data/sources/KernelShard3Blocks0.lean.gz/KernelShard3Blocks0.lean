import KernelRowIndex
import KernelWitness3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_3_0 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 0 * 256 + i.val))
      kernelWitness3Row0[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_0

theorem kernelBlock_3_1 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 1 * 256 + i.val))
      kernelWitness3Row1[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_1

theorem kernelBlock_3_2 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 2 * 256 + i.val))
      kernelWitness3Row2[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_2

theorem kernelBlock_3_3 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 3 * 256 + i.val))
      kernelWitness3Row3[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_3

theorem kernelBlock_3_4 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 4 * 256 + i.val))
      kernelWitness3Row4[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_4

theorem kernelBlock_3_5 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 5 * 256 + i.val))
      kernelWitness3Row5[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_5

theorem kernelBlock_3_6 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 6 * 256 + i.val))
      kernelWitness3Row6[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_6

theorem kernelBlock_3_7 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 7 * 256 + i.val))
      kernelWitness3Row7[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_7

theorem kernelBlock_3_8 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 8 * 256 + i.val))
      kernelWitness3Row8[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_8

theorem kernelBlock_3_9 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 9 * 256 + i.val))
      kernelWitness3Row9[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_9

theorem kernelBlock_3_10 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 10 * 256 + i.val))
      kernelWitness3Row10[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_10

theorem kernelBlock_3_11 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 11 * 256 + i.val))
      kernelWitness3Row11[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_11

theorem kernelBlock_3_12 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 12 * 256 + i.val))
      kernelWitness3Row12[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_12

theorem kernelBlock_3_13 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 13 * 256 + i.val))
      kernelWitness3Row13[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_13

theorem kernelBlock_3_14 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 14 * 256 + i.val))
      kernelWitness3Row14[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_14

theorem kernelBlock_3_15 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 15 * 256 + i.val))
      kernelWitness3Row15[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_15

theorem kernelBlock_3_16 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 16 * 256 + i.val))
      kernelWitness3Row16[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_16

theorem kernelBlock_3_17 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 17 * 256 + i.val))
      kernelWitness3Row17[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_17

theorem kernelBlock_3_18 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 18 * 256 + i.val))
      kernelWitness3Row18[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_18

theorem kernelBlock_3_19 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 19 * 256 + i.val))
      kernelWitness3Row19[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_19

theorem kernelBlock_3_20 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 20 * 256 + i.val))
      kernelWitness3Row20[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_20

theorem kernelBlock_3_21 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 21 * 256 + i.val))
      kernelWitness3Row21[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_21

theorem kernelBlock_3_22 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 22 * 256 + i.val))
      kernelWitness3Row22[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_22

theorem kernelBlock_3_23 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 23 * 256 + i.val))
      kernelWitness3Row23[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_23

theorem kernelBlock_3_24 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 24 * 256 + i.val))
      kernelWitness3Row24[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_24

theorem kernelBlock_3_25 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 25 * 256 + i.val))
      kernelWitness3Row25[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_25

theorem kernelBlock_3_26 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 26 * 256 + i.val))
      kernelWitness3Row26[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_26

theorem kernelBlock_3_27 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 27 * 256 + i.val))
      kernelWitness3Row27[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_27

theorem kernelBlock_3_28 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 28 * 256 + i.val))
      kernelWitness3Row28[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_28

theorem kernelBlock_3_29 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 29 * 256 + i.val))
      kernelWitness3Row29[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_29

theorem kernelBlock_3_30 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 30 * 256 + i.val))
      kernelWitness3Row30[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_30

theorem kernelBlock_3_31 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 31 * 256 + i.val))
      kernelWitness3Row31[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_31

end TightCycleC5.Bridge.Cover
