import P33PSDSeed14Data

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33PSD

theorem seed14_weights : ∀ k, 0 ≤ weight14 k := by decide +kernel
theorem seed14_gram : (fun i j => (seed14 i j : ℚ)) =
    rationalGram weight14 vec14 := by native_decide
theorem seed14_psd : (intMatrixReal seed14).PosSemidef :=
  rational_gram_posSemidef seed14 weight14 vec14 seed14_weights seed14_gram

def changedSeed14 : Matrix (Fin 128) (Fin 128) ℤ :=
  fun i j => seed14 i j + if i = 0 ∧ j = 0 then 1 else 0
theorem seed14_rejects_corruption :
    (fun i j => (changedSeed14 i j : ℚ)) ≠ rationalGram weight14 vec14 := by native_decide

#print axioms seed14_weights
#print axioms seed14_gram
#print axioms seed14_psd
#print axioms seed14_rejects_corruption
end TightCycleC5.Bridge.P33PSD
