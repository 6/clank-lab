import KernelShard14Blocks0
import KernelShard14Blocks1
import KernelShard14Blocks2
import KernelShard14Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard14 : kernelShardCheck 14 kernelWitness14 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (14 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness14 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_14_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard14
end TightCycleC5.Bridge.Cover
