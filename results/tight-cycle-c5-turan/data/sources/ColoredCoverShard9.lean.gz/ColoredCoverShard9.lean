import ColoredCoverSemantics

namespace TightCycleC5.Bridge.ColoredCover
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def coloredWitness288 : Array Nat := #[9781920, 9782640, 9783360, 9784080, 9784800, 9785520, 9786240, 9786960, 9787680, 9788400, 9789120, 9789840, 9790560, 9791280, 9792000, 9792720, 9793440, 9794160, 9794880, 9795600, 9796320, 9797040, 9797760, 9798480, 9799200, 9799920, 9800640, 9801360, 9802080, 9802800, 9803520, 9804240, 9804960, 9805680, 9806400, 9807120, 9807840, 9808560, 9809280, 9810000, 9810720, 9811440, 9812160, 9812880, 9813600, 9814320, 9815040, 9815760, 9816480, 9817200, 9817920, 9818640, 9819360, 9820080, 9820800, 9821520, 9822240, 9822960, 9823680, 9824400, 9825120, 9825840, 9826560, 9827280]

theorem colored_row288 : ∀ c : Fin 64,
    readRow witnessRows (288 * 64 + c.val) = coloredWitness288[c.val]! := by
  decide +kernel
#print axioms colored_row288

theorem colored_check288 : ∀ c : Fin 64,
    checkColored 288 (BitVec.ofNat 6 c.val) (coloredWitness288[c.val]!) = true := by
  decide +kernel
#print axioms colored_check288

theorem colored_family288 : ∀ c : Fin 64,
    checkColored 288 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (288 * 64 + c.val)) = true := by
  intro c
  rw [colored_row288]
  exact colored_check288 c
#print axioms colored_family288

def coloredWitness289 : Array Nat := #[9828000, 9828720, 9829440, 9830160, 9830880, 9831600, 9832320, 9833040, 9833760, 9834480, 9835200, 9835920, 9836640, 9837360, 9838080, 9838800, 9839520, 9840240, 9840960, 9841680, 9842400, 9843120, 9843840, 9844560, 9845280, 9846000, 9846720, 9847440, 9848160, 9848880, 9849600, 9850320, 9851040, 9851760, 9852480, 9853200, 9853920, 9854640, 9855360, 9856080, 9856800, 9857520, 9858240, 9858960, 9859680, 9860400, 9861120, 9861840, 9862560, 9863280, 9864000, 9864720, 9865440, 9866160, 9866880, 9867600, 9868320, 9869040, 9869760, 9870480, 9871200, 9871920, 9872640, 9873360]

theorem colored_row289 : ∀ c : Fin 64,
    readRow witnessRows (289 * 64 + c.val) = coloredWitness289[c.val]! := by
  decide +kernel
#print axioms colored_row289

theorem colored_check289 : ∀ c : Fin 64,
    checkColored 289 (BitVec.ofNat 6 c.val) (coloredWitness289[c.val]!) = true := by
  decide +kernel
#print axioms colored_check289

theorem colored_family289 : ∀ c : Fin 64,
    checkColored 289 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (289 * 64 + c.val)) = true := by
  intro c
  rw [colored_row289]
  exact colored_check289 c
#print axioms colored_family289

def coloredWitness290 : Array Nat := #[9874080, 9874800, 9875520, 9876240, 9875544, 9876264, 9876960, 9877680, 9878400, 9879120, 9879840, 9880560, 9879864, 9880584, 9881280, 9882000, 9878402, 9879122, 9879842, 9880562, 9879866, 9880586, 9881282, 9882002, 9882720, 9883440, 9884160, 9884880, 9884184, 9884904, 9885600, 9886320, 9887040, 9887760, 9888480, 9889200, 9888504, 9889224, 9889920, 9890640, 9891360, 9892080, 9892800, 9893520, 9892824, 9893544, 9894240, 9894960, 9891362, 9892082, 9892802, 9893522, 9892826, 9893546, 9894242, 9894962, 9895680, 9896400, 9897120, 9897840, 9897144, 9897864, 9898560, 9899280]

theorem colored_row290 : ∀ c : Fin 64,
    readRow witnessRows (290 * 64 + c.val) = coloredWitness290[c.val]! := by
  decide +kernel
#print axioms colored_row290

theorem colored_check290 : ∀ c : Fin 64,
    checkColored 290 (BitVec.ofNat 6 c.val) (coloredWitness290[c.val]!) = true := by
  decide +kernel
#print axioms colored_check290

theorem colored_family290 : ∀ c : Fin 64,
    checkColored 290 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (290 * 64 + c.val)) = true := by
  intro c
  rw [colored_row290]
  exact colored_check290 c
#print axioms colored_family290

def coloredWitness291 : Array Nat := #[9900000, 9900720, 9901440, 9902160, 9901464, 9902184, 9902880, 9903600, 9904320, 9905040, 9905760, 9906480, 9905784, 9906504, 9907200, 9907920, 9904322, 9905042, 9905762, 9906482, 9905786, 9906506, 9907202, 9907922, 9908640, 9909360, 9910080, 9910800, 9910104, 9910824, 9911520, 9912240, 9912960, 9913680, 9914400, 9915120, 9914424, 9915144, 9915840, 9916560, 9917280, 9918000, 9918720, 9919440, 9918744, 9919464, 9920160, 9920880, 9917282, 9918002, 9918722, 9919442, 9918746, 9919466, 9920162, 9920882, 9921600, 9922320, 9923040, 9923760, 9923064, 9923784, 9924480, 9925200]

theorem colored_row291 : ∀ c : Fin 64,
    readRow witnessRows (291 * 64 + c.val) = coloredWitness291[c.val]! := by
  decide +kernel
#print axioms colored_row291

theorem colored_check291 : ∀ c : Fin 64,
    checkColored 291 (BitVec.ofNat 6 c.val) (coloredWitness291[c.val]!) = true := by
  decide +kernel
#print axioms colored_check291

theorem colored_family291 : ∀ c : Fin 64,
    checkColored 291 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (291 * 64 + c.val)) = true := by
  intro c
  rw [colored_row291]
  exact colored_check291 c
#print axioms colored_family291

def coloredWitness292 : Array Nat := #[9925920, 9926640, 9927360, 9928080, 9928800, 9929520, 9930240, 9930960, 9931680, 9932400, 9933120, 9933840, 9934560, 9935280, 9936000, 9936720, 9931682, 9932402, 9933122, 9933842, 9934562, 9935282, 9936002, 9936722, 9937440, 9938160, 9938880, 9939600, 9940320, 9941040, 9941760, 9942480, 9943200, 9943920, 9944640, 9945360, 9946080, 9946800, 9947520, 9948240, 9948960, 9949680, 9950400, 9951120, 9951840, 9952560, 9953280, 9954000, 9948962, 9949682, 9950402, 9951122, 9951842, 9952562, 9953282, 9954002, 9954720, 9955440, 9956160, 9956880, 9957600, 9958320, 9959040, 9959760]

theorem colored_row292 : ∀ c : Fin 64,
    readRow witnessRows (292 * 64 + c.val) = coloredWitness292[c.val]! := by
  decide +kernel
#print axioms colored_row292

theorem colored_check292 : ∀ c : Fin 64,
    checkColored 292 (BitVec.ofNat 6 c.val) (coloredWitness292[c.val]!) = true := by
  decide +kernel
#print axioms colored_check292

theorem colored_family292 : ∀ c : Fin 64,
    checkColored 292 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (292 * 64 + c.val)) = true := by
  intro c
  rw [colored_row292]
  exact colored_check292 c
#print axioms colored_family292

def coloredWitness293 : Array Nat := #[9960480, 9961200, 9961920, 9962640, 9963360, 9964080, 9964800, 9965520, 9966240, 9966960, 9967680, 9968400, 9969120, 9969840, 9970560, 9971280, 9966242, 9966962, 9967682, 9968402, 9969122, 9969842, 9970562, 9971282, 9972000, 9972720, 9973440, 9974160, 9974880, 9975600, 9976320, 9977040, 9977760, 9978480, 9979200, 9979920, 9980640, 9981360, 9982080, 9982800, 9983520, 9984240, 9984960, 9985680, 9986400, 9987120, 9987840, 9988560, 9983522, 9984242, 9984962, 9985682, 9986402, 9987122, 9987842, 9988562, 9989280, 9990000, 9990720, 9991440, 9992160, 9992880, 9993600, 9994320]

theorem colored_row293 : ∀ c : Fin 64,
    readRow witnessRows (293 * 64 + c.val) = coloredWitness293[c.val]! := by
  decide +kernel
#print axioms colored_row293

theorem colored_check293 : ∀ c : Fin 64,
    checkColored 293 (BitVec.ofNat 6 c.val) (coloredWitness293[c.val]!) = true := by
  decide +kernel
#print axioms colored_check293

theorem colored_family293 : ∀ c : Fin 64,
    checkColored 293 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (293 * 64 + c.val)) = true := by
  intro c
  rw [colored_row293]
  exact colored_check293 c
#print axioms colored_family293

def coloredWitness294 : Array Nat := #[9995040, 9995760, 9996480, 9997200, 9997920, 9998640, 9999360, 10000080, 10000800, 10001520, 10002240, 10002960, 10003680, 10004400, 10005120, 10005840, 10006560, 10007280, 10008000, 10008720, 10009440, 10010160, 10010880, 10011600, 10012320, 10013040, 10013760, 10014480, 10015200, 10015920, 10016640, 10017360, 10018080, 10018800, 10019520, 10020240, 10020960, 10021680, 10022400, 10023120, 10023840, 10024560, 10025280, 10026000, 10026720, 10027440, 10028160, 10028880, 10029600, 10030320, 10031040, 10031760, 10032480, 10033200, 10033920, 10034640, 10035360, 10036080, 10036800, 10037520, 10038240, 10038960, 10039680, 10040400]

theorem colored_row294 : ∀ c : Fin 64,
    readRow witnessRows (294 * 64 + c.val) = coloredWitness294[c.val]! := by
  decide +kernel
#print axioms colored_row294

theorem colored_check294 : ∀ c : Fin 64,
    checkColored 294 (BitVec.ofNat 6 c.val) (coloredWitness294[c.val]!) = true := by
  decide +kernel
#print axioms colored_check294

theorem colored_family294 : ∀ c : Fin 64,
    checkColored 294 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (294 * 64 + c.val)) = true := by
  intro c
  rw [colored_row294]
  exact colored_check294 c
#print axioms colored_family294

def coloredWitness295 : Array Nat := #[10041120, 10041840, 10042560, 10043280, 10044000, 10044720, 10045440, 10046160, 10046880, 10047600, 10048320, 10049040, 10049760, 10050480, 10051200, 10051920, 10052640, 10053360, 10054080, 10054800, 10055520, 10056240, 10056960, 10057680, 10058400, 10059120, 10059840, 10060560, 10061280, 10062000, 10062720, 10063440, 10064160, 10064880, 10065600, 10066320, 10067040, 10067760, 10068480, 10069200, 10069920, 10070640, 10071360, 10072080, 10072800, 10073520, 10074240, 10074960, 10075680, 10076400, 10077120, 10077840, 10078560, 10079280, 10080000, 10080720, 10081440, 10082160, 10082880, 10083600, 10084320, 10085040, 10085760, 10086480]

theorem colored_row295 : ∀ c : Fin 64,
    readRow witnessRows (295 * 64 + c.val) = coloredWitness295[c.val]! := by
  decide +kernel
#print axioms colored_row295

theorem colored_check295 : ∀ c : Fin 64,
    checkColored 295 (BitVec.ofNat 6 c.val) (coloredWitness295[c.val]!) = true := by
  decide +kernel
#print axioms colored_check295

theorem colored_family295 : ∀ c : Fin 64,
    checkColored 295 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (295 * 64 + c.val)) = true := by
  intro c
  rw [colored_row295]
  exact colored_check295 c
#print axioms colored_family295

def coloredWitness296 : Array Nat := #[10087200, 10087920, 10088640, 10089360, 10090080, 10090800, 10091520, 10092240, 10092960, 10093680, 10094400, 10095120, 10095840, 10096560, 10097280, 10098000, 10092962, 10093682, 10094402, 10095122, 10095842, 10096562, 10097282, 10098002, 10098720, 10099440, 10100160, 10100880, 10101600, 10102320, 10103040, 10103760, 10104480, 10105200, 10105920, 10106640, 10107360, 10108080, 10108800, 10109520, 10110240, 10110960, 10111680, 10112400, 10113120, 10113840, 10114560, 10115280, 10110242, 10110962, 10111682, 10112402, 10113122, 10113842, 10114562, 10115282, 10116000, 10116720, 10117440, 10118160, 10118880, 10119600, 10120320, 10121040]

theorem colored_row296 : ∀ c : Fin 64,
    readRow witnessRows (296 * 64 + c.val) = coloredWitness296[c.val]! := by
  decide +kernel
#print axioms colored_row296

theorem colored_check296 : ∀ c : Fin 64,
    checkColored 296 (BitVec.ofNat 6 c.val) (coloredWitness296[c.val]!) = true := by
  decide +kernel
#print axioms colored_check296

theorem colored_family296 : ∀ c : Fin 64,
    checkColored 296 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (296 * 64 + c.val)) = true := by
  intro c
  rw [colored_row296]
  exact colored_check296 c
#print axioms colored_family296

def coloredWitness297 : Array Nat := #[10121760, 10122480, 10123200, 10123920, 10124640, 10125360, 10126080, 10126800, 10127520, 10128240, 10128960, 10129680, 10130400, 10131120, 10131840, 10132560, 10127522, 10128242, 10128962, 10129682, 10130402, 10131122, 10131842, 10132562, 10133280, 10134000, 10134720, 10135440, 10136160, 10136880, 10137600, 10138320, 10139040, 10139760, 10140480, 10141200, 10141920, 10142640, 10143360, 10144080, 10144800, 10145520, 10146240, 10146960, 10147680, 10148400, 10149120, 10149840, 10144802, 10145522, 10146242, 10146962, 10147682, 10148402, 10149122, 10149842, 10150560, 10151280, 10152000, 10152720, 10153440, 10154160, 10154880, 10155600]

theorem colored_row297 : ∀ c : Fin 64,
    readRow witnessRows (297 * 64 + c.val) = coloredWitness297[c.val]! := by
  decide +kernel
#print axioms colored_row297

theorem colored_check297 : ∀ c : Fin 64,
    checkColored 297 (BitVec.ofNat 6 c.val) (coloredWitness297[c.val]!) = true := by
  decide +kernel
#print axioms colored_check297

theorem colored_family297 : ∀ c : Fin 64,
    checkColored 297 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (297 * 64 + c.val)) = true := by
  intro c
  rw [colored_row297]
  exact colored_check297 c
#print axioms colored_family297

def coloredWitness298 : Array Nat := #[10156320, 10157040, 10157760, 10158480, 10157784, 10158504, 10159200, 10159920, 10160640, 10161360, 10162080, 10162800, 10162104, 10162824, 10163520, 10164240, 10160642, 10161362, 10162082, 10162802, 10162106, 10162826, 10163522, 10164242, 10164960, 10165680, 10166400, 10167120, 10166424, 10167144, 10167840, 10168560, 10157673, 10169280, 10159113, 10170000, 10159137, 10170024, 10160553, 10170720, 10161993, 10171440, 10163433, 10172160, 10163457, 10172184, 10164873, 10172880, 10161995, 10171442, 10163435, 10172162, 10163459, 10172186, 10164875, 10172882, 10166313, 10173600, 10167753, 10174320, 10167777, 10174344, 10169193, 10175040]

theorem colored_row298 : ∀ c : Fin 64,
    readRow witnessRows (298 * 64 + c.val) = coloredWitness298[c.val]! := by
  decide +kernel
#print axioms colored_row298

theorem colored_check298 : ∀ c : Fin 64,
    checkColored 298 (BitVec.ofNat 6 c.val) (coloredWitness298[c.val]!) = true := by
  decide +kernel
#print axioms colored_check298

theorem colored_family298 : ∀ c : Fin 64,
    checkColored 298 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (298 * 64 + c.val)) = true := by
  intro c
  rw [colored_row298]
  exact colored_check298 c
#print axioms colored_family298

def coloredWitness299 : Array Nat := #[10175760, 10176480, 10177200, 10177920, 10177224, 10177944, 10178640, 10179360, 10180080, 10180800, 10181520, 10182240, 10181544, 10182264, 10182960, 10183680, 10180082, 10180802, 10181522, 10182242, 10181546, 10182266, 10182962, 10183682, 10184400, 10185120, 10185840, 10186560, 10185864, 10186584, 10187280, 10188000, 10188720, 10189440, 10190160, 10190880, 10190184, 10190904, 10191600, 10192320, 10193040, 10193760, 10194480, 10195200, 10194504, 10195224, 10195920, 10196640, 10193042, 10193762, 10194482, 10195202, 10194506, 10195226, 10195922, 10196642, 10197360, 10198080, 10198800, 10199520, 10198824, 10199544, 10200240, 10200960]

theorem colored_row299 : ∀ c : Fin 64,
    readRow witnessRows (299 * 64 + c.val) = coloredWitness299[c.val]! := by
  decide +kernel
#print axioms colored_row299

theorem colored_check299 : ∀ c : Fin 64,
    checkColored 299 (BitVec.ofNat 6 c.val) (coloredWitness299[c.val]!) = true := by
  decide +kernel
#print axioms colored_check299

theorem colored_family299 : ∀ c : Fin 64,
    checkColored 299 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (299 * 64 + c.val)) = true := by
  intro c
  rw [colored_row299]
  exact colored_check299 c
#print axioms colored_family299

def coloredWitness300 : Array Nat := #[10201680, 10202400, 10203120, 10203840, 10204560, 10205280, 10206000, 10206720, 10207440, 10208160, 10208880, 10209600, 10210320, 10211040, 10211760, 10212480, 10213200, 10213920, 10214640, 10215360, 10216080, 10216800, 10217520, 10218240, 10218960, 10219680, 10220400, 10221120, 10221840, 10222560, 10223280, 10224000, 10224720, 10225440, 10226160, 10226880, 10227600, 10228320, 10229040, 10229760, 10230480, 10231200, 10231920, 10232640, 10233360, 10234080, 10234800, 10235520, 10236240, 10236960, 10237680, 10238400, 10239120, 10239840, 10240560, 10241280, 10242000, 10242720, 10243440, 10244160, 10244880, 10245600, 10246320, 10247040]

theorem colored_row300 : ∀ c : Fin 64,
    readRow witnessRows (300 * 64 + c.val) = coloredWitness300[c.val]! := by
  decide +kernel
#print axioms colored_row300

theorem colored_check300 : ∀ c : Fin 64,
    checkColored 300 (BitVec.ofNat 6 c.val) (coloredWitness300[c.val]!) = true := by
  decide +kernel
#print axioms colored_check300

theorem colored_family300 : ∀ c : Fin 64,
    checkColored 300 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (300 * 64 + c.val)) = true := by
  intro c
  rw [colored_row300]
  exact colored_check300 c
#print axioms colored_family300

def coloredWitness301 : Array Nat := #[10247760, 10248480, 10249200, 10249920, 10250640, 10251360, 10252080, 10252800, 10253520, 10254240, 10254960, 10255680, 10256400, 10257120, 10257840, 10258560, 10259280, 10260000, 10260720, 10261440, 10262160, 10262880, 10263600, 10264320, 10265040, 10265760, 10266480, 10267200, 10267920, 10268640, 10269360, 10270080, 10270800, 10271520, 10272240, 10272960, 10273680, 10274400, 10275120, 10275840, 10276560, 10277280, 10278000, 10278720, 10279440, 10280160, 10280880, 10281600, 10282320, 10283040, 10283760, 10284480, 10285200, 10285920, 10286640, 10287360, 10288080, 10288800, 10289520, 10290240, 10290960, 10291680, 10292400, 10293120]

theorem colored_row301 : ∀ c : Fin 64,
    readRow witnessRows (301 * 64 + c.val) = coloredWitness301[c.val]! := by
  decide +kernel
#print axioms colored_row301

theorem colored_check301 : ∀ c : Fin 64,
    checkColored 301 (BitVec.ofNat 6 c.val) (coloredWitness301[c.val]!) = true := by
  decide +kernel
#print axioms colored_check301

theorem colored_family301 : ∀ c : Fin 64,
    checkColored 301 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (301 * 64 + c.val)) = true := by
  intro c
  rw [colored_row301]
  exact colored_check301 c
#print axioms colored_family301

def coloredWitness302 : Array Nat := #[10293840, 10294560, 10295280, 10296000, 10296720, 10297440, 10298160, 10298880, 10299600, 10300320, 10301040, 10301760, 10302480, 10303200, 10303920, 10304640, 10299602, 10300322, 10301042, 10301762, 10302482, 10303202, 10303922, 10304642, 10305360, 10306080, 10306800, 10307520, 10308240, 10308960, 10309680, 10310400, 10311120, 10311840, 10312560, 10313280, 10314000, 10314720, 10315440, 10316160, 10316880, 10317600, 10318320, 10319040, 10319760, 10320480, 10321200, 10321920, 10316882, 10317602, 10318322, 10319042, 10319762, 10320482, 10321202, 10321922, 10322640, 10323360, 10324080, 10324800, 10325520, 10326240, 10326960, 10327680]

theorem colored_row302 : ∀ c : Fin 64,
    readRow witnessRows (302 * 64 + c.val) = coloredWitness302[c.val]! := by
  decide +kernel
#print axioms colored_row302

theorem colored_check302 : ∀ c : Fin 64,
    checkColored 302 (BitVec.ofNat 6 c.val) (coloredWitness302[c.val]!) = true := by
  decide +kernel
#print axioms colored_check302

theorem colored_family302 : ∀ c : Fin 64,
    checkColored 302 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (302 * 64 + c.val)) = true := by
  intro c
  rw [colored_row302]
  exact colored_check302 c
#print axioms colored_family302

def coloredWitness303 : Array Nat := #[10328400, 10329120, 10329840, 10330560, 10331280, 10332000, 10332720, 10333440, 10334160, 10334880, 10335600, 10336320, 10337040, 10337760, 10338480, 10339200, 10334162, 10334882, 10335602, 10336322, 10337042, 10337762, 10338482, 10339202, 10339920, 10340640, 10341360, 10342080, 10342800, 10343520, 10344240, 10344960, 10345680, 10346400, 10347120, 10347840, 10348560, 10349280, 10350000, 10350720, 10351440, 10352160, 10352880, 10353600, 10354320, 10355040, 10355760, 10356480, 10351442, 10352162, 10352882, 10353602, 10354322, 10355042, 10355762, 10356482, 10357200, 10357920, 10358640, 10359360, 10360080, 10360800, 10361520, 10362240]

theorem colored_row303 : ∀ c : Fin 64,
    readRow witnessRows (303 * 64 + c.val) = coloredWitness303[c.val]! := by
  decide +kernel
#print axioms colored_row303

theorem colored_check303 : ∀ c : Fin 64,
    checkColored 303 (BitVec.ofNat 6 c.val) (coloredWitness303[c.val]!) = true := by
  decide +kernel
#print axioms colored_check303

theorem colored_family303 : ∀ c : Fin 64,
    checkColored 303 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (303 * 64 + c.val)) = true := by
  intro c
  rw [colored_row303]
  exact colored_check303 c
#print axioms colored_family303

def coloredWitness304 : Array Nat := #[10362960, 10363680, 10364400, 10365120, 10364424, 10365144, 10365840, 10366560, 10367280, 10368000, 10368720, 10369440, 10368744, 10369464, 10370160, 10370880, 10371600, 10372320, 10373040, 10373760, 10373064, 10373784, 10374480, 10375200, 10375920, 10376640, 10377360, 10378080, 10377384, 10378104, 10378800, 10379520, 10380240, 10380960, 10381680, 10382400, 10381704, 10382424, 10383120, 10383840, 10384560, 10385280, 10386000, 10386720, 10386024, 10386744, 10387440, 10388160, 10388880, 10389600, 10390320, 10391040, 10390344, 10391064, 10391760, 10392480, 10393200, 10393920, 10394640, 10395360, 10394664, 10395384, 10396080, 10396800]

theorem colored_row304 : ∀ c : Fin 64,
    readRow witnessRows (304 * 64 + c.val) = coloredWitness304[c.val]! := by
  decide +kernel
#print axioms colored_row304

theorem colored_check304 : ∀ c : Fin 64,
    checkColored 304 (BitVec.ofNat 6 c.val) (coloredWitness304[c.val]!) = true := by
  decide +kernel
#print axioms colored_check304

theorem colored_family304 : ∀ c : Fin 64,
    checkColored 304 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (304 * 64 + c.val)) = true := by
  intro c
  rw [colored_row304]
  exact colored_check304 c
#print axioms colored_family304

def coloredWitness305 : Array Nat := #[10397520, 10398240, 10398960, 10399680, 10398984, 10399704, 10400400, 10401120, 10401840, 10402560, 10403280, 10404000, 10403304, 10404024, 10404720, 10405440, 10406160, 10406880, 10407600, 10408320, 10407624, 10408344, 10409040, 10409760, 10410480, 10411200, 10411920, 10412640, 10411944, 10412664, 10413360, 10414080, 10414800, 10415520, 10416240, 10416960, 10416264, 10416984, 10417680, 10418400, 10419120, 10419840, 10420560, 10421280, 10420584, 10421304, 10422000, 10422720, 10423440, 10424160, 10424880, 10425600, 10424904, 10425624, 10426320, 10427040, 10427760, 10428480, 10429200, 10429920, 10429224, 10429944, 10430640, 10431360]

theorem colored_row305 : ∀ c : Fin 64,
    readRow witnessRows (305 * 64 + c.val) = coloredWitness305[c.val]! := by
  decide +kernel
#print axioms colored_row305

theorem colored_check305 : ∀ c : Fin 64,
    checkColored 305 (BitVec.ofNat 6 c.val) (coloredWitness305[c.val]!) = true := by
  decide +kernel
#print axioms colored_check305

theorem colored_family305 : ∀ c : Fin 64,
    checkColored 305 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (305 * 64 + c.val)) = true := by
  intro c
  rw [colored_row305]
  exact colored_check305 c
#print axioms colored_family305

def coloredWitness306 : Array Nat := #[10432080, 10432800, 10433520, 10434240, 10433546, 10434266, 10434960, 10435680, 10436400, 10437120, 10437840, 10438560, 10439280, 10440000, 10440720, 10441440, 10436426, 10437146, 10439306, 10440026, 10437866, 10438586, 10440746, 10441466, 10442160, 10442880, 10443600, 10444320, 10443626, 10444346, 10445040, 10445760, 10446480, 10447200, 10447920, 10448640, 10447946, 10448666, 10449360, 10450080, 10450800, 10451520, 10452240, 10452960, 10453680, 10454400, 10455120, 10455840, 10450826, 10451546, 10453706, 10454426, 10452266, 10452986, 10455146, 10455866, 10456560, 10457280, 10458000, 10458720, 10458026, 10458746, 10459440, 10460160]

theorem colored_row306 : ∀ c : Fin 64,
    readRow witnessRows (306 * 64 + c.val) = coloredWitness306[c.val]! := by
  decide +kernel
#print axioms colored_row306

theorem colored_check306 : ∀ c : Fin 64,
    checkColored 306 (BitVec.ofNat 6 c.val) (coloredWitness306[c.val]!) = true := by
  decide +kernel
#print axioms colored_check306

theorem colored_family306 : ∀ c : Fin 64,
    checkColored 306 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (306 * 64 + c.val)) = true := by
  intro c
  rw [colored_row306]
  exact colored_check306 c
#print axioms colored_family306

def coloredWitness307 : Array Nat := #[10460880, 10461600, 10462320, 10463040, 10462346, 10463066, 10463760, 10464480, 10465200, 10465920, 10466640, 10467360, 10468080, 10468800, 10469520, 10470240, 10465226, 10465946, 10468106, 10468826, 10466666, 10467386, 10469546, 10470266, 10470960, 10471680, 10472400, 10473120, 10472426, 10473146, 10473840, 10474560, 10475280, 10476000, 10476720, 10477440, 10476746, 10477466, 10478160, 10478880, 10479600, 10480320, 10481040, 10481760, 10482480, 10483200, 10483920, 10484640, 10479626, 10480346, 10482506, 10483226, 10481066, 10481786, 10483946, 10484666, 10485360, 10486080, 10486800, 10487520, 10486826, 10487546, 10488240, 10488960]

theorem colored_row307 : ∀ c : Fin 64,
    readRow witnessRows (307 * 64 + c.val) = coloredWitness307[c.val]! := by
  decide +kernel
#print axioms colored_row307

theorem colored_check307 : ∀ c : Fin 64,
    checkColored 307 (BitVec.ofNat 6 c.val) (coloredWitness307[c.val]!) = true := by
  decide +kernel
#print axioms colored_check307

theorem colored_family307 : ∀ c : Fin 64,
    checkColored 307 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (307 * 64 + c.val)) = true := by
  intro c
  rw [colored_row307]
  exact colored_check307 c
#print axioms colored_family307

def coloredWitness308 : Array Nat := #[10489680, 10490400, 10491120, 10491840, 10492560, 10493280, 10494000, 10494720, 10495440, 10496160, 10496880, 10497600, 10498320, 10499040, 10499760, 10500480, 10501200, 10501920, 10502640, 10503360, 10504080, 10504800, 10505520, 10506240, 10506960, 10507680, 10508400, 10509120, 10509840, 10510560, 10511280, 10512000, 10512720, 10513440, 10514160, 10514880, 10515600, 10516320, 10517040, 10517760, 10518480, 10519200, 10519920, 10520640, 10521360, 10522080, 10522800, 10523520, 10524240, 10524960, 10525680, 10526400, 10527120, 10527840, 10528560, 10529280, 10530000, 10530720, 10531440, 10532160, 10532880, 10533600, 10534320, 10535040]

theorem colored_row308 : ∀ c : Fin 64,
    readRow witnessRows (308 * 64 + c.val) = coloredWitness308[c.val]! := by
  decide +kernel
#print axioms colored_row308

theorem colored_check308 : ∀ c : Fin 64,
    checkColored 308 (BitVec.ofNat 6 c.val) (coloredWitness308[c.val]!) = true := by
  decide +kernel
#print axioms colored_check308

theorem colored_family308 : ∀ c : Fin 64,
    checkColored 308 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (308 * 64 + c.val)) = true := by
  intro c
  rw [colored_row308]
  exact colored_check308 c
#print axioms colored_family308

def coloredWitness309 : Array Nat := #[10535760, 10536480, 10537200, 10537920, 10538640, 10539360, 10540080, 10540800, 10541520, 10542240, 10542960, 10543680, 10544400, 10545120, 10545840, 10546560, 10547280, 10548000, 10548720, 10549440, 10550160, 10550880, 10551600, 10552320, 10553040, 10553760, 10554480, 10555200, 10555920, 10556640, 10557360, 10558080, 10558800, 10559520, 10560240, 10560960, 10561680, 10562400, 10563120, 10563840, 10564560, 10565280, 10566000, 10566720, 10567440, 10568160, 10568880, 10569600, 10570320, 10571040, 10571760, 10572480, 10573200, 10573920, 10574640, 10575360, 10576080, 10576800, 10577520, 10578240, 10578960, 10579680, 10580400, 10581120]

theorem colored_row309 : ∀ c : Fin 64,
    readRow witnessRows (309 * 64 + c.val) = coloredWitness309[c.val]! := by
  decide +kernel
#print axioms colored_row309

theorem colored_check309 : ∀ c : Fin 64,
    checkColored 309 (BitVec.ofNat 6 c.val) (coloredWitness309[c.val]!) = true := by
  decide +kernel
#print axioms colored_check309

theorem colored_family309 : ∀ c : Fin 64,
    checkColored 309 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (309 * 64 + c.val)) = true := by
  intro c
  rw [colored_row309]
  exact colored_check309 c
#print axioms colored_family309

def coloredWitness310 : Array Nat := #[10581840, 10582560, 10583280, 10584000, 10583304, 10584024, 10584720, 10585440, 10586160, 10586880, 10587600, 10588320, 10587624, 10588344, 10589040, 10589760, 10586162, 10586882, 10587602, 10588322, 10587626, 10588346, 10589042, 10589762, 10590480, 10591200, 10591920, 10592640, 10591944, 10592664, 10593360, 10594080, 10594800, 10595520, 10596240, 10596960, 10596264, 10596984, 10597680, 10598400, 10599120, 10599840, 10600560, 10601280, 10600584, 10601304, 10602000, 10602720, 10599122, 10599842, 10600562, 10601282, 10600586, 10601306, 10602002, 10602722, 10603440, 10604160, 10604880, 10605600, 10604904, 10605624, 10606320, 10607040]

theorem colored_row310 : ∀ c : Fin 64,
    readRow witnessRows (310 * 64 + c.val) = coloredWitness310[c.val]! := by
  decide +kernel
#print axioms colored_row310

theorem colored_check310 : ∀ c : Fin 64,
    checkColored 310 (BitVec.ofNat 6 c.val) (coloredWitness310[c.val]!) = true := by
  decide +kernel
#print axioms colored_check310

theorem colored_family310 : ∀ c : Fin 64,
    checkColored 310 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (310 * 64 + c.val)) = true := by
  intro c
  rw [colored_row310]
  exact colored_check310 c
#print axioms colored_family310

def coloredWitness311 : Array Nat := #[10607760, 10608480, 10609200, 10609920, 10609224, 10609944, 10610640, 10611360, 10612080, 10612800, 10613520, 10614240, 10613544, 10614264, 10614960, 10615680, 10612082, 10612802, 10613522, 10614242, 10613546, 10614266, 10614962, 10615682, 10616400, 10617120, 10617840, 10618560, 10617864, 10618584, 10619280, 10620000, 10620720, 10621440, 10622160, 10622880, 10622184, 10622904, 10623600, 10624320, 10625040, 10625760, 10626480, 10627200, 10626504, 10627224, 10627920, 10628640, 10625042, 10625762, 10626482, 10627202, 10626506, 10627226, 10627922, 10628642, 10629360, 10630080, 10630800, 10631520, 10630824, 10631544, 10632240, 10632960]

theorem colored_row311 : ∀ c : Fin 64,
    readRow witnessRows (311 * 64 + c.val) = coloredWitness311[c.val]! := by
  decide +kernel
#print axioms colored_row311

theorem colored_check311 : ∀ c : Fin 64,
    checkColored 311 (BitVec.ofNat 6 c.val) (coloredWitness311[c.val]!) = true := by
  decide +kernel
#print axioms colored_check311

theorem colored_family311 : ∀ c : Fin 64,
    checkColored 311 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (311 * 64 + c.val)) = true := by
  intro c
  rw [colored_row311]
  exact colored_check311 c
#print axioms colored_family311

def coloredWitness312 : Array Nat := #[10633680, 10634400, 10635120, 10635840, 10635144, 10635864, 10636560, 10637280, 10638000, 10638720, 10639440, 10640160, 10639464, 10640184, 10640880, 10641600, 10638002, 10638722, 10639442, 10640162, 10639466, 10640186, 10640882, 10641602, 10642320, 10643040, 10643760, 10644480, 10643784, 10644504, 10645200, 10645920, 10646640, 10647360, 10648080, 10648800, 10648104, 10648824, 10649520, 10650240, 10650960, 10651680, 10652400, 10653120, 10652424, 10653144, 10653840, 10654560, 10650962, 10651682, 10652402, 10653122, 10652426, 10653146, 10653842, 10654562, 10655280, 10656000, 10656720, 10657440, 10656744, 10657464, 10658160, 10658880]

theorem colored_row312 : ∀ c : Fin 64,
    readRow witnessRows (312 * 64 + c.val) = coloredWitness312[c.val]! := by
  decide +kernel
#print axioms colored_row312

theorem colored_check312 : ∀ c : Fin 64,
    checkColored 312 (BitVec.ofNat 6 c.val) (coloredWitness312[c.val]!) = true := by
  decide +kernel
#print axioms colored_check312

theorem colored_family312 : ∀ c : Fin 64,
    checkColored 312 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (312 * 64 + c.val)) = true := by
  intro c
  rw [colored_row312]
  exact colored_check312 c
#print axioms colored_family312

def coloredWitness313 : Array Nat := #[10659600, 10660320, 10661040, 10661760, 10661064, 10661784, 10662480, 10663200, 10663920, 10664640, 10665360, 10666080, 10665384, 10666104, 10666800, 10667520, 10663922, 10664642, 10665362, 10666082, 10665386, 10666106, 10666802, 10667522, 10668240, 10668960, 10669680, 10670400, 10669704, 10670424, 10671120, 10671840, 10672560, 10673280, 10674000, 10674720, 10674024, 10674744, 10675440, 10676160, 10676880, 10677600, 10678320, 10679040, 10678344, 10679064, 10679760, 10680480, 10676882, 10677602, 10678322, 10679042, 10678346, 10679066, 10679762, 10680482, 10681200, 10681920, 10682640, 10683360, 10682664, 10683384, 10684080, 10684800]

theorem colored_row313 : ∀ c : Fin 64,
    readRow witnessRows (313 * 64 + c.val) = coloredWitness313[c.val]! := by
  decide +kernel
#print axioms colored_row313

theorem colored_check313 : ∀ c : Fin 64,
    checkColored 313 (BitVec.ofNat 6 c.val) (coloredWitness313[c.val]!) = true := by
  decide +kernel
#print axioms colored_check313

theorem colored_family313 : ∀ c : Fin 64,
    checkColored 313 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (313 * 64 + c.val)) = true := by
  intro c
  rw [colored_row313]
  exact colored_check313 c
#print axioms colored_family313

def coloredWitness314 : Array Nat := #[10685520, 10686240, 10686960, 10687680, 10688400, 10689120, 10689840, 10690560, 10691280, 10692000, 10692720, 10693440, 10694160, 10694880, 10695600, 10696320, 10697040, 10697760, 10698480, 10699200, 10699920, 10700640, 10701360, 10702080, 10702800, 10703520, 10704240, 10704960, 10705680, 10706400, 10707120, 10707840, 10708560, 10709280, 10710000, 10710720, 10711440, 10712160, 10712880, 10713600, 10714320, 10715040, 10715760, 10716480, 10717200, 10717920, 10718640, 10719360, 10720080, 10720800, 10721520, 10722240, 10722960, 10723680, 10724400, 10725120, 10725840, 10726560, 10727280, 10728000, 10728720, 10729440, 10730160, 10730880]

theorem colored_row314 : ∀ c : Fin 64,
    readRow witnessRows (314 * 64 + c.val) = coloredWitness314[c.val]! := by
  decide +kernel
#print axioms colored_row314

theorem colored_check314 : ∀ c : Fin 64,
    checkColored 314 (BitVec.ofNat 6 c.val) (coloredWitness314[c.val]!) = true := by
  decide +kernel
#print axioms colored_check314

theorem colored_family314 : ∀ c : Fin 64,
    checkColored 314 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (314 * 64 + c.val)) = true := by
  intro c
  rw [colored_row314]
  exact colored_check314 c
#print axioms colored_family314

def coloredWitness315 : Array Nat := #[10731600, 10732320, 10733040, 10733760, 10734480, 10735200, 10735920, 10736640, 10737360, 10738080, 10738800, 10739520, 10740240, 10740960, 10741680, 10742400, 10743120, 10743840, 10744560, 10745280, 10746000, 10746720, 10747440, 10748160, 10748880, 10749600, 10750320, 10751040, 10751760, 10752480, 10753200, 10753920, 10754640, 10755360, 10756080, 10756800, 10757520, 10758240, 10758960, 10759680, 10760400, 10761120, 10761840, 10762560, 10763280, 10764000, 10764720, 10765440, 10766160, 10766880, 10767600, 10768320, 10769040, 10769760, 10770480, 10771200, 10771920, 10772640, 10773360, 10774080, 10774800, 10775520, 10776240, 10776960]

theorem colored_row315 : ∀ c : Fin 64,
    readRow witnessRows (315 * 64 + c.val) = coloredWitness315[c.val]! := by
  decide +kernel
#print axioms colored_row315

theorem colored_check315 : ∀ c : Fin 64,
    checkColored 315 (BitVec.ofNat 6 c.val) (coloredWitness315[c.val]!) = true := by
  decide +kernel
#print axioms colored_check315

theorem colored_family315 : ∀ c : Fin 64,
    checkColored 315 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (315 * 64 + c.val)) = true := by
  intro c
  rw [colored_row315]
  exact colored_check315 c
#print axioms colored_family315

def coloredWitness316 : Array Nat := #[10777680, 10778400, 10779120, 10779840, 10780560, 10781280, 10782000, 10782720, 10783440, 10784160, 10784880, 10785600, 10786320, 10787040, 10787760, 10788480, 10783442, 10784162, 10784882, 10785602, 10786322, 10787042, 10787762, 10788482, 10789200, 10789920, 10790640, 10791360, 10792080, 10792800, 10793520, 10794240, 10794960, 10795680, 10796400, 10797120, 10797840, 10798560, 10799280, 10800000, 10800720, 10801440, 10802160, 10802880, 10803600, 10804320, 10805040, 10805760, 10800722, 10801442, 10802162, 10802882, 10803602, 10804322, 10805042, 10805762, 10806480, 10807200, 10807920, 10808640, 10809360, 10810080, 10810800, 10811520]

theorem colored_row316 : ∀ c : Fin 64,
    readRow witnessRows (316 * 64 + c.val) = coloredWitness316[c.val]! := by
  decide +kernel
#print axioms colored_row316

theorem colored_check316 : ∀ c : Fin 64,
    checkColored 316 (BitVec.ofNat 6 c.val) (coloredWitness316[c.val]!) = true := by
  decide +kernel
#print axioms colored_check316

theorem colored_family316 : ∀ c : Fin 64,
    checkColored 316 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (316 * 64 + c.val)) = true := by
  intro c
  rw [colored_row316]
  exact colored_check316 c
#print axioms colored_family316

def coloredWitness317 : Array Nat := #[10812240, 10812960, 10813680, 10814400, 10815120, 10815840, 10816560, 10817280, 10818000, 10818720, 10819440, 10820160, 10820880, 10821600, 10822320, 10823040, 10818002, 10818722, 10819442, 10820162, 10820882, 10821602, 10822322, 10823042, 10823760, 10824480, 10825200, 10825920, 10826640, 10827360, 10828080, 10828800, 10829520, 10830240, 10830960, 10831680, 10832400, 10833120, 10833840, 10834560, 10835280, 10836000, 10836720, 10837440, 10838160, 10838880, 10839600, 10840320, 10835282, 10836002, 10836722, 10837442, 10838162, 10838882, 10839602, 10840322, 10841040, 10841760, 10842480, 10843200, 10843920, 10844640, 10845360, 10846080]

theorem colored_row317 : ∀ c : Fin 64,
    readRow witnessRows (317 * 64 + c.val) = coloredWitness317[c.val]! := by
  decide +kernel
#print axioms colored_row317

theorem colored_check317 : ∀ c : Fin 64,
    checkColored 317 (BitVec.ofNat 6 c.val) (coloredWitness317[c.val]!) = true := by
  decide +kernel
#print axioms colored_check317

theorem colored_family317 : ∀ c : Fin 64,
    checkColored 317 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (317 * 64 + c.val)) = true := by
  intro c
  rw [colored_row317]
  exact colored_check317 c
#print axioms colored_family317

def coloredWitness318 : Array Nat := #[10846800, 10847520, 10848240, 10848960, 10849680, 10850400, 10851120, 10851840, 10852560, 10853280, 10854000, 10854720, 10855440, 10856160, 10856880, 10857600, 10852562, 10853282, 10854002, 10854722, 10855442, 10856162, 10856882, 10857602, 10858320, 10859040, 10859760, 10860480, 10861200, 10861920, 10862640, 10863360, 10864080, 10864800, 10865520, 10866240, 10866960, 10867680, 10868400, 10869120, 10869840, 10870560, 10871280, 10872000, 10872720, 10873440, 10874160, 10874880, 10869842, 10870562, 10871282, 10872002, 10872722, 10873442, 10874162, 10874882, 10875600, 10876320, 10877040, 10877760, 10878480, 10879200, 10879920, 10880640]

theorem colored_row318 : ∀ c : Fin 64,
    readRow witnessRows (318 * 64 + c.val) = coloredWitness318[c.val]! := by
  decide +kernel
#print axioms colored_row318

theorem colored_check318 : ∀ c : Fin 64,
    checkColored 318 (BitVec.ofNat 6 c.val) (coloredWitness318[c.val]!) = true := by
  decide +kernel
#print axioms colored_check318

theorem colored_family318 : ∀ c : Fin 64,
    checkColored 318 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (318 * 64 + c.val)) = true := by
  intro c
  rw [colored_row318]
  exact colored_check318 c
#print axioms colored_family318

def coloredWitness319 : Array Nat := #[10881360, 10882080, 10882800, 10883520, 10884240, 10884960, 10885680, 10886400, 10887120, 10887840, 10888560, 10889280, 10890000, 10890720, 10891440, 10892160, 10887122, 10887842, 10888562, 10889282, 10890002, 10890722, 10891442, 10892162, 10892880, 10893600, 10894320, 10895040, 10895760, 10896480, 10897200, 10897920, 10898640, 10899360, 10900080, 10900800, 10901520, 10902240, 10902960, 10903680, 10904400, 10905120, 10905840, 10906560, 10907280, 10908000, 10908720, 10909440, 10904402, 10905122, 10905842, 10906562, 10907282, 10908002, 10908722, 10909442, 10910160, 10910880, 10911600, 10912320, 10913040, 10913760, 10914480, 10915200]

theorem colored_row319 : ∀ c : Fin 64,
    readRow witnessRows (319 * 64 + c.val) = coloredWitness319[c.val]! := by
  decide +kernel
#print axioms colored_row319

theorem colored_check319 : ∀ c : Fin 64,
    checkColored 319 (BitVec.ofNat 6 c.val) (coloredWitness319[c.val]!) = true := by
  decide +kernel
#print axioms colored_check319

theorem colored_family319 : ∀ c : Fin 64,
    checkColored 319 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (319 * 64 + c.val)) = true := by
  intro c
  rw [colored_row319]
  exact colored_check319 c
#print axioms colored_family319

end TightCycleC5.Bridge.ColoredCover
