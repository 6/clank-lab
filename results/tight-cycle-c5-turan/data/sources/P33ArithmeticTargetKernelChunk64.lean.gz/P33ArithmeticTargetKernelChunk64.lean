-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk256 :
    ∀ i : Fin (min 128 (40547 - 128 * 256)),
      targetCountsMatch (classAt (targetKernelClass ⟨256, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk256

theorem target_counts_kernel_chunk257 :
    ∀ i : Fin (min 128 (40547 - 128 * 257)),
      targetCountsMatch (classAt (targetKernelClass ⟨257, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk257

theorem target_counts_kernel_chunk258 :
    ∀ i : Fin (min 128 (40547 - 128 * 258)),
      targetCountsMatch (classAt (targetKernelClass ⟨258, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk258

theorem target_counts_kernel_chunk259 :
    ∀ i : Fin (min 128 (40547 - 128 * 259)),
      targetCountsMatch (classAt (targetKernelClass ⟨259, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk259


end TightCycleC5.Bridge.P33Arithmetic
