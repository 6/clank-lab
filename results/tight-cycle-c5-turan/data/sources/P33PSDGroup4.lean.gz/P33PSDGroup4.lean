import P33PSDData

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33PSD

theorem terms4_psd : ∀ k, (intMatrixReal (terms4 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector4x0
  · exact int_outer_posSemidef vector4x1
  · exact int_outer_posSemidef vector4x2
  · exact int_outer_posSemidef vector4x3
  · exact int_outer_posSemidef vector4x4
  · exact int_outer_posSemidef vector4x5
  · exact int_outer_posSemidef vector4x6
  · exact int_outer_posSemidef vector4x7
theorem terms4_diagonal : ∀ k i, terms4 k i i ≤ (diagBounds4 k : ℤ) := by
  decide +kernel
theorem psd4 : (intMatrixReal q4).PosSemidef :=
  integer_sos_posSemidef weights4 terms4 terms4_psd
theorem diagonal4 : ∀ i, q4 i i ≤ (m4 : ℤ) :=
  integer_sos_diagonal weights4 diagBounds4 terms4 terms4_diagonal
theorem normalized_psd4 : matrix4.PosSemidef :=
  scale_int_posSemidef q4 scale psd4
theorem normalized_diagonal4 : ∀ i, matrix4 i i ≤ bound4 :=
  scale_int_diagonal q4 scale m4 diagonal4
theorem normalized_nonneg4 : 0 ≤ bound4 :=
  scale_int_bound_nonneg scale m4 (Nat.cast_nonneg _)

#print axioms psd4
#print axioms diagonal4
#print axioms normalized_psd4
#print axioms normalized_diagonal4
#print axioms normalized_nonneg4
#print axioms terms4_psd
#print axioms terms4_diagonal

theorem terms10_psd : ∀ k, (intMatrixReal (terms10 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector10x0
  · exact int_outer_posSemidef vector10x1
  · exact int_outer_posSemidef vector10x2
  · exact int_outer_posSemidef vector10x3
  · exact int_outer_posSemidef vector10x4
  · exact int_outer_posSemidef vector10x5
  · exact int_outer_posSemidef vector10x6
  · exact int_outer_posSemidef vector10x7
  · exact int_outer_posSemidef vector10x8
  · exact int_outer_posSemidef vector10x9
  · exact int_outer_posSemidef vector10x10
  · exact int_outer_posSemidef vector10x11
  · exact int_outer_posSemidef vector10x12
  · exact int_outer_posSemidef vector10x13
theorem terms10_diagonal : ∀ k i, terms10 k i i ≤ (diagBounds10 k : ℤ) := by
  decide +kernel
theorem psd10 : (intMatrixReal q10).PosSemidef :=
  integer_sos_posSemidef weights10 terms10 terms10_psd
theorem diagonal10 : ∀ i, q10 i i ≤ (m10 : ℤ) :=
  integer_sos_diagonal weights10 diagBounds10 terms10 terms10_diagonal
theorem normalized_psd10 : matrix10.PosSemidef :=
  scale_int_posSemidef q10 scale psd10
theorem normalized_diagonal10 : ∀ i, matrix10 i i ≤ bound10 :=
  scale_int_diagonal q10 scale m10 diagonal10
theorem normalized_nonneg10 : 0 ≤ bound10 :=
  scale_int_bound_nonneg scale m10 (Nat.cast_nonneg _)

#print axioms psd10
#print axioms diagonal10
#print axioms normalized_psd10
#print axioms normalized_diagonal10
#print axioms normalized_nonneg10
#print axioms terms10_psd
#print axioms terms10_diagonal

theorem terms16_psd : ∀ k, (intMatrixReal (terms16 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector16x0
  · exact int_outer_posSemidef vector16x1
  · exact int_outer_posSemidef vector16x2
  · exact int_outer_posSemidef vector16x3
  · exact int_outer_posSemidef vector16x4
  · exact int_outer_posSemidef vector16x5
  · exact int_outer_posSemidef vector16x6
  · exact int_outer_posSemidef vector16x7
  · exact int_outer_posSemidef vector16x8
  · exact int_outer_posSemidef vector16x9
theorem terms16_diagonal : ∀ k i, terms16 k i i ≤ (diagBounds16 k : ℤ) := by
  decide +kernel
theorem psd16 : (intMatrixReal q16).PosSemidef :=
  integer_sos_posSemidef weights16 terms16 terms16_psd
theorem diagonal16 : ∀ i, q16 i i ≤ (m16 : ℤ) :=
  integer_sos_diagonal weights16 diagBounds16 terms16 terms16_diagonal
theorem normalized_psd16 : matrix16.PosSemidef :=
  scale_int_posSemidef q16 scale psd16
theorem normalized_diagonal16 : ∀ i, matrix16 i i ≤ bound16 :=
  scale_int_diagonal q16 scale m16 diagonal16
theorem normalized_nonneg16 : 0 ≤ bound16 :=
  scale_int_bound_nonneg scale m16 (Nat.cast_nonneg _)

#print axioms psd16
#print axioms diagonal16
#print axioms normalized_psd16
#print axioms normalized_diagonal16
#print axioms normalized_nonneg16
#print axioms terms16_psd
#print axioms terms16_diagonal

theorem terms22_psd : ∀ k, (intMatrixReal (terms22 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector22x0
  · exact int_outer_posSemidef vector22x1
  · exact int_outer_posSemidef vector22x2
  · exact int_outer_posSemidef vector22x3
  · exact int_outer_posSemidef vector22x4
  · exact int_outer_posSemidef vector22x5
  · exact int_outer_posSemidef vector22x6
  · exact int_outer_posSemidef vector22x7
  · exact int_outer_posSemidef vector22x8
  · exact int_outer_posSemidef vector22x9
  · exact int_outer_posSemidef vector22x10
  · exact int_outer_posSemidef vector22x11
  · exact int_outer_posSemidef vector22x12
theorem terms22_diagonal : ∀ k i, terms22 k i i ≤ (diagBounds22 k : ℤ) := by
  decide +kernel
theorem psd22 : (intMatrixReal q22).PosSemidef :=
  integer_sos_posSemidef weights22 terms22 terms22_psd
theorem diagonal22 : ∀ i, q22 i i ≤ (m22 : ℤ) :=
  integer_sos_diagonal weights22 diagBounds22 terms22 terms22_diagonal
theorem normalized_psd22 : matrix22.PosSemidef :=
  scale_int_posSemidef q22 scale psd22
theorem normalized_diagonal22 : ∀ i, matrix22 i i ≤ bound22 :=
  scale_int_diagonal q22 scale m22 diagonal22
theorem normalized_nonneg22 : 0 ≤ bound22 :=
  scale_int_bound_nonneg scale m22 (Nat.cast_nonneg _)

#print axioms psd22
#print axioms diagonal22
#print axioms normalized_psd22
#print axioms normalized_diagonal22
#print axioms normalized_nonneg22
#print axioms terms22_psd
#print axioms terms22_diagonal

theorem terms28_psd : ∀ k, (intMatrixReal (terms28 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector28x0
  · exact int_outer_posSemidef vector28x1
  · exact int_outer_posSemidef vector28x2
  · exact int_outer_posSemidef vector28x3
  · exact int_outer_posSemidef vector28x4
  · exact int_outer_posSemidef vector28x5
  · exact int_outer_posSemidef vector28x6
  · exact int_outer_posSemidef vector28x7
  · exact int_outer_posSemidef vector28x8
  · exact int_outer_posSemidef vector28x9
  · exact int_outer_posSemidef vector28x10
  · exact int_outer_posSemidef vector28x11
  · exact int_outer_posSemidef vector28x12
  · exact int_outer_posSemidef vector28x13
  · exact int_outer_posSemidef vector28x14
  · exact int_outer_posSemidef vector28x15
  · exact int_outer_posSemidef vector28x16
  · exact int_outer_posSemidef vector28x17
  · exact int_outer_posSemidef vector28x18
theorem terms28_diagonal : ∀ k i, terms28 k i i ≤ (diagBounds28 k : ℤ) := by
  decide +kernel
theorem psd28 : (intMatrixReal q28).PosSemidef :=
  integer_sos_posSemidef weights28 terms28 terms28_psd
theorem diagonal28 : ∀ i, q28 i i ≤ (m28 : ℤ) :=
  integer_sos_diagonal weights28 diagBounds28 terms28 terms28_diagonal
theorem normalized_psd28 : matrix28.PosSemidef :=
  scale_int_posSemidef q28 scale psd28
theorem normalized_diagonal28 : ∀ i, matrix28 i i ≤ bound28 :=
  scale_int_diagonal q28 scale m28 diagonal28
theorem normalized_nonneg28 : 0 ≤ bound28 :=
  scale_int_bound_nonneg scale m28 (Nat.cast_nonneg _)

#print axioms psd28
#print axioms diagonal28
#print axioms normalized_psd28
#print axioms normalized_diagonal28
#print axioms normalized_nonneg28
#print axioms terms28_psd
#print axioms terms28_diagonal

theorem terms34_psd : ∀ k, (intMatrixReal (terms34 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector34x0
theorem terms34_diagonal : ∀ k i, terms34 k i i ≤ (diagBounds34 k : ℤ) := by
  decide +kernel
theorem psd34 : (intMatrixReal q34).PosSemidef :=
  integer_sos_posSemidef weights34 terms34 terms34_psd
theorem diagonal34 : ∀ i, q34 i i ≤ (m34 : ℤ) :=
  integer_sos_diagonal weights34 diagBounds34 terms34 terms34_diagonal
theorem normalized_psd34 : matrix34.PosSemidef :=
  scale_int_posSemidef q34 scale psd34
theorem normalized_diagonal34 : ∀ i, matrix34 i i ≤ bound34 :=
  scale_int_diagonal q34 scale m34 diagonal34
theorem normalized_nonneg34 : 0 ≤ bound34 :=
  scale_int_bound_nonneg scale m34 (Nat.cast_nonneg _)

#print axioms psd34
#print axioms diagonal34
#print axioms normalized_psd34
#print axioms normalized_diagonal34
#print axioms normalized_nonneg34
#print axioms terms34_psd
#print axioms terms34_diagonal

end TightCycleC5.Bridge.P33PSD
