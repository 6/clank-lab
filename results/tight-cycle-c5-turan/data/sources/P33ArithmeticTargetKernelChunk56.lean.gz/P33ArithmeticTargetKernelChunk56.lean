-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk224 :
    ∀ i : Fin (min 128 (40547 - 128 * 224)),
      targetCountsMatch (classAt (targetKernelClass ⟨224, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk224

theorem target_counts_kernel_chunk225 :
    ∀ i : Fin (min 128 (40547 - 128 * 225)),
      targetCountsMatch (classAt (targetKernelClass ⟨225, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk225

theorem target_counts_kernel_chunk226 :
    ∀ i : Fin (min 128 (40547 - 128 * 226)),
      targetCountsMatch (classAt (targetKernelClass ⟨226, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk226

theorem target_counts_kernel_chunk227 :
    ∀ i : Fin (min 128 (40547 - 128 * 227)),
      targetCountsMatch (classAt (targetKernelClass ⟨227, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk227


end TightCycleC5.Bridge.P33Arithmetic
