-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk112 :
    ∀ i : Fin (min 128 (40547 - 128 * 112)),
      targetCountsMatch (classAt (targetKernelClass ⟨112, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk112

theorem target_counts_kernel_chunk113 :
    ∀ i : Fin (min 128 (40547 - 128 * 113)),
      targetCountsMatch (classAt (targetKernelClass ⟨113, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk113

theorem target_counts_kernel_chunk114 :
    ∀ i : Fin (min 128 (40547 - 128 * 114)),
      targetCountsMatch (classAt (targetKernelClass ⟨114, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk114

theorem target_counts_kernel_chunk115 :
    ∀ i : Fin (min 128 (40547 - 128 * 115)),
      targetCountsMatch (classAt (targetKernelClass ⟨115, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk115


end TightCycleC5.Bridge.P33Arithmetic
