import DisjointSampling

/-! Absolute means and restriction errors, used for free-sign regularity rows. -/
namespace TightCycleC5.Bridge
open Finset

theorem uniformMean_abs_le_const {Ω : Type*} [Fintype Ω] [Nonempty Ω]
    (f : Ω → ℝ) (C : ℝ) (hf : ∀ x, |f x| ≤ C) : |uniformMean f| ≤ C := by
  have hc : (0 : ℝ) < Fintype.card Ω := by exact_mod_cast Fintype.card_pos
  rw [uniformMean, abs_div, abs_of_pos hc]
  apply (div_le_iff₀ hc).mpr
  calc
    _ ≤ ∑ x : Ω, |f x| := abs_sum_le_sum_abs f _
    _ ≤ ∑ _x : Ω, C := sum_le_sum fun x _ => hf x
    _ = _ := by simp [mul_comm]

theorem disjointSampleProduct_abs_le {A : Type*} [Fintype A] [DecidableEq A] {r f : ℕ}
    [Nonempty (Fin r ↪ A)] [Nonempty (Fin f ↪ A)]
    (g : (Fin r ↪ A) → ℝ) (h : (Fin f ↪ A) → ℝ)
    (hg : ∀ t, |g t| ≤ 1) (hh0 : ∀ t, 0 ≤ h t) (hh1 : ∀ t, h t ≤ 1) :
    |uniformMean (disjointSampleProduct g h)| ≤
      (Fintype.card ((Fin r ↪ A) × (Fin f ↪ A)) : ℝ) /
        ((disjointEmbeddingPairs A r f).card : ℝ) * |uniformMean g| +
        (((disjointEmbeddingPairs A r f)ᶜ).card : ℝ) /
          ((disjointEmbeddingPairs A r f).card : ℝ) := by
  classical
  have hprod : ∀ p : (Fin r ↪ A) × (Fin f ↪ A), |g p.1 * h p.2| ≤ 1 := by
    intro p
    rw [abs_mul, abs_of_nonneg (hh0 p.2)]
    simpa using mul_le_mul (hg p.1) (hh1 p.2) (hh0 p.2) (by norm_num : (0 : ℝ) ≤ 1)
  obtain ⟨ε, he, hε⟩ := restricted_mean_decomposition (disjointEmbeddingPairs A r f)
    (fun p : (Fin r ↪ A) × (Fin f ↪ A) => g p.1 * h p.2) hprod
  rw [← disjointSampleProduct_mean g h, uniformMean_product g h] at he
  have hmh : |uniformMean h| ≤ 1 := uniformMean_abs_le_const h 1 (fun t => by
    rw [abs_of_nonneg (hh0 t)]; exact hh1 t)
  have hc : 0 ≤ (Fintype.card ((Fin r ↪ A) × (Fin f ↪ A)) : ℝ) /
      ((disjointEmbeddingPairs A r f).card : ℝ) :=
    div_nonneg (Nat.cast_nonneg _) (Nat.cast_nonneg _)
  have hp : |uniformMean g| * |uniformMean h| ≤ |uniformMean g| := by
    simpa using mul_le_mul_of_nonneg_left hmh (abs_nonneg (uniformMean g))
  rw [he]
  calc
    _ ≤ |(Fintype.card ((Fin r ↪ A) × (Fin f ↪ A)) : ℝ) /
        ((disjointEmbeddingPairs A r f).card : ℝ) * (uniformMean g * uniformMean h)| + |ε| :=
      abs_sub _ _
    _ = (Fintype.card ((Fin r ↪ A) × (Fin f ↪ A)) : ℝ) /
        ((disjointEmbeddingPairs A r f).card : ℝ) * (|uniformMean g| * |uniformMean h|) + |ε| := by
      simp only [abs_mul, abs_of_nonneg hc]
    _ ≤ _ := add_le_add (mul_le_mul_of_nonneg_left hp hc) hε

#print axioms uniformMean_abs_le_const
#print axioms disjointSampleProduct_abs_le
end TightCycleC5.Bridge
