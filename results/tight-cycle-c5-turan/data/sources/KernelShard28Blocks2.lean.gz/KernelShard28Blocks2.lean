import KernelRowIndex
import KernelWitness28

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_28_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 64 * 256 + i.val))
      kernelWitness28Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_64

theorem kernelBlock_28_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 65 * 256 + i.val))
      kernelWitness28Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_65

theorem kernelBlock_28_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 66 * 256 + i.val))
      kernelWitness28Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_66

theorem kernelBlock_28_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 67 * 256 + i.val))
      kernelWitness28Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_67

theorem kernelBlock_28_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 68 * 256 + i.val))
      kernelWitness28Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_68

theorem kernelBlock_28_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 69 * 256 + i.val))
      kernelWitness28Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_69

theorem kernelBlock_28_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 70 * 256 + i.val))
      kernelWitness28Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_70

theorem kernelBlock_28_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 71 * 256 + i.val))
      kernelWitness28Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_71

theorem kernelBlock_28_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 72 * 256 + i.val))
      kernelWitness28Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_72

theorem kernelBlock_28_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 73 * 256 + i.val))
      kernelWitness28Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_73

theorem kernelBlock_28_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 74 * 256 + i.val))
      kernelWitness28Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_74

theorem kernelBlock_28_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 75 * 256 + i.val))
      kernelWitness28Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_75

theorem kernelBlock_28_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 76 * 256 + i.val))
      kernelWitness28Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_76

theorem kernelBlock_28_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 77 * 256 + i.val))
      kernelWitness28Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_77

theorem kernelBlock_28_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 78 * 256 + i.val))
      kernelWitness28Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_78

theorem kernelBlock_28_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 79 * 256 + i.val))
      kernelWitness28Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_79

theorem kernelBlock_28_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 80 * 256 + i.val))
      kernelWitness28Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_80

theorem kernelBlock_28_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 81 * 256 + i.val))
      kernelWitness28Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_81

theorem kernelBlock_28_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 82 * 256 + i.val))
      kernelWitness28Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_82

theorem kernelBlock_28_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 83 * 256 + i.val))
      kernelWitness28Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_83

theorem kernelBlock_28_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 84 * 256 + i.val))
      kernelWitness28Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_84

theorem kernelBlock_28_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 85 * 256 + i.val))
      kernelWitness28Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_85

theorem kernelBlock_28_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 86 * 256 + i.val))
      kernelWitness28Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_86

theorem kernelBlock_28_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 87 * 256 + i.val))
      kernelWitness28Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_87

theorem kernelBlock_28_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 88 * 256 + i.val))
      kernelWitness28Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_88

theorem kernelBlock_28_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 89 * 256 + i.val))
      kernelWitness28Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_89

theorem kernelBlock_28_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 90 * 256 + i.val))
      kernelWitness28Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_90

theorem kernelBlock_28_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 91 * 256 + i.val))
      kernelWitness28Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_91

theorem kernelBlock_28_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 92 * 256 + i.val))
      kernelWitness28Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_92

theorem kernelBlock_28_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 93 * 256 + i.val))
      kernelWitness28Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_93

theorem kernelBlock_28_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 94 * 256 + i.val))
      kernelWitness28Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_94

theorem kernelBlock_28_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (28 * 32768 + 95 * 256 + i.val))
      kernelWitness28Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_28_95

end TightCycleC5.Bridge.Cover
