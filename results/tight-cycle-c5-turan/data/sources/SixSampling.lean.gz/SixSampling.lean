import ClassSampling
import BLLP

/-! Labelled six-vertex sampling and class expansion. The orbit-cover
witnesses are explicit hypotheses, pending the exact certificate checker. -/

namespace TightCycleC5.Bridge

open Finset

/-- Edge and colour predicates on labelled vertices. Edge predicates are
defined on all subsets; sampled three-graphs are separately proved to
vanish off triples. Colour true is the complement of the chosen cut. -/
@[ext] structure LabelledStructure (k : ℕ) where
  edge : Finset (Fin k) → Bool
  color : Fin k → Bool

instance (k : ℕ) : MulAction (Equiv.Perm (Fin k)) (LabelledStructure k) where
  smul p G := ⟨fun e => G.edge (e.map p.symm.toEmbedding), fun v => G.color (p.symm v)⟩
  one_smul G := by
    apply LabelledStructure.ext
    · funext e
      change G.edge (e.map (Equiv.refl _).toEmbedding) = G.edge e
      simp
    · rfl
  mul_smul p q G := by
    apply LabelledStructure.ext
    · funext e
      change G.edge (e.map (p * q).symm.toEmbedding) =
        G.edge ((e.map p.symm.toEmbedding).map q.symm.toEmbedding)
      rw [Finset.map_map]
      rfl
    · rfl

/-- Relabel a sample by precomposing it with the inverse permutation. -/
def samplePerm {k n : ℕ} (p : Equiv.Perm (Fin k)) :
    (Fin k ↪ Fin n) ≃ (Fin k ↪ Fin n) :=
  Equiv.embeddingCongr p (Equiv.refl _)

@[simp] theorem samplePerm_apply {k n : ℕ} (p : Equiv.Perm (Fin k))
    (σ : Fin k ↪ Fin n) (i : Fin k) : samplePerm p σ i = σ (p.symm i) := rfl

/-- The labelled structure induced by an injection, using actual edge
membership in H and colour 1 exactly outside S. -/
def sampleStructure {k n : ℕ} (σ : Fin k ↪ Fin n)
    (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) : LabelledStructure k :=
  ⟨fun e => decide (e.map σ ∈ H), fun i => decide (σ i ∉ S)⟩

/-- Relabelling an injection relabels its induced coloured structure. -/
theorem sampleStructure_equivariant {k n : ℕ} (p : Equiv.Perm (Fin k))
    (σ : Fin k ↪ Fin n) (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    sampleStructure (samplePerm p σ) H S = p • sampleStructure σ H S := by
  apply LabelledStructure.ext
  · funext e
    change decide (e.map (samplePerm p σ) ∈ H) =
      decide ((e.map p.symm.toEmbedding).map σ ∈ H)
    rw [Finset.map_map]
    rfl
  · rfl

/-- Induced edge predicates of a three-graph vanish outside triples. -/
theorem sampleStructure_three {k n : ℕ} (σ : Fin k ↪ Fin n)
    {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H) (S : Finset (Fin n))
    (e : Finset (Fin k)) (he : (sampleStructure σ H S).edge e = true) : e.card = 3 := by
  change decide (e.map σ ∈ H) = true at he
  have h := hH _ (of_decide_eq_true he)
  simpa using h

/-- A sampled structure cannot contain a tight cycle if its parent is
C5-free. The five vertices remain injective after composition. -/
theorem sampleStructure_c5free {k n : ℕ} (σ : Fin k ↪ Fin n)
    {H : Finset (Finset (Fin n))} (hC : ¬ ContainsC5 H) (S : Finset (Fin n)) :
    ¬ ∃ f : Fin 5 ↪ Fin k, ∀ i : Fin 5,
      (sampleStructure σ H S).edge {f i, f (i + 1), f (i + 2)} = true := by
  rintro ⟨f, hf⟩
  apply hC
  refine ⟨f.trans σ, fun i => ?_⟩
  have h := of_decide_eq_true (hf i)
  simpa [Finset.map_insert, Finset.map_singleton] using h

/-- Uniform six-injection samples have a probability distribution on any
total assignment to classes. The orbit-cover theorem below ensures that
such assignments respect the actual induced structures. -/
theorem six_class_probability {n : ℕ} (hn : 6 ≤ n) {K : Type*} [Fintype K]
    (classOf : (Fin 6 ↪ Fin n) → K) :
    (∀ k, 0 ≤ classMass classOf k) ∧ ∑ k, classMass classOf k = 1 := by
  letI : Nonempty (Fin 6 ↪ Fin n) := ⟨Fin.castLEEmb hn⟩
  exact ⟨classMass_nonneg classOf, classMass_sum classOf⟩

/-- Concrete form of Lemma 0's class expansion for six-vertex sampling.
The supplied cover must give an actual relabelling to the representative
for every injection, including its colours. -/
theorem six_class_expansion {n : ℕ} {K : Type*} [Fintype K]
    (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (classOf : (Fin 6 ↪ Fin n) → K) (rep : K → LabelledStructure 6)
    (hcover : ∀ σ : Fin 6 ↪ Fin n, ∃ p : Equiv.Perm (Fin 6),
      sampleStructure σ H S = p • rep (classOf σ)) (row : LabelledStructure 6 → ℝ) :
    uniformMean (fun σ : Fin 6 ↪ Fin n => row (sampleStructure σ H S)) =
      ∑ k, classMass classOf k *
        uniformMean (fun p : Equiv.Perm (Fin 6) => row (p • rep k)) := by
  exact class_expansion_of_orbit_cover samplePerm (fun σ => sampleStructure σ H S)
    classOf rep (fun p σ => sampleStructure_equivariant p σ H S) hcover row

theorem six_permutation_count : Fintype.card (Equiv.Perm (Fin 6)) = 720 := by
  rw [Fintype.card_perm]
  norm_num

#print axioms samplePerm_apply
#print axioms sampleStructure_equivariant
#print axioms sampleStructure_three
#print axioms sampleStructure_c5free
#print axioms six_class_probability
#print axioms six_class_expansion
#print axioms six_permutation_count

end TightCycleC5.Bridge
