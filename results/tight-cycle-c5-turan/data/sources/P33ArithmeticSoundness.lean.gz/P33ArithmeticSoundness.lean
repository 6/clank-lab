import Mathlib

/-! Algebra needed by exact P33 arithmetic. These lemmas do not assert
that any quoted certificate or any class inequality has been checked. -/
namespace TightCycleC5.Bridge.P33Arithmetic
open Finset

/-- Sparse evaluation is a reindexing of a full finite coefficient sum.
Repeated sparse indices add, and coefficients may be negative. -/
theorem sparse_sum_eq {ι τ R : Type*} [Fintype ι] [DecidableEq ι]
    [Fintype τ] [CommSemiring R] (index : τ → ι) (weight : τ → R)
    (value : ι → R) :
    (∑ i : ι, (∑ t : τ, if index t = i then weight t else 0) * value i) =
      ∑ t : τ, weight t * value (index t) := by
  simp_rw [Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro t _
  simp only [ite_mul, zero_mul]
  simp

/-- A selected matrix entry is the full ordered double sum of two one-hot
vectors. No upper-triangular pairing or off-diagonal halving occurs. -/
theorem full_trace_one_hot {ι R : Type*} [Fintype ι] [DecidableEq ι]
    [CommSemiring R] (Q : ι → ι → R) (a b : ι) :
    (∑ i : ι, ∑ j : ι, Q i j * (if i = a then 1 else 0) *
      (if j = b then 1 else 0)) = Q a b := by
  simp

/-- Summing SOS terms at a selected pair agrees with first assembling
all matrix entries. This is algebra, without a PSD premise. -/
theorem selected_sos_eq {ι τ R : Type*} [Fintype ι] [DecidableEq ι]
    [Fintype τ] [CommSemiring R] (weight : τ → R) (seed : τ → ι → ι → R)
    (a b : ι) :
    (∑ i : ι, ∑ j : ι, (∑ t : τ, weight t * seed t i j) *
      (if i = a then 1 else 0) * (if j = b then 1 else 0)) =
      ∑ t : τ, weight t * seed t a b :=
  full_trace_one_hot _ a b

/-- Exact clearing of the common scale and sampling denominator.
The target coefficient is 1; the nuisance scale is divided only once. -/
theorem rational_mean_scaling {ι : Type*} [Fintype ι]
    (target : ℚ) (row : ι → ℤ) (scale unit : ℤ)
    (hscale : scale ≠ 0) (hunit : unit ≠ 0) (hcard : Fintype.card ι ≠ 0) :
    (∑ i : ι, (target + (Fintype.card ι : ℚ) * (row i : ℚ) /
      (unit : ℚ) / (scale : ℚ))) / (Fintype.card ι : ℚ) =
      ((scale : ℚ) * (unit : ℚ) * target + (∑ i : ι, (row i : ℚ))) /
        ((unit : ℚ) * (scale : ℚ)) := by
  have hs : (scale : ℚ) ≠ 0 := Int.cast_ne_zero.mpr hscale
  have hu : (unit : ℚ) ≠ 0 := Int.cast_ne_zero.mpr hunit
  have hc : (Fintype.card ι : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr hcard
  simp only [Finset.sum_add_distrib, Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
  simp_rw [div_div]
  rw [← Finset.sum_div, ← Finset.mul_sum]
  field_simp

/-- A checked signed integer total gives precisely the corresponding
rational inequality after positive scaling. -/
theorem int_total_nonpos_iff (total scale unit : ℤ)
    (hscale : 0 < scale) (hunit : 0 < unit) :
    ((total : ℚ) / ((unit : ℚ) * (scale : ℚ)) ≤ 0) ↔ total ≤ 0 := by
  have hd : (0 : ℚ) < (unit : ℚ) * (scale : ℚ) :=
    mul_pos (Int.cast_pos.mpr hunit) (Int.cast_pos.mpr hscale)
  rw [div_le_iff₀ hd, zero_mul]
  exact Int.cast_nonpos

/-- No floating point conversion is used between rational and real signs. -/
theorem rat_real_nonpos_iff (x : ℚ) : (x : ℝ) ≤ 0 ↔ x ≤ 0 := by
  exact_mod_cast (Iff.rfl : x ≤ 0 ↔ x ≤ 0)

/-- Casting the actual rational finite mean commutes with the finite sum. -/
theorem rat_real_mean {ι : Type*} [Fintype ι] (f : ι → ℚ) :
    (((∑ i : ι, f i) / (Fintype.card ι : ℚ) : ℚ) : ℝ) =
      (∑ i : ι, (f i : ℝ)) / (Fintype.card ι : ℝ) := by
  push_cast
  rfl

#print axioms sparse_sum_eq
#print axioms full_trace_one_hot
#print axioms selected_sos_eq
#print axioms rational_mean_scaling
#print axioms int_total_nonpos_iff
#print axioms rat_real_nonpos_iff
#print axioms rat_real_mean
end TightCycleC5.Bridge.P33Arithmetic
