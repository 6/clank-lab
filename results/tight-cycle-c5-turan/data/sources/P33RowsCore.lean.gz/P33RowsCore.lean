import LocalCut
import SixSampling

/-! Literal non-PSD descriptor semantics. Colour true is outside the cut.
Canonicalization fixes every root position and permutes only free labels. -/
namespace TightCycleC5.Bridge.P33Rows
open Finset

abbrev EdgeFn (V : Type*) := V → V → V → Bool
abbrev ColorFn (V : Type*) := V → Bool

def actualEdge {n : Nat} (H : Finset (Finset (Fin n))) (x u v : Fin n) : Bool :=
  decide (({x, u, v} : Finset (Fin n)) ∈ H)
def actualColor {n : Nat} (S : Finset (Fin n)) (x : Fin n) : Bool := decide (x ∉ S)

def raw4 {V : Type*} (e : EdgeFn V) (c : ColorFn V) (x u v a : V) : Nat :=
  16 * ((e x u v).toNat + 2 * (e x u a).toNat +
    4 * (e x v a).toNat + 8 * (e u v a).toNat) +
    (c x).toNat + 2 * (c u).toNat + 4 * (c v).toNat + 8 * (c a).toNat

/-- Minimum of the six orders of free positions 1,2,3; position 0 is fixed. -/
def canonicalLocal {V : Type*} (e : EdgeFn V) (c : ColorFn V) (x a b d : V) : Nat :=
  min (raw4 e c x a b d) (min (raw4 e c x a d b)
    (min (raw4 e c x b a d) (min (raw4 e c x b d a)
      (min (raw4 e c x d a b) (raw4 e c x d b a)))))

/-- Minimum of free orders 2,3 and 3,2; root positions 0 and 1 are fixed. -/
def canonicalRegular {V : Type*} (e : EdgeFn V) (c : ColorFn V) (x u b d : V) : Nat :=
  min (raw4 e c x u b d) (raw4 e c x u d b)

structure LocalDescriptor where
  rootColor : Bool
  flag : Nat

structure RegularDescriptor where
  rootColors : Nat
  flag : Nat

def localFlag {V : Type*} (q : LocalDescriptor) (e : EdgeFn V) (c : ColorFn V)
    (x a b d : V) : ℝ :=
  if c x = q.rootColor ∧ canonicalLocal e c x a b d = q.flag then 1 else 0

def regularFlag {V : Type*} (q : RegularDescriptor) (e : EdgeFn V) (c : ColorFn V)
    (x u b d : V) : ℝ :=
  if (c x).toNat + 2 * (c u).toNat = q.rootColors ∧
    canonicalRegular e c x u b d = q.flag then 1 else 0

/-- Exactly the literal colour-count expression in PROOF Lemma 5. -/
def literalEll {V : Type*} (e : EdgeFn V) (c : ColorFn V) (x u v : V) : ℝ :=
  (if e x u v then 1 else 0) *
    ((if (c u).toNat + (c v).toNat = 1 then 1 else 0) -
      (if (c u).toNat + (c v).toNat = 0 then 1 else 0)) *
    (1 - 2 * ((c x).toNat : ℝ))

/-- No distinctness or graph-uniformity premise is needed for this identity. -/
theorem literalEll_actual {n : Nat} (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (x u v : Fin n) :
    literalEll (actualEdge H) (actualColor S) x u v = localGain H S x u v := by
  by_cases he : ({x, u, v} : Finset (Fin n)) ∈ H <;>
    by_cases hx : x ∈ S <;> by_cases hu : u ∈ S <;> by_cases hv : v ∈ S <;>
    norm_num [literalEll, actualEdge, actualColor, localGain, localSign, he, hx, hu, hv]

def localEvaluate {V : Type*} (q : LocalDescriptor) (e : EdgeFn V) (c : ColorFn V)
    (x u v a b d : V) : ℝ := literalEll e c x u v * localFlag q e c x a b d

def regularEvaluate {V : Type*} (q : RegularDescriptor) (e : EdgeFn V) (c : ColorFn V)
    (x u v a b d : V) : ℝ :=
  ((if e x v a then 1 else 0) - (if e u v a then 1 else 0)) * regularFlag q e c x u b d

def localRow (q : LocalDescriptor) (G : LabelledStructure 6) : ℝ :=
  localEvaluate q (fun x u v => G.edge {x, u, v}) G.color 0 1 2 3 4 5

def regularRow (q : RegularDescriptor) (G : LabelledStructure 6) : ℝ :=
  regularEvaluate q (fun x u v => G.edge {x, u, v}) G.color 0 1 2 3 4 5

theorem localFlag_zero_one {V : Type*} (q : LocalDescriptor) (e : EdgeFn V) (c : ColorFn V)
    (x a b d : V) : localFlag q e c x a b d = 0 ∨ localFlag q e c x a b d = 1 := by
  unfold localFlag
  split_ifs <;> simp

theorem regularFlag_zero_one {V : Type*} (q : RegularDescriptor) (e : EdgeFn V) (c : ColorFn V)
    (x u b d : V) : regularFlag q e c x u b d = 0 ∨ regularFlag q e c x u b d = 1 := by
  unfold regularFlag
  split_ifs <;> simp

theorem localRow_sample {n : Nat} (q : LocalDescriptor)
    (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) :
    localRow q (sampleStructure σ H S) = localEvaluate q (actualEdge H) (actualColor S)
      (σ 0) (σ 1) (σ 2) (σ 3) (σ 4) (σ 5) := by
  have he : (fun x u v => (sampleStructure σ H S).edge {x, u, v}) =
      (fun x u v => actualEdge H (σ x) (σ u) (σ v)) := by
    funext x u v
    simp [sampleStructure, actualEdge]
  unfold localRow
  rw [he]
  rfl

theorem regularRow_sample {n : Nat} (q : RegularDescriptor)
    (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) :
    regularRow q (sampleStructure σ H S) = regularEvaluate q (actualEdge H) (actualColor S)
      (σ 0) (σ 1) (σ 2) (σ 3) (σ 4) (σ 5) := by
  have he : (fun x u v => (sampleStructure σ H S).edge {x, u, v}) =
      (fun x u v => actualEdge H (σ x) (σ u) (σ v)) := by
    funext x u v
    simp [sampleStructure, actualEdge]
  unfold regularRow
  rw [he]
  rfl

#print axioms literalEll_actual
#print axioms localFlag_zero_one
#print axioms regularFlag_zero_one
#print axioms localRow_sample
#print axioms regularRow_sample
end TightCycleC5.Bridge.P33Rows
