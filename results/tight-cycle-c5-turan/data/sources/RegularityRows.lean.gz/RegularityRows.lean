import DegreeCancellation
import PairPairLoss

/-! PROOF §3 Lemma 6: the free-sign degree-regularity row bound. -/
namespace TightCycleC5.Bridge
open Finset
variable {n : ℕ}

theorem linkDifference_outside_mean_abs_le (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hn : 12 ≤ n) (δ : ℝ)
    (hreg : ∀ x u, (deg H x : ℝ) ≤ deg H u + δ * (n : ℝ) ^ 2)
    (root : Fin 2 ↪ Fin n) :
    |uniformMean (fun va : Fin 2 ↪ Outside root =>
      linkDifference H (root 0) (root 1) (va 0).val (va 1).val)| ≤
      2 * δ * (n : ℝ) ^ 2 / (((n : ℝ) - 2) * ((n : ℝ) - 3)) := by
  have hnR : (12 : ℝ) ≤ n := by exact_mod_cast hn
  have hd : 0 < ((n : ℝ) - 2) * ((n : ℝ) - 3) := mul_pos (by linarith) (by linarith)
  have habs : |(deg H (root 0) : ℝ) - deg H (root 1)| ≤ δ * (n : ℝ) ^ 2 := by
    apply abs_le.mpr
    constructor
    · linarith [hreg (root 1) (root 0)]
    · linarith [hreg (root 0) (root 1)]
  rw [linkDifference_outside_mean H hH hn root, abs_div, abs_mul,
    abs_of_pos (by norm_num : (0 : ℝ) < 2), abs_of_pos hd]
  simpa only [mul_assoc] using div_le_div_of_nonneg_right
    (mul_le_mul_of_nonneg_left habs (by norm_num : (0 : ℝ) ≤ 2)) hd.le

theorem regularity_free_mean_abs_le (H : Finset (Finset (Fin n)))
    (hH : IsThreeGraph H) (hn : 12 ≤ n) (δ : ℝ)
    (hreg : ∀ x u, (deg H x : ℝ) ≤ deg H u + δ * (n : ℝ) ^ 2)
    (root : Fin 2 ↪ Fin n) (F : (Fin 2 ↪ Outside root) → ℝ)
    (hF0 : ∀ t, 0 ≤ F t) (hF1 : ∀ t, F t ≤ 1) :
    |uniformMean (disjointSampleProduct
      (fun va : Fin 2 ↪ Outside root => linkDifference H (root 0) (root 1) (va 0).val (va 1).val) F)| ≤
      (2 * δ * (n : ℝ) ^ 2 + 4 * (n : ℝ) - 14) /
        (((n : ℝ) - 4) * ((n : ℝ) - 5)) := by
  classical
  have hcard : Fintype.card (Outside root) = n - 2 := by
    simpa only [Fintype.card_fin] using outside_card root
  have hk : 4 ≤ Fintype.card (Outside root) := by rw [hcard]; omega
  have hcardR : (Fintype.card (Outside root) : ℝ) = (n : ℝ) - 2 := by
    rw [hcard, Nat.cast_sub (by omega : 2 ≤ n)]
    norm_num
  have h := pair_pair_disjoint_abs_le hk
    (fun va : Fin 2 ↪ Outside root => linkDifference H (root 0) (root 1) (va 0).val (va 1).val) F
    (fun va => linkDifference_abs_le H (root 0) (root 1) (va 0).val (va 1).val) hF0 hF1
  simp only [hcardR, sub_sub, show (2 : ℝ) + 1 = 3 by norm_num,
    show (2 : ℝ) + 2 = 4 by norm_num, show (2 : ℝ) + 3 = 5 by norm_num] at h
  have hnR : (12 : ℝ) ≤ n := by exact_mod_cast hn
  have h2 : (n : ℝ) - 2 ≠ 0 := by linarith
  have h3 : (n : ℝ) - 3 ≠ 0 := by linarith
  have h4 : (n : ℝ) - 4 ≠ 0 := by linarith
  have h5 : (n : ℝ) - 5 ≠ 0 := by linarith
  have hρ : 0 ≤ ((n : ℝ) - 2) * ((n : ℝ) - 3) /
      (((n : ℝ) - 4) * ((n : ℝ) - 5)) :=
    div_nonneg (mul_nonneg (by linarith) (by linarith))
      (mul_nonneg (by linarith) (by linarith))
  calc
    _ ≤ _ := h
    _ ≤ (((n : ℝ) - 2) * ((n : ℝ) - 3) /
        (((n : ℝ) - 4) * ((n : ℝ) - 5))) *
        (2 * δ * (n : ℝ) ^ 2 / (((n : ℝ) - 2) * ((n : ℝ) - 3))) +
        (4 * ((n : ℝ) - 2) - 6) / (((n : ℝ) - 4) * ((n : ℝ) - 5)) :=
      add_le_add (mul_le_mul_of_nonneg_left
        (linkDifference_outside_mean_abs_le H hH hn δ hreg root) hρ) le_rfl
    _ = _ := by field_simp; ring

noncomputable def regularSixRow (H : Finset (Finset (Fin n)))
    (F : (root : Fin 2 ↪ Fin n) → (Fin 2 ↪ Outside root) → ℝ)
    (σ : Fin 6 ↪ Fin n) : ℝ :=
  let rf := splitSampleEquiv (r := 2) (f := 4) σ
  disjointSampleProduct
    (fun va : Fin 2 ↪ Outside rf.1 => linkDifference H (rf.1 0) (rf.1 1) (va 0).val (va 1).val)
    (F rf.1) rf.2

theorem regularSixRow_join (H : Finset (Finset (Fin n)))
    (F : (root : Fin 2 ↪ Fin n) → (Fin 2 ↪ Outside root) → ℝ)
    (root : Fin 2 ↪ Fin n) (free : Fin 4 ↪ Outside root) :
    regularSixRow H F (joinSample root free) =
      linkDifference H (root 0) (root 1) (free 0).val (free 1).val *
        F root ((Fin.natAddEmb 2).trans free) := by
  change (fun rf : Σ root : Fin 2 ↪ Fin n, Fin 4 ↪ Outside root =>
    disjointSampleProduct
      (fun va : Fin 2 ↪ Outside rf.1 => linkDifference H (rf.1 0) (rf.1 1) (va 0).val (va 1).val)
      (F rf.1) rf.2) (splitSampleEquiv (joinSample root free)) = _
  rw [splitSampleEquiv_join]
  dsimp only
  rw [disjointSampleProduct_coordinates
    (fun va : Fin 2 ↪ Outside root => linkDifference H (root 0) (root 1) (va 0).val (va 1).val)
    (F root) free]
  rfl

/-- Full Lemma 6. The regularity inequality in both orders supplies the
absolute degree bound. δ is unrestricted; its needed sign follows from
that hypothesis itself. -/
theorem regularity_six_row_abs_le (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (hn : 12 ≤ n) (δ : ℝ)
    (hreg : ∀ x u, (deg H x : ℝ) ≤ deg H u + δ * (n : ℝ) ^ 2)
    (F : (root : Fin 2 ↪ Fin n) → (Fin 2 ↪ Outside root) → ℝ)
    (hF : ∀ root t, F root t = 0 ∨ F root t = 1) :
    |uniformMean (regularSixRow H F)| ≤
      (2 * δ * (n : ℝ) ^ 2 + 4 * (n : ℝ) - 14) /
        (((n : ℝ) - 4) * ((n : ℝ) - 5)) := by
  classical
  letI : Nonempty (Fin 2 ↪ Fin n) := ⟨Fin.castLEEmb (by omega : 2 ≤ n)⟩
  rw [uniformMean_joinSample (r := 2) (f := 4)]
  have he : ∀ (root : Fin 2 ↪ Fin n) (free : Fin 4 ↪ Outside root),
      regularSixRow H F (joinSample root free) =
        disjointSampleProduct
          (fun va : Fin 2 ↪ Outside root => linkDifference H (root 0) (root 1) (va 0).val (va 1).val)
          (F root) free := by
    intro root free
    change (fun rf : Σ root : Fin 2 ↪ Fin n, Fin 4 ↪ Outside root =>
      disjointSampleProduct
        (fun va : Fin 2 ↪ Outside rf.1 => linkDifference H (rf.1 0) (rf.1 1) (va 0).val (va 1).val)
        (F rf.1) rf.2) (splitSampleEquiv (joinSample root free)) = _
    rw [splitSampleEquiv_join]
  simp_rw [he]
  apply uniformMean_abs_le_const
  intro root
  apply regularity_free_mean_abs_le H hH hn δ hreg root (F root)
  · intro t
    rcases hF root t with h | h <;> norm_num [h]
  · intro t
    rcases hF root t with h | h <;> norm_num [h]

#print axioms linkDifference_outside_mean_abs_le
#print axioms regularity_free_mean_abs_le
#print axioms regularSixRow_join
#print axioms regularity_six_row_abs_le
end TightCycleC5.Bridge
