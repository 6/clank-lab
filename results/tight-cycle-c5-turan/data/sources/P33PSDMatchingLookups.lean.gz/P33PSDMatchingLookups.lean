import P33PSDMatchingCore
import P33ArithmeticFinite
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000

namespace TightCycleC5.Bridge.P33PSDMatching

/-- The early-return state used by the frozen arithmetic lookup loop. -/
def rejectStep (bad : Nat → Bool) (i : Nat) (_ : Option Bool × Unit) :
    Id (ForInStep (Option Bool × Unit)) :=
  if bad i then pure (.done (some false, ())) else pure (.yield (none, ()))

/-- A successful traversal has rejected none of the visited indices. -/
theorem rejectLoop (xs : List Nat) (bad : Nat → Bool) :
    (forIn xs (none, ()) (rejectStep bad) : Id (Option Bool × Unit)) =
      if xs.any bad then (some false, ()) else (none, ()) := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
    simp only [List.forIn_cons, rejectStep]
    cases h : bad x <;> simp [h, ih, List.any_cons] <;> rfl

/-- The loop source uses the whole root list in the two-root branch. -/
def sourceLeft (b : P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Fin 6 → Fin 6) : Nat :=
  let root := (List.range b.roots).map (fun v => (p (Fin.ofNat 6 v)).val)
  if b.roots = 2 then P33Arithmetic.canonical K.mask K.colours root [(p 2).val,(p 3).val]
  else P33Arithmetic.encoded K.mask K.colours (root ++ [(p 4).val])

def sourceRight (b : P33Arithmetic.Block) (K : P33Arithmetic.Class) (p : Fin 6 → Fin 6) : Nat :=
  let root := (List.range b.roots).map (fun v => (p (Fin.ofNat 6 v)).val)
  if b.roots = 2 then P33Arithmetic.canonical K.mask K.colours root [(p 4).val,(p 5).val]
  else P33Arithmetic.encoded K.mask K.colours (root ++ [(p 5).val])

theorem sourceLeft_eq (b : P33Arithmetic.Block) (K : P33Arithmetic.Class)
    (p : Fin 6 → Fin 6) : sourceLeft b K p = leftQuery b K p := by
  unfold sourceLeft leftQuery
  split_ifs with h
  · rw [h]; rfl
  · rfl

theorem sourceRight_eq (b : P33Arithmetic.Block) (K : P33Arithmetic.Class)
    (p : Fin 6 → Fin 6) : sourceRight b K p = rightQuery b K p := by
  unfold sourceRight rightQuery
  split_ifs with h
  · rw [h]; rfl
  · rfl

def sourceRejected (b : P33Arithmetic.Block) (K : P33Arithmetic.Class)
    (p : Fin 6 → Fin 6) : Bool :=
  if rootQuery b K p = b.typeCode then
    decide (P33Arithmetic.lookup b.flags (sourceLeft b K p) ≥ b.flags.size) ||
    decide (P33Arithmetic.lookup b.flags (sourceRight b K p) ≥ b.flags.size)
  else false

theorem sourceRejected_false (b : P33Arithmetic.Block) (K : P33Arithmetic.Class)
    (p : Fin 6 → Fin 6) (h : sourceRejected b K p = false) : ValidLookups b K p := by
  intro hr
  simp only [sourceRejected, hr, ite_true, Bool.or_eq_false_iff,
    decide_eq_false_iff_not, sourceLeft_eq, sourceRight_eq] at h
  exact ⟨Nat.lt_of_not_ge h.1, Nat.lt_of_not_ge h.2⟩

def sourceStep (K : P33Arithmetic.Class) (j : Fin 720) (bi : Nat)
    (_ : Option Bool × Unit) : Id (ForInStep (Option Bool × Unit)) :=
  let b := P33Arithmetic.blocks[bi]!
  if rootQuery b K (P33Arithmetic.order j) = b.typeCode then
    if decide (P33Arithmetic.lookup b.flags (sourceLeft b K (P33Arithmetic.order j)) ≥ b.flags.size) ||
       decide (P33Arithmetic.lookup b.flags (sourceRight b K (P33Arithmetic.order j)) ≥ b.flags.size) then
      pure (.done (some false, ()))
    else pure (.yield (none, ()))
  else pure (.yield (none, ()))

theorem sourceStep_eq (K : P33Arithmetic.Class) (j : Fin 720) :
    sourceStep K j = rejectStep (fun bi => sourceRejected P33Arithmetic.blocks[bi]! K (P33Arithmetic.order j)) := by
  funext bi s
  dsimp only [sourceStep, rejectStep, sourceRejected]
  split_ifs <;> simp_all

theorem sourceStep_literal (K : P33Arithmetic.Class) (j : Fin 720) :
    (fun (bi : Nat) (_ : Option Bool × Unit) =>
      let p := fun i : Fin 6 => (P33Arithmetic.order j i).val
      let b := P33Arithmetic.blocks[bi]!
      let root := (List.range b.roots).map (fun v => p (Fin.ofNat 6 v))
      if P33Arithmetic.encoded K.mask K.colours root = b.typeCode then
        let a := if b.roots = 2 then P33Arithmetic.canonical K.mask K.colours root [p 2,p 3]
          else P33Arithmetic.encoded K.mask K.colours (root ++ [p 4])
        let z := if b.roots = 2 then P33Arithmetic.canonical K.mask K.colours root [p 4,p 5]
          else P33Arithmetic.encoded K.mask K.colours (root ++ [p 5])
        if P33Arithmetic.lookup b.flags a ≥ b.flags.size || P33Arithmetic.lookup b.flags z ≥ b.flags.size then
          (pure (.done (some false, ())) : Id (ForInStep (Option Bool × Unit)))
        else pure (.yield (none, ()))
      else pure (.yield (none, ()))) = sourceStep K j := by
  funext bi s
  dsimp only [sourceStep, rootQuery, sourceLeft, sourceRight]
  rfl

/-- The checks following the PSD lookup loop, quoted without modification. -/
def lookupTail (K : P33Arithmetic.Class) (j : Fin 720) : Bool := Id.run do
  let f := P33Arithmetic.features P33Arithmetic.localFlags P33Arithmetic.globalFlags P33Arithmetic.blocks K j
  if f.localIndex ≥ 80 || f.globalIndex ≥ 8 || f.degreeIndex > 120 then return false
  if f.tau ≥ 2 || f.rootColour ≥ 8 then return false
  if !(f.patterns.all (· < 8)) || !(f.freeColours.all (· < 2)) then return false
  return true

/-- The checks preceding the PSD loop; the continuation is a Boolean result. -/
def lookupPrefix (K : P33Arithmetic.Class) (j : Fin 720) (result : Bool) : Bool :=
  let p := fun i : Fin 6 => (P33Arithmetic.order j i).val
  let c := P33Arithmetic.colour K.colours (p 0)
  if c ≥ P33Arithmetic.localFlags.size then false else
  if P33Arithmetic.lookup P33Arithmetic.localFlags[c]!
      (P33Arithmetic.canonical K.mask K.colours [p 0] [p 3,p 4,p 5]) ≥ P33Arithmetic.localFlags[c]!.size then false else
  if P33Arithmetic.lookup P33Arithmetic.globalFlags
      (P33Arithmetic.canonical K.mask K.colours [] [p 3,p 4,p 5]) ≥ P33Arithmetic.globalFlags.size then false else result

/-- Definitional separation of the actual imperative checker, not a replacement checker. -/
theorem lookupsValid_factor (K : P33Arithmetic.Class) (j : Fin 720) :
    P33Arithmetic.lookupsValid K j = lookupPrefix K j
      (match ((forIn [:P33Arithmetic.blocks.size] (none, ()) (sourceStep K j) :
        Id (Option Bool × Unit))).1 with
       | some r => r
       | none => lookupTail K j) := by
  unfold P33Arithmetic.lookupsValid
  simp only [sourceStep_literal]
  dsimp only [lookupPrefix, lookupTail]
  split_ifs <;> try rfl
  all_goals
    generalize he : (forIn [:P33Arithmetic.blocks.size] (none, ()) (sourceStep K j) :
      Id (Option Bool × Unit)) = s
    rcases s with ⟨ret, u⟩
    cases ret <;> rfl

/-- Rejection in the PSD loop cannot be hidden by checks before or after it. -/
theorem lookupPrefix_true (K : P33Arithmetic.Class) (j : Fin 720) (result : Bool)
    (h : lookupPrefix K j result = true) : result = true := by
  dsimp only [lookupPrefix] at h
  split_ifs at h <;> simp_all

/-- All actual lookup bounds follow from the existing finite arithmetic predicate. -/
theorem lookupsValid_bounds (K : P33Arithmetic.Class) (j : Fin 720)
    (h : P33Arithmetic.lookupsValid K j = true) (bi : Fin P33Arithmetic.blocks.size) :
    ValidLookups P33Arithmetic.blocks[bi.val]! K (P33Arithmetic.order j) := by
  rw [lookupsValid_factor] at h
  have hs := lookupPrefix_true K j _ h
  rw [sourceStep_eq, Std.Legacy.Range.forIn_eq_forIn_range', rejectLoop] at hs
  have ha : (List.range' 0 P33Arithmetic.blocks.size 1).any
      (fun bi => sourceRejected P33Arithmetic.blocks[bi]! K (P33Arithmetic.order j)) = false := by
    by_contra hn
    have ht : (List.range' 0 P33Arithmetic.blocks.size 1).any
        (fun bi => sourceRejected P33Arithmetic.blocks[bi]! K (P33Arithmetic.order j)) = true := by
      cases hh : (List.range' 0 P33Arithmetic.blocks.size 1).any
          (fun bi => sourceRejected P33Arithmetic.blocks[bi]! K (P33Arithmetic.order j)) <;> simp_all
    simp only [Std.Legacy.Range.size] at hs
    simp_all
  apply sourceRejected_false
  have hm : bi.val ∈ List.range' 0 P33Arithmetic.blocks.size 1 := by
    simp only [List.mem_range']
    exact ⟨bi.val, bi.isLt, by omega⟩
  simpa using List.any_eq_false.mp ha bi.val hm

#print axioms rejectLoop
#print axioms sourceLeft_eq
#print axioms sourceRight_eq
#print axioms sourceRejected_false
#print axioms sourceStep_eq
#print axioms sourceStep_literal
#print axioms lookupsValid_factor
#print axioms lookupPrefix_true
#print axioms lookupsValid_bounds
end TightCycleC5.Bridge.P33PSDMatching
