-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk72 :
    ∀ i : Fin (min 128 (40547 - 128 * 72)),
      targetCountsMatch (classAt (targetKernelClass ⟨72, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk72

theorem target_counts_kernel_chunk73 :
    ∀ i : Fin (min 128 (40547 - 128 * 73)),
      targetCountsMatch (classAt (targetKernelClass ⟨73, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk73

theorem target_counts_kernel_chunk74 :
    ∀ i : Fin (min 128 (40547 - 128 * 74)),
      targetCountsMatch (classAt (targetKernelClass ⟨74, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk74

theorem target_counts_kernel_chunk75 :
    ∀ i : Fin (min 128 (40547 - 128 * 75)),
      targetCountsMatch (classAt (targetKernelClass ⟨75, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk75


end TightCycleC5.Bridge.P33Arithmetic
