-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk284 :
    ∀ i : Fin (min 128 (40547 - 128 * 284)),
      targetCountsMatch (classAt (targetKernelClass ⟨284, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk284

theorem target_counts_kernel_chunk285 :
    ∀ i : Fin (min 128 (40547 - 128 * 285)),
      targetCountsMatch (classAt (targetKernelClass ⟨285, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk285

theorem target_counts_kernel_chunk286 :
    ∀ i : Fin (min 128 (40547 - 128 * 286)),
      targetCountsMatch (classAt (targetKernelClass ⟨286, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk286

theorem target_counts_kernel_chunk287 :
    ∀ i : Fin (min 128 (40547 - 128 * 287)),
      targetCountsMatch (classAt (targetKernelClass ⟨287, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk287


end TightCycleC5.Bridge.P33Arithmetic
