import KernelShard18Blocks0
import KernelShard18Blocks1
import KernelShard18Blocks2
import KernelShard18Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard18 : kernelShardCheck 18 kernelWitness18 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (18 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness18 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_18_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard18
end TightCycleC5.Bridge.Cover
