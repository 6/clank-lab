-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk276 :
    ∀ i : Fin (min 128 (40547 - 128 * 276)),
      targetCountsMatch (classAt (targetKernelClass ⟨276, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk276

theorem target_counts_kernel_chunk277 :
    ∀ i : Fin (min 128 (40547 - 128 * 277)),
      targetCountsMatch (classAt (targetKernelClass ⟨277, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk277

theorem target_counts_kernel_chunk278 :
    ∀ i : Fin (min 128 (40547 - 128 * 278)),
      targetCountsMatch (classAt (targetKernelClass ⟨278, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk278

theorem target_counts_kernel_chunk279 :
    ∀ i : Fin (min 128 (40547 - 128 * 279)),
      targetCountsMatch (classAt (targetKernelClass ⟨279, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk279


end TightCycleC5.Bridge.P33Arithmetic
