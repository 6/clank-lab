import Mathlib

/-! Actual indicator-vector traces, including keys absent from a finite basis. -/
namespace TightCycleC5.Bridge
open Finset Matrix

/-- Adjoin a zero row and column, without requiring an inhabited basis. -/
def zeroExtend {I : Type*} (Q : Matrix I I ℝ) : Matrix (Option I) (Option I) ℝ
  | some i, some j => Q i j
  | _, _ => 0

/-- Executable search in the explicitly listed finite basis. -/
def flagLookup {k : ℕ} (code : Fin k → ℕ) (key : ℕ) : Option (Fin k) :=
  (List.finRange k).find? (fun i => code i == key)

theorem flagLookup_none_iff {k : ℕ} (code : Fin k → ℕ) (key : ℕ) :
    flagLookup code key = none ↔ ∀ i, key ≠ code i := by
  simp [flagLookup, List.find?_eq_none, ne_comm]

theorem flagLookup_some_iff {k : ℕ} (code : Fin k → ℕ)
    (hinj : Function.Injective code) (key : ℕ) (i : Fin k) :
    flagLookup code key = some i ↔ key = code i := by
  constructor
  · intro h
    have hi : code i = key := by
      simpa only [beq_iff_eq] using List.find?_some h
    exact hi.symm
  · intro hkey
    cases h : flagLookup code key with
    | none => exact False.elim ((flagLookup_none_iff code key).mp h i hkey)
    | some j =>
      have hj : code j = key := by
        have := List.find?_some h
        simpa using this
      have : j = i := hinj (hj.trans hkey)
      simpa only [this] using h

/-- The full written bilinear indicator trace is the optional lookup entry.
Only injectivity is assumed: neither key has to occur in the basis. -/
theorem flag_indicator_trace {k : ℕ} (Q : Matrix (Fin k) (Fin k) ℝ)
    (code : Fin k → ℕ) (hinj : Function.Injective code) (key1 key2 : ℕ) :
    (∑ i, ∑ j, Q i j * (if key1 = code i then 1 else 0) *
      (if key2 = code j then 1 else 0)) =
      zeroExtend Q (flagLookup code key1) (flagLookup code key2) := by
  cases h1 : flagLookup code key1 with
  | none =>
    have hn := (flagLookup_none_iff code key1).mp h1
    simp [hn, zeroExtend]
  | some a =>
    have ha := (flagLookup_some_iff code hinj key1 a).mp h1
    cases h2 : flagLookup code key2 with
    | none =>
      have hn := (flagLookup_none_iff code key2).mp h2
      simp [hn, zeroExtend]
    | some b =>
      have hb := (flagLookup_some_iff code hinj key2 b).mp h2
      simp [ha, hb, hinj.eq_iff, zeroExtend]

#print axioms flagLookup_none_iff
#print axioms flagLookup_some_iff
#print axioms flag_indicator_trace
end TightCycleC5.Bridge
