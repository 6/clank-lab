import ColoredCoverSemantics

namespace TightCycleC5.Bridge.ColoredCover
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def coloredWitness32 : Array Nat := #[732240, 732960, 733680, 734400, 733704, 734424, 735120, 735840, 733728, 734448, 735126, 735846, 735150, 735870, 736560, 737280, 738000, 738720, 739440, 740160, 739464, 740184, 740880, 741600, 739488, 740208, 740886, 741606, 740910, 741630, 742320, 743040, 738001, 738721, 739441, 740161, 739465, 740185, 740881, 741601, 739489, 740209, 740887, 741607, 740911, 741631, 742321, 743041, 743760, 744480, 745200, 745920, 745224, 745944, 746640, 747360, 745248, 745968, 746646, 747366, 746670, 747390, 748080, 748800]

theorem colored_row32 : ∀ c : Fin 64,
    readRow witnessRows (32 * 64 + c.val) = coloredWitness32[c.val]! := by
  decide +kernel
#print axioms colored_row32

theorem colored_check32 : ∀ c : Fin 64,
    checkColored 32 (BitVec.ofNat 6 c.val) (coloredWitness32[c.val]!) = true := by
  decide +kernel
#print axioms colored_check32

theorem colored_family32 : ∀ c : Fin 64,
    checkColored 32 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (32 * 64 + c.val)) = true := by
  intro c
  rw [colored_row32]
  exact colored_check32 c
#print axioms colored_family32

def coloredWitness33 : Array Nat := #[749520, 750240, 750960, 751680, 750984, 751704, 752400, 753120, 751008, 751728, 752406, 753126, 752430, 753150, 753840, 754560, 751032, 751752, 752412, 753132, 752436, 753156, 753842, 754562, 752460, 753180, 753848, 754568, 753872, 754592, 755280, 756000, 751056, 751776, 752418, 753138, 752442, 753162, 753844, 754564, 752466, 753186, 753850, 754570, 753874, 754594, 755281, 756001, 752490, 753210, 753856, 754576, 753880, 754600, 755283, 756003, 753904, 754624, 755289, 756009, 755313, 756033, 756720, 757440]

theorem colored_row33 : ∀ c : Fin 64,
    readRow witnessRows (33 * 64 + c.val) = coloredWitness33[c.val]! := by
  decide +kernel
#print axioms colored_row33

theorem colored_check33 : ∀ c : Fin 64,
    checkColored 33 (BitVec.ofNat 6 c.val) (coloredWitness33[c.val]!) = true := by
  decide +kernel
#print axioms colored_check33

theorem colored_family33 : ∀ c : Fin 64,
    checkColored 33 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (33 * 64 + c.val)) = true := by
  intro c
  rw [colored_row33]
  exact colored_check33 c
#print axioms colored_family33

def coloredWitness34 : Array Nat := #[758160, 758880, 759000, 759600, 759120, 759624, 759744, 760320, 759240, 759648, 759768, 760326, 759888, 760350, 760470, 761040, 761760, 762480, 762600, 763200, 762720, 763224, 763344, 763920, 762840, 763248, 763368, 763926, 763488, 763950, 764070, 764640, 761761, 762481, 762601, 763201, 762721, 763225, 763345, 763921, 762841, 763249, 763369, 763927, 763489, 763951, 764071, 764641, 765360, 766080, 766200, 766800, 766320, 766824, 766944, 767520, 766440, 766848, 766968, 767526, 767088, 767550, 767670, 768240]

theorem colored_row34 : ∀ c : Fin 64,
    readRow witnessRows (34 * 64 + c.val) = coloredWitness34[c.val]! := by
  decide +kernel
#print axioms colored_row34

theorem colored_check34 : ∀ c : Fin 64,
    checkColored 34 (BitVec.ofNat 6 c.val) (coloredWitness34[c.val]!) = true := by
  decide +kernel
#print axioms colored_check34

theorem colored_family34 : ∀ c : Fin 64,
    checkColored 34 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (34 * 64 + c.val)) = true := by
  intro c
  rw [colored_row34]
  exact colored_check34 c
#print axioms colored_family34

def coloredWitness35 : Array Nat := #[768960, 769680, 769800, 770400, 771120, 771840, 771960, 772560, 771126, 771846, 771966, 772566, 773280, 774000, 774120, 774720, 775440, 776160, 776280, 776880, 777600, 778320, 778440, 779040, 777606, 778326, 778446, 779046, 779760, 780480, 780600, 781200, 781920, 782640, 782760, 783360, 784080, 784800, 784920, 785520, 784086, 784806, 784926, 785526, 786240, 786960, 787080, 787680, 788400, 789120, 789240, 789840, 790560, 791280, 791400, 792000, 790566, 791286, 791406, 792006, 792720, 793440, 793560, 794160]

theorem colored_row35 : ∀ c : Fin 64,
    readRow witnessRows (35 * 64 + c.val) = coloredWitness35[c.val]! := by
  decide +kernel
#print axioms colored_row35

theorem colored_check35 : ∀ c : Fin 64,
    checkColored 35 (BitVec.ofNat 6 c.val) (coloredWitness35[c.val]!) = true := by
  decide +kernel
#print axioms colored_check35

theorem colored_family35 : ∀ c : Fin 64,
    checkColored 35 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (35 * 64 + c.val)) = true := by
  intro c
  rw [colored_row35]
  exact colored_check35 c
#print axioms colored_family35

def coloredWitness36 : Array Nat := #[794880, 795600, 795720, 796320, 797040, 797760, 797880, 798480, 799200, 799920, 800040, 800640, 801360, 802080, 802200, 802800, 803520, 804240, 804360, 804960, 805680, 806400, 806520, 807120, 807840, 808560, 808680, 809280, 810000, 810720, 810840, 811440, 812160, 812880, 813000, 813600, 814320, 815040, 815160, 815760, 816480, 817200, 817320, 817920, 818640, 819360, 819480, 820080, 820800, 821520, 821640, 822240, 822960, 823680, 823800, 824400, 825120, 825840, 825960, 826560, 827280, 828000, 828120, 828720]

theorem colored_row36 : ∀ c : Fin 64,
    readRow witnessRows (36 * 64 + c.val) = coloredWitness36[c.val]! := by
  decide +kernel
#print axioms colored_row36

theorem colored_check36 : ∀ c : Fin 64,
    checkColored 36 (BitVec.ofNat 6 c.val) (coloredWitness36[c.val]!) = true := by
  decide +kernel
#print axioms colored_check36

theorem colored_family36 : ∀ c : Fin 64,
    checkColored 36 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (36 * 64 + c.val)) = true := by
  intro c
  rw [colored_row36]
  exact colored_check36 c
#print axioms colored_family36

def coloredWitness37 : Array Nat := #[829440, 830160, 830280, 830880, 831600, 832320, 832440, 833040, 831606, 832326, 832446, 833046, 833760, 834480, 834600, 835200, 835920, 836640, 836760, 837360, 838080, 838800, 838920, 839520, 838086, 838806, 838926, 839526, 840240, 840960, 841080, 841680, 842400, 843120, 843240, 843840, 844560, 845280, 845400, 846000, 844566, 845286, 845406, 846006, 846720, 847440, 847560, 848160, 848880, 849600, 849720, 850320, 851040, 851760, 851880, 852480, 851046, 851766, 851886, 852486, 853200, 853920, 854040, 854640]

theorem colored_row37 : ∀ c : Fin 64,
    readRow witnessRows (37 * 64 + c.val) = coloredWitness37[c.val]! := by
  decide +kernel
#print axioms colored_row37

theorem colored_check37 : ∀ c : Fin 64,
    checkColored 37 (BitVec.ofNat 6 c.val) (coloredWitness37[c.val]!) = true := by
  decide +kernel
#print axioms colored_check37

theorem colored_family37 : ∀ c : Fin 64,
    checkColored 37 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (37 * 64 + c.val)) = true := by
  intro c
  rw [colored_row37]
  exact colored_check37 c
#print axioms colored_family37

def coloredWitness38 : Array Nat := #[855360, 856080, 856200, 856800, 857520, 858240, 858360, 858960, 857526, 858246, 858366, 858966, 859680, 860400, 860520, 861120, 861840, 862560, 862680, 863280, 864000, 864720, 864840, 865440, 864006, 864726, 864846, 865446, 866160, 866880, 867000, 867600, 861841, 862561, 862681, 863281, 864001, 864721, 864841, 865441, 864007, 864727, 864847, 865447, 866161, 866881, 867001, 867601, 868320, 869040, 869160, 869760, 870480, 871200, 871320, 871920, 870486, 871206, 871326, 871926, 872640, 873360, 873480, 874080]

theorem colored_row38 : ∀ c : Fin 64,
    readRow witnessRows (38 * 64 + c.val) = coloredWitness38[c.val]! := by
  decide +kernel
#print axioms colored_row38

theorem colored_check38 : ∀ c : Fin 64,
    checkColored 38 (BitVec.ofNat 6 c.val) (coloredWitness38[c.val]!) = true := by
  decide +kernel
#print axioms colored_check38

theorem colored_family38 : ∀ c : Fin 64,
    checkColored 38 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (38 * 64 + c.val)) = true := by
  intro c
  rw [colored_row38]
  exact colored_check38 c
#print axioms colored_family38

def coloredWitness39 : Array Nat := #[874800, 875520, 875640, 876240, 876960, 877680, 877800, 878400, 879120, 879840, 879960, 880560, 881280, 882000, 882120, 882720, 883440, 884160, 884280, 884880, 885600, 886320, 886440, 887040, 887760, 888480, 888600, 889200, 889920, 890640, 890760, 891360, 883441, 884161, 884281, 884881, 885601, 886321, 886441, 887041, 887761, 888481, 888601, 889201, 889921, 890641, 890761, 891361, 892080, 892800, 892920, 893520, 894240, 894960, 895080, 895680, 896400, 897120, 897240, 897840, 898560, 899280, 899400, 900000]

theorem colored_row39 : ∀ c : Fin 64,
    readRow witnessRows (39 * 64 + c.val) = coloredWitness39[c.val]! := by
  decide +kernel
#print axioms colored_row39

theorem colored_check39 : ∀ c : Fin 64,
    checkColored 39 (BitVec.ofNat 6 c.val) (coloredWitness39[c.val]!) = true := by
  decide +kernel
#print axioms colored_check39

theorem colored_family39 : ∀ c : Fin 64,
    checkColored 39 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (39 * 64 + c.val)) = true := by
  intro c
  rw [colored_row39]
  exact colored_check39 c
#print axioms colored_family39

def coloredWitness40 : Array Nat := #[900720, 901440, 901560, 902160, 902880, 903600, 903720, 904320, 902886, 903606, 903726, 904326, 905040, 905760, 905880, 906480, 907200, 907920, 908040, 908640, 909360, 910080, 910200, 910800, 909366, 910086, 910206, 910806, 911520, 912240, 912360, 912960, 907201, 907921, 908041, 908641, 909361, 910081, 910201, 910801, 909367, 910087, 910207, 910807, 911521, 912241, 912361, 912961, 913680, 914400, 914520, 915120, 915840, 916560, 916680, 917280, 915846, 916566, 916686, 917286, 918000, 918720, 918840, 919440]

theorem colored_row40 : ∀ c : Fin 64,
    readRow witnessRows (40 * 64 + c.val) = coloredWitness40[c.val]! := by
  decide +kernel
#print axioms colored_row40

theorem colored_check40 : ∀ c : Fin 64,
    checkColored 40 (BitVec.ofNat 6 c.val) (coloredWitness40[c.val]!) = true := by
  decide +kernel
#print axioms colored_check40

theorem colored_family40 : ∀ c : Fin 64,
    checkColored 40 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (40 * 64 + c.val)) = true := by
  intro c
  rw [colored_row40]
  exact colored_check40 c
#print axioms colored_family40

def coloredWitness41 : Array Nat := #[920160, 920880, 921002, 921600, 922320, 923040, 923162, 923760, 924480, 925200, 925920, 926640, 927360, 928080, 928800, 929520, 924602, 926042, 925322, 926762, 927482, 928922, 928202, 929642, 930240, 930960, 931082, 931680, 932400, 933120, 933242, 933840, 934560, 935280, 935402, 936000, 936720, 937440, 937562, 938160, 938880, 939600, 940320, 941040, 941760, 942480, 943200, 943920, 939002, 940442, 939722, 941162, 941882, 943322, 942602, 944042, 944640, 945360, 945482, 946080, 946800, 947520, 947642, 948240]

theorem colored_row41 : ∀ c : Fin 64,
    readRow witnessRows (41 * 64 + c.val) = coloredWitness41[c.val]! := by
  decide +kernel
#print axioms colored_row41

theorem colored_check41 : ∀ c : Fin 64,
    checkColored 41 (BitVec.ofNat 6 c.val) (coloredWitness41[c.val]!) = true := by
  decide +kernel
#print axioms colored_check41

theorem colored_family41 : ∀ c : Fin 64,
    checkColored 41 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (41 * 64 + c.val)) = true := by
  intro c
  rw [colored_row41]
  exact colored_check41 c
#print axioms colored_family41

def coloredWitness42 : Array Nat := #[948960, 949680, 949802, 950400, 951120, 951840, 951962, 952560, 953280, 954000, 954720, 955440, 956160, 956880, 957600, 958320, 953402, 954842, 954122, 955562, 956282, 957722, 957002, 958442, 959040, 959760, 959882, 960480, 961200, 961920, 962042, 962640, 963360, 964080, 964202, 964800, 965520, 966240, 966362, 966960, 967680, 968400, 969120, 969840, 970560, 971280, 972000, 972720, 967802, 969242, 968522, 969962, 970682, 972122, 971402, 972842, 973440, 974160, 974282, 974880, 975600, 976320, 976442, 977040]

theorem colored_row42 : ∀ c : Fin 64,
    readRow witnessRows (42 * 64 + c.val) = coloredWitness42[c.val]! := by
  decide +kernel
#print axioms colored_row42

theorem colored_check42 : ∀ c : Fin 64,
    checkColored 42 (BitVec.ofNat 6 c.val) (coloredWitness42[c.val]!) = true := by
  decide +kernel
#print axioms colored_check42

theorem colored_family42 : ∀ c : Fin 64,
    checkColored 42 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (42 * 64 + c.val)) = true := by
  intro c
  rw [colored_row42]
  exact colored_check42 c
#print axioms colored_family42

def coloredWitness43 : Array Nat := #[977760, 978480, 978602, 979200, 978724, 979225, 979347, 979920, 980640, 981360, 982080, 982800, 982105, 982825, 983520, 984240, 980762, 982202, 981482, 982922, 982227, 983642, 982947, 984362, 984960, 985680, 985802, 986400, 987120, 987840, 987962, 988560, 980884, 982324, 982349, 983764, 981604, 983044, 983069, 984484, 984985, 985705, 987145, 987865, 985924, 986425, 988084, 988585, 985107, 987267, 985827, 987987, 985949, 988109, 986547, 988707, 989280, 990000, 990122, 990720, 990244, 990745, 990867, 991440]

theorem colored_row43 : ∀ c : Fin 64,
    readRow witnessRows (43 * 64 + c.val) = coloredWitness43[c.val]! := by
  decide +kernel
#print axioms colored_row43

theorem colored_check43 : ∀ c : Fin 64,
    checkColored 43 (BitVec.ofNat 6 c.val) (coloredWitness43[c.val]!) = true := by
  decide +kernel
#print axioms colored_check43

theorem colored_family43 : ∀ c : Fin 64,
    checkColored 43 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (43 * 64 + c.val)) = true := by
  intro c
  rw [colored_row43]
  exact colored_check43 c
#print axioms colored_family43

def coloredWitness44 : Array Nat := #[992160, 992880, 993002, 993600, 993124, 993625, 993747, 994320, 995040, 995760, 996480, 997200, 996505, 997225, 997920, 998640, 995162, 996602, 995882, 997322, 996627, 998042, 997347, 998762, 999360, 1000080, 1000202, 1000800, 1001520, 1002240, 1002362, 1002960, 995284, 996724, 996749, 998164, 996004, 997444, 997469, 998884, 999385, 1000105, 1001545, 1002265, 1000324, 1000825, 1002484, 1002985, 999507, 1001667, 1000227, 1002387, 1000349, 1002509, 1000947, 1003107, 1003680, 1004400, 1004522, 1005120, 1004644, 1005145, 1005267, 1005840]

theorem colored_row44 : ∀ c : Fin 64,
    readRow witnessRows (44 * 64 + c.val) = coloredWitness44[c.val]! := by
  decide +kernel
#print axioms colored_row44

theorem colored_check44 : ∀ c : Fin 64,
    checkColored 44 (BitVec.ofNat 6 c.val) (coloredWitness44[c.val]!) = true := by
  decide +kernel
#print axioms colored_check44

theorem colored_family44 : ∀ c : Fin 64,
    checkColored 44 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (44 * 64 + c.val)) = true := by
  intro c
  rw [colored_row44]
  exact colored_check44 c
#print axioms colored_family44

def coloredWitness45 : Array Nat := #[1006560, 1007280, 1008000, 1008720, 1009440, 1010160, 1010880, 1011600, 1012320, 1013040, 1013760, 1014480, 1015200, 1015920, 1016640, 1017360, 1018080, 1018800, 1019520, 1020240, 1020960, 1021680, 1022400, 1023120, 1023840, 1024560, 1025280, 1026000, 1026720, 1027440, 1028160, 1028880, 1029600, 1030320, 1031040, 1031760, 1032480, 1033200, 1033920, 1034640, 1035360, 1036080, 1036800, 1037520, 1038240, 1038960, 1039680, 1040400, 1041120, 1041840, 1042560, 1043280, 1044000, 1044720, 1045440, 1046160, 1046880, 1047600, 1048320, 1049040, 1049760, 1050480, 1051200, 1051920]

theorem colored_row45 : ∀ c : Fin 64,
    readRow witnessRows (45 * 64 + c.val) = coloredWitness45[c.val]! := by
  decide +kernel
#print axioms colored_row45

theorem colored_check45 : ∀ c : Fin 64,
    checkColored 45 (BitVec.ofNat 6 c.val) (coloredWitness45[c.val]!) = true := by
  decide +kernel
#print axioms colored_check45

theorem colored_family45 : ∀ c : Fin 64,
    checkColored 45 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (45 * 64 + c.val)) = true := by
  intro c
  rw [colored_row45]
  exact colored_check45 c
#print axioms colored_family45

def coloredWitness46 : Array Nat := #[1052640, 1053360, 1054080, 1054800, 1055520, 1056240, 1056960, 1057680, 1058400, 1059120, 1059840, 1060560, 1061280, 1062000, 1062720, 1063440, 1064160, 1064880, 1065600, 1066320, 1067040, 1067760, 1068480, 1069200, 1069920, 1070640, 1071360, 1072080, 1072800, 1073520, 1074240, 1074960, 1075680, 1076400, 1077120, 1077840, 1078560, 1079280, 1080000, 1080720, 1081440, 1082160, 1082880, 1083600, 1084320, 1085040, 1085760, 1086480, 1087200, 1087920, 1088640, 1089360, 1090080, 1090800, 1091520, 1092240, 1092960, 1093680, 1094400, 1095120, 1095840, 1096560, 1097280, 1098000]

theorem colored_row46 : ∀ c : Fin 64,
    readRow witnessRows (46 * 64 + c.val) = coloredWitness46[c.val]! := by
  decide +kernel
#print axioms colored_row46

theorem colored_check46 : ∀ c : Fin 64,
    checkColored 46 (BitVec.ofNat 6 c.val) (coloredWitness46[c.val]!) = true := by
  decide +kernel
#print axioms colored_check46

theorem colored_family46 : ∀ c : Fin 64,
    checkColored 46 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (46 * 64 + c.val)) = true := by
  intro c
  rw [colored_row46]
  exact colored_check46 c
#print axioms colored_family46

def coloredWitness47 : Array Nat := #[1098720, 1099440, 1099562, 1100160, 1100880, 1101600, 1101722, 1102320, 1103040, 1103760, 1104480, 1105200, 1105920, 1106640, 1107360, 1108080, 1103162, 1104602, 1103882, 1105322, 1106042, 1107482, 1106762, 1108202, 1108800, 1109520, 1109642, 1110240, 1110960, 1111680, 1111802, 1112400, 1113120, 1113840, 1113962, 1114560, 1115280, 1116000, 1116122, 1116720, 1117440, 1118160, 1118880, 1119600, 1120320, 1121040, 1121760, 1122480, 1117562, 1119002, 1118282, 1119722, 1120442, 1121882, 1121162, 1122602, 1123200, 1123920, 1124042, 1124640, 1125360, 1126080, 1126202, 1126800]

theorem colored_row47 : ∀ c : Fin 64,
    readRow witnessRows (47 * 64 + c.val) = coloredWitness47[c.val]! := by
  decide +kernel
#print axioms colored_row47

theorem colored_check47 : ∀ c : Fin 64,
    checkColored 47 (BitVec.ofNat 6 c.val) (coloredWitness47[c.val]!) = true := by
  decide +kernel
#print axioms colored_check47

theorem colored_family47 : ∀ c : Fin 64,
    checkColored 47 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (47 * 64 + c.val)) = true := by
  intro c
  rw [colored_row47]
  exact colored_check47 c
#print axioms colored_family47

def coloredWitness48 : Array Nat := #[1127520, 1128240, 1128362, 1128960, 1129680, 1130400, 1130522, 1131120, 1131840, 1132560, 1133280, 1134000, 1134720, 1135440, 1136160, 1136880, 1131962, 1133402, 1132682, 1134122, 1134842, 1136282, 1135562, 1137002, 1137600, 1138320, 1138442, 1139040, 1139760, 1140480, 1140602, 1141200, 1141920, 1142640, 1142762, 1143360, 1144080, 1144800, 1144922, 1145520, 1146240, 1146960, 1147680, 1148400, 1149120, 1149840, 1150560, 1151280, 1146362, 1147802, 1147082, 1148522, 1149242, 1150682, 1149962, 1151402, 1152000, 1152720, 1152842, 1153440, 1154160, 1154880, 1155002, 1155600]

theorem colored_row48 : ∀ c : Fin 64,
    readRow witnessRows (48 * 64 + c.val) = coloredWitness48[c.val]! := by
  decide +kernel
#print axioms colored_row48

theorem colored_check48 : ∀ c : Fin 64,
    checkColored 48 (BitVec.ofNat 6 c.val) (coloredWitness48[c.val]!) = true := by
  decide +kernel
#print axioms colored_check48

theorem colored_family48 : ∀ c : Fin 64,
    checkColored 48 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (48 * 64 + c.val)) = true := by
  intro c
  rw [colored_row48]
  exact colored_check48 c
#print axioms colored_family48

def coloredWitness49 : Array Nat := #[1156320, 1157040, 1157760, 1158480, 1157784, 1158504, 1159200, 1159920, 1160640, 1161360, 1162080, 1162800, 1162104, 1162824, 1163520, 1164240, 1164960, 1165680, 1166400, 1167120, 1166424, 1167144, 1167840, 1168560, 1169280, 1170000, 1170720, 1171440, 1170744, 1171464, 1172160, 1172880, 1173600, 1174320, 1175040, 1175760, 1175064, 1175784, 1176480, 1177200, 1177920, 1178640, 1179360, 1180080, 1179384, 1180104, 1180800, 1181520, 1182240, 1182960, 1183680, 1184400, 1183704, 1184424, 1185120, 1185840, 1186560, 1187280, 1188000, 1188720, 1188024, 1188744, 1189440, 1190160]

theorem colored_row49 : ∀ c : Fin 64,
    readRow witnessRows (49 * 64 + c.val) = coloredWitness49[c.val]! := by
  decide +kernel
#print axioms colored_row49

theorem colored_check49 : ∀ c : Fin 64,
    checkColored 49 (BitVec.ofNat 6 c.val) (coloredWitness49[c.val]!) = true := by
  decide +kernel
#print axioms colored_check49

theorem colored_family49 : ∀ c : Fin 64,
    checkColored 49 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (49 * 64 + c.val)) = true := by
  intro c
  rw [colored_row49]
  exact colored_check49 c
#print axioms colored_family49

def coloredWitness50 : Array Nat := #[1190880, 1191600, 1192320, 1193040, 1192344, 1193064, 1193760, 1194480, 1195200, 1195920, 1196640, 1197360, 1196664, 1197384, 1198080, 1198800, 1199520, 1200240, 1200960, 1201680, 1200984, 1201704, 1202400, 1203120, 1203840, 1204560, 1205280, 1206000, 1205304, 1206024, 1206720, 1207440, 1208160, 1208880, 1209600, 1210320, 1209624, 1210344, 1211040, 1211760, 1212480, 1213200, 1213920, 1214640, 1213944, 1214664, 1215360, 1216080, 1216800, 1217520, 1218240, 1218960, 1218264, 1218984, 1219680, 1220400, 1221120, 1221840, 1222560, 1223280, 1222584, 1223304, 1224000, 1224720]

theorem colored_row50 : ∀ c : Fin 64,
    readRow witnessRows (50 * 64 + c.val) = coloredWitness50[c.val]! := by
  decide +kernel
#print axioms colored_row50

theorem colored_check50 : ∀ c : Fin 64,
    checkColored 50 (BitVec.ofNat 6 c.val) (coloredWitness50[c.val]!) = true := by
  decide +kernel
#print axioms colored_check50

theorem colored_family50 : ∀ c : Fin 64,
    checkColored 50 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (50 * 64 + c.val)) = true := by
  intro c
  rw [colored_row50]
  exact colored_check50 c
#print axioms colored_family50

def coloredWitness51 : Array Nat := #[1225440, 1226160, 1226880, 1227600, 1226905, 1227625, 1228320, 1229040, 1229760, 1230480, 1231200, 1231920, 1231225, 1231945, 1232640, 1233360, 1234080, 1234800, 1235520, 1236240, 1236960, 1237680, 1238400, 1239120, 1239840, 1240560, 1241280, 1242000, 1242720, 1243440, 1244160, 1244880, 1234105, 1234825, 1236985, 1237705, 1235545, 1236265, 1238425, 1239145, 1239865, 1240585, 1242745, 1243465, 1241305, 1242025, 1244185, 1244905, 1245600, 1246320, 1247040, 1247760, 1247065, 1247785, 1248480, 1249200, 1249920, 1250640, 1251360, 1252080, 1251385, 1252105, 1252800, 1253520]

theorem colored_row51 : ∀ c : Fin 64,
    readRow witnessRows (51 * 64 + c.val) = coloredWitness51[c.val]! := by
  decide +kernel
#print axioms colored_row51

theorem colored_check51 : ∀ c : Fin 64,
    checkColored 51 (BitVec.ofNat 6 c.val) (coloredWitness51[c.val]!) = true := by
  decide +kernel
#print axioms colored_check51

theorem colored_family51 : ∀ c : Fin 64,
    checkColored 51 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (51 * 64 + c.val)) = true := by
  intro c
  rw [colored_row51]
  exact colored_check51 c
#print axioms colored_family51

def coloredWitness52 : Array Nat := #[1254240, 1254960, 1255680, 1256400, 1255705, 1256425, 1257120, 1257840, 1258560, 1259280, 1260000, 1260720, 1260025, 1260745, 1261440, 1262160, 1262880, 1263600, 1264320, 1265040, 1265760, 1266480, 1267200, 1267920, 1268640, 1269360, 1270080, 1270800, 1271520, 1272240, 1272960, 1273680, 1262905, 1263625, 1265785, 1266505, 1264345, 1265065, 1267225, 1267945, 1268665, 1269385, 1271545, 1272265, 1270105, 1270825, 1272985, 1273705, 1274400, 1275120, 1275840, 1276560, 1275865, 1276585, 1277280, 1278000, 1278720, 1279440, 1280160, 1280880, 1280185, 1280905, 1281600, 1282320]

theorem colored_row52 : ∀ c : Fin 64,
    readRow witnessRows (52 * 64 + c.val) = coloredWitness52[c.val]! := by
  decide +kernel
#print axioms colored_row52

theorem colored_check52 : ∀ c : Fin 64,
    checkColored 52 (BitVec.ofNat 6 c.val) (coloredWitness52[c.val]!) = true := by
  decide +kernel
#print axioms colored_check52

theorem colored_family52 : ∀ c : Fin 64,
    checkColored 52 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (52 * 64 + c.val)) = true := by
  intro c
  rw [colored_row52]
  exact colored_check52 c
#print axioms colored_family52

def coloredWitness53 : Array Nat := #[1283040, 1283760, 1284480, 1285200, 1285920, 1286640, 1287360, 1288080, 1288800, 1289520, 1290240, 1290960, 1291680, 1292400, 1293120, 1293840, 1294560, 1295280, 1296000, 1296720, 1297440, 1298160, 1298880, 1299600, 1300320, 1301040, 1301760, 1302480, 1303200, 1303920, 1304640, 1305360, 1306080, 1306800, 1307520, 1308240, 1308960, 1309680, 1310400, 1311120, 1311840, 1312560, 1313280, 1314000, 1314720, 1315440, 1316160, 1316880, 1317600, 1318320, 1319040, 1319760, 1320480, 1321200, 1321920, 1322640, 1323360, 1324080, 1324800, 1325520, 1326240, 1326960, 1327680, 1328400]

theorem colored_row53 : ∀ c : Fin 64,
    readRow witnessRows (53 * 64 + c.val) = coloredWitness53[c.val]! := by
  decide +kernel
#print axioms colored_row53

theorem colored_check53 : ∀ c : Fin 64,
    checkColored 53 (BitVec.ofNat 6 c.val) (coloredWitness53[c.val]!) = true := by
  decide +kernel
#print axioms colored_check53

theorem colored_family53 : ∀ c : Fin 64,
    checkColored 53 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (53 * 64 + c.val)) = true := by
  intro c
  rw [colored_row53]
  exact colored_check53 c
#print axioms colored_family53

def coloredWitness54 : Array Nat := #[1329120, 1329840, 1330560, 1331280, 1332000, 1332720, 1333440, 1334160, 1334880, 1335600, 1336320, 1337040, 1337760, 1338480, 1339200, 1339920, 1340640, 1341360, 1342080, 1342800, 1343520, 1344240, 1344960, 1345680, 1346400, 1347120, 1347840, 1348560, 1349280, 1350000, 1350720, 1351440, 1352160, 1352880, 1353600, 1354320, 1355040, 1355760, 1356480, 1357200, 1357920, 1358640, 1359360, 1360080, 1360800, 1361520, 1362240, 1362960, 1363680, 1364400, 1365120, 1365840, 1366560, 1367280, 1368000, 1368720, 1369440, 1370160, 1370880, 1371600, 1372320, 1373040, 1373760, 1374480]

theorem colored_row54 : ∀ c : Fin 64,
    readRow witnessRows (54 * 64 + c.val) = coloredWitness54[c.val]! := by
  decide +kernel
#print axioms colored_row54

theorem colored_check54 : ∀ c : Fin 64,
    checkColored 54 (BitVec.ofNat 6 c.val) (coloredWitness54[c.val]!) = true := by
  decide +kernel
#print axioms colored_check54

theorem colored_family54 : ∀ c : Fin 64,
    checkColored 54 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (54 * 64 + c.val)) = true := by
  intro c
  rw [colored_row54]
  exact colored_check54 c
#print axioms colored_family54

def coloredWitness55 : Array Nat := #[1375200, 1375920, 1376640, 1377360, 1378080, 1378800, 1379520, 1380240, 1380960, 1381680, 1382400, 1383120, 1383840, 1384560, 1385280, 1386000, 1386720, 1387440, 1388160, 1388880, 1389600, 1390320, 1391040, 1391760, 1392480, 1393200, 1393920, 1394640, 1395360, 1396080, 1396800, 1397520, 1398240, 1398960, 1399680, 1400400, 1401120, 1401840, 1402560, 1403280, 1404000, 1404720, 1405440, 1406160, 1406880, 1407600, 1408320, 1409040, 1409760, 1410480, 1411200, 1411920, 1412640, 1413360, 1414080, 1414800, 1415520, 1416240, 1416960, 1417680, 1418400, 1419120, 1419840, 1420560]

theorem colored_row55 : ∀ c : Fin 64,
    readRow witnessRows (55 * 64 + c.val) = coloredWitness55[c.val]! := by
  decide +kernel
#print axioms colored_row55

theorem colored_check55 : ∀ c : Fin 64,
    checkColored 55 (BitVec.ofNat 6 c.val) (coloredWitness55[c.val]!) = true := by
  decide +kernel
#print axioms colored_check55

theorem colored_family55 : ∀ c : Fin 64,
    checkColored 55 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (55 * 64 + c.val)) = true := by
  intro c
  rw [colored_row55]
  exact colored_check55 c
#print axioms colored_family55

def coloredWitness56 : Array Nat := #[1421280, 1422000, 1422720, 1423440, 1424160, 1424880, 1425600, 1426320, 1427040, 1427760, 1428480, 1429200, 1429920, 1430640, 1431360, 1432080, 1432800, 1433520, 1434240, 1434960, 1435680, 1436400, 1437120, 1437840, 1438560, 1439280, 1440000, 1440720, 1441440, 1442160, 1442880, 1443600, 1444320, 1445040, 1445760, 1446480, 1447200, 1447920, 1448640, 1449360, 1450080, 1450800, 1451520, 1452240, 1452960, 1453680, 1454400, 1455120, 1455840, 1456560, 1457280, 1458000, 1458720, 1459440, 1460160, 1460880, 1461600, 1462320, 1463040, 1463760, 1464480, 1465200, 1465920, 1466640]

theorem colored_row56 : ∀ c : Fin 64,
    readRow witnessRows (56 * 64 + c.val) = coloredWitness56[c.val]! := by
  decide +kernel
#print axioms colored_row56

theorem colored_check56 : ∀ c : Fin 64,
    checkColored 56 (BitVec.ofNat 6 c.val) (coloredWitness56[c.val]!) = true := by
  decide +kernel
#print axioms colored_check56

theorem colored_family56 : ∀ c : Fin 64,
    checkColored 56 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (56 * 64 + c.val)) = true := by
  intro c
  rw [colored_row56]
  exact colored_check56 c
#print axioms colored_family56

def coloredWitness57 : Array Nat := #[1467360, 1468080, 1468800, 1469520, 1468824, 1469544, 1470240, 1470960, 1471680, 1472400, 1473120, 1473840, 1473144, 1473864, 1474560, 1475280, 1476000, 1476720, 1477440, 1478160, 1477464, 1478184, 1478880, 1479600, 1480320, 1481040, 1481760, 1482480, 1481784, 1482504, 1483200, 1483920, 1476001, 1476721, 1477441, 1478161, 1477465, 1478185, 1478881, 1479601, 1480321, 1481041, 1481761, 1482481, 1481785, 1482505, 1483201, 1483921, 1484640, 1485360, 1486080, 1486800, 1486104, 1486824, 1487520, 1488240, 1488960, 1489680, 1490400, 1491120, 1490424, 1491144, 1491840, 1492560]

theorem colored_row57 : ∀ c : Fin 64,
    readRow witnessRows (57 * 64 + c.val) = coloredWitness57[c.val]! := by
  decide +kernel
#print axioms colored_row57

theorem colored_check57 : ∀ c : Fin 64,
    checkColored 57 (BitVec.ofNat 6 c.val) (coloredWitness57[c.val]!) = true := by
  decide +kernel
#print axioms colored_check57

theorem colored_family57 : ∀ c : Fin 64,
    checkColored 57 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (57 * 64 + c.val)) = true := by
  intro c
  rw [colored_row57]
  exact colored_check57 c
#print axioms colored_family57

def coloredWitness58 : Array Nat := #[1493280, 1494000, 1494720, 1495440, 1494744, 1495464, 1496160, 1496880, 1497600, 1498320, 1499040, 1499760, 1499064, 1499784, 1500480, 1501200, 1501920, 1502640, 1503360, 1504080, 1503384, 1504104, 1504800, 1505520, 1506240, 1506960, 1507680, 1508400, 1507704, 1508424, 1509120, 1509840, 1501921, 1502641, 1503361, 1504081, 1503385, 1504105, 1504801, 1505521, 1506241, 1506961, 1507681, 1508401, 1507705, 1508425, 1509121, 1509841, 1510560, 1511280, 1512000, 1512720, 1512024, 1512744, 1513440, 1514160, 1514880, 1515600, 1516320, 1517040, 1516344, 1517064, 1517760, 1518480]

theorem colored_row58 : ∀ c : Fin 64,
    readRow witnessRows (58 * 64 + c.val) = coloredWitness58[c.val]! := by
  decide +kernel
#print axioms colored_row58

theorem colored_check58 : ∀ c : Fin 64,
    checkColored 58 (BitVec.ofNat 6 c.val) (coloredWitness58[c.val]!) = true := by
  decide +kernel
#print axioms colored_check58

theorem colored_family58 : ∀ c : Fin 64,
    checkColored 58 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (58 * 64 + c.val)) = true := by
  intro c
  rw [colored_row58]
  exact colored_check58 c
#print axioms colored_family58

def coloredWitness59 : Array Nat := #[1519200, 1519920, 1520640, 1521360, 1522080, 1522800, 1523520, 1524240, 1524960, 1525680, 1526400, 1527120, 1527840, 1528560, 1529280, 1530000, 1530720, 1531440, 1532160, 1532880, 1533600, 1534320, 1535040, 1535760, 1536480, 1537200, 1537920, 1538640, 1539360, 1540080, 1540800, 1541520, 1530721, 1531441, 1532161, 1532881, 1533601, 1534321, 1535041, 1535761, 1536481, 1537201, 1537921, 1538641, 1539361, 1540081, 1540801, 1541521, 1542240, 1542960, 1543680, 1544400, 1545120, 1545840, 1546560, 1547280, 1548000, 1548720, 1549440, 1550160, 1550880, 1551600, 1552320, 1553040]

theorem colored_row59 : ∀ c : Fin 64,
    readRow witnessRows (59 * 64 + c.val) = coloredWitness59[c.val]! := by
  decide +kernel
#print axioms colored_row59

theorem colored_check59 : ∀ c : Fin 64,
    checkColored 59 (BitVec.ofNat 6 c.val) (coloredWitness59[c.val]!) = true := by
  decide +kernel
#print axioms colored_check59

theorem colored_family59 : ∀ c : Fin 64,
    checkColored 59 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (59 * 64 + c.val)) = true := by
  intro c
  rw [colored_row59]
  exact colored_check59 c
#print axioms colored_family59

def coloredWitness60 : Array Nat := #[1553760, 1554480, 1555200, 1555920, 1556640, 1557360, 1558080, 1558800, 1559520, 1560240, 1560960, 1561680, 1562400, 1563120, 1563840, 1564560, 1565280, 1566000, 1566720, 1567440, 1568160, 1568880, 1569600, 1570320, 1571040, 1571760, 1572480, 1573200, 1573920, 1574640, 1575360, 1576080, 1565281, 1566001, 1566721, 1567441, 1568161, 1568881, 1569601, 1570321, 1571041, 1571761, 1572481, 1573201, 1573921, 1574641, 1575361, 1576081, 1576800, 1577520, 1578240, 1578960, 1579680, 1580400, 1581120, 1581840, 1582560, 1583280, 1584000, 1584720, 1585440, 1586160, 1586880, 1587600]

theorem colored_row60 : ∀ c : Fin 64,
    readRow witnessRows (60 * 64 + c.val) = coloredWitness60[c.val]! := by
  decide +kernel
#print axioms colored_row60

theorem colored_check60 : ∀ c : Fin 64,
    checkColored 60 (BitVec.ofNat 6 c.val) (coloredWitness60[c.val]!) = true := by
  decide +kernel
#print axioms colored_check60

theorem colored_family60 : ∀ c : Fin 64,
    checkColored 60 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (60 * 64 + c.val)) = true := by
  intro c
  rw [colored_row60]
  exact colored_check60 c
#print axioms colored_family60

def coloredWitness61 : Array Nat := #[1588320, 1589040, 1589760, 1590480, 1589784, 1590504, 1591200, 1591920, 1592640, 1593360, 1594080, 1594800, 1594104, 1594824, 1595520, 1596240, 1596960, 1597680, 1598400, 1599120, 1598424, 1599144, 1599840, 1600560, 1601280, 1602000, 1602720, 1603440, 1602744, 1603464, 1604160, 1604880, 1596961, 1597681, 1598401, 1599121, 1598425, 1599145, 1599841, 1600561, 1601281, 1602001, 1602721, 1603441, 1602745, 1603465, 1604161, 1604881, 1605600, 1606320, 1607040, 1607760, 1607064, 1607784, 1608480, 1609200, 1609920, 1610640, 1611360, 1612080, 1611384, 1612104, 1612800, 1613520]

theorem colored_row61 : ∀ c : Fin 64,
    readRow witnessRows (61 * 64 + c.val) = coloredWitness61[c.val]! := by
  decide +kernel
#print axioms colored_row61

theorem colored_check61 : ∀ c : Fin 64,
    checkColored 61 (BitVec.ofNat 6 c.val) (coloredWitness61[c.val]!) = true := by
  decide +kernel
#print axioms colored_check61

theorem colored_family61 : ∀ c : Fin 64,
    checkColored 61 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (61 * 64 + c.val)) = true := by
  intro c
  rw [colored_row61]
  exact colored_check61 c
#print axioms colored_family61

def coloredWitness62 : Array Nat := #[1614240, 1614960, 1615680, 1616400, 1615704, 1616424, 1617120, 1617840, 1618560, 1619280, 1620000, 1620720, 1620024, 1620744, 1621440, 1622160, 1622880, 1623600, 1624320, 1625040, 1624344, 1625064, 1625760, 1626480, 1627200, 1627920, 1628640, 1629360, 1628664, 1629384, 1630080, 1630800, 1622881, 1623601, 1624321, 1625041, 1624345, 1625065, 1625761, 1626481, 1627201, 1627921, 1628641, 1629361, 1628665, 1629385, 1630081, 1630801, 1631520, 1632240, 1632960, 1633680, 1632984, 1633704, 1634400, 1635120, 1635840, 1636560, 1637280, 1638000, 1637304, 1638024, 1638720, 1639440]

theorem colored_row62 : ∀ c : Fin 64,
    readRow witnessRows (62 * 64 + c.val) = coloredWitness62[c.val]! := by
  decide +kernel
#print axioms colored_row62

theorem colored_check62 : ∀ c : Fin 64,
    checkColored 62 (BitVec.ofNat 6 c.val) (coloredWitness62[c.val]!) = true := by
  decide +kernel
#print axioms colored_check62

theorem colored_family62 : ∀ c : Fin 64,
    checkColored 62 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (62 * 64 + c.val)) = true := by
  intro c
  rw [colored_row62]
  exact colored_check62 c
#print axioms colored_family62

def coloredWitness63 : Array Nat := #[1640160, 1640880, 1641600, 1642320, 1641624, 1642344, 1643040, 1643760, 1641648, 1642368, 1643046, 1643766, 1643070, 1643790, 1644480, 1645200, 1641392, 1645920, 1642832, 1646640, 1642856, 1646664, 1644272, 1647360, 1642880, 1646688, 1644278, 1647366, 1644302, 1647390, 1645712, 1648080, 1648800, 1649520, 1650240, 1650960, 1650264, 1650984, 1651680, 1652400, 1650288, 1651008, 1651686, 1652406, 1651710, 1652430, 1653120, 1653840, 1650032, 1654560, 1651472, 1655280, 1651496, 1655304, 1652912, 1656000, 1651520, 1655328, 1652918, 1656006, 1652942, 1656030, 1654352, 1656720]

theorem colored_row63 : ∀ c : Fin 64,
    readRow witnessRows (63 * 64 + c.val) = coloredWitness63[c.val]! := by
  decide +kernel
#print axioms colored_row63

theorem colored_check63 : ∀ c : Fin 64,
    checkColored 63 (BitVec.ofNat 6 c.val) (coloredWitness63[c.val]!) = true := by
  decide +kernel
#print axioms colored_check63

theorem colored_family63 : ∀ c : Fin 64,
    checkColored 63 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (63 * 64 + c.val)) = true := by
  intro c
  rw [colored_row63]
  exact colored_check63 c
#print axioms colored_family63

end TightCycleC5.Bridge.ColoredCover
