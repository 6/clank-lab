import KernelRowIndex
import KernelWitness27

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_27_96 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 96 * 256 + i.val))
      kernelWitness27Row96[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_96

theorem kernelBlock_27_97 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 97 * 256 + i.val))
      kernelWitness27Row97[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_97

theorem kernelBlock_27_98 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 98 * 256 + i.val))
      kernelWitness27Row98[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_98

theorem kernelBlock_27_99 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 99 * 256 + i.val))
      kernelWitness27Row99[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_99

theorem kernelBlock_27_100 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 100 * 256 + i.val))
      kernelWitness27Row100[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_100

theorem kernelBlock_27_101 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 101 * 256 + i.val))
      kernelWitness27Row101[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_101

theorem kernelBlock_27_102 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 102 * 256 + i.val))
      kernelWitness27Row102[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_102

theorem kernelBlock_27_103 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 103 * 256 + i.val))
      kernelWitness27Row103[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_103

theorem kernelBlock_27_104 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 104 * 256 + i.val))
      kernelWitness27Row104[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_104

theorem kernelBlock_27_105 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 105 * 256 + i.val))
      kernelWitness27Row105[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_105

theorem kernelBlock_27_106 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 106 * 256 + i.val))
      kernelWitness27Row106[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_106

theorem kernelBlock_27_107 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 107 * 256 + i.val))
      kernelWitness27Row107[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_107

theorem kernelBlock_27_108 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 108 * 256 + i.val))
      kernelWitness27Row108[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_108

theorem kernelBlock_27_109 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 109 * 256 + i.val))
      kernelWitness27Row109[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_109

theorem kernelBlock_27_110 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 110 * 256 + i.val))
      kernelWitness27Row110[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_110

theorem kernelBlock_27_111 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 111 * 256 + i.val))
      kernelWitness27Row111[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_111

theorem kernelBlock_27_112 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 112 * 256 + i.val))
      kernelWitness27Row112[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_112

theorem kernelBlock_27_113 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 113 * 256 + i.val))
      kernelWitness27Row113[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_113

theorem kernelBlock_27_114 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 114 * 256 + i.val))
      kernelWitness27Row114[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_114

theorem kernelBlock_27_115 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 115 * 256 + i.val))
      kernelWitness27Row115[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_115

theorem kernelBlock_27_116 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 116 * 256 + i.val))
      kernelWitness27Row116[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_116

theorem kernelBlock_27_117 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 117 * 256 + i.val))
      kernelWitness27Row117[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_117

theorem kernelBlock_27_118 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 118 * 256 + i.val))
      kernelWitness27Row118[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_118

theorem kernelBlock_27_119 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 119 * 256 + i.val))
      kernelWitness27Row119[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_119

theorem kernelBlock_27_120 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 120 * 256 + i.val))
      kernelWitness27Row120[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_120

theorem kernelBlock_27_121 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 121 * 256 + i.val))
      kernelWitness27Row121[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_121

theorem kernelBlock_27_122 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 122 * 256 + i.val))
      kernelWitness27Row122[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_122

theorem kernelBlock_27_123 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 123 * 256 + i.val))
      kernelWitness27Row123[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_123

theorem kernelBlock_27_124 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 124 * 256 + i.val))
      kernelWitness27Row124[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_124

theorem kernelBlock_27_125 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 125 * 256 + i.val))
      kernelWitness27Row125[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_125

theorem kernelBlock_27_126 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 126 * 256 + i.val))
      kernelWitness27Row126[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_126

theorem kernelBlock_27_127 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (27 * 32768 + 127 * 256 + i.val))
      kernelWitness27Row127[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_27_127

end TightCycleC5.Bridge.Cover
