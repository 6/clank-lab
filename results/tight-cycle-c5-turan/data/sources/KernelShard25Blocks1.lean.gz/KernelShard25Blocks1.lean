import KernelRowIndex
import KernelWitness25

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_25_32 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 32 * 256 + i.val))
      kernelWitness25Row32[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_32

theorem kernelBlock_25_33 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 33 * 256 + i.val))
      kernelWitness25Row33[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_33

theorem kernelBlock_25_34 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 34 * 256 + i.val))
      kernelWitness25Row34[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_34

theorem kernelBlock_25_35 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 35 * 256 + i.val))
      kernelWitness25Row35[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_35

theorem kernelBlock_25_36 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 36 * 256 + i.val))
      kernelWitness25Row36[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_36

theorem kernelBlock_25_37 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 37 * 256 + i.val))
      kernelWitness25Row37[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_37

theorem kernelBlock_25_38 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 38 * 256 + i.val))
      kernelWitness25Row38[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_38

theorem kernelBlock_25_39 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 39 * 256 + i.val))
      kernelWitness25Row39[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_39

theorem kernelBlock_25_40 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 40 * 256 + i.val))
      kernelWitness25Row40[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_40

theorem kernelBlock_25_41 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 41 * 256 + i.val))
      kernelWitness25Row41[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_41

theorem kernelBlock_25_42 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 42 * 256 + i.val))
      kernelWitness25Row42[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_42

theorem kernelBlock_25_43 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 43 * 256 + i.val))
      kernelWitness25Row43[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_43

theorem kernelBlock_25_44 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 44 * 256 + i.val))
      kernelWitness25Row44[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_44

theorem kernelBlock_25_45 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 45 * 256 + i.val))
      kernelWitness25Row45[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_45

theorem kernelBlock_25_46 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 46 * 256 + i.val))
      kernelWitness25Row46[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_46

theorem kernelBlock_25_47 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 47 * 256 + i.val))
      kernelWitness25Row47[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_47

theorem kernelBlock_25_48 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 48 * 256 + i.val))
      kernelWitness25Row48[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_48

theorem kernelBlock_25_49 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 49 * 256 + i.val))
      kernelWitness25Row49[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_49

theorem kernelBlock_25_50 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 50 * 256 + i.val))
      kernelWitness25Row50[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_50

theorem kernelBlock_25_51 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 51 * 256 + i.val))
      kernelWitness25Row51[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_51

theorem kernelBlock_25_52 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 52 * 256 + i.val))
      kernelWitness25Row52[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_52

theorem kernelBlock_25_53 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 53 * 256 + i.val))
      kernelWitness25Row53[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_53

theorem kernelBlock_25_54 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 54 * 256 + i.val))
      kernelWitness25Row54[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_54

theorem kernelBlock_25_55 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 55 * 256 + i.val))
      kernelWitness25Row55[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_55

theorem kernelBlock_25_56 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 56 * 256 + i.val))
      kernelWitness25Row56[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_56

theorem kernelBlock_25_57 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 57 * 256 + i.val))
      kernelWitness25Row57[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_57

theorem kernelBlock_25_58 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 58 * 256 + i.val))
      kernelWitness25Row58[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_58

theorem kernelBlock_25_59 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 59 * 256 + i.val))
      kernelWitness25Row59[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_59

theorem kernelBlock_25_60 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 60 * 256 + i.val))
      kernelWitness25Row60[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_60

theorem kernelBlock_25_61 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 61 * 256 + i.val))
      kernelWitness25Row61[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_61

theorem kernelBlock_25_62 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 62 * 256 + i.val))
      kernelWitness25Row62[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_62

theorem kernelBlock_25_63 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (25 * 32768 + 63 * 256 + i.val))
      kernelWitness25Row63[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_25_63

end TightCycleC5.Bridge.Cover
