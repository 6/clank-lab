-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk124 :
    ∀ i : Fin (min 128 (40547 - 128 * 124)),
      targetCountsMatch (classAt (targetKernelClass ⟨124, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk124

theorem target_counts_kernel_chunk125 :
    ∀ i : Fin (min 128 (40547 - 128 * 125)),
      targetCountsMatch (classAt (targetKernelClass ⟨125, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk125

theorem target_counts_kernel_chunk126 :
    ∀ i : Fin (min 128 (40547 - 128 * 126)),
      targetCountsMatch (classAt (targetKernelClass ⟨126, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk126

theorem target_counts_kernel_chunk127 :
    ∀ i : Fin (min 128 (40547 - 128 * 127)),
      targetCountsMatch (classAt (targetKernelClass ⟨127, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk127


end TightCycleC5.Bridge.P33Arithmetic
