import P33ArithmeticRelabel
import P33ArithmeticCoverKernel

/-! Match the entire arithmetic class index with the accepted genuine
coloured cover. No class representative or colour ordering is assumed. -/
namespace TightCycleC5.Bridge.P33Arithmetic
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem all_class_bits_match : ∀ k : Fin 40547,
    BitVec.ofNat 20 (classAt k).mask = ColoredCover.classMask k ∧
    BitVec.ofNat 6 (classAt k).colours = ColoredCover.classColor k := by
  exact all_class_bits_kernel_match

theorem decodedClass_eq_classRep (k : Fin 40547) :
    decodedClass (classAt k) = ColoredCover.classRep k := by
  simp only [decodedClass, ColoredCover.classRep,
    (all_class_bits_match k).1, (all_class_bits_match k).2]

#print axioms all_class_bits_match
#print axioms decodedClass_eq_classRep
end TightCycleC5.Bridge.P33Arithmetic
