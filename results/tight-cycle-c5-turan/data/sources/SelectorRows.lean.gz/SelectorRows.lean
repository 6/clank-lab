import SelectorMarginal
import ComplementEmbedding
import TargetNormalization
import TripleProducts
import OutsideSums

/-! P32 selector quantities (PROOF Lemma 7) and the full selector bound
(PROOF Lemma 8), with exact injection and edge-set normalizations. -/
namespace TightCycleC5.Bridge
open Finset
variable {n : ℕ}

noncomputable def selectorTriple (H : Finset (Finset (Fin n))) (π : Fin n → ℝ)
    (σ : Fin 3 ↪ Fin n) : ℝ :=
  if embeddingSet σ ∈ H then exactlyTwoProbability π (embeddingSet σ) else 0

/-- The six orders of an edge and the exclusion of root vertices are
proved by the generic complement and unordered-set identities. -/
theorem selector_free_sum (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (root : Fin 3 ↪ Fin n) (π : Fin n → ℝ) :
    (∑ free : Fin 3 ↪ Outside root,
      selectorTriple H π (free.trans ⟨Subtype.val, Subtype.val_injective⟩)) =
      6 * ∑ e ∈ H.filter (fun e => Disjoint e (rootSet root)), exactlyTwoProbability π e := by
  unfold selectorTriple
  rw [free_triple_set_sum root
    (fun e : Finset (Fin n) => if e ∈ H then exactlyTwoProbability π e else 0)]
  have hp : ∀ e : Finset (Fin n),
      (if Disjoint e (rootSet root) then (if e ∈ H then exactlyTwoProbability π e else 0) else 0) =
      if e ∈ H then (if Disjoint e (rootSet root) then exactlyTwoProbability π e else 0) else 0 := by
    intro e
    split_ifs <;> rfl
  simp_rw [hp]
  rw [← sum_filter, filter_all_triples H hH, sum_filter]

theorem selector_free_mean (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (root : Fin 3 ↪ Fin n) (π : Fin n → ℝ) :
    uniformMean (fun free : Fin 3 ↪ Outside root =>
      selectorTriple H π (free.trans ⟨Subtype.val, Subtype.val_injective⟩)) =
      (6 * ∑ e ∈ H.filter (fun e => Disjoint e (rootSet root)), exactlyTwoProbability π e) /
        ((n - 3).descFactorial 3 : ℝ) := by
  rw [uniformMean, selector_free_sum H hH root π,
    Fintype.card_embedding_eq, outside_card, Fintype.card_fin, Fintype.card_fin]

theorem selector_free_mean_le (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (root : Fin 3 ↪ Fin n) (π : Fin n → ℝ)
    (hπ0 : ∀ v, 0 ≤ π v) (hπ1 : ∀ v, π v ≤ 1) :
    uniformMean (fun free : Fin 3 ↪ Outside root =>
      selectorTriple H π (free.trans ⟨Subtype.val, Subtype.val_injective⟩)) ≤
      6 * (maxCut H : ℝ) / ((n - 3).descFactorial 3 : ℝ) := by
  rw [selector_free_mean H hH root π]
  exact div_le_div_of_nonneg_right
    (mul_le_mul_of_nonneg_left (selector_probability_le_maxCut H hH (rootSet root) π hπ0 hπ1)
      (by norm_num : (0 : ℝ) ≤ 6)) (Nat.cast_nonneg _)

noncomputable def selectorSixRow (H : Finset (Finset (Fin n)))
    (g : (Fin 3 ↪ Fin n) → ℝ) (π : (Fin 3 ↪ Fin n) → Fin n → ℝ)
    (σ : Fin 6 ↪ Fin n) : ℝ :=
  let rf := splitSampleEquiv (r := 3) (f := 3) σ
  g rf.1 * selectorTriple H (π rf.1) (rf.2.trans ⟨Subtype.val, Subtype.val_injective⟩)

noncomputable def selectorN (H : Finset (Finset (Fin n)))
    (g : (Fin 3 ↪ Fin n) → ℝ) (π : (Fin 3 ↪ Fin n) → Fin n → ℝ) : ℝ :=
  uniformMean (selectorSixRow H g π)

noncomputable def selectorD (g : (Fin 3 ↪ Fin n) → ℝ) : ℝ := uniformMean g

/-- The numerator row on the actual six-injection uses x,u,v as roots
and a,b,d as the free triple, with no choice of another denominator. -/
theorem selectorSixRow_join (H : Finset (Finset (Fin n)))
    (g : (Fin 3 ↪ Fin n) → ℝ) (π : (Fin 3 ↪ Fin n) → Fin n → ℝ)
    (root : Fin 3 ↪ Fin n) (free : Fin 3 ↪ Outside root) :
    selectorSixRow H g π (joinSample root free) =
      g root * selectorTriple H (π root) (free.trans ⟨Subtype.val, Subtype.val_injective⟩) := by
  change (fun rf : Σ root : Fin 3 ↪ Fin n, Fin 3 ↪ Outside root =>
    g rf.1 * selectorTriple H (π rf.1) (rf.2.trans ⟨Subtype.val, Subtype.val_injective⟩))
      (splitSampleEquiv (joinSample root free)) = _
  rw [splitSampleEquiv_join]

/-- The denominator is the actual root-type probability as in Lemma 7. -/
theorem selectorD_six_mean (g : (Fin 3 ↪ Fin n) → ℝ) (hn : 6 ≤ n) :
    uniformMean (fun σ : Fin 6 ↪ Fin n => g ((Fin.castAddEmb 3).trans σ)) = selectorD g :=
  uniformMean_first_three hn g

theorem selectorN_root_mean (H : Finset (Finset (Fin n)))
    (g : (Fin 3 ↪ Fin n) → ℝ) (π : (Fin 3 ↪ Fin n) → Fin n → ℝ) :
    selectorN H g π = uniformMean (fun root : Fin 3 ↪ Fin n =>
      g root * uniformMean (fun free : Fin 3 ↪ Outside root =>
        selectorTriple H (π root) (free.trans ⟨Subtype.val, Subtype.val_injective⟩))) := by
  unfold selectorN
  rw [uniformMean_joinSample (r := 3) (f := 3)]
  simp_rw [selectorSixRow_join, uniformMean_const_mul]

theorem uniformMean_mono {A : Type*} [Fintype A] (f h : A → ℝ) (hle : ∀ a, f a ≤ h a) :
    uniformMean f ≤ uniformMean h :=
  div_le_div_of_nonneg_right (sum_le_sum fun a _ => hle a) (Nat.cast_nonneg _)

/-- Full Lemma 8 at the exact finite falling-factorial denominator. -/
theorem selectorN_le_falling (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (g : (Fin 3 ↪ Fin n) → ℝ) (hg : ∀ root, g root = 0 ∨ g root = 1)
    (π : (Fin 3 ↪ Fin n) → Fin n → ℝ)
    (hπ0 : ∀ root v, 0 ≤ π root v) (hπ1 : ∀ root v, π root v ≤ 1) :
    selectorN H g π ≤ 6 * selectorD g * (maxCut H : ℝ) / ((n - 3).descFactorial 3 : ℝ) := by
  rw [selectorN_root_mean]
  have hgn : ∀ root, 0 ≤ g root := by
    intro root
    rcases hg root with h | h <;> norm_num [h]
  calc
    _ ≤ uniformMean (fun root : Fin 3 ↪ Fin n =>
        g root * (6 * (maxCut H : ℝ) / ((n - 3).descFactorial 3 : ℝ))) :=
      uniformMean_mono _ _ (fun root => mul_le_mul_of_nonneg_left
        (selector_free_mean_le H hH root (π root) (hπ0 root) (hπ1 root)) (hgn root))
    _ = _ := by
      simp only [uniformMean, selectorD, ← Finset.sum_mul]
      ring

/-- Full Lemma 8 in the real polynomial notation of the frozen proof. -/
theorem selectorN_le (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H) (hn : 12 ≤ n)
    (g : (Fin 3 ↪ Fin n) → ℝ) (hg : ∀ root, g root = 0 ∨ g root = 1)
    (π : (Fin 3 ↪ Fin n) → Fin n → ℝ)
    (hπ0 : ∀ root v, 0 ≤ π root v) (hπ1 : ∀ root v, π root v ≤ 1) :
    selectorN H g π ≤ 6 * selectorD g * (maxCut H : ℝ) /
      (((n : ℝ) - 3) * ((n : ℝ) - 4) * ((n : ℝ) - 5)) := by
  have h := selectorN_le_falling H hH g hg π hπ0 hπ1
  have hc : ((n - 3).descFactorial 3 : ℝ) =
      ((n : ℝ) - 3) * ((n : ℝ) - 4) * ((n : ℝ) - 5) := by
    rw [descFactorial_three_cast (by omega : 3 ≤ n - 3), Nat.cast_sub (by omega : 3 ≤ n)]
    norm_num
    ring
  rwa [hc] at h

#print axioms selector_free_sum
#print axioms selector_free_mean
#print axioms selector_free_mean_le
#print axioms selectorSixRow_join
#print axioms selectorD_six_mean
#print axioms selectorN_root_mean
#print axioms uniformMean_mono
#print axioms selectorN_le_falling
#print axioms selectorN_le
end TightCycleC5.Bridge
