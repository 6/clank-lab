import KernelShard23Blocks0
import KernelShard23Blocks1
import KernelShard23Blocks2
import KernelShard23Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard23 : kernelShardCheck 23 kernelWitness23 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (23 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness23 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_23_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard23
end TightCycleC5.Bridge.Cover
