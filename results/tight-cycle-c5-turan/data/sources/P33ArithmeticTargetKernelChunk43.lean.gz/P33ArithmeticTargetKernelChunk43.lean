-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk172 :
    ∀ i : Fin (min 128 (40547 - 128 * 172)),
      targetCountsMatch (classAt (targetKernelClass ⟨172, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk172

theorem target_counts_kernel_chunk173 :
    ∀ i : Fin (min 128 (40547 - 128 * 173)),
      targetCountsMatch (classAt (targetKernelClass ⟨173, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk173

theorem target_counts_kernel_chunk174 :
    ∀ i : Fin (min 128 (40547 - 128 * 174)),
      targetCountsMatch (classAt (targetKernelClass ⟨174, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk174

theorem target_counts_kernel_chunk175 :
    ∀ i : Fin (min 128 (40547 - 128 * 175)),
      targetCountsMatch (classAt (targetKernelClass ⟨175, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk175


end TightCycleC5.Bridge.P33Arithmetic
