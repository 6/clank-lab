import KernelRowIndex
import KernelWitness1

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_1_96 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 96 * 256 + i.val))
      kernelWitness1Row96[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_96

theorem kernelBlock_1_97 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 97 * 256 + i.val))
      kernelWitness1Row97[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_97

theorem kernelBlock_1_98 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 98 * 256 + i.val))
      kernelWitness1Row98[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_98

theorem kernelBlock_1_99 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 99 * 256 + i.val))
      kernelWitness1Row99[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_99

theorem kernelBlock_1_100 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 100 * 256 + i.val))
      kernelWitness1Row100[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_100

theorem kernelBlock_1_101 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 101 * 256 + i.val))
      kernelWitness1Row101[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_101

theorem kernelBlock_1_102 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 102 * 256 + i.val))
      kernelWitness1Row102[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_102

theorem kernelBlock_1_103 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 103 * 256 + i.val))
      kernelWitness1Row103[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_103

theorem kernelBlock_1_104 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 104 * 256 + i.val))
      kernelWitness1Row104[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_104

theorem kernelBlock_1_105 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 105 * 256 + i.val))
      kernelWitness1Row105[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_105

theorem kernelBlock_1_106 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 106 * 256 + i.val))
      kernelWitness1Row106[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_106

theorem kernelBlock_1_107 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 107 * 256 + i.val))
      kernelWitness1Row107[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_107

theorem kernelBlock_1_108 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 108 * 256 + i.val))
      kernelWitness1Row108[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_108

theorem kernelBlock_1_109 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 109 * 256 + i.val))
      kernelWitness1Row109[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_109

theorem kernelBlock_1_110 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 110 * 256 + i.val))
      kernelWitness1Row110[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_110

theorem kernelBlock_1_111 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 111 * 256 + i.val))
      kernelWitness1Row111[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_111

theorem kernelBlock_1_112 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 112 * 256 + i.val))
      kernelWitness1Row112[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_112

theorem kernelBlock_1_113 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 113 * 256 + i.val))
      kernelWitness1Row113[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_113

theorem kernelBlock_1_114 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 114 * 256 + i.val))
      kernelWitness1Row114[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_114

theorem kernelBlock_1_115 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 115 * 256 + i.val))
      kernelWitness1Row115[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_115

theorem kernelBlock_1_116 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 116 * 256 + i.val))
      kernelWitness1Row116[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_116

theorem kernelBlock_1_117 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 117 * 256 + i.val))
      kernelWitness1Row117[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_117

theorem kernelBlock_1_118 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 118 * 256 + i.val))
      kernelWitness1Row118[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_118

theorem kernelBlock_1_119 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 119 * 256 + i.val))
      kernelWitness1Row119[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_119

theorem kernelBlock_1_120 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 120 * 256 + i.val))
      kernelWitness1Row120[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_120

theorem kernelBlock_1_121 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 121 * 256 + i.val))
      kernelWitness1Row121[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_121

theorem kernelBlock_1_122 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 122 * 256 + i.val))
      kernelWitness1Row122[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_122

theorem kernelBlock_1_123 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 123 * 256 + i.val))
      kernelWitness1Row123[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_123

theorem kernelBlock_1_124 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 124 * 256 + i.val))
      kernelWitness1Row124[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_124

theorem kernelBlock_1_125 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 125 * 256 + i.val))
      kernelWitness1Row125[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_125

theorem kernelBlock_1_126 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 126 * 256 + i.val))
      kernelWitness1Row126[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_126

theorem kernelBlock_1_127 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 127 * 256 + i.val))
      kernelWitness1Row127[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_127

end TightCycleC5.Bridge.Cover
