import ConditionalMean

/-! PROOF §3 Lemma 4: exact independent/disjoint ordered-triple comparison. -/
namespace TightCycleC5.Bridge
open Finset

abbrev Triple (n : ℕ) := Fin 3 ↪ Fin n

def CrossApart {n : ℕ} (a b : Triple n) : Prop := ∀ i j, a i ≠ b j

instance {n : ℕ} (a b : Triple n) : Decidable (CrossApart a b) := by
  unfold CrossApart
  infer_instance

noncomputable def disjointTriplePairs (n : ℕ) : Finset (Triple n × Triple n) :=
  open Classical in univ.filter (fun p => CrossApart p.1 p.2)

/-- A root triple together with a free triple is precisely a pair of
ordered triples with disjoint vertex ranges. -/
noncomputable def rootFreeTriplePairEquiv {n : ℕ} :
    (Σ root : Triple n, Fin 3 ↪ Outside root) ≃ disjointTriplePairs n := by
  classical
  exact {
    toFun := fun rf => ⟨(rf.1, rf.2.trans ⟨Subtype.val, Subtype.val_injective⟩), by
      simp only [disjointTriplePairs, mem_filter, mem_univ, true_and, CrossApart]
      intro i j h
      exact (rf.2 j).property ⟨i, h⟩⟩
    invFun := fun p => ⟨p.val.1, ⟨fun j => ⟨p.val.2 j, by
      rintro ⟨i, hi⟩
      exact (mem_filter.mp p.property).2 i j hi⟩,
      fun i j h => p.val.2.injective (congrArg Subtype.val h)⟩⟩
    left_inv := fun _ => rfl
    right_inv := fun _ => rfl }

noncomputable def sixDisjointTripleEquiv {n : ℕ} :
    (Fin 6 ↪ Fin n) ≃ disjointTriplePairs n :=
  (splitSampleEquiv (r := 3) (f := 3)).trans rootFreeTriplePairEquiv

theorem disjointTriplePairs_card (n : ℕ) :
    (disjointTriplePairs n).card = n.descFactorial 3 * (n - 3).descFactorial 3 := by
  classical
  have h := Fintype.card_congr (rootFreeTriplePairEquiv (n := n))
  simp only [Fintype.card_sigma, Fintype.card_coe, Fintype.card_embedding_eq,
    outside_card, Fintype.card_fin, sum_const, card_univ, nsmul_eq_mul] at h
  exact h.symm

/-- The two triples named by a six-injection, in the frozen label order. -/
noncomputable def sixTripleProduct {n : ℕ} (g h : Triple n → ℝ)
    (σ : Fin 6 ↪ Fin n) : ℝ :=
  let p := sixDisjointTripleEquiv σ
  g p.val.1 * h p.val.2

theorem sixTripleProduct_join {n : ℕ} (g h : Triple n → ℝ) (root : Triple n)
    (free : Fin 3 ↪ Outside root) :
    sixTripleProduct g h (joinSample root free) =
      g root * h (free.trans ⟨Subtype.val, Subtype.val_injective⟩) := by
  change (fun rf : Σ root : Triple n, Fin 3 ↪ Outside root =>
    g (rootFreeTriplePairEquiv rf).val.1 * h (rootFreeTriplePairEquiv rf).val.2)
      (splitSampleEquiv (joinSample root free)) = _
  rw [splitSampleEquiv_join]
  rfl

theorem descFactorial_three_cast {n : ℕ} (hn : 3 ≤ n) :
    (n.descFactorial 3 : ℝ) = (n : ℝ) * ((n : ℝ) - 1) * ((n : ℝ) - 2) := by
  rw [Nat.descFactorial_succ, Nat.descFactorial_succ, Nat.descFactorial_succ]
  simp only [Nat.descFactorial_zero, Nat.sub_zero, mul_one, Nat.cast_mul,
    Nat.cast_sub (by omega : 2 ≤ n), Nat.cast_sub (by omega : 1 ≤ n)]
  norm_num
  ring

/-- Full finite Lemma 4. Both triple functions are bounded in absolute
value; the error is the signed contribution of all intersecting triples. -/
theorem disjoint_triple_product {n : ℕ} (hn : 12 ≤ n)
    (g h : Triple n → ℝ) (hg : ∀ t, |g t| ≤ 1) (hh : ∀ t, |h t| ≤ 1) :
    ∃ ε : ℝ,
      uniformMean (sixTripleProduct g h) =
        ((n : ℝ) * ((n : ℝ) - 1) * ((n : ℝ) - 2) /
          (((n : ℝ) - 3) * ((n : ℝ) - 4) * ((n : ℝ) - 5))) *
          uniformMean g * uniformMean h - ε ∧
      |ε| ≤ (9 * (n : ℝ) ^ 2 - 45 * (n : ℝ) + 60) /
        (((n : ℝ) - 3) * ((n : ℝ) - 4) * ((n : ℝ) - 5)) := by
  classical
  letI : Nonempty (Triple n) := ⟨Fin.castLEEmb (by omega : 3 ≤ n)⟩
  have hf : ∀ p : Triple n × Triple n, |g p.1 * h p.2| ≤ 1 := by
    intro p
    rw [abs_mul]
    simpa using mul_le_mul (hg p.1) (hh p.2) (abs_nonneg (h p.2)) (by norm_num : (0 : ℝ) ≤ 1)
  obtain ⟨ε, he, hε⟩ := restricted_mean_decomposition (disjointTriplePairs n)
    (fun p : Triple n × Triple n => g p.1 * h p.2) hf
  have heq : uniformMean (sixTripleProduct g h) =
      uniformMean (fun p : disjointTriplePairs n => g p.val.1 * h p.val.2) :=
    uniformMean_equiv_between (sixDisjointTripleEquiv (n := n))
      (fun p : disjointTriplePairs n => g p.val.1 * h p.val.2)
  rw [← heq, uniformMean_product g h] at he
  let A : ℝ := n.descFactorial 3
  let B : ℝ := (n - 3).descFactorial 3
  have hA : A = (n : ℝ) * ((n : ℝ) - 1) * ((n : ℝ) - 2) :=
    descFactorial_three_cast (by omega)
  have hB : B = ((n : ℝ) - 3) * ((n : ℝ) - 4) * ((n : ℝ) - 5) := by
    change ((n - 3).descFactorial 3 : ℝ) = _
    rw [descFactorial_three_cast (by omega : 3 ≤ n - 3),
      Nat.cast_sub (by omega : 3 ≤ n)]
    norm_num
    ring
  have hnR : (12 : ℝ) ≤ n := by exact_mod_cast hn
  have hAp : 0 < A := by
    rw [hA]
    exact mul_pos (mul_pos (by linarith) (by linarith)) (by linarith)
  have hBp : 0 < B := by
    rw [hB]
    exact mul_pos (mul_pos (by linarith) (by linarith)) (by linarith)
  have hspace : (Fintype.card (Triple n × Triple n) : ℝ) = A * A := by
    simp only [Fintype.card_prod, Nat.cast_mul, Triple, Fintype.card_embedding_eq,
      Fintype.card_fin, A]
  have hgood : ((disjointTriplePairs n).card : ℝ) = A * B := by
    rw [disjointTriplePairs_card, Nat.cast_mul]
  have hbad : (((disjointTriplePairs n)ᶜ).card : ℝ) = A * A - A * B := by
    rw [Finset.card_compl, Nat.cast_sub (Finset.card_le_univ _), hspace, hgood]
  rw [hspace, hgood] at he
  rw [hbad, hgood] at hε
  have hratio : A * A / (A * B) = A / B := by
    field_simp
  have herror : (A * A - A * B) / (A * B) =
      (9 * (n : ℝ) ^ 2 - 45 * (n : ℝ) + 60) /
        (((n : ℝ) - 3) * ((n : ℝ) - 4) * ((n : ℝ) - 5)) := by
    calc
      _ = (A - B) / B := by field_simp
      _ = _ := by rw [hA, hB]; congr 1; ring
  refine ⟨ε, ?_, ?_⟩
  · rw [hratio, hA, hB] at he
    simpa only [mul_assoc] using he
  · rwa [herror] at hε

#print axioms descFactorial_three_cast
#print axioms disjoint_triple_product
#print axioms disjointTriplePairs_card
#print axioms sixTripleProduct_join
end TightCycleC5.Bridge
