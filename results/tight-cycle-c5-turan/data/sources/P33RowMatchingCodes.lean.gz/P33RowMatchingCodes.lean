import P33RowMatchingCore

namespace TightCycleC5.Bridge.P33RowMatching
open Finset
set_option maxHeartbeats 2000000

/-- The list canonicalizer really permutes only its two free labels. -/
theorem canonical_two (m c x u b d : Nat) :
    P33Arithmetic.canonical m c [x,u] [b,d] =
      min (P33Arithmetic.encoded m c [x,u,b,d])
        (P33Arithmetic.encoded m c [x,u,d,b]) := by
  have hp : ([b,d] : List Nat).permutations = [[b,d],[d,b]] := by
    simp [List.permutations, List.permutationsAux_cons, List.permutationsAux_nil, List.permutationsAux2]
  rw [P33Arithmetic.canonical, hp]
  simp

/-- Exact six free-label orders; no roots are exchanged. -/
theorem canonical_three (m c x a b d : Nat) :
    P33Arithmetic.canonical m c [x] [a,b,d] =
      min (P33Arithmetic.encoded m c [x,a,b,d])
        (min (P33Arithmetic.encoded m c [x,a,d,b])
          (min (P33Arithmetic.encoded m c [x,b,a,d])
            (min (P33Arithmetic.encoded m c [x,b,d,a])
              (min (P33Arithmetic.encoded m c [x,d,a,b])
                (P33Arithmetic.encoded m c [x,d,b,a]))))) := by
  have hp : ([a,b,d] : List Nat).permutations =
      [[a,b,d],[b,a,d],[d,b,a],[b,d,a],[d,a,b],[a,d,b]] := by
    simp [List.permutations, List.permutationsAux_cons, List.permutationsAux_nil, List.permutationsAux2]
  rw [P33Arithmetic.canonical, hp]
  simp
  <;> ac_rfl

theorem encoded_raw4 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (a b c d : Fin 6) (hab : a ≠ b) (hac : a ≠ c) (had : a ≠ d)
    (hbc : b ≠ c) (hbd : b ≠ d) (hcd : c ≠ d) :
    P33Arithmetic.encoded K.mask K.colours [(p a).val,(p b).val,(p c).val,(p d).val] =
      P33Rows.raw4 (fun x u v => (structureAt K p).edge {x,u,v})
        (structureAt K p).color a b c d := by
  rw [encoded_four]
  rw [edge_at K p a b c hab hac hbc, edge_at K p a b d hab had hbd,
    edge_at K p a c d hac had hcd, edge_at K p b c d hbc hbd hcd]
  simp only [colour_at]
  unfold P33Rows.raw4
  dsimp only
  omega

theorem canonical_local (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) :
    P33Arithmetic.canonical K.mask K.colours [(p 0).val] [(p 3).val,(p 4).val,(p 5).val] =
      P33Rows.canonicalLocal (fun x u v => (structureAt K p).edge {x,u,v})
        (structureAt K p).color 0 3 4 5 := by
  rw [canonical_three]
  unfold P33Rows.canonicalLocal
  rw [encoded_raw4 K p 0 3 4 5 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
    encoded_raw4 K p 0 3 5 4 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
    encoded_raw4 K p 0 4 3 5 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
    encoded_raw4 K p 0 4 5 3 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
    encoded_raw4 K p 0 5 3 4 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
    encoded_raw4 K p 0 5 4 3 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]

theorem canonical_regular (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) :
    P33Arithmetic.canonical K.mask K.colours [(p 0).val,(p 1).val] [(p 4).val,(p 5).val] =
      P33Rows.canonicalRegular (fun x u v => (structureAt K p).edge {x,u,v})
        (structureAt K p).color 0 1 4 5 := by
  rw [canonical_two]
  exact congrArg₂ min
    (encoded_raw4 K p 0 1 4 5 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide))
    (encoded_raw4 K p 0 1 5 4 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide))

#print axioms canonical_two
#print axioms canonical_three
#print axioms encoded_raw4
#print axioms canonical_local
#print axioms canonical_regular
end TightCycleC5.Bridge.P33RowMatching
