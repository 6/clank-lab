import KernelRowIndex
import KernelWitness0

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_0_32 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 32 * 256 + i.val))
      kernelWitness0Row32[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_32

theorem kernelBlock_0_33 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 33 * 256 + i.val))
      kernelWitness0Row33[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_33

theorem kernelBlock_0_34 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 34 * 256 + i.val))
      kernelWitness0Row34[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_34

theorem kernelBlock_0_35 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 35 * 256 + i.val))
      kernelWitness0Row35[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_35

theorem kernelBlock_0_36 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 36 * 256 + i.val))
      kernelWitness0Row36[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_36

theorem kernelBlock_0_37 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 37 * 256 + i.val))
      kernelWitness0Row37[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_37

theorem kernelBlock_0_38 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 38 * 256 + i.val))
      kernelWitness0Row38[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_38

theorem kernelBlock_0_39 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 39 * 256 + i.val))
      kernelWitness0Row39[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_39

theorem kernelBlock_0_40 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 40 * 256 + i.val))
      kernelWitness0Row40[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_40

theorem kernelBlock_0_41 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 41 * 256 + i.val))
      kernelWitness0Row41[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_41

theorem kernelBlock_0_42 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 42 * 256 + i.val))
      kernelWitness0Row42[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_42

theorem kernelBlock_0_43 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 43 * 256 + i.val))
      kernelWitness0Row43[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_43

theorem kernelBlock_0_44 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 44 * 256 + i.val))
      kernelWitness0Row44[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_44

theorem kernelBlock_0_45 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 45 * 256 + i.val))
      kernelWitness0Row45[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_45

theorem kernelBlock_0_46 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 46 * 256 + i.val))
      kernelWitness0Row46[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_46

theorem kernelBlock_0_47 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 47 * 256 + i.val))
      kernelWitness0Row47[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_47

theorem kernelBlock_0_48 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 48 * 256 + i.val))
      kernelWitness0Row48[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_48

theorem kernelBlock_0_49 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 49 * 256 + i.val))
      kernelWitness0Row49[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_49

theorem kernelBlock_0_50 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 50 * 256 + i.val))
      kernelWitness0Row50[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_50

theorem kernelBlock_0_51 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 51 * 256 + i.val))
      kernelWitness0Row51[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_51

theorem kernelBlock_0_52 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 52 * 256 + i.val))
      kernelWitness0Row52[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_52

theorem kernelBlock_0_53 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 53 * 256 + i.val))
      kernelWitness0Row53[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_53

theorem kernelBlock_0_54 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 54 * 256 + i.val))
      kernelWitness0Row54[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_54

theorem kernelBlock_0_55 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 55 * 256 + i.val))
      kernelWitness0Row55[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_55

theorem kernelBlock_0_56 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 56 * 256 + i.val))
      kernelWitness0Row56[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_56

theorem kernelBlock_0_57 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 57 * 256 + i.val))
      kernelWitness0Row57[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_57

theorem kernelBlock_0_58 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 58 * 256 + i.val))
      kernelWitness0Row58[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_58

theorem kernelBlock_0_59 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 59 * 256 + i.val))
      kernelWitness0Row59[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_59

theorem kernelBlock_0_60 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 60 * 256 + i.val))
      kernelWitness0Row60[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_60

theorem kernelBlock_0_61 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 61 * 256 + i.val))
      kernelWitness0Row61[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_61

theorem kernelBlock_0_62 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 62 * 256 + i.val))
      kernelWitness0Row62[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_62

theorem kernelBlock_0_63 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 63 * 256 + i.val))
      kernelWitness0Row63[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_63

end TightCycleC5.Bridge.Cover
