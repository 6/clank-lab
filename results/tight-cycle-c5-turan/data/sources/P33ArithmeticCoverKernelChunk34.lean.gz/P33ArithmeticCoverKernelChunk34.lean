-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticCoverKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem class_alignment_kernel_chunk34 :
    ∀ i : Fin (min 512 (40547 - 512 * 34)),
      classBitsAligned (coverKernelClass ⟨34, by decide⟩ i) := by
  decide +kernel
#print axioms class_alignment_kernel_chunk34

end TightCycleC5.Bridge.P33Arithmetic
