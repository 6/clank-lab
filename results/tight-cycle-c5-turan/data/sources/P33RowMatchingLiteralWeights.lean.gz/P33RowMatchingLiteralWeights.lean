import P33ArithmeticData
import CertificateDescriptorsData

namespace TightCycleC5.Bridge.P33RowMatching
set_option maxRecDepth 100000
set_option maxHeartbeats 0

/-- List flattening is linear structural reduction, avoiding array push loops. -/
theorem dense_source_lists : P33Arithmetic.denseInequalities.toList =
    (CertificateDescriptors.p33aYBlocks.toList.map Array.toList).flatten := by rfl

theorem dense_source_array : P33Arithmetic.denseInequalities = CertificateDescriptors.p33aYData := by
  apply Array.toList_inj.mp
  exact dense_source_lists.trans Array.toList_flatten.symm

#print axioms dense_source_lists
#print axioms dense_source_array
end TightCycleC5.Bridge.P33RowMatching
