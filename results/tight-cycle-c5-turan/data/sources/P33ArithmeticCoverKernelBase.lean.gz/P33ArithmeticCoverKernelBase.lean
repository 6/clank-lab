import P33ArithmeticData
import ColoredCoverSemantics

/-! Kernel class-list comparison, split into bounded finite chunks. -/
namespace TightCycleC5.Bridge.P33Arithmetic
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def classBitsMatch (K : Class) (k : Fin 40547) : Prop :=
  BitVec.ofNat 20 K.mask = ColoredCover.classMask k ∧
  BitVec.ofNat 6 K.colours = ColoredCover.classColor k

def classBitsAligned (k : Fin 40547) : Prop := classBitsMatch (classAt k) k

instance (K : Class) (k : Fin 40547) : Decidable (classBitsMatch K k) := by
  unfold classBitsMatch
  infer_instance

instance (k : Fin 40547) : Decidable (classBitsAligned k) :=
  inferInstanceAs (Decidable (classBitsMatch (classAt k) k))

def coverKernelClass (b : Fin 80) (i : Fin (min 512 (40547 - 512 * b.val))) :
    Fin 40547 := ⟨512 * b.val + i.val, by have hi := i.isLt; omega⟩

theorem coverKernelClass_val (b : Fin 80) (i : Fin (min 512 (40547 - 512 * b.val))) :
    (coverKernelClass b i).val = 512 * b.val + i.val := rfl

theorem class_mask_corruption_rejected : ¬ classBitsMatch ⟨1, 0, 0⟩ ⟨0, by decide⟩ := by
  decide +kernel

theorem class_colour_corruption_rejected : ¬ classBitsMatch ⟨0, 1, 0⟩ ⟨0, by decide⟩ := by
  decide +kernel

#print axioms coverKernelClass_val
#print axioms class_mask_corruption_rejected
#print axioms class_colour_corruption_rejected
end TightCycleC5.Bridge.P33Arithmetic
