import P33PSDMatchingRowsBase
import P33PSDMatchingEntries4
import P33FlagRows4
namespace TightCycleC5.Bridge.P33PSDMatching

theorem source_row4 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block4 K p) :
    (sourceContribution P33Arithmetic.block4 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row4 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block4 rfl P33PSD.q4 P33PSD.scale source_entry4
    P33Flag.basis4 P33Flag.basis4_injective rfl (fun _ => rfl) P33Flag.type4 rfl K p hv
#print axioms source_row4

theorem source_row10 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block10 K p) :
    (sourceContribution P33Arithmetic.block10 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row10 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block10 rfl P33PSD.q10 P33PSD.scale source_entry10
    P33Flag.basis10 P33Flag.basis10_injective rfl (fun _ => rfl) P33Flag.type10 rfl K p hv
#print axioms source_row10

theorem source_row16 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block16 K p) :
    (sourceContribution P33Arithmetic.block16 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row16 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block16 rfl P33PSD.q16 P33PSD.scale source_entry16
    P33Flag.basis16 P33Flag.basis16_injective rfl (fun _ => rfl) P33Flag.type16 rfl K p hv
#print axioms source_row16

theorem source_row22 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block22 K p) :
    (sourceContribution P33Arithmetic.block22 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row22 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block22 rfl P33PSD.q22 P33PSD.scale source_entry22
    P33Flag.basis22 P33Flag.basis22_injective rfl (fun _ => rfl) P33Flag.type22 rfl K p hv
#print axioms source_row22

theorem source_row28 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block28 K p) :
    (sourceContribution P33Arithmetic.block28 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row28 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block28 rfl P33PSD.q28 P33PSD.scale source_entry28
    P33Flag.basis28 P33Flag.basis28_injective rfl (fun _ => rfl) P33Flag.type28 rfl K p hv
#print axioms source_row28

theorem source_row34 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block34 K p) :
    (sourceContribution P33Arithmetic.block34 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row34 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block34 rfl P33PSD.q34 P33PSD.scale source_entry34
    P33Flag.basis34 P33Flag.basis34_injective rfl (fun _ => rfl) P33Flag.type34 rfl K p hv
#print axioms source_row34

end TightCycleC5.Bridge.P33PSDMatching
