import P33RowMatchingLocal
import P33RowMatchingGlobal
import P33RowMatchingRegular
import P33RowMatchingCL
import P33RowMatchingAggregate

namespace TightCycleC5.Bridge.P33RowMatching

theorem inequality_row_match (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hl : localQueryValid K p) (hg : globalQueryValid K p) (i : Fin 12847) :
    (P33Arithmetic.inequalityRow (P33Arithmetic.featuresAt P33Arithmetic.localFlags
      P33Arithmetic.globalFlags P33Arithmetic.blocks K p) i.val : ℝ) / 1000000000 =
      actualInequalityRow (structureAt K p) i := by
  by_cases h80 : i.val < 80
  · simpa only [actualInequalityRow,dif_pos h80] using local_row_match K p ⟨i.val,h80⟩ hl
  · by_cases h88 : i.val < 88
    · have he : 80+(i.val-80)=i.val := by omega
      simpa only [he,actualInequalityRow,dif_neg h80,dif_pos h88] using
        cut_row_match K p ⟨i.val-80,by omega⟩ hg
    · by_cases h97 : i.val < 97
      · have he : 88+(i.val-88)=i.val := by omega
        simpa only [he,actualInequalityRow,dif_neg h80,dif_neg h88,dif_pos h97] using
          density_row_match K p ⟨i.val-88,by omega⟩ hg
      · have he : 97+(i.val-97)=i.val := by omega
        simpa only [he,actualInequalityRow,dif_neg h80,dif_neg h88,dif_neg h97] using
          cl_row_match K p ⟨i.val-97,by omega⟩

#print axioms inequality_row_match
end TightCycleC5.Bridge.P33RowMatching
