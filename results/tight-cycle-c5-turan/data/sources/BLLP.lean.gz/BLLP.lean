import Endpoint
import Lemmas

/-!
# The endpoint from BLLP's two flag-algebra statements

Bodnár–León–Liu–Pikhurko (arXiv 2506.03223, Lemma 4.1 and Theorem 2.4)
derive the density bound from two flag-algebra statements, Propositions 3.2
and 3.3. Here both are hypotheses (`P32Statement`, `P33Statement`), and the
combinatorial argument from them to the endpoint is checked.

* Cloning (`clone_c5free`): replacing the link of `u` by a copy of the link
  of `v` keeps a 3-graph `C₅³`-free, because the map `u ↦ v` sends the new
  graph into the old one and a tight 5-cycle's image is injective (L1).
  Hence in an extremal graph `deg v ≤ deg u + n` (`deg_le_of_extremal`).
* A cut `S` maximising `cutCount` is locally maximal, and
  `e(H) ≤ C(|S|,2)·|Sᶜ| + (bad − miss) + ex |Sᶜ|` (`card_le_cut_identity`).
* `core_bound`: P32 gives cut density `≥ 2/5 − δ`, hence `|S| ≥ n/6`; P33
  gives `bad − miss ≤ ξ n³`; so `ex n ≤ |S|²|Sᶜ|/2 + ex |Sᶜ| + ξ n³`.
* `limsup_le`: with `scalar_step`, the limsup of `ex n / C(n,3)` is at most
  `2√3 − 3`; with `ex_ge`, `mubayi_rodl_of_bllp`.
-/

namespace TightCycleC5

open Finset Filter Topology

section Defs

variable {n : ℕ}

/-- Edges meeting `S` in exactly two vertices. -/
def cutCount (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) : ℕ :=
  (H.filter (fun e => (e ∩ S).card = 2)).card

/-- Edges meeting `S` in one or three vertices. -/
def badCount (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) : ℕ :=
  (H.filter (fun e => (e ∩ S).card = 1 ∨ (e ∩ S).card = 3)).card

/-- 3-sets meeting `S` in exactly two vertices that are not edges. -/
def missCount (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) : ℕ :=
  (((Finset.univ : Finset (Fin n)).powersetCard 3).filter
    (fun T => (T ∩ S).card = 2 ∧ T ∉ H)).card

/-- The largest `cutCount` over all `S`. -/
def maxCut (H : Finset (Finset (Fin n))) : ℕ :=
  (Finset.univ : Finset (Finset (Fin n))).sup (cutCount H)

/-- Moving one vertex across `S` does not increase `cutCount`. -/
def LocallyMaximal (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) : Prop :=
  ∀ v : Fin n, cutCount H (symmDiff S {v}) ≤ cutCount H S

/-- The degree of `v`. -/
def deg (H : Finset (Finset (Fin n))) (v : Fin n) : ℕ :=
  (H.filter (fun e => v ∈ e)).card

end Defs

/-- BLLP's Proposition 3.2 for `C₅³` alone (certified in `rounds/p32-exact`). -/
def P32Statement : Prop :=
  ∀ ε > (0 : ℝ), ∃ N : ℕ, ∀ n ≥ N, ∀ H : Finset (Finset (Fin n)),
    IsThreeGraph H → ¬ ContainsC5 H →
    (H.card : ℝ) ≥ 4641 / 10000 * (n.choose 3 : ℝ) →
    (maxCut H : ℝ) ≥ (2 / 5 - ε) * (n.choose 3 : ℝ)

/-- BLLP's Proposition 3.3 for `C₅³` alone (certified in `rounds/p33-exact`). -/
def P33Statement : Prop :=
  ∀ ξ > (0 : ℝ), ∃ δ > (0 : ℝ), ∃ N : ℕ, ∀ n ≥ N,
    ∀ (H : Finset (Finset (Fin n))) (S : Finset (Fin n)),
    IsThreeGraph H → ¬ ContainsC5 H → LocallyMaximal H S →
    (∀ u v, (deg H u : ℝ) ≤ deg H v + δ * (n : ℝ) ^ 2) →
    (cutCount H S : ℝ) ≥ (2 / 5 - δ) * (n.choose 3 : ℝ) →
    (H.card : ℝ) ≥ (464101615 / 10 ^ 9 - δ) * (n.choose 3 : ℝ) →
    (badCount H S : ℝ) - missCount H S ≤ ξ * (n : ℝ) ^ 3

/-! ### Extremal graphs and cloning -/

theorem exists_extremal (n : ℕ) :
    ∃ H : Finset (Finset (Fin n)), IsThreeGraph H ∧ ¬ ContainsC5 H ∧ H.card = ex n := by
  classical
  have hmem : (∅ : Finset (Finset (Fin n))) ∈ (Finset.univ : Finset (Finset (Finset (Fin n)))).filter
      (fun H => IsThreeGraph H ∧ ¬ ContainsC5 H) := by
    simp only [Finset.mem_filter, Finset.mem_univ, true_and]
    refine ⟨fun e he => absurd he (Finset.notMem_empty e), ?_⟩
    rintro ⟨f, hf⟩
    exact Finset.notMem_empty _ (hf 0)
  obtain ⟨H, hH, hsup⟩ := Finset.exists_mem_eq_sup _ ⟨_, hmem⟩ Finset.card
  simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hH
  refine ⟨H, hH.1, hH.2, ?_⟩
  unfold ex
  convert hsup.symm

/-- `ex n ≤ C(n,3)`. -/
theorem ex_le_choose (n : ℕ) : ex n ≤ n.choose 3 := by
  obtain ⟨H, hH, -, hcard⟩ := exists_extremal n
  rw [← hcard]
  have hsub : H ⊆ (Finset.univ : Finset (Fin n)).powersetCard 3 := by
    intro e he
    simp [Finset.mem_powersetCard, hH e he]
  simpa using Finset.card_le_card hsub

/-- Replace the link of `u` by a copy of the link of `v`. -/
def clone {n : ℕ} (H : Finset (Finset (Fin n))) (u v : Fin n) : Finset (Finset (Fin n)) :=
  H.filter (fun e => u ∉ e) ∪
    (H.filter (fun e => v ∈ e ∧ u ∉ e)).image (fun e => insert u (e.erase v))

theorem clone_three {n : ℕ} {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H) (u v : Fin n) :
    IsThreeGraph (clone H u v) := by
  intro e he
  simp only [clone, mem_union, mem_filter, mem_image] at he
  rcases he with ⟨he, -⟩ | ⟨e₀, ⟨he₀, hv, hu⟩, rfl⟩
  · exact hH e he
  · have hu' : u ∉ e₀.erase v := fun h => hu (Finset.mem_of_mem_erase h)
    rw [Finset.card_insert_of_notMem hu', Finset.card_erase_of_mem hv, hH e₀ he₀]

/-- The map `u ↦ v` sends every edge of the clone onto an edge of `H`. -/
theorem image_clone_mem {n : ℕ} {H : Finset (Finset (Fin n))} {u v : Fin n} {e : Finset (Fin n)}
    (he : e ∈ clone H u v) : e.image (fun x => if x = u then v else x) ∈ H := by
  have hid : ∀ s : Finset (Fin n), u ∉ s → s.image (fun x => if x = u then v else x) = s := by
    intro s hs
    rw [Finset.image_congr (g := id) (fun x hx => by
      have : x ≠ u := fun h => hs (h ▸ hx)
      simp [this]), Finset.image_id]
  simp only [clone, mem_union, mem_filter, mem_image] at he
  rcases he with ⟨he, hu⟩ | ⟨e₀, ⟨he₀, hv, hu⟩, rfl⟩
  · rw [hid e hu]; exact he
  · have hu' : u ∉ e₀.erase v := fun h => hu (Finset.mem_of_mem_erase h)
    rw [Finset.image_insert, hid _ hu', if_pos rfl, Finset.insert_erase hv]
    exact he₀

/-- **Cloning keeps `C₅³`-freeness.** -/
theorem clone_c5free {n : ℕ} {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H)
    (hC : ¬ ContainsC5 H) (u v : Fin n) : ¬ ContainsC5 (clone H u v) := by
  rintro ⟨f, hf⟩
  apply hC
  set g : Fin 5 → Fin n := fun i => if f i = u then v else f i with hg
  have hgH : ∀ i : Fin 5, ({g i, g (i + 1), g (i + 2)} : Finset (Fin n)) ∈ H := by
    intro i
    have := image_clone_mem (hf i)
    simpa [Finset.image_insert, Finset.image_singleton, hg] using this
  exact ⟨⟨g, injective_of_c5_edges hH g hgH⟩, hgH⟩

theorem card_clone {n : ℕ} (H : Finset (Finset (Fin n))) (u v : Fin n) :
    (clone H u v).card =
      (H.filter (fun e => u ∉ e)).card + (H.filter (fun e => v ∈ e ∧ u ∉ e)).card := by
  unfold clone
  rw [Finset.card_union_of_disjoint, Finset.card_image_of_injOn]
  · intro a ha b hb hab
    simp only [coe_filter, Set.mem_setOf_eq] at ha hb
    have hab' : (insert u (a.erase v)).erase u = (insert u (b.erase v)).erase u := by
      simp only at hab; rw [hab]
    rw [Finset.erase_insert (fun h => ha.2.2 (Finset.mem_of_mem_erase h)),
      Finset.erase_insert (fun h => hb.2.2 (Finset.mem_of_mem_erase h))] at hab'
    rw [← Finset.insert_erase ha.2.1, ← Finset.insert_erase hb.2.1, hab']
  · rw [Finset.disjoint_left]
    intro e he he'
    simp only [mem_filter, mem_image] at he he'
    obtain ⟨e₀, -, rfl⟩ := he'
    exact he.2 (Finset.mem_insert_self _ _)

/-- Edges through two distinct vertices number at most `n`. -/
theorem card_pair_le {n : ℕ} {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H) {u v : Fin n}
    (huv : u ≠ v) : (H.filter (fun e => v ∈ e ∧ u ∈ e)).card ≤ n := by
  have h := Finset.card_le_card_of_injOn (fun e : Finset (Fin n) => (e.erase u).erase v)
    (s := H.filter (fun e => v ∈ e ∧ u ∈ e))
    (t := (Finset.univ : Finset (Fin n)).powersetCard 1) ?_ ?_
  · simpa using h
  · intro e he
    simp only [coe_filter, Set.mem_setOf_eq] at he
    rw [Finset.mem_coe, Finset.mem_powersetCard]
    refine ⟨Finset.subset_univ _, ?_⟩
    have hv' : v ∈ e.erase u := Finset.mem_erase.2 ⟨huv.symm, he.2.1⟩
    rw [Finset.card_erase_of_mem hv', Finset.card_erase_of_mem he.2.2, hH e he.1]
  · intro a ha b hb hab
    simp only [coe_filter, Set.mem_setOf_eq] at ha hb
    simp only at hab
    have hva : v ∈ a.erase u := Finset.mem_erase.2 ⟨huv.symm, ha.2.1⟩
    have hvb : v ∈ b.erase u := Finset.mem_erase.2 ⟨huv.symm, hb.2.1⟩
    rw [← Finset.insert_erase ha.2.2, ← Finset.insert_erase hva, hab,
      Finset.insert_erase hvb, Finset.insert_erase hb.2.2]

/-- **Near-regularity of extremal graphs**: `deg v ≤ deg u + n`. -/
theorem deg_le_of_extremal {n : ℕ} {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H)
    (hC : ¬ ContainsC5 H) (hex : H.card = ex n) (u v : Fin n) : deg H v ≤ deg H u + n := by
  by_cases huv : u = v
  · subst huv; omega
  have hcl : (clone H u v).card ≤ H.card := hex ▸ card_le_ex (clone_three hH u v)
    (clone_c5free hH hC u v)
  rw [card_clone] at hcl
  have hsplit := Finset.card_filter_add_card_filter_not (s := H) (fun e => u ∈ e)
  have hv := Finset.card_filter_add_card_filter_not (s := H.filter (fun e => v ∈ e))
    (fun e => u ∈ e)
  rw [Finset.filter_filter, Finset.filter_filter] at hv
  have hpair := card_pair_le hH huv
  unfold deg
  omega

/-! ### Counting at a cut -/

/-- 3-sets meeting `S` in two vertices number at most `C(|S|,2)·|Sᶜ|`. -/
theorem card_two_le {n : ℕ} (S : Finset (Fin n)) :
    (((Finset.univ : Finset (Fin n)).powersetCard 3).filter (fun T => (T ∩ S).card = 2)).card
      ≤ S.card.choose 2 * Sᶜ.card := by
  have hsub : ((Finset.univ : Finset (Fin n)).powersetCard 3).filter (fun T => (T ∩ S).card = 2)
      ⊆ ((S.powersetCard 2) ×ˢ Sᶜ).image (fun q => insert q.2 q.1) := by
    intro T hT
    simp only [mem_filter, mem_powersetCard] at hT
    obtain ⟨⟨-, h3⟩, h2⟩ := hT
    have h1 : (T \ S).card = 1 := by
      have := Finset.card_inter_add_card_sdiff T S
      omega
    obtain ⟨z, hz⟩ := Finset.card_eq_one.1 h1
    have hx : ∀ x, x ∈ T ∧ x ∉ S ↔ x = z := fun x => by
      rw [← Finset.mem_singleton, ← hz, Finset.mem_sdiff]
    rw [mem_image]
    refine ⟨(T ∩ S, z), ?_, ?_⟩
    · simp only [mem_product, mem_powersetCard, mem_compl]
      exact ⟨⟨Finset.inter_subset_right, h2⟩, ((hx z).2 rfl).2⟩
    · ext x
      simp only [mem_insert, mem_inter]
      have := hx x
      tauto
  refine (Finset.card_le_card hsub).trans ((Finset.card_image_le).trans ?_)
  rw [Finset.card_product, Finset.card_powersetCard]

/-- Every edge meets `S` in zero, one, two or three vertices. -/
theorem card_le_parts {n : ℕ} {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H)
    (S : Finset (Fin n)) :
    H.card ≤ cutCount H S + badCount H S + (H.filter (fun e => (e ∩ S).card = 0)).card := by
  unfold cutCount badCount
  have hsub : H ⊆ H.filter (fun e => (e ∩ S).card = 2) ∪
      H.filter (fun e => (e ∩ S).card = 1 ∨ (e ∩ S).card = 3) ∪
      H.filter (fun e => (e ∩ S).card = 0) := by
    intro e he
    have hle : (e ∩ S).card ≤ 3 := hH e he ▸ Finset.card_le_card Finset.inter_subset_left
    simp only [mem_union, mem_filter, he, true_and]
    omega
  refine (Finset.card_le_card hsub).trans ?_
  exact (Finset.card_union_le _ _).trans (by
    have := Finset.card_union_le (H.filter (fun e => (e ∩ S).card = 2))
      (H.filter (fun e => (e ∩ S).card = 1 ∨ (e ∩ S).card = 3))
    omega)

/-- `cut + miss ≤ C(|S|,2)·|Sᶜ|`. -/
theorem cut_add_miss_le {n : ℕ} {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H)
    (S : Finset (Fin n)) : cutCount H S + missCount H S ≤ S.card.choose 2 * Sᶜ.card := by
  unfold cutCount missCount
  rw [← Finset.card_union_of_disjoint]
  · refine (Finset.card_le_card ?_).trans (card_two_le S)
    intro T hT
    simp only [mem_union, mem_filter, mem_powersetCard] at hT ⊢
    rcases hT with ⟨hT, h2⟩ | ⟨hT, h2, -⟩
    · exact ⟨⟨Finset.subset_univ _, hH T hT⟩, h2⟩
    · exact ⟨hT, h2⟩
  · rw [Finset.disjoint_left]
    intro T hT hT'
    simp only [mem_filter] at hT hT'
    exact hT'.2.2 hT.1

/-- The edges inside `Sᶜ` number at most `ex |Sᶜ|`. -/
theorem card_inside_le {n : ℕ} {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H)
    (hC : ¬ ContainsC5 H) (S : Finset (Fin n)) :
    (H.filter (fun e => (e ∩ S).card = 0)).card ≤ ex Sᶜ.card := by
  set φ : Fin Sᶜ.card ↪ Fin n := (Sᶜ.orderEmbOfFin rfl).toEmbedding with hφ
  have hrange : Set.range φ = (Sᶜ : Set (Fin n)) := by
    rw [hφ, RelEmbedding.coe_toEmbedding, Finset.range_orderEmbOfFin, Finset.coe_compl]
  refine le_trans ?_ (card_le_ex (pullback_three φ hH) (pullback_c5free φ hC))
  rw [← Finset.card_map (Finset.mapEmbedding φ).toEmbedding]
  apply Finset.card_le_card
  intro e he
  simp only [mem_filter] at he
  have hsub : e ⊆ Finset.univ.map φ := by
    intro x hx
    have hxS : x ∈ (Sᶜ : Set (Fin n)) := by
      rw [Set.mem_compl_iff, Finset.mem_coe]
      intro hxS
      have : x ∈ e ∩ S := Finset.mem_inter.2 ⟨hx, hxS⟩
      rw [Finset.card_eq_zero.1 he.2] at this
      exact Finset.notMem_empty _ this
    rw [← hrange] at hxS
    obtain ⟨i, rfl⟩ := hxS
    exact Finset.mem_map_of_mem _ (Finset.mem_univ i)
  obtain ⟨u, -, rfl⟩ := Finset.subset_map_iff.1 hsub
  simp only [Finset.mem_map, pullback, Finset.mem_filter, Finset.mem_univ, true_and,
    RelEmbedding.coe_toEmbedding, Finset.mapEmbedding_apply]
  exact ⟨u, he.1, rfl⟩

/-- A cut of maximum size exists and is locally maximal. -/
theorem exists_maxCut {n : ℕ} (H : Finset (Finset (Fin n))) :
    ∃ S, LocallyMaximal H S ∧ cutCount H S = maxCut H := by
  obtain ⟨S, -, hS⟩ := Finset.exists_max_image Finset.univ (cutCount H) Finset.univ_nonempty
  exact ⟨S, fun v => hS _ (Finset.mem_univ _),
    le_antisymm (Finset.le_sup (Finset.mem_univ S))
      (Finset.sup_le fun T _ => hS T (Finset.mem_univ T))⟩

/-- **The cut identity** (as an inequality):
`e(H) ≤ C(|S|,2)·|Sᶜ| + (bad − miss) + ex |Sᶜ|`. -/
theorem card_le_cut_identity {n : ℕ} {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H)
    (hC : ¬ ContainsC5 H) (S : Finset (Fin n)) :
    (H.card : ℝ) ≤ ((S.card.choose 2 : ℕ) : ℝ) * (Sᶜ.card : ℝ)
      + ((badCount H S : ℝ) - missCount H S) + (ex Sᶜ.card : ℝ) := by
  have h1 := card_le_parts hH S
  have h2 := cut_add_miss_le hH S
  have h3 := card_inside_le hH hC S
  have : H.card + missCount H S ≤ S.card.choose 2 * Sᶜ.card + badCount H S + ex Sᶜ.card := by
    omega
  have : ((H.card + missCount H S : ℕ) : ℝ) ≤
      ((S.card.choose 2 * Sᶜ.card + badCount H S + ex Sᶜ.card : ℕ) : ℝ) := by exact_mod_cast this
  push_cast at this
  linarith

/-! ### Numerical facts -/

theorem choose3_le (m : ℕ) : (m.choose 3 : ℝ) ≤ (m : ℝ) ^ 3 / 6 := by
  have h := six_choose_three m
  rcases Nat.eq_zero_or_pos m with hm | hm
  · subst hm; simp
  · have : (1 : ℝ) ≤ m := by exact_mod_cast hm
    nlinarith

theorem choose3_ge {m : ℕ} (hm : 6 ≤ m) : (m : ℝ) ^ 3 / 12 ≤ (m.choose 3 : ℝ) := by
  have h := six_choose_three m
  have : (6 : ℝ) ≤ m := by exact_mod_cast hm
  nlinarith

theorem choose3_ge' (m : ℕ) : (m : ℝ) ^ 3 - 3 * (m : ℝ) ^ 2 ≤ 6 * (m.choose 3 : ℝ) := by
  rw [six_choose_three]
  have : (0 : ℝ) ≤ m := Nat.cast_nonneg m
  nlinarith

/-- `ex n ≥ α C(n,3) − 2n²`, from `ex_ge`. -/
theorem ex_ge_choose (n : ℕ) :
    (2 * Real.sqrt 3 - 3) * (n.choose 3 : ℝ) - 2 * (n : ℝ) ^ 2 ≤ ex n := by
  have h := ex_ge n
  have hc := choose3_le n
  have ha := alpha_pos
  have : (2 * Real.sqrt 3 - 3) * (n.choose 3 : ℝ) ≤ turanL * (n : ℝ) ^ 3 := by
    unfold turanL
    nlinarith
  linarith

/-- `√3 > 1.7320508075`, so `α ≥ 464101615 / 10⁹` (and `> 4641/10⁴`). -/
theorem alpha_ge_p33 : (464101615 / 10 ^ 9 : ℝ) ≤ 2 * Real.sqrt 3 - 3 := by
  have : (17320508075 / 10 ^ 10 : ℝ) < Real.sqrt 3 :=
    (Real.lt_sqrt (by norm_num)).2 (by norm_num)
  linarith

theorem alpha_gt_p32 : (4641 / 10000 : ℝ) < 2 * Real.sqrt 3 - 3 := by
  have := alpha_ge_p33
  linarith

/-! ### The core bound -/

set_option maxHeartbeats 1000000 in
/-- **The core bound.** From P32 and P33: for every `ξ > 0` and all large
`n` there is a split `n = s + m` with `s ≥ n/6` and
`ex n ≤ s² m / 2 + ex m + ξ n³`. -/
theorem core_bound (h32 : P32Statement) (h33 : P33Statement) {ξ : ℝ} (hξ : 0 < ξ) :
    ∃ N : ℕ, ∀ n ≥ N, ∃ s m : ℕ, s + m = n ∧ (n : ℝ) ≤ 6 * s ∧
      (ex n : ℝ) ≤ (s : ℝ) ^ 2 * m / 2 + ex m + ξ * (n : ℝ) ^ 3 := by
  obtain ⟨δ₀, hδ₀, N₃, h3⟩ := h33 ξ hξ
  -- P32 is used at `δ = min δ₀ (1/5)`: it meets P33's hypotheses and bounds `|S|` below
  obtain ⟨δ, hδpos, hδle, hδ5⟩ : ∃ δ : ℝ, 0 < δ ∧ δ ≤ δ₀ ∧ δ ≤ 1 / 5 :=
    ⟨min δ₀ (1 / 5), lt_min hδ₀ (by norm_num), min_le_left _ _, min_le_right _ _⟩
  obtain ⟨N₂, h2⟩ := h32 δ hδpos
  have hα1 := alpha_gt_p32
  have hα2 := alpha_ge_p33
  have hαc : 0 < 2 * Real.sqrt 3 - 3 - 4641 / 10000 := by linarith
  obtain ⟨N₄, hN₄⟩ := exists_nat_gt (24 / (2 * Real.sqrt 3 - 3 - 4641 / 10000) + 24 / δ₀ + 6)
  refine ⟨max N₂ (max N₃ N₄), fun n hn => ?_⟩
  have hn2 : N₂ ≤ n := le_of_max_le_left hn
  have hn3 : N₃ ≤ n := le_of_max_le_left (le_of_max_le_right hn)
  have hn4 : (N₄ : ℝ) ≤ n := by exact_mod_cast le_of_max_le_right (le_of_max_le_right hn)
  have hA : 0 < 24 / (2 * Real.sqrt 3 - 3 - 4641 / 10000) := div_pos (by norm_num) hαc
  have hB : 0 < 24 / δ₀ := div_pos (by norm_num) hδ₀
  have hn6 : (6 : ℝ) ≤ n := by linarith
  have hn0 : (0 : ℝ) < n := by linarith
  have hnA : 24 < (2 * Real.sqrt 3 - 3 - 4641 / 10000) * n := by
    have : 24 / (2 * Real.sqrt 3 - 3 - 4641 / 10000) < n := by linarith
    rw [div_lt_iff₀ hαc] at this
    linarith
  have hnB : 24 < δ₀ * n := by
    have : 24 / δ₀ < n := by linarith
    rw [div_lt_iff₀ hδ₀] at this
    linarith
  have hC12 : (n : ℝ) ^ 3 / 12 ≤ (n.choose 3 : ℝ) := choose3_ge (by exact_mod_cast hn6)
  have hC0 : (0 : ℝ) ≤ (n.choose 3 : ℝ) := Nat.cast_nonneg _
  have hsq : (0 : ℝ) ≤ (n : ℝ) ^ 2 := sq_nonneg _
  have h2a : 2 * (n : ℝ) ^ 2 ≤ (2 * Real.sqrt 3 - 3 - 4641 / 10000) * (n.choose 3 : ℝ) := by
    have : 2 * (n : ℝ) ^ 2 ≤ (2 * Real.sqrt 3 - 3 - 4641 / 10000) * ((n : ℝ) ^ 3 / 12) := by
      have := mul_le_mul_of_nonneg_right hnA.le hsq
      nlinarith
    exact this.trans (mul_le_mul_of_nonneg_left hC12 hαc.le)
  have h2b : 2 * (n : ℝ) ^ 2 ≤ δ₀ * (n.choose 3 : ℝ) := by
    have : 2 * (n : ℝ) ^ 2 ≤ δ₀ * ((n : ℝ) ^ 3 / 12) := by
      have := mul_le_mul_of_nonneg_right hnB.le hsq
      nlinarith
    exact this.trans (mul_le_mul_of_nonneg_left hC12 hδ₀.le)
  obtain ⟨H, hH, hC, hex⟩ := exists_extremal n
  have hlow := ex_ge_choose n
  have hHc : (H.card : ℝ) = ex n := by exact_mod_cast hex
  obtain ⟨S, hloc, hSmax⟩ := exists_maxCut H
  have hcut : (cutCount H S : ℝ) ≥ (2 / 5 - δ) * (n.choose 3 : ℝ) := by
    rw [hSmax]
    exact h2 n hn2 H hH hC (by rw [hHc]; linarith)
  have hdeg : ∀ u v, (deg H u : ℝ) ≤ deg H v + δ₀ * (n : ℝ) ^ 2 := by
    intro u v
    have h' : (deg H u : ℝ) ≤ deg H v + n := by exact_mod_cast deg_le_of_extremal hH hC hex v u
    have : (n : ℝ) ≤ δ₀ * (n : ℝ) ^ 2 := by nlinarith
    linarith
  have hbm := h3 n hn3 H S hH hC hloc hdeg
    (by have := mul_le_mul_of_nonneg_right hδle hC0; linarith)
    (by rw [hHc]; have := mul_le_mul_of_nonneg_right hα2 hC0; linarith)
  have hid := card_le_cut_identity hH hC S
  have hcm := cut_add_miss_le hH S
  have hsm : S.card + Sᶜ.card = n := by
    rw [Finset.card_add_card_compl, Fintype.card_fin]
  have hsm' : (S.card : ℝ) + Sᶜ.card = n := by exact_mod_cast hsm
  have hchoose : ((S.card.choose 2 : ℕ) : ℝ) ≤ (S.card : ℝ) ^ 2 / 2 := by
    rw [Nat.cast_choose_two]
    have : (0 : ℝ) ≤ S.card := Nat.cast_nonneg _
    nlinarith
  have hm0 : (0 : ℝ) ≤ Sᶜ.card := Nat.cast_nonneg _
  have hcm' : (cutCount H S : ℝ) ≤ ((S.card.choose 2 : ℕ) : ℝ) * (Sᶜ.card : ℝ) := by
    have : cutCount H S ≤ S.card.choose 2 * Sᶜ.card := by omega
    exact_mod_cast this
  have hcm'' : (cutCount H S : ℝ) ≤ (S.card : ℝ) ^ 2 / 2 * Sᶜ.card :=
    hcm'.trans (mul_le_mul_of_nonneg_right hchoose hm0)
  refine ⟨S.card, Sᶜ.card, hsm, ?_, ?_⟩
  · by_contra hlt
    push Not at hlt
    have hs0 : (0 : ℝ) ≤ S.card := Nat.cast_nonneg _
    have h6 := mul_self_lt_mul_self (by positivity) hlt
    have hs36 : 36 * (S.card : ℝ) ^ 2 < (n : ℝ) ^ 2 := by linarith
    have hmn : (Sᶜ.card : ℝ) ≤ n := by linarith
    have hup : (cutCount H S : ℝ) ≤ (S.card : ℝ) ^ 2 / 2 * n :=
      hcm''.trans (mul_le_mul_of_nonneg_left hmn (by positivity))
    have hlo : (n : ℝ) ^ 3 / 60 ≤ cutCount H S := by
      have h1 := mul_le_mul_of_nonneg_left hC12 (show (0 : ℝ) ≤ 2 / 5 - δ by linarith)
      have h2 := mul_le_mul_of_nonneg_right (show (1 : ℝ) / 5 ≤ 2 / 5 - δ by linarith)
        (show (0 : ℝ) ≤ (n : ℝ) ^ 3 / 12 by positivity)
      linarith
    have := mul_lt_mul_of_pos_right hs36 hn0
    linarith
  · have hm' : ((S.card.choose 2 : ℕ) : ℝ) * (Sᶜ.card : ℝ) ≤ (S.card : ℝ) ^ 2 * Sᶜ.card / 2 := by
      have := mul_le_mul_of_nonneg_right hchoose hm0
      linarith
    rw [← hHc]
    linarith

/-! ### The limsup argument -/

/-- The tail bound used in `limsup_le`: `f m ≤ c m³/6 + K` for every `m`,
from `f m ≤ C(m,3)` and eventually `f m / C(m,3) < c`. -/
theorem all_le_of_eventually {f : ℕ → ℕ} (hf : ∀ m, f m ≤ m.choose 3) {c : ℝ} (hc : 0 ≤ c)
    {M : ℕ} (hM : ∀ m ≥ M, (f m : ℝ) / m.choose 3 < c) :
    ∀ m : ℕ, (f m : ℝ) ≤ c * (m : ℝ) ^ 3 / 6 + ((max M 3 : ℕ) : ℝ) ^ 3 / 6 := by
  intro m
  have hK : (0 : ℝ) ≤ ((max M 3 : ℕ) : ℝ) ^ 3 / 6 := by positivity
  have hcm : (0 : ℝ) ≤ c * (m : ℝ) ^ 3 / 6 := by positivity
  have hfm : (f m : ℝ) ≤ m.choose 3 := by exact_mod_cast hf m
  have hc3 := choose3_le m
  by_cases hm : max M 3 ≤ m
  · have hCpos : (0 : ℝ) < m.choose 3 := by
      exact_mod_cast Nat.choose_pos (le_of_max_le_right hm)
    have h := hM m (le_of_max_le_left hm)
    rw [div_lt_iff₀ hCpos] at h
    have := mul_le_mul_of_nonneg_left hc3 hc
    linarith
  · push Not at hm
    have : (m : ℝ) ^ 3 ≤ ((max M 3 : ℕ) : ℝ) ^ 3 :=
      pow_le_pow_left₀ (Nat.cast_nonneg _) (by exact_mod_cast hm.le) 3
    linarith

/-- **The limsup step.** If `f m ≤ C(m,3)` and, for every `ξ > 0` and all
large `n`, `f n ≤ s² m / 2 + f m + ξ n³` for some `n = s + m` with
`s ≥ n/6`, then `limsup f n / C(n,3) ≤ 2√3 − 3`. The proof: with
`B` the limsup, `scalar_step` bounds `s² m/2 + (B/6) m³` by
`L n³ + (B/6 − L) m³`, and `m ≤ 5n/6` makes this a fixed fraction less than
`(B/6) n³` when `B > 6L`. -/
theorem limsup_le {f : ℕ → ℕ} (hf : ∀ m, f m ≤ m.choose 3)
    (hkey : ∀ ξ > (0 : ℝ), ∃ N : ℕ, ∀ n ≥ N, ∃ s m : ℕ, s + m = n ∧ (n : ℝ) ≤ 6 * s ∧
      (f n : ℝ) ≤ (s : ℝ) ^ 2 * m / 2 + f m + ξ * (n : ℝ) ^ 3) :
    limsup (fun n : ℕ => (f n : ℝ) / n.choose 3) atTop ≤ 2 * Real.sqrt 3 - 3 := by
  set r : ℕ → ℝ := fun n => (f n : ℝ) / n.choose 3 with hr
  have hr0 : ∀ n, 0 ≤ r n := fun n => by positivity
  have hr1 : ∀ n, r n ≤ 1 := fun n =>
    div_le_one_of_le₀ (by exact_mod_cast hf n) (Nat.cast_nonneg _)
  have hbdd : IsBoundedUnder (· ≤ ·) atTop r := isBoundedUnder_of ⟨1, hr1⟩
  have hcobdd : IsCoboundedUnder (· ≤ ·) atTop r := isCoboundedUnder_le_of_le atTop hr0
  have hB1 : limsup r atTop ≤ 1 := limsup_le_of_le hcobdd (Eventually.of_forall hr1)
  set B := limsup r atTop with hBdef
  by_contra hB
  push Not at hB
  obtain ⟨d, hd_def⟩ : ∃ d, d = B - (2 * Real.sqrt 3 - 3) := ⟨_, rfl⟩
  have hd : 0 < d := by linarith
  have hαpos := alpha_pos
  have hL : turanL = (B - d) / 6 := by unfold turanL; linarith
  -- the tail: `f m ≤ (B + d/100) m³ / 6 + K` for every `m`
  obtain ⟨M, hM⟩ := eventually_atTop.1
    (eventually_lt_of_limsup_lt (show B < B + d / 100 by linarith) hbdd)
  have hsmall := all_le_of_eventually hf (c := B + d / 100) (by linarith) hM
  set K : ℝ := ((max M 3 : ℕ) : ℝ) ^ 3 / 6 with hK
  have hK0 : 0 ≤ K := by positivity
  -- a large `n` with `r n > B − d/100` where the key bound holds
  obtain ⟨N, hN⟩ := hkey (d / 100) (by positivity)
  have hfreq := frequently_lt_of_lt_limsup hcobdd (show B - d / 100 < B by linarith)
  obtain ⟨n, hn, hfn⟩ :=
    (frequently_atTop.1 hfreq) (max N (max 3 (⌈4 * (3 + 6 * K) / d⌉₊ + 1)))
  obtain ⟨s, m, hsm, hs6, hfle⟩ := hN n (le_of_max_le_left hn)
  have hn3 : (3 : ℝ) ≤ n := by exact_mod_cast le_of_max_le_left (le_of_max_le_right hn)
  have hnd : 4 * (3 + 6 * K) / d < n := by
    have h1 := Nat.le_ceil (4 * (3 + 6 * K) / d)
    have h2 : ((⌈4 * (3 + 6 * K) / d⌉₊ + 1 : ℕ) : ℝ) ≤ n := by
      exact_mod_cast le_of_max_le_right (le_of_max_le_right hn)
    push_cast at h2
    linarith
  have hdn : 4 * (3 + 6 * K) < d * n := by
    rw [div_lt_iff₀ hd] at hnd
    linarith
  have hCpos : (0 : ℝ) < n.choose 3 := by
    exact_mod_cast Nat.choose_pos (by exact_mod_cast hn3 : 3 ≤ n)
  have hfn' : (B - d / 100) * n.choose 3 < f n := by
    have : B - d / 100 < (f n : ℝ) / n.choose 3 := hfn
    rwa [lt_div_iff₀ hCpos] at this
  -- upper bound on `f n`
  have hsm' : (s : ℝ) + m = n := by exact_mod_cast hsm
  have hs0 : (0 : ℝ) ≤ s := Nat.cast_nonneg _
  have hm0 : (0 : ℝ) ≤ m := Nat.cast_nonneg _
  have hsc := scalar_step hs0 hm0
  rw [hsm'] at hsc
  have hm56 : (m : ℝ) ≤ 5 / 6 * n := by linarith
  have hm3 : (m : ℝ) ^ 3 ≤ 125 / 216 * (n : ℝ) ^ 3 := by
    have := pow_le_pow_left₀ hm0 hm56 3
    linarith [show (5 / 6 * (n : ℝ)) ^ 3 = 125 / 216 * (n : ℝ) ^ 3 by ring]
  have hcoef : 0 ≤ (B + d / 100) / 6 - turanL := by rw [hL]; linarith
  have hcm := mul_le_mul_of_nonneg_left hm3 hcoef
  have hfm := hsmall m
  have key : (f n : ℝ) ≤ turanL * (n : ℝ) ^ 3
      + ((B + d / 100) / 6 - turanL) * (125 / 216 * (n : ℝ) ^ 3) + K
      + d / 100 * (n : ℝ) ^ 3 := by
    linarith
  rw [hL] at key
  -- lower bound on `f n`
  have hC6 := choose3_ge' n
  have hlow : (B - d / 100) * ((n : ℝ) ^ 3 - 3 * (n : ℝ) ^ 2) < 6 * f n := by
    have := mul_le_mul_of_nonneg_left hC6 (show (0 : ℝ) ≤ B - d / 100 by linarith)
    linarith
  -- combine
  have hn2 : (0 : ℝ) ≤ (n : ℝ) ^ 2 := sq_nonneg _
  have hn1 : (1 : ℝ) ≤ (n : ℝ) ^ 2 := by nlinarith
  have hdn3 := mul_lt_mul_of_pos_right hdn (show (0 : ℝ) < (n : ℝ) ^ 2 by positivity)
  have hKn := mul_le_mul_of_nonneg_left hn1 hK0
  have hBn := mul_le_mul_of_nonneg_right (show B - d / 100 ≤ 1 by linarith) hn2
  linarith

/-- **The endpoint from BLLP's two flag-algebra statements.** -/
theorem mubayi_rodl_of_bllp (h32 : P32Statement) (h33 : P33Statement) :
    Tendsto (fun n : ℕ => (ex n : ℝ) / (n.choose 3 : ℝ)) atTop
      (𝓝 (2 * Real.sqrt 3 - 3)) := by
  have hls := limsup_le ex_le_choose (fun ξ hξ => core_bound h32 h33 hξ)
  have hbdd : IsBoundedUnder (· ≤ ·) atTop (fun n : ℕ => (ex n : ℝ) / (n.choose 3 : ℝ)) :=
    isBoundedUnder_of ⟨1, fun n => div_le_one_of_le₀ (by exact_mod_cast ex_le_choose n)
      (Nat.cast_nonneg _)⟩
  set α := 2 * Real.sqrt 3 - 3 with hα
  -- the lower bound, as in `mubayi_rodl_of_m4`
  have hlow : Tendsto (fun n : ℕ => (α - 12 / (n : ℝ)) * ((n : ℝ) ^ 3 / (6 * (n.choose 3 : ℝ))))
      atTop (𝓝 α) := by
    have : Tendsto (fun n : ℕ => α - 12 / (n : ℝ)) atTop (𝓝 α) := by
      simpa using (tendsto_const_nhds (x := α)).sub
        (tendsto_const_div_atTop_nhds_zero_nat (𝕜 := ℝ) 12)
    simpa using this.mul tendsto_ratio
  have hle : ∀ᶠ n : ℕ in atTop, (α - 12 / (n : ℝ)) * ((n : ℝ) ^ 3 / (6 * (n.choose 3 : ℝ)))
      ≤ (ex n : ℝ) / (n.choose 3 : ℝ) := by
    filter_upwards [eventually_ge_atTop 3] with n hn
    have hn' : (3 : ℝ) ≤ n := by exact_mod_cast hn
    have hC : 0 < (n.choose 3 : ℝ) := by exact_mod_cast Nat.choose_pos hn
    have heq : (α - 12 / (n : ℝ)) * ((n : ℝ) ^ 3 / (6 * (n.choose 3 : ℝ))) =
        (turanL * (n : ℝ) ^ 3 - 2 * (n : ℝ) ^ 2) / (n.choose 3 : ℝ) := by
      unfold turanL
      rw [← hα]
      have hn0 : (n : ℝ) ≠ 0 := by positivity
      field_simp
      ring
    rw [heq]
    exact div_le_div_of_nonneg_right (ex_ge n) hC.le
  rw [tendsto_order]
  refine ⟨fun a ha => ?_, fun a ha => eventually_lt_of_limsup_lt (hls.trans_lt ha) hbdd⟩
  filter_upwards [(tendsto_order.1 hlow).1 a ha, hle] with n h1 h2
  exact h1.trans_le h2

end TightCycleC5
