import KernelShard22Blocks0
import KernelShard22Blocks1
import KernelShard22Blocks2
import KernelShard22Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard22 : kernelShardCheck 22 kernelWitness22 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (22 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness22 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_22_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard22
end TightCycleC5.Bridge.Cover
