import CoverUnit
import CoverWitness1
import CoverWitness2
import CoverWitness3
import CoverWitness4
import CoverWitness5
import CoverWitness6
import CoverWitness7
import CoverWitness8
import CoverWitness9
import CoverWitness10
import CoverWitness11
import CoverWitness12
import CoverWitness13
import CoverWitness14
import CoverWitness15
import CoverWitness16
import CoverWitness17
import CoverWitness18
import CoverWitness19
import CoverWitness20
import CoverWitness21
import CoverWitness22
import CoverWitness23
import CoverWitness24
import CoverWitness25
import CoverWitness26
import CoverWitness27
import CoverWitness28
import CoverWitness29
import CoverWitness30
import CoverWitness31

/-! Exhaustive, checked P32 coverage of all 2^20 masks. -/
namespace TightCycleC5.Bridge.Cover
open MaskEncoding

set_option maxHeartbeats 0 in
theorem shard1 : shardCheck 1 witnessHex1 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard2 : shardCheck 2 witnessHex2 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard3 : shardCheck 3 witnessHex3 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard4 : shardCheck 4 witnessHex4 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard5 : shardCheck 5 witnessHex5 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard6 : shardCheck 6 witnessHex6 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard7 : shardCheck 7 witnessHex7 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard8 : shardCheck 8 witnessHex8 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard9 : shardCheck 9 witnessHex9 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard10 : shardCheck 10 witnessHex10 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard11 : shardCheck 11 witnessHex11 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard12 : shardCheck 12 witnessHex12 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard13 : shardCheck 13 witnessHex13 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard14 : shardCheck 14 witnessHex14 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard15 : shardCheck 15 witnessHex15 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard16 : shardCheck 16 witnessHex16 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard17 : shardCheck 17 witnessHex17 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard18 : shardCheck 18 witnessHex18 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard19 : shardCheck 19 witnessHex19 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard20 : shardCheck 20 witnessHex20 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard21 : shardCheck 21 witnessHex21 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard22 : shardCheck 22 witnessHex22 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard23 : shardCheck 23 witnessHex23 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard24 : shardCheck 24 witnessHex24 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard25 : shardCheck 25 witnessHex25 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard26 : shardCheck 26 witnessHex26 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard27 : shardCheck 27 witnessHex27 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard28 : shardCheck 28 witnessHex28 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard29 : shardCheck 29 witnessHex29 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard30 : shardCheck 30 witnessHex30 := by
  unfold shardCheck shardCheckBytes
  native_decide

set_option maxHeartbeats 0 in
theorem shard31 : shardCheck 31 witnessHex31 := by
  unfold shardCheck shardCheckBytes
  native_decide

def shardHex (j : Fin 32) : String :=
  match j.val with
  | 0 => witnessHex0
  | 1 => witnessHex1
  | 2 => witnessHex2
  | 3 => witnessHex3
  | 4 => witnessHex4
  | 5 => witnessHex5
  | 6 => witnessHex6
  | 7 => witnessHex7
  | 8 => witnessHex8
  | 9 => witnessHex9
  | 10 => witnessHex10
  | 11 => witnessHex11
  | 12 => witnessHex12
  | 13 => witnessHex13
  | 14 => witnessHex14
  | 15 => witnessHex15
  | 16 => witnessHex16
  | 17 => witnessHex17
  | 18 => witnessHex18
  | 19 => witnessHex19
  | 20 => witnessHex20
  | 21 => witnessHex21
  | 22 => witnessHex22
  | 23 => witnessHex23
  | 24 => witnessHex24
  | 25 => witnessHex25
  | 26 => witnessHex26
  | 27 => witnessHex27
  | 28 => witnessHex28
  | 29 => witnessHex29
  | 30 => witnessHex30
  | _ => witnessHex31

theorem all_shards : ∀ j, shardCheck j.val (shardHex j) := by
  intro j
  fin_cases j
  · exact shard0
  · exact shard1
  · exact shard2
  · exact shard3
  · exact shard4
  · exact shard5
  · exact shard6
  · exact shard7
  · exact shard8
  · exact shard9
  · exact shard10
  · exact shard11
  · exact shard12
  · exact shard13
  · exact shard14
  · exact shard15
  · exact shard16
  · exact shard17
  · exact shard18
  · exact shard19
  · exact shard20
  · exact shard21
  · exact shard22
  · exact shard23
  · exact shard24
  · exact shard25
  · exact shard26
  · exact shard27
  · exact shard28
  · exact shard29
  · exact shard30
  · exact shard31

theorem p32_mask_cover (m : BitVec 20) (hC : ¬ CodeContainsC5 m) :
    ∃ k : Fin 835, ∃ p : Equiv.Perm (Fin 6),
      m = permuteMask p (representative k) := by
  have hm : m.toNat < 1048576 := m.toFin.isLt
  let j : Fin 32 := ⟨m.toNat / 32768, by omega⟩
  let i : Fin 32768 := ⟨m.toNat % 32768, Nat.mod_lt _ (by decide)⟩
  have h := all_shards j i
  have he : BitVec.ofNat 20 (j.val * 32768 + i.val) = m := by
    have hs : j.val * 32768 + i.val = m.toNat := by
      dsimp [j, i]
      omega
    rw [hs]
    simp
  have hs := witness_sound _ _ h
  rw [he] at hs
  exact hs.resolve_left hC

#print axioms shard1
#print axioms shard2
#print axioms shard3
#print axioms shard4
#print axioms shard5
#print axioms shard6
#print axioms shard7
#print axioms shard8
#print axioms shard9
#print axioms shard10
#print axioms shard11
#print axioms shard12
#print axioms shard13
#print axioms shard14
#print axioms shard15
#print axioms shard16
#print axioms shard17
#print axioms shard18
#print axioms shard19
#print axioms shard20
#print axioms shard21
#print axioms shard22
#print axioms shard23
#print axioms shard24
#print axioms shard25
#print axioms shard26
#print axioms shard27
#print axioms shard28
#print axioms shard29
#print axioms shard30
#print axioms shard31
#print axioms all_shards
#print axioms p32_mask_cover
end TightCycleC5.Bridge.Cover
