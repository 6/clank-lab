import P32RowMatchingFlags

namespace TightCycleC5.Bridge.P32RowMatching
open Finset
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000

/-- Finite root routing, abstracted from the large quoted matrix data. -/
theorem root_option_sum (r : Fin 16) (v : Fin 6 → Option Int) (s : ℝ) :
    ((match P32Arithmetic.fourRootBlock r with
      | none => some 0 | some b => v b).getD 0 : ℝ) / s =
      (if r.val = 0 then ((v 0).getD 0 : ℝ)/s else 0) +
      (if r.val = 1 then ((v 1).getD 0 : ℝ)/s else 0) +
      (if r.val = 3 then ((v 2).getD 0 : ℝ)/s else 0) +
      (if r.val = 7 then ((v 3).getD 0 : ℝ)/s else 0) +
      (if r.val = 15 then ((v 4).getD 0 : ℝ)/s else 0) := by
  fin_cases r <;> norm_num [P32Arithmetic.fourRootBlock]

/-- Ordered four-root masks gate exactly one of the five accepted blocks. -/
theorem four_option_decomposition (f : P32Arithmetic.Features) :
    ((fourOption f).getD 0 : ℝ) / (P32Arithmetic.factorScale : ℝ)^2 =
      (if f.root4.val = 0 then zeroExtend P32PSD.matrix0
        (flagLookup P32Flag.code0 f.fourA.val) (flagLookup P32Flag.code0 f.fourB.val) else 0) +
      (if f.root4.val = 1 then zeroExtend P32PSD.matrix1
        (flagLookup P32Flag.code1 f.fourA.val) (flagLookup P32Flag.code1 f.fourB.val) else 0) +
      (if f.root4.val = 3 then zeroExtend P32PSD.matrix2
        (flagLookup P32Flag.code2 f.fourA.val) (flagLookup P32Flag.code2 f.fourB.val) else 0) +
      (if f.root4.val = 7 then zeroExtend P32PSD.matrix3
        (flagLookup P32Flag.code3 f.fourA.val) (flagLookup P32Flag.code3 f.fourB.val) else 0) +
      (if f.root4.val = 15 then zeroExtend P32PSD.matrix4
        (flagLookup P32Flag.code4 f.fourA.val) (flagLookup P32Flag.code4 f.fourB.val) else 0) := by
  have ht := root_option_sum f.root4
    (fun b => P32Arithmetic.matrixLookup (P32Arithmetic.blocks.get b) f.fourA f.fourB)
    ((P32Arithmetic.factorScale : ℝ)^2)
  simp only [matrix_lookup0_eq, matrix_lookup1_eq, matrix_lookup2_eq,
    matrix_lookup3_eq, matrix_lookup4_eq] at ht
  exact ht

/-- Pointwise matching needs only success of this combined arithmetic Option.
No flag completeness or support assumption is imposed on arbitrary G. -/
theorem psd_contribution_eq (G : LabelledStructure 6)
    (hvalid : (P32Arithmetic.psdNumerator (P32Arithmetic.features G)).isSome = true) :
    P32Arithmetic.psdContribution G = psdRows G := by
  rw [psd_contribution_cast, psd_numerator_split _ hvalid, Int.cast_add, add_div]
  rw [four_option_decomposition, matrix_lookup5_eq]
  unfold psdRows
  rw [row0_optional, row1_optional, row2_optional, row3_optional, row4_optional, row5_optional]

#print axioms root_option_sum
#print axioms four_option_decomposition
#print axioms psd_contribution_eq
end TightCycleC5.Bridge.P32RowMatching
