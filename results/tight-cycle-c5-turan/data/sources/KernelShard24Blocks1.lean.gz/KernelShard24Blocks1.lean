import KernelRowIndex
import KernelWitness24

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_24_32 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 32 * 256 + i.val))
      kernelWitness24Row32[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_32

theorem kernelBlock_24_33 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 33 * 256 + i.val))
      kernelWitness24Row33[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_33

theorem kernelBlock_24_34 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 34 * 256 + i.val))
      kernelWitness24Row34[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_34

theorem kernelBlock_24_35 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 35 * 256 + i.val))
      kernelWitness24Row35[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_35

theorem kernelBlock_24_36 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 36 * 256 + i.val))
      kernelWitness24Row36[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_36

theorem kernelBlock_24_37 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 37 * 256 + i.val))
      kernelWitness24Row37[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_37

theorem kernelBlock_24_38 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 38 * 256 + i.val))
      kernelWitness24Row38[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_38

theorem kernelBlock_24_39 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 39 * 256 + i.val))
      kernelWitness24Row39[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_39

theorem kernelBlock_24_40 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 40 * 256 + i.val))
      kernelWitness24Row40[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_40

theorem kernelBlock_24_41 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 41 * 256 + i.val))
      kernelWitness24Row41[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_41

theorem kernelBlock_24_42 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 42 * 256 + i.val))
      kernelWitness24Row42[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_42

theorem kernelBlock_24_43 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 43 * 256 + i.val))
      kernelWitness24Row43[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_43

theorem kernelBlock_24_44 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 44 * 256 + i.val))
      kernelWitness24Row44[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_44

theorem kernelBlock_24_45 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 45 * 256 + i.val))
      kernelWitness24Row45[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_45

theorem kernelBlock_24_46 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 46 * 256 + i.val))
      kernelWitness24Row46[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_46

theorem kernelBlock_24_47 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 47 * 256 + i.val))
      kernelWitness24Row47[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_47

theorem kernelBlock_24_48 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 48 * 256 + i.val))
      kernelWitness24Row48[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_48

theorem kernelBlock_24_49 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 49 * 256 + i.val))
      kernelWitness24Row49[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_49

theorem kernelBlock_24_50 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 50 * 256 + i.val))
      kernelWitness24Row50[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_50

theorem kernelBlock_24_51 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 51 * 256 + i.val))
      kernelWitness24Row51[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_51

theorem kernelBlock_24_52 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 52 * 256 + i.val))
      kernelWitness24Row52[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_52

theorem kernelBlock_24_53 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 53 * 256 + i.val))
      kernelWitness24Row53[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_53

theorem kernelBlock_24_54 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 54 * 256 + i.val))
      kernelWitness24Row54[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_54

theorem kernelBlock_24_55 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 55 * 256 + i.val))
      kernelWitness24Row55[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_55

theorem kernelBlock_24_56 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 56 * 256 + i.val))
      kernelWitness24Row56[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_56

theorem kernelBlock_24_57 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 57 * 256 + i.val))
      kernelWitness24Row57[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_57

theorem kernelBlock_24_58 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 58 * 256 + i.val))
      kernelWitness24Row58[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_58

theorem kernelBlock_24_59 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 59 * 256 + i.val))
      kernelWitness24Row59[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_59

theorem kernelBlock_24_60 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 60 * 256 + i.val))
      kernelWitness24Row60[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_60

theorem kernelBlock_24_61 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 61 * 256 + i.val))
      kernelWitness24Row61[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_61

theorem kernelBlock_24_62 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 62 * 256 + i.val))
      kernelWitness24Row62[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_62

theorem kernelBlock_24_63 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (24 * 32768 + 63 * 256 + i.val))
      kernelWitness24Row63[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_24_63

end TightCycleC5.Bridge.Cover
