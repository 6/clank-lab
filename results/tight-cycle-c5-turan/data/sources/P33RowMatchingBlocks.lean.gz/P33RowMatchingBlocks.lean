import Mathlib

namespace TightCycleC5.Bridge.P33RowMatching
set_option maxHeartbeats 1000000

/-- Read a bounded cell without reducing the complete flattened quotation.
Only blocks preceding the selected block must have the common width. -/
theorem list_flatten_read {α : Type*} (xss : List (List α)) (width b r : Nat)
    (hb : b < xss.length) (hr : r < (xss[b]'hb).length)
    (hs : ∀ j (hj : j < b), (xss[j]'(by omega)).length = width) :
    xss.flatten[width*b+r]? = (xss[b]'hb)[r]? := by
  induction xss generalizing b with
  | nil => simp at hb
  | cons xs xss ih =>
    cases b with
    | zero =>
      simpa only [Nat.mul_zero,Nat.zero_add,List.getElem_cons_zero,List.flatten_cons]
        using (List.getElem?_append_left (l₁ := xs) (l₂ := xss.flatten) hr)
    | succ b =>
      have hx : xs.length = width := hs 0 (by omega)
      have hb' : b < xss.length := by simpa using hb
      have hr' : r < (xss[b]'hb').length := by simpa using hr
      have hs' : ∀ j (hj : j < b), (xss[j]'(by omega)).length = width := by
        intro j hj
        simpa using hs (j+1) (by omega)
      simp only [List.flatten_cons]
      rw [List.getElem?_append_right (by rw [hx,Nat.mul_succ]; omega)]
      have he : width*(b+1)+r-xs.length = width*b+r := by rw [hx,Nat.mul_succ]; omega
      simpa only [he,List.getElem_cons_succ] using ih b hb' hr' hs'

/-- Array form of the same semantic indexing fact. -/
theorem array_flatten_read {α : Type*} [Inhabited α] (xss : Array (Array α))
    (width b r : Nat) (hb : b < xss.size) (hr : r < (xss[b]'hb).size)
    (hs : ∀ j (hj : j < b), (xss[j]'(by omega)).size = width) :
    xss.flatten[width*b+r]! = (xss[b]'hb)[r]! := by
  have h := list_flatten_read (xss.toList.map Array.toList) width b r
    (by simpa using hb) (by simpa using hr) (fun j hj => by simpa using hs j hj)
  simp only [← Array.toList_flatten,List.getElem_map,Array.getElem_toList,
    Array.getElem?_toList] at h
  simpa only [Array.getElem!_eq_getD,Array.getD_eq_getD_getElem?] using
    congrArg (fun z : Option α => z.getD default) h

#print axioms array_flatten_read

#print axioms list_flatten_read
end TightCycleC5.Bridge.P33RowMatching
