import KernelRowIndex
import KernelWitness0

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_0_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 64 * 256 + i.val))
      kernelWitness0Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_64

theorem kernelBlock_0_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 65 * 256 + i.val))
      kernelWitness0Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_65

theorem kernelBlock_0_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 66 * 256 + i.val))
      kernelWitness0Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_66

theorem kernelBlock_0_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 67 * 256 + i.val))
      kernelWitness0Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_67

theorem kernelBlock_0_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 68 * 256 + i.val))
      kernelWitness0Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_68

theorem kernelBlock_0_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 69 * 256 + i.val))
      kernelWitness0Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_69

theorem kernelBlock_0_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 70 * 256 + i.val))
      kernelWitness0Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_70

theorem kernelBlock_0_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 71 * 256 + i.val))
      kernelWitness0Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_71

theorem kernelBlock_0_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 72 * 256 + i.val))
      kernelWitness0Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_72

theorem kernelBlock_0_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 73 * 256 + i.val))
      kernelWitness0Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_73

theorem kernelBlock_0_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 74 * 256 + i.val))
      kernelWitness0Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_74

theorem kernelBlock_0_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 75 * 256 + i.val))
      kernelWitness0Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_75

theorem kernelBlock_0_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 76 * 256 + i.val))
      kernelWitness0Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_76

theorem kernelBlock_0_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 77 * 256 + i.val))
      kernelWitness0Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_77

theorem kernelBlock_0_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 78 * 256 + i.val))
      kernelWitness0Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_78

theorem kernelBlock_0_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 79 * 256 + i.val))
      kernelWitness0Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_79

theorem kernelBlock_0_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 80 * 256 + i.val))
      kernelWitness0Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_80

theorem kernelBlock_0_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 81 * 256 + i.val))
      kernelWitness0Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_81

theorem kernelBlock_0_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 82 * 256 + i.val))
      kernelWitness0Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_82

theorem kernelBlock_0_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 83 * 256 + i.val))
      kernelWitness0Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_83

theorem kernelBlock_0_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 84 * 256 + i.val))
      kernelWitness0Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_84

theorem kernelBlock_0_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 85 * 256 + i.val))
      kernelWitness0Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_85

theorem kernelBlock_0_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 86 * 256 + i.val))
      kernelWitness0Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_86

theorem kernelBlock_0_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 87 * 256 + i.val))
      kernelWitness0Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_87

theorem kernelBlock_0_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 88 * 256 + i.val))
      kernelWitness0Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_88

theorem kernelBlock_0_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 89 * 256 + i.val))
      kernelWitness0Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_89

theorem kernelBlock_0_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 90 * 256 + i.val))
      kernelWitness0Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_90

theorem kernelBlock_0_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 91 * 256 + i.val))
      kernelWitness0Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_91

theorem kernelBlock_0_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 92 * 256 + i.val))
      kernelWitness0Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_92

theorem kernelBlock_0_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 93 * 256 + i.val))
      kernelWitness0Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_93

theorem kernelBlock_0_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 94 * 256 + i.val))
      kernelWitness0Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_94

theorem kernelBlock_0_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (0 * 32768 + 95 * 256 + i.val))
      kernelWitness0Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_0_95

end TightCycleC5.Bridge.Cover
