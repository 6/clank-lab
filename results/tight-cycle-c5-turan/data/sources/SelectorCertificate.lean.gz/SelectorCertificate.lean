import SelectorRows
import CLCertificate

/-! Literal selector semantics from PROOF §3a, Lemmas 7–8. -/
namespace TightCycleC5.Bridge.SelectorCertificate
open Finset

structure Descriptor where
  rootEdge : Bool
  probability : Fin 8 → ℝ

def twoPolynomial (a b d : ℝ) : ℝ :=
  (1 - a) * b * d + a * (1 - b) * d + a * b * (1 - d)

theorem probability_triple {n : Nat} (π : Fin n → ℝ) (a b d : Fin n)
    (hab : a ≠ b) (had : a ≠ d) (hbd : b ≠ d) :
    exactlyTwoProbability π {a, b, d} = twoPolynomial (π a) (π b) (π d) := by
  simp [exactlyTwoProbability, twoPolynomial, Finset.erase_insert_of_ne, hab, had, hbd]
  ring

theorem twoPolynomial_bounds (a b d : ℝ) (ha : 0 ≤ a ∧ a ≤ 1)
    (hb : 0 ≤ b ∧ b ≤ 1) (hd : 0 ≤ d ∧ d ≤ 1) :
    0 ≤ twoPolynomial a b d ∧ twoPolynomial a b d ≤ 1 := by
  rcases ha with ⟨ha0, ha1⟩
  rcases hb with ⟨hb0, hb1⟩
  rcases hd with ⟨hd0, hd1⟩
  have ha' : 0 ≤ 1 - a := sub_nonneg.mpr ha1
  have hb' : 0 ≤ 1 - b := sub_nonneg.mpr hb1
  have hd' : 0 ≤ 1 - d := sub_nonneg.mpr hd1
  constructor
  · unfold twoPolynomial
    positivity
  · have h0 : 0 ≤ (1 - a) * (1 - b) * (1 - d) := by positivity
    have h1 : 0 ≤ a * (1 - b) * (1 - d) := by positivity
    have h2 : 0 ≤ (1 - a) * b * (1 - d) := by positivity
    have h3 : 0 ≤ (1 - a) * (1 - b) * d := by positivity
    have h4 : 0 ≤ a * b * d := by positivity
    unfold twoPolynomial
    nlinarith

def patternIndex {V : Type*} (e : V → V → V → Bool) (x u v z : V) : Fin 8 :=
  ⟨CLCertificate.pattern e x u v z, CLCertificate.pattern_lt e x u v z⟩

def rootIndicator {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (root : Fin 3 ↪ Fin n) : ℝ :=
  if CLCertificate.actualEdge H (root 0) (root 1) (root 2) = d.rootEdge then 1 else 0

def probabilities {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (root : Fin 3 ↪ Fin n) (z : Fin n) : ℝ :=
  d.probability (patternIndex (CLCertificate.actualEdge H) (root 0) (root 1) (root 2) z)

def evaluate {V : Type*} (d : Descriptor) (e : V → V → V → Bool)
    (x u v a b z : V) : ℝ :=
  (if e x u v = d.rootEdge then 1 else 0) *
    (if e a b z then 1 else 0) *
    twoPolynomial (d.probability (patternIndex e x u v a))
      (d.probability (patternIndex e x u v b))
      (d.probability (patternIndex e x u v z))

def numerator (d : Descriptor) (G : LabelledStructure 6) : ℝ :=
  evaluate d (fun a b c => G.edge {a, b, c}) 0 1 2 3 4 5

def denominator (d : Descriptor) (G : LabelledStructure 6) : ℝ :=
  if G.edge {0, 1, 2} = d.rootEdge then 1 else 0

theorem numerator_bounds (d : Descriptor)
    (h0 : ∀ p, 0 ≤ d.probability p) (h1 : ∀ p, d.probability p ≤ 1)
    (G : LabelledStructure 6) :
    0 ≤ numerator d G ∧ numerator d G ≤ denominator d G := by
  have h := twoPolynomial_bounds
    (d.probability (patternIndex (fun a b c => G.edge {a, b, c}) 0 1 2 3))
    (d.probability (patternIndex (fun a b c => G.edge {a, b, c}) 0 1 2 4))
    (d.probability (patternIndex (fun a b c => G.edge {a, b, c}) 0 1 2 5))
    ⟨h0 _, h1 _⟩ ⟨h0 _, h1 _⟩ ⟨h0 _, h1 _⟩
  unfold numerator evaluate denominator
  split_ifs <;> simp_all

theorem rootIndicator_zero_one {n : Nat} (d : Descriptor)
    (H : Finset (Finset (Fin n))) (root : Fin 3 ↪ Fin n) :
    rootIndicator d H root = 0 ∨ rootIndicator d H root = 1 := by
  unfold rootIndicator
  split_ifs <;> simp

theorem numerator_sample {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) :
    numerator d (sampleStructure σ H S) = evaluate d (CLCertificate.actualEdge H)
      (σ 0) (σ 1) (σ 2) (σ 3) (σ 4) (σ 5) := by
  have he : (fun a b c => (sampleStructure σ H S).edge {a, b, c}) =
      (fun a b c => CLCertificate.actualEdge H (σ a) (σ b) (σ c)) := by
    funext a b c
    simp [sampleStructure, CLCertificate.actualEdge]
  unfold numerator
  rw [he]
  rfl

theorem numerator_join {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (root : Fin 3 ↪ Fin n) (free : Fin 3 ↪ Outside root) :
    numerator d (sampleStructure (joinSample root free) H S) =
      rootIndicator d H root * selectorTriple H (probabilities d H root)
        (free.trans ⟨Subtype.val, Subtype.val_injective⟩) := by
  rw [numerator_sample]
  change evaluate d (CLCertificate.actualEdge H)
    (joinSample root free (Fin.castAdd 3 (0 : Fin 3)))
    (joinSample root free (Fin.castAdd 3 (1 : Fin 3)))
    (joinSample root free (Fin.castAdd 3 (2 : Fin 3)))
    (joinSample root free (Fin.natAdd 3 (0 : Fin 3)))
    (joinSample root free (Fin.natAdd 3 (1 : Fin 3)))
    (joinSample root free (Fin.natAdd 3 (2 : Fin 3))) = _
  simp only [joinSample_root, joinSample_free]
  let f : Fin 3 ↪ Fin n := free.trans ⟨Subtype.val, Subtype.val_injective⟩
  have hset : embeddingSet f = {f 0, f 1, f 2} := by
    ext a
    simp [embeddingSet, Fin.exists_fin_succ, eq_comm]
  have hprob := probability_triple (probabilities d H root) (f 0) (f 1) (f 2)
    (f.injective.ne (by decide)) (f.injective.ne (by decide)) (f.injective.ne (by decide))
  change _ = rootIndicator d H root * selectorTriple H (probabilities d H root) f
  unfold selectorTriple
  rw [hset, hprob]
  change (if CLCertificate.actualEdge H (root 0) (root 1) (root 2) = d.rootEdge then 1 else 0) *
    (if CLCertificate.actualEdge H (f 0) (f 1) (f 2) then 1 else 0) *
      twoPolynomial (probabilities d H root (f 0)) (probabilities d H root (f 1))
        (probabilities d H root (f 2)) = _
  unfold rootIndicator CLCertificate.actualEdge
  by_cases hr : decide ({root 0, root 1, root 2} ∈ H) = d.rootEdge <;>
    by_cases he : ({f 0, f 1, f 2} : Finset (Fin n)) ∈ H <;> simp [hr, he]

theorem numerator_as_selectorSixRow {n : Nat} (d : Descriptor)
    (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) :
    numerator d (sampleStructure σ H S) =
      selectorSixRow H (rootIndicator d H) (probabilities d H) σ := by
  have h := numerator_join d H S (splitSampleEquiv (r := 3) (f := 3) σ).1
    (splitSampleEquiv (r := 3) (f := 3) σ).2
  rw [joinSample_split] at h
  exact h

theorem numerator_mean {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) :
    uniformMean (fun σ : Fin 6 ↪ Fin n => numerator d (sampleStructure σ H S)) =
      selectorN H (rootIndicator d H) (probabilities d H) := by
  simp_rw [numerator_as_selectorSixRow]
  rfl

theorem denominator_mean {n : Nat} (d : Descriptor) (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (hn : 6 ≤ n) :
    uniformMean (fun σ : Fin 6 ↪ Fin n => denominator d (sampleStructure σ H S)) =
      selectorD (rootIndicator d H) := by
  convert selectorD_six_mean (rootIndicator d H) hn using 1
  congr 1
  funext σ
  change (if (sampleStructure σ H S).edge {0, 1, 2} = d.rootEdge then 1 else 0) =
    if CLCertificate.actualEdge H (σ 0) (σ 1) (σ 2) = d.rootEdge then 1 else 0
  simp [sampleStructure, CLCertificate.actualEdge]

theorem numerator_mean_le {n : Nat} (d : Descriptor)
    (h0 : ∀ p, 0 ≤ d.probability p) (h1 : ∀ p, d.probability p ≤ 1)
    (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H) (S : Finset (Fin n)) :
    uniformMean (fun σ : Fin 6 ↪ Fin n => numerator d (sampleStructure σ H S)) ≤
      6 * selectorD (rootIndicator d H) * (maxCut H : ℝ) /
        ((n - 3).descFactorial 3 : ℝ) := by
  rw [numerator_mean]
  exact selectorN_le_falling H hH (rootIndicator d H) (rootIndicator_zero_one d H)
    (probabilities d H) (fun _ _ => h0 _) (fun _ _ => h1 _)

#print axioms probability_triple
#print axioms twoPolynomial_bounds
#print axioms numerator_bounds
#print axioms rootIndicator_zero_one
#print axioms numerator_sample
#print axioms numerator_join
#print axioms numerator_as_selectorSixRow
#print axioms numerator_mean
#print axioms denominator_mean
#print axioms numerator_mean_le
end TightCycleC5.Bridge.SelectorCertificate
