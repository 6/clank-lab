import P33PSDData

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33PSD

theorem terms3_psd : ∀ k, (intMatrixReal (terms3 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector3x0
theorem terms3_diagonal : ∀ k i, terms3 k i i ≤ (diagBounds3 k : ℤ) := by
  decide +kernel
theorem psd3 : (intMatrixReal q3).PosSemidef :=
  integer_sos_posSemidef weights3 terms3 terms3_psd
theorem diagonal3 : ∀ i, q3 i i ≤ (m3 : ℤ) :=
  integer_sos_diagonal weights3 diagBounds3 terms3 terms3_diagonal
theorem normalized_psd3 : matrix3.PosSemidef :=
  scale_int_posSemidef q3 scale psd3
theorem normalized_diagonal3 : ∀ i, matrix3 i i ≤ bound3 :=
  scale_int_diagonal q3 scale m3 diagonal3
theorem normalized_nonneg3 : 0 ≤ bound3 :=
  scale_int_bound_nonneg scale m3 (Nat.cast_nonneg _)

#print axioms psd3
#print axioms diagonal3
#print axioms normalized_psd3
#print axioms normalized_diagonal3
#print axioms normalized_nonneg3
#print axioms terms3_psd
#print axioms terms3_diagonal

theorem terms9_psd : ∀ k, (intMatrixReal (terms9 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector9x0
  · exact int_outer_posSemidef vector9x1
  · exact int_outer_posSemidef vector9x2
  · exact int_outer_posSemidef vector9x3
  · exact int_outer_posSemidef vector9x4
  · exact int_outer_posSemidef vector9x5
  · exact int_outer_posSemidef vector9x6
  · exact int_outer_posSemidef vector9x7
  · exact int_outer_posSemidef vector9x8
  · exact int_outer_posSemidef vector9x9
  · exact int_outer_posSemidef vector9x10
  · exact int_outer_posSemidef vector9x11
  · exact int_outer_posSemidef vector9x12
  · exact int_outer_posSemidef vector9x13
theorem terms9_diagonal : ∀ k i, terms9 k i i ≤ (diagBounds9 k : ℤ) := by
  decide +kernel
theorem psd9 : (intMatrixReal q9).PosSemidef :=
  integer_sos_posSemidef weights9 terms9 terms9_psd
theorem diagonal9 : ∀ i, q9 i i ≤ (m9 : ℤ) :=
  integer_sos_diagonal weights9 diagBounds9 terms9 terms9_diagonal
theorem normalized_psd9 : matrix9.PosSemidef :=
  scale_int_posSemidef q9 scale psd9
theorem normalized_diagonal9 : ∀ i, matrix9 i i ≤ bound9 :=
  scale_int_diagonal q9 scale m9 diagonal9
theorem normalized_nonneg9 : 0 ≤ bound9 :=
  scale_int_bound_nonneg scale m9 (Nat.cast_nonneg _)

#print axioms psd9
#print axioms diagonal9
#print axioms normalized_psd9
#print axioms normalized_diagonal9
#print axioms normalized_nonneg9
#print axioms terms9_psd
#print axioms terms9_diagonal

theorem terms15_psd : ∀ k, (intMatrixReal (terms15 k)).PosSemidef := by
  intro k
  fin_cases k
theorem terms15_diagonal : ∀ k i, terms15 k i i ≤ (diagBounds15 k : ℤ) := by
  decide +kernel
theorem psd15 : (intMatrixReal q15).PosSemidef :=
  integer_sos_posSemidef weights15 terms15 terms15_psd
theorem diagonal15 : ∀ i, q15 i i ≤ (m15 : ℤ) :=
  integer_sos_diagonal weights15 diagBounds15 terms15 terms15_diagonal
theorem normalized_psd15 : matrix15.PosSemidef :=
  scale_int_posSemidef q15 scale psd15
theorem normalized_diagonal15 : ∀ i, matrix15 i i ≤ bound15 :=
  scale_int_diagonal q15 scale m15 diagonal15
theorem normalized_nonneg15 : 0 ≤ bound15 :=
  scale_int_bound_nonneg scale m15 (Nat.cast_nonneg _)

#print axioms psd15
#print axioms diagonal15
#print axioms normalized_psd15
#print axioms normalized_diagonal15
#print axioms normalized_nonneg15
#print axioms terms15_psd
#print axioms terms15_diagonal

theorem terms21_psd : ∀ k, (intMatrixReal (terms21 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector21x0
  · exact int_outer_posSemidef vector21x1
  · exact int_outer_posSemidef vector21x2
  · exact int_outer_posSemidef vector21x3
  · exact int_outer_posSemidef vector21x4
  · exact int_outer_posSemidef vector21x5
  · exact int_outer_posSemidef vector21x6
  · exact int_outer_posSemidef vector21x7
  · exact int_outer_posSemidef vector21x8
  · exact int_outer_posSemidef vector21x9
theorem terms21_diagonal : ∀ k i, terms21 k i i ≤ (diagBounds21 k : ℤ) := by
  decide +kernel
theorem psd21 : (intMatrixReal q21).PosSemidef :=
  integer_sos_posSemidef weights21 terms21 terms21_psd
theorem diagonal21 : ∀ i, q21 i i ≤ (m21 : ℤ) :=
  integer_sos_diagonal weights21 diagBounds21 terms21 terms21_diagonal
theorem normalized_psd21 : matrix21.PosSemidef :=
  scale_int_posSemidef q21 scale psd21
theorem normalized_diagonal21 : ∀ i, matrix21 i i ≤ bound21 :=
  scale_int_diagonal q21 scale m21 diagonal21
theorem normalized_nonneg21 : 0 ≤ bound21 :=
  scale_int_bound_nonneg scale m21 (Nat.cast_nonneg _)

#print axioms psd21
#print axioms diagonal21
#print axioms normalized_psd21
#print axioms normalized_diagonal21
#print axioms normalized_nonneg21
#print axioms terms21_psd
#print axioms terms21_diagonal

theorem terms27_psd : ∀ k, (intMatrixReal (terms27 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector27x0
  · exact int_outer_posSemidef vector27x1
  · exact int_outer_posSemidef vector27x2
  · exact int_outer_posSemidef vector27x3
  · exact int_outer_posSemidef vector27x4
  · exact int_outer_posSemidef vector27x5
  · exact int_outer_posSemidef vector27x6
  · exact int_outer_posSemidef vector27x7
  · exact int_outer_posSemidef vector27x8
  · exact int_outer_posSemidef vector27x9
  · exact int_outer_posSemidef vector27x10
  · exact int_outer_posSemidef vector27x11
  · exact int_outer_posSemidef vector27x12
theorem terms27_diagonal : ∀ k i, terms27 k i i ≤ (diagBounds27 k : ℤ) := by
  decide +kernel
theorem psd27 : (intMatrixReal q27).PosSemidef :=
  integer_sos_posSemidef weights27 terms27 terms27_psd
theorem diagonal27 : ∀ i, q27 i i ≤ (m27 : ℤ) :=
  integer_sos_diagonal weights27 diagBounds27 terms27 terms27_diagonal
theorem normalized_psd27 : matrix27.PosSemidef :=
  scale_int_posSemidef q27 scale psd27
theorem normalized_diagonal27 : ∀ i, matrix27 i i ≤ bound27 :=
  scale_int_diagonal q27 scale m27 diagonal27
theorem normalized_nonneg27 : 0 ≤ bound27 :=
  scale_int_bound_nonneg scale m27 (Nat.cast_nonneg _)

#print axioms psd27
#print axioms diagonal27
#print axioms normalized_psd27
#print axioms normalized_diagonal27
#print axioms normalized_nonneg27
#print axioms terms27_psd
#print axioms terms27_diagonal

theorem terms33_psd : ∀ k, (intMatrixReal (terms33 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector33x0
  · exact int_outer_posSemidef vector33x1
  · exact int_outer_posSemidef vector33x2
  · exact int_outer_posSemidef vector33x3
theorem terms33_diagonal : ∀ k i, terms33 k i i ≤ (diagBounds33 k : ℤ) := by
  decide +kernel
theorem psd33 : (intMatrixReal q33).PosSemidef :=
  integer_sos_posSemidef weights33 terms33 terms33_psd
theorem diagonal33 : ∀ i, q33 i i ≤ (m33 : ℤ) :=
  integer_sos_diagonal weights33 diagBounds33 terms33 terms33_diagonal
theorem normalized_psd33 : matrix33.PosSemidef :=
  scale_int_posSemidef q33 scale psd33
theorem normalized_diagonal33 : ∀ i, matrix33 i i ≤ bound33 :=
  scale_int_diagonal q33 scale m33 diagonal33
theorem normalized_nonneg33 : 0 ≤ bound33 :=
  scale_int_bound_nonneg scale m33 (Nat.cast_nonneg _)

#print axioms psd33
#print axioms diagonal33
#print axioms normalized_psd33
#print axioms normalized_diagonal33
#print axioms normalized_nonneg33
#print axioms terms33_psd
#print axioms terms33_diagonal

end TightCycleC5.Bridge.P33PSD
