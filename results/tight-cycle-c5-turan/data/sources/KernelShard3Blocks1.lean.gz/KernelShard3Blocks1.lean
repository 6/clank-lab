import KernelRowIndex
import KernelWitness3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_3_32 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 32 * 256 + i.val))
      kernelWitness3Row32[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_32

theorem kernelBlock_3_33 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 33 * 256 + i.val))
      kernelWitness3Row33[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_33

theorem kernelBlock_3_34 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 34 * 256 + i.val))
      kernelWitness3Row34[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_34

theorem kernelBlock_3_35 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 35 * 256 + i.val))
      kernelWitness3Row35[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_35

theorem kernelBlock_3_36 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 36 * 256 + i.val))
      kernelWitness3Row36[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_36

theorem kernelBlock_3_37 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 37 * 256 + i.val))
      kernelWitness3Row37[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_37

theorem kernelBlock_3_38 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 38 * 256 + i.val))
      kernelWitness3Row38[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_38

theorem kernelBlock_3_39 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 39 * 256 + i.val))
      kernelWitness3Row39[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_39

theorem kernelBlock_3_40 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 40 * 256 + i.val))
      kernelWitness3Row40[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_40

theorem kernelBlock_3_41 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 41 * 256 + i.val))
      kernelWitness3Row41[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_41

theorem kernelBlock_3_42 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 42 * 256 + i.val))
      kernelWitness3Row42[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_42

theorem kernelBlock_3_43 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 43 * 256 + i.val))
      kernelWitness3Row43[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_43

theorem kernelBlock_3_44 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 44 * 256 + i.val))
      kernelWitness3Row44[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_44

theorem kernelBlock_3_45 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 45 * 256 + i.val))
      kernelWitness3Row45[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_45

theorem kernelBlock_3_46 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 46 * 256 + i.val))
      kernelWitness3Row46[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_46

theorem kernelBlock_3_47 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 47 * 256 + i.val))
      kernelWitness3Row47[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_47

theorem kernelBlock_3_48 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 48 * 256 + i.val))
      kernelWitness3Row48[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_48

theorem kernelBlock_3_49 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 49 * 256 + i.val))
      kernelWitness3Row49[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_49

theorem kernelBlock_3_50 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 50 * 256 + i.val))
      kernelWitness3Row50[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_50

theorem kernelBlock_3_51 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 51 * 256 + i.val))
      kernelWitness3Row51[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_51

theorem kernelBlock_3_52 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 52 * 256 + i.val))
      kernelWitness3Row52[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_52

theorem kernelBlock_3_53 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 53 * 256 + i.val))
      kernelWitness3Row53[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_53

theorem kernelBlock_3_54 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 54 * 256 + i.val))
      kernelWitness3Row54[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_54

theorem kernelBlock_3_55 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 55 * 256 + i.val))
      kernelWitness3Row55[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_55

theorem kernelBlock_3_56 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 56 * 256 + i.val))
      kernelWitness3Row56[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_56

theorem kernelBlock_3_57 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 57 * 256 + i.val))
      kernelWitness3Row57[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_57

theorem kernelBlock_3_58 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 58 * 256 + i.val))
      kernelWitness3Row58[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_58

theorem kernelBlock_3_59 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 59 * 256 + i.val))
      kernelWitness3Row59[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_59

theorem kernelBlock_3_60 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 60 * 256 + i.val))
      kernelWitness3Row60[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_60

theorem kernelBlock_3_61 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 61 * 256 + i.val))
      kernelWitness3Row61[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_61

theorem kernelBlock_3_62 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 62 * 256 + i.val))
      kernelWitness3Row62[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_62

theorem kernelBlock_3_63 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (3 * 32768 + 63 * 256 + i.val))
      kernelWitness3Row63[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_3_63

end TightCycleC5.Bridge.Cover
