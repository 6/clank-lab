import TupleSampling

/-! Exact diagonal deletion for the CL rows. The two first-vertex
coincidences vanish; the leaf coincidence remains and must be bounded. -/

namespace TightCycleC5.Bridge

open Finset

variable {A : Type*} [Fintype A] [DecidableEq A]

omit [Fintype A] in
theorem offDiag_eq_filter (s : Finset A) :
    s.offDiag = (s ×ˢ s).filter (fun p => p.1 ≠ p.2) := by
  ext p
  simp [mem_offDiag, and_assoc]

/-- Separating the sole surviving repeated-vertex contribution. -/
theorem triple_diagonal_identity (v : A → A → A → ℝ)
    (h01 : ∀ a b, v a a b = 0) (h02 : ∀ a b, v a b a = 0) :
    (∑ a, ∑ b, ∑ c, v a b c) =
      (∑ t ∈ distinctTriples (univ : Finset A), v t.1 t.2.1 t.2.2) +
      ∑ p ∈ (univ : Finset A).offDiag, v p.1 p.2 p.2 := by
  have hpoint : ∀ a b c, v a b c =
      (if a ≠ b ∧ a ≠ c ∧ b ≠ c then v a b c else 0) +
      (if a ≠ b ∧ c = b then v a b b else 0) := by
    intro a b c
    by_cases hab : a = b
    · subst b
      simp [h01]
    by_cases hac : a = c
    · subst c
      simp [h02, hab]
    by_cases hbc : b = c
    · subst c
      simp [hab]
    simp [hab, hac, hbc, Ne.symm hbc]
  have hsum := Finset.sum_congr (s₁ := (univ : Finset A)) rfl (fun a _ =>
    Finset.sum_congr (s₁ := (univ : Finset A)) rfl (fun b _ =>
      Finset.sum_congr (s₁ := (univ : Finset A)) rfl (fun c _ => hpoint a b c)))
  simp only [Finset.sum_add_distrib] at hsum
  rw [hsum]
  congr 1
  · simp only [distinctTriples, Finset.sum_filter, Finset.sum_product]
  · rw [offDiag_eq_filter, Finset.sum_filter, Finset.sum_product]
    apply Finset.sum_congr rfl
    intro a _
    apply Finset.sum_congr rfl
    intro b _
    by_cases hab : a = b <;> simp [hab]

/-- CL diagonal deletion before normalization. The diagonal bound is an
upper bound only; the graph-specific CL theorem supplies the full-sum
nonnegativity. -/
theorem distinct_triple_sum_lower (v : A → A → A → ℝ)
    (h01 : ∀ a b, v a a b = 0) (h02 : ∀ a b, v a b a = 0)
    (hdiag : ∀ a b, a ≠ b → v a b b ≤ 1)
    (hfull : 0 ≤ ∑ a, ∑ b, ∑ c, v a b c) :
    -((Fintype.card A : ℝ) * ((Fintype.card A : ℝ) - 1)) ≤
      ∑ t ∈ distinctTriples (univ : Finset A), v t.1 t.2.1 t.2.2 := by
  have hloss : (∑ p ∈ (univ : Finset A).offDiag, v p.1 p.2 p.2) ≤
      (Fintype.card A : ℝ) * ((Fintype.card A : ℝ) - 1) := by
    calc
      _ ≤ ∑ _p ∈ (univ : Finset A).offDiag, (1 : ℝ) :=
        Finset.sum_le_sum (fun p hp => hdiag _ _ (mem_offDiag.mp hp).2.2)
      _ = _ := by
        rw [Finset.sum_const, nsmul_eq_mul, mul_one, offDiag_card_real, card_univ]
  rw [triple_diagonal_identity v h01 h02] at hfull
  linarith

/-- Exact finite CL error for any kernel with the stated diagonal
structure. At k free vertices it is -1/(k-2), not zero. -/
theorem distinct_triple_mean_lower (v : A → A → A → ℝ) (hk : 3 ≤ Fintype.card A)
    (h01 : ∀ a b, v a a b = 0) (h02 : ∀ a b, v a b a = 0)
    (hdiag : ∀ a b, a ≠ b → v a b b ≤ 1)
    (hfull : 0 ≤ ∑ a, ∑ b, ∑ c, v a b c) :
    -(1 / ((Fintype.card A : ℝ) - 2)) ≤
      uniformMean (fun σ : Fin 3 ↪ A => v (σ 0) (σ 1) (σ 2)) := by
  rw [triple_injection_mean, distinctTriples_card_real hk]
  have hkR : (3 : ℝ) ≤ Fintype.card A := by exact_mod_cast hk
  have hd : 0 < (Fintype.card A : ℝ) * ((Fintype.card A : ℝ) - 1) *
      ((Fintype.card A : ℝ) - 2) :=
    mul_pos (mul_pos (by linarith) (by linarith)) (by linarith)
  apply (le_div_iff₀ hd).mpr
  calc
    _ = -((Fintype.card A : ℝ) * ((Fintype.card A : ℝ) - 1)) := by
      have h2 : (Fintype.card A : ℝ) - 2 ≠ 0 := by linarith
      field_simp
    _ ≤ _ := distinct_triple_sum_lower v h01 h02 hdiag hfull

#print axioms offDiag_eq_filter
#print axioms triple_diagonal_identity
#print axioms distinct_triple_sum_lower
#print axioms distinct_triple_mean_lower

end TightCycleC5.Bridge
