import KernelCoverAll
import ColoredCoverFinite

/-! Concrete P33 coverage using the kernel-only P32 cover and the accepted
53,440 coloured finite witnesses. The class selector belongs to this cover. -/
namespace TightCycleC5.Bridge.KernelColoredCover
open Finset MaskEncoding

/-- The same stored coloured representatives as the accepted finite table. -/
def p33ClassRep (k : Fin 40547) : LabelledStructure 6 := ColoredCover.classRep k

theorem p33_mask_cover (m : BitVec 20) (c : BitVec 6) (hC : ¬ CodeContainsC5 m) :
    ∃ l : Fin 40547, ∃ p : Equiv.Perm (Fin 6), decodeStructure m c = p • p33ClassRep l := by
  obtain ⟨k, p, hp⟩ := Cover.p32_kernel_mask_cover m hC
  let c' := permuteColor p.symm c
  let ci : Fin 64 := ⟨c'.toNat, c'.toFin.isLt⟩
  have hc : BitVec.ofNat 6 ci.val = c' := by simp [ci]
  have hw := ColoredCover.colored_finite k ci
  rw [hc] at hw
  obtain ⟨l, q, hq⟩ := ColoredCover.witness_sound k c' _ hw
  change decodeStructure (Cover.representative k) c' = q • p33ClassRep l at hq
  refine ⟨l, p * q, ?_⟩
  calc
    decodeStructure m c = p • decodeStructure (Cover.representative k) c' := by
      rw [hp]
      simpa only [c', ColoredCover.permuteColor_cancel] using
        decode_permute p (Cover.representative k) c'
    _ = p • (q • p33ClassRep l) := by rw [hq]
    _ = (p * q) • p33ClassRep l := (mul_smul p q _).symm

theorem p33_sample_cover {n : ℕ} (σ : Fin 6 ↪ Fin n)
    {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H)
    (S : Finset (Fin n)) :
    ∃ l : Fin 40547, ∃ p : Equiv.Perm (Fin 6), sampleStructure σ H S = p • p33ClassRep l := by
  obtain ⟨l, p, hp⟩ := p33_mask_cover (graphCode (sampleStructure σ H S))
    (colorCode (sampleStructure σ H S)) (sample_code_c5free σ hH hC S)
  exact ⟨l, p, (encode_sample σ hH S).symm.trans hp⟩

noncomputable def p33ClassOf {n : ℕ} {H : Finset (Finset (Fin n))}
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (S : Finset (Fin n))
    (σ : Fin 6 ↪ Fin n) : Fin 40547 :=
  Classical.choose (p33_sample_cover σ hH hC S)

theorem p33_classOf_cover {n : ℕ} {H : Finset (Finset (Fin n))}
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (S : Finset (Fin n)) :
    ∀ σ : Fin 6 ↪ Fin n, ∃ p : Equiv.Perm (Fin 6),
      sampleStructure σ H S = p • p33ClassRep (p33ClassOf hH hC S σ) := by
  intro σ
  exact Classical.choose_spec (p33_sample_cover σ hH hC S)

theorem p33_class_probability {n : ℕ} (hn : 6 ≤ n)
    {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H)
    (S : Finset (Fin n)) :
    (∀ k, 0 ≤ classMass (p33ClassOf hH hC S) k) ∧
      ∑ k, classMass (p33ClassOf hH hC S) k = 1 :=
  six_class_probability hn (p33ClassOf hH hC S)

theorem p33_class_expansion {n : ℕ} {H : Finset (Finset (Fin n))}
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (S : Finset (Fin n))
    (row : LabelledStructure 6 → ℝ) :
    uniformMean (fun σ : Fin 6 ↪ Fin n => row (sampleStructure σ H S)) =
      ∑ k, classMass (p33ClassOf hH hC S) k *
        uniformMean (fun p : Equiv.Perm (Fin 6) => row (p • p33ClassRep k)) :=
  six_class_expansion H S (p33ClassOf hH hC S) p33ClassRep (p33_classOf_cover hH hC S) row

#print axioms p33_mask_cover
#print axioms p33_sample_cover
#print axioms p33_classOf_cover
#print axioms p33_class_probability
#print axioms p33_class_expansion
end TightCycleC5.Bridge.KernelColoredCover
