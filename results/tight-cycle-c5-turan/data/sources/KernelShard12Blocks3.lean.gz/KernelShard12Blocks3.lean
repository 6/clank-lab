import KernelRowIndex
import KernelWitness12

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_12_96 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 96 * 256 + i.val))
      kernelWitness12Row96[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_96

theorem kernelBlock_12_97 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 97 * 256 + i.val))
      kernelWitness12Row97[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_97

theorem kernelBlock_12_98 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 98 * 256 + i.val))
      kernelWitness12Row98[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_98

theorem kernelBlock_12_99 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 99 * 256 + i.val))
      kernelWitness12Row99[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_99

theorem kernelBlock_12_100 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 100 * 256 + i.val))
      kernelWitness12Row100[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_100

theorem kernelBlock_12_101 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 101 * 256 + i.val))
      kernelWitness12Row101[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_101

theorem kernelBlock_12_102 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 102 * 256 + i.val))
      kernelWitness12Row102[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_102

theorem kernelBlock_12_103 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 103 * 256 + i.val))
      kernelWitness12Row103[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_103

theorem kernelBlock_12_104 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 104 * 256 + i.val))
      kernelWitness12Row104[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_104

theorem kernelBlock_12_105 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 105 * 256 + i.val))
      kernelWitness12Row105[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_105

theorem kernelBlock_12_106 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 106 * 256 + i.val))
      kernelWitness12Row106[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_106

theorem kernelBlock_12_107 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 107 * 256 + i.val))
      kernelWitness12Row107[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_107

theorem kernelBlock_12_108 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 108 * 256 + i.val))
      kernelWitness12Row108[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_108

theorem kernelBlock_12_109 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 109 * 256 + i.val))
      kernelWitness12Row109[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_109

theorem kernelBlock_12_110 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 110 * 256 + i.val))
      kernelWitness12Row110[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_110

theorem kernelBlock_12_111 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 111 * 256 + i.val))
      kernelWitness12Row111[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_111

theorem kernelBlock_12_112 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 112 * 256 + i.val))
      kernelWitness12Row112[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_112

theorem kernelBlock_12_113 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 113 * 256 + i.val))
      kernelWitness12Row113[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_113

theorem kernelBlock_12_114 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 114 * 256 + i.val))
      kernelWitness12Row114[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_114

theorem kernelBlock_12_115 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 115 * 256 + i.val))
      kernelWitness12Row115[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_115

theorem kernelBlock_12_116 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 116 * 256 + i.val))
      kernelWitness12Row116[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_116

theorem kernelBlock_12_117 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 117 * 256 + i.val))
      kernelWitness12Row117[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_117

theorem kernelBlock_12_118 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 118 * 256 + i.val))
      kernelWitness12Row118[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_118

theorem kernelBlock_12_119 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 119 * 256 + i.val))
      kernelWitness12Row119[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_119

theorem kernelBlock_12_120 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 120 * 256 + i.val))
      kernelWitness12Row120[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_120

theorem kernelBlock_12_121 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 121 * 256 + i.val))
      kernelWitness12Row121[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_121

theorem kernelBlock_12_122 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 122 * 256 + i.val))
      kernelWitness12Row122[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_122

theorem kernelBlock_12_123 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 123 * 256 + i.val))
      kernelWitness12Row123[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_123

theorem kernelBlock_12_124 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 124 * 256 + i.val))
      kernelWitness12Row124[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_124

theorem kernelBlock_12_125 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 125 * 256 + i.val))
      kernelWitness12Row125[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_125

theorem kernelBlock_12_126 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 126 * 256 + i.val))
      kernelWitness12Row126[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_126

theorem kernelBlock_12_127 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (12 * 32768 + 127 * 256 + i.val))
      kernelWitness12Row127[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_12_127

end TightCycleC5.Bridge.Cover
