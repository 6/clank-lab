import P32FlagData
import P32FlagSemantics
import P32Normalized

/-! Literal P32 matrix-coordinate rows, with exact frozen flag bases.
All identities in this module have only standard axioms. -/
namespace TightCycleC5.Bridge.P32Flag
open Finset Matrix

def flag0 {n : ℕ} (G : Finset (Finset (Fin n)))
    (root : Fin 4 ↪ Fin n) (z : Outside root) : Option (Fin 64) :=
  flagLookup code0 (fourKey G root z.val)

noncomputable def row0 {n : ℕ} (G : Finset (Finset (Fin n))) :
    (Fin 6 ↪ Fin n) → ℝ := literalFourRow 0 P32PSD.matrix0 code0 G

theorem row0_eq {n : ℕ} (G : Finset (Finset (Fin n))) :
    row0 G = psdFourRootSixRow (zeroExtend P32PSD.matrix0) (flag0 G)
      (fun root => rootIndicator 0 G root) :=
  literalFourRow_eq 0 P32PSD.matrix0 code0 injective0 G

def flag1 {n : ℕ} (G : Finset (Finset (Fin n)))
    (root : Fin 4 ↪ Fin n) (z : Outside root) : Option (Fin 64) :=
  flagLookup code1 (fourKey G root z.val)

noncomputable def row1 {n : ℕ} (G : Finset (Finset (Fin n))) :
    (Fin 6 ↪ Fin n) → ℝ := literalFourRow 1 P32PSD.matrix1 code1 G

theorem row1_eq {n : ℕ} (G : Finset (Finset (Fin n))) :
    row1 G = psdFourRootSixRow (zeroExtend P32PSD.matrix1) (flag1 G)
      (fun root => rootIndicator 1 G root) :=
  literalFourRow_eq 1 P32PSD.matrix1 code1 injective1 G

def flag2 {n : ℕ} (G : Finset (Finset (Fin n)))
    (root : Fin 4 ↪ Fin n) (z : Outside root) : Option (Fin 50) :=
  flagLookup code2 (fourKey G root z.val)

noncomputable def row2 {n : ℕ} (G : Finset (Finset (Fin n))) :
    (Fin 6 ↪ Fin n) → ℝ := literalFourRow 2 P32PSD.matrix2 code2 G

theorem row2_eq {n : ℕ} (G : Finset (Finset (Fin n))) :
    row2 G = psdFourRootSixRow (zeroExtend P32PSD.matrix2) (flag2 G)
      (fun root => rootIndicator 2 G root) :=
  literalFourRow_eq 2 P32PSD.matrix2 code2 injective2 G

def flag3 {n : ℕ} (G : Finset (Finset (Fin n)))
    (root : Fin 4 ↪ Fin n) (z : Outside root) : Option (Fin 39) :=
  flagLookup code3 (fourKey G root z.val)

noncomputable def row3 {n : ℕ} (G : Finset (Finset (Fin n))) :
    (Fin 6 ↪ Fin n) → ℝ := literalFourRow 3 P32PSD.matrix3 code3 G

theorem row3_eq {n : ℕ} (G : Finset (Finset (Fin n))) :
    row3 G = psdFourRootSixRow (zeroExtend P32PSD.matrix3) (flag3 G)
      (fun root => rootIndicator 3 G root) :=
  literalFourRow_eq 3 P32PSD.matrix3 code3 injective3 G

def flag4 {n : ℕ} (G : Finset (Finset (Fin n)))
    (root : Fin 4 ↪ Fin n) (z : Outside root) : Option (Fin 30) :=
  flagLookup code4 (fourKey G root z.val)

noncomputable def row4 {n : ℕ} (G : Finset (Finset (Fin n))) :
    (Fin 6 ↪ Fin n) → ℝ := literalFourRow 4 P32PSD.matrix4 code4 G

theorem row4_eq {n : ℕ} (G : Finset (Finset (Fin n))) :
    row4 G = psdFourRootSixRow (zeroExtend P32PSD.matrix4) (flag4 G)
      (fun root => rootIndicator 4 G root) :=
  literalFourRow_eq 4 P32PSD.matrix4 code4 injective4 G

def flag5 {n : ℕ} (G : Finset (Finset (Fin n)))
    (root : Fin 2 ↪ Fin n) (p : Outside root × Outside root) : Option (Fin 12) :=
  flagLookup code5 (twoKey G root p.1.val p.2.val)

noncomputable def row5 {n : ℕ} (G : Finset (Finset (Fin n))) :
    (Fin 6 ↪ Fin n) → ℝ := literalTwoRow P32PSD.matrix5 code5 G

theorem row5_eq {n : ℕ} (G : Finset (Finset (Fin n))) :
    row5 G = psdTwoRootSixRow (zeroExtend P32PSD.matrix5) (flag5 G) (fun _ => 1) :=
  literalTwoRow_eq P32PSD.matrix5 code5 injective5 G

#print axioms row0_eq
#print axioms row1_eq
#print axioms row2_eq
#print axioms row3_eq
#print axioms row4_eq
#print axioms row5_eq
end TightCycleC5.Bridge.P32Flag
