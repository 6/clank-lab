import RootIncidence
import OutsideRootPartition
import PairDeletion

/-! The exact degree/codegree cancellation in PROOF §3 Lemma 6. -/
namespace TightCycleC5.Bridge
open Finset
variable {n : ℕ}

def edgeIndicator (H : Finset (Finset (Fin n))) (x u v : Fin n) : ℝ :=
  if ({x, u, v} : Finset (Fin n)) ∈ H then 1 else 0

def linkDifference (H : Finset (Finset (Fin n))) (x u v a : Fin n) : ℝ :=
  edgeIndicator H x v a - edgeIndicator H u v a

theorem edgeIndicator_swap01 (H : Finset (Finset (Fin n))) (x u v : Fin n) :
    edgeIndicator H x u v = edgeIndicator H u x v := by
  have he : ({x, u, v} : Finset (Fin n)) = {u, x, v} := by ext a; simp; tauto
  simp only [edgeIndicator, he]

theorem edgeIndicator_swap02 (H : Finset (Finset (Fin n))) (x u v : Fin n) :
    edgeIndicator H x u v = edgeIndicator H v u x := by
  have he : ({x, u, v} : Finset (Fin n)) = {v, u, x} := by ext a; simp; tauto
  simp only [edgeIndicator, he]

theorem edgeIndicator_repeat01 (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (x v : Fin n) : edgeIndicator H x x v = 0 := by
  simp [edgeIndicator, three_graph_no_pair hH x v]

theorem edgeIndicator_repeat02 (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (x u : Fin n) : edgeIndicator H x u x = 0 := by
  simp [edgeIndicator, three_graph_no_pair hH u x]

theorem edgeIndicator_repeat12 (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (x u : Fin n) : edgeIndicator H x u u = 0 := by
  simp [edgeIndicator, three_graph_no_pair hH x u]

theorem linkDifference_abs_le (H : Finset (Finset (Fin n))) (x u v a : Fin n) :
    |linkDifference H x u v a| ≤ 1 := by
  unfold linkDifference edgeIndicator
  split_ifs <;> norm_num

theorem linkDifference_diagonal_zero (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (x u v : Fin n) : linkDifference H x u v v = 0 := by
  simp [linkDifference, edgeIndicator_repeat12 H hH]

theorem linkDifference_full_sum (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (x u : Fin n) :
    (∑ v, ∑ a, linkDifference H x u v a) = 2 * ((deg H x : ℝ) - (deg H u : ℝ)) := by
  simp only [linkDifference, edgeIndicator, Finset.sum_sub_distrib, root_pair_degree H hH]
  ring

/-- Terms with v or a in {x,u} cancel in aggregate, rather than being
silently deleted as though they vanished individually. -/
theorem linkDifference_outside_sum (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (root : Fin 2 ↪ Fin n) :
    (∑ v : Outside root, ∑ a : Outside root,
      linkDifference H (root 0) (root 1) v.val a.val) =
      2 * ((deg H (root 0) : ℝ) - (deg H (root 1) : ℝ)) := by
  rw [sum2_outside_two_cancel root (linkDifference H (root 0) (root 1))]
  · exact linkDifference_full_sum H hH (root 0) (root 1)
  · intro a
    simp only [linkDifference, edgeIndicator_repeat01 H hH, zero_sub, sub_zero]
    rw [edgeIndicator_swap01 H (root 1) (root 0) a]
    ring
  · intro v
    simp only [linkDifference, edgeIndicator_repeat02 H hH, zero_sub, sub_zero]
    rw [edgeIndicator_swap02 H (root 1) v (root 0)]
    ring

theorem linkDifference_outside_mean (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (hn : 12 ≤ n) (root : Fin 2 ↪ Fin n) :
    uniformMean (fun va : Fin 2 ↪ Outside root =>
      linkDifference H (root 0) (root 1) (va 0).val (va 1).val) =
      2 * ((deg H (root 0) : ℝ) - (deg H (root 1) : ℝ)) /
        (((n : ℝ) - 2) * ((n : ℝ) - 3)) := by
  classical
  rw [pair_injection_mean
    (fun v a : Outside root => linkDifference H (root 0) (root 1) v.val a.val)]
  have hs := pair_diagonal_identity
    (fun v a : Outside root => linkDifference H (root 0) (root 1) v.val a.val)
  simp only [linkDifference_diagonal_zero H hH, sum_const_zero, add_zero] at hs
  rw [← hs, linkDifference_outside_sum H hH root, offDiag_card_real, card_univ]
  have hcard : Fintype.card (Outside root) = n - 2 := by
    simpa only [Fintype.card_fin] using outside_card root
  have hcardR : (Fintype.card (Outside root) : ℝ) = (n : ℝ) - 2 := by
    rw [hcard, Nat.cast_sub (by omega : 2 ≤ n)]
    norm_num
  rw [hcardR]
  congr 2
  ring

#print axioms edgeIndicator_swap01
#print axioms edgeIndicator_swap02
#print axioms edgeIndicator_repeat01
#print axioms edgeIndicator_repeat02
#print axioms edgeIndicator_repeat12
#print axioms linkDifference_abs_le
#print axioms linkDifference_diagonal_zero
#print axioms linkDifference_full_sum
#print axioms linkDifference_outside_sum
#print axioms linkDifference_outside_mean
end TightCycleC5.Bridge
