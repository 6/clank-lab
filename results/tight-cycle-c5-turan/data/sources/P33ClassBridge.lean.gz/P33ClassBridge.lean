import P33UniformAveraging
import P33RowMatching
import P33RowMatchingAssembly
import P33PSDMatchingChecked
import P33ArithmeticAssembly

/-! Actual class arithmetic and row semantics for Theorem B. Only the
finite successful class checks remain as an explicit prerequisite. -/
namespace TightCycleC5.Bridge.P33ClassBridge
open Finset
set_option maxRecDepth 100000
set_option maxHeartbeats 2000000

theorem actual_nonPSD_eq (G : LabelledStructure 6) :
    P33RowMatching.actualNonPSD G = P33NonPSDRowBounds.rows G := by
  simpa only [P33NonPSDRowBounds.rows, P33NonPSDRowBounds.localRows,
    P33NonPSDRowBounds.cutRows, P33NonPSDRowBounds.densityRows,
    P33NonPSDRowBounds.regularRows, P33NonPSDRowBounds.clRows] using
    P33RowMatching.actualNonPSD_source_sum G

theorem actual_PSD_eq (G : LabelledStructure 6) :
    P33PSDMatching.totalRows G = P33PSDRowBounds.rows G := by
  simpa only [P33PSDRowBounds.rows] using P33PSDMatching.totalRows_eq_explicit G

theorem normalized_nuisance_match (K : P33Arithmetic.Class)
    (h : P33Arithmetic.classCheck K = true) (j : Fin 720) :
    (P33Arithmetic.denseNuisanceAt K (Cover.kernelPermutation j) : ℝ) /
      1000000000 / (P33Arithmetic.sosScale : ℝ) =
    P33UniformAveraging.nuisanceRows
      ((Cover.kernelPermutation j).symm • P33Arithmetic.decodedClass K) := by
  rw [← P33Arithmetic.nuisanceInteger_eq_dense,
    P33RowMatching.nuisanceInteger_decomposition, Int.cast_add, add_div, add_div]
  have hp := P33PSDMatching.classCheck_psdOrder K h j
  have hn := P33RowMatching.checked_nonPSD_match K h j
  have hp' : (P33Arithmetic.psdOrder P33Arithmetic.blocks K j : ℝ) /
      1000000000 / (P33Arithmetic.sosScale : ℝ) =
      P33PSDMatching.totalRows ((Cover.kernelPermutation j).symm •
        P33PSDMatching.decoded K.mask K.colours) := by
    simpa only [div_div] using hp
  rw [hp', hn, actual_PSD_eq, actual_nonPSD_eq]
  change P33PSDRowBounds.rows _ + P33NonPSDRowBounds.rows _ =
    P33NonPSDRowBounds.rows _ + P33PSDRowBounds.rows _
  exact add_comm _ _

theorem checked_class_mean (k : Fin 40547)
    (h : P33Arithmetic.classCheck (P33Arithmetic.classAt k) = true) :
    uniformMean (fun p : Equiv.Perm (Fin 6) =>
      P33Arithmetic.literalTarget (p • ColoredCover.classRep k) +
      P33UniformAveraging.nuisanceRows (p • ColoredCover.classRep k)) ≤ 0 := by
  have hc := P33Arithmetic.classCheck_sourceRow_mean_nonpos k h
    P33UniformAveraging.nuisanceRows
    (normalized_nuisance_match (P33Arithmetic.classAt k) h)
  simp only [P33Arithmetic.decodedClass_eq_classRep] at hc
  have he := Cover.PermutationEnumeration.uniformMean_kernelPermutation
    (fun p : Equiv.Perm (Fin 6) =>
      P33Arithmetic.literalTarget (p • ColoredCover.classRep k) +
      P33UniformAveraging.nuisanceRows (p • ColoredCover.classRep k))
  exact he ▸ hc

/-- PARTIAL until the complete finite replay supplies all genuine class
checks. No separate row matching, flag lookup or graph premise remains. -/
theorem p33_of_checked_classes
    (hchecks : ∀ k : Fin 40547,
      P33Arithmetic.classCheck (P33Arithmetic.classAt k) = true) : P33Statement :=
  P33UniformAveraging.p33_of_literal_class_means
    (fun k => checked_class_mean k (hchecks k))

#print axioms actual_nonPSD_eq
#print axioms actual_PSD_eq
#print axioms normalized_nuisance_match
#print axioms checked_class_mean
#print axioms p33_of_checked_classes
end TightCycleC5.Bridge.P33ClassBridge
