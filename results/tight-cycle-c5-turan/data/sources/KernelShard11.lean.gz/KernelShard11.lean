import KernelShard11Blocks0
import KernelShard11Blocks1
import KernelShard11Blocks2
import KernelShard11Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard11 : kernelShardCheck 11 kernelWitness11 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (11 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness11 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_11_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard11
end TightCycleC5.Bridge.Cover
