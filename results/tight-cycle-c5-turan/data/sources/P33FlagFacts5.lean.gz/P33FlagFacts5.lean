import P33FlagData
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace TightCycleC5.Bridge.P33Flag
open ColouredFlags

theorem basis5_size : basis5Data.size = 128 := by decide +kernel
theorem basis5_psd_data : ∀ i, basis5 i = P33PSD.flags5[i.val]! := by decide +kernel
theorem basis5_steps : ∀ i : Fin 127,
    basis5 i.castSucc < basis5 i.succ := by decide +kernel
theorem basis5_injective : Function.Injective basis5 :=
  (Fin.strictMono_iff_lt_succ.mpr basis5_steps).injective
theorem basis5_range : ∀ i, basis5 i < 32768 := by decide +kernel
theorem basis5_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis5 i))).toNat = type5 := by decide +kernel
#print axioms basis5_size
#print axioms basis5_psd_data
#print axioms basis5_steps
#print axioms basis5_injective
#print axioms basis5_range
#print axioms basis5_root

theorem basis11_size : basis11Data.size = 128 := by decide +kernel
theorem basis11_psd_data : ∀ i, basis11 i = P33PSD.flags11[i.val]! := by decide +kernel
theorem basis11_steps : ∀ i : Fin 127,
    basis11 i.castSucc < basis11 i.succ := by decide +kernel
theorem basis11_injective : Function.Injective basis11 :=
  (Fin.strictMono_iff_lt_succ.mpr basis11_steps).injective
theorem basis11_range : ∀ i, basis11 i < 32768 := by decide +kernel
theorem basis11_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis11 i))).toNat = type11 := by decide +kernel
#print axioms basis11_size
#print axioms basis11_psd_data
#print axioms basis11_steps
#print axioms basis11_injective
#print axioms basis11_range
#print axioms basis11_root

theorem basis17_size : basis17Data.size = 100 := by decide +kernel
theorem basis17_psd_data : ∀ i, basis17 i = P33PSD.flags17[i.val]! := by decide +kernel
theorem basis17_steps : ∀ i : Fin 99,
    basis17 i.castSucc < basis17 i.succ := by decide +kernel
theorem basis17_injective : Function.Injective basis17 :=
  (Fin.strictMono_iff_lt_succ.mpr basis17_steps).injective
theorem basis17_range : ∀ i, basis17 i < 32768 := by decide +kernel
theorem basis17_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis17 i))).toNat = type17 := by decide +kernel
#print axioms basis17_size
#print axioms basis17_psd_data
#print axioms basis17_steps
#print axioms basis17_injective
#print axioms basis17_range
#print axioms basis17_root

theorem basis23_size : basis23Data.size = 100 := by decide +kernel
theorem basis23_psd_data : ∀ i, basis23 i = P33PSD.flags23[i.val]! := by decide +kernel
theorem basis23_steps : ∀ i : Fin 99,
    basis23 i.castSucc < basis23 i.succ := by decide +kernel
theorem basis23_injective : Function.Injective basis23 :=
  (Fin.strictMono_iff_lt_succ.mpr basis23_steps).injective
theorem basis23_range : ∀ i, basis23 i < 32768 := by decide +kernel
theorem basis23_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis23 i))).toNat = type23 := by decide +kernel
#print axioms basis23_size
#print axioms basis23_psd_data
#print axioms basis23_steps
#print axioms basis23_injective
#print axioms basis23_range
#print axioms basis23_root

theorem basis29_size : basis29Data.size = 78 := by decide +kernel
theorem basis29_psd_data : ∀ i, basis29 i = P33PSD.flags29[i.val]! := by decide +kernel
theorem basis29_steps : ∀ i : Fin 77,
    basis29 i.castSucc < basis29 i.succ := by decide +kernel
theorem basis29_injective : Function.Injective basis29 :=
  (Fin.strictMono_iff_lt_succ.mpr basis29_steps).injective
theorem basis29_range : ∀ i, basis29 i < 32768 := by decide +kernel
theorem basis29_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis29 i))).toNat = type29 := by decide +kernel
#print axioms basis29_size
#print axioms basis29_psd_data
#print axioms basis29_steps
#print axioms basis29_injective
#print axioms basis29_range
#print axioms basis29_root

theorem basis35_size : basis35Data.size = 60 := by decide +kernel
theorem basis35_psd_data : ∀ i, basis35 i = P33PSD.flags35[i.val]! := by decide +kernel
theorem basis35_steps : ∀ i : Fin 59,
    basis35 i.castSucc < basis35 i.succ := by decide +kernel
theorem basis35_injective : Function.Injective basis35 :=
  (Fin.strictMono_iff_lt_succ.mpr basis35_steps).injective
theorem basis35_range : ∀ i, basis35 i < 32768 := by decide +kernel
theorem basis35_root : ∀ i,
    (rootCode5 (BitVec.ofNat 15 (basis35 i))).toNat = type35 := by decide +kernel
#print axioms basis35_size
#print axioms basis35_psd_data
#print axioms basis35_steps
#print axioms basis35_injective
#print axioms basis35_range
#print axioms basis35_root

end TightCycleC5.Bridge.P33Flag
