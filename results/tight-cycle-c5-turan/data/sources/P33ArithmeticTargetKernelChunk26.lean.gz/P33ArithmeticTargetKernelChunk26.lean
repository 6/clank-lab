-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk104 :
    ∀ i : Fin (min 128 (40547 - 128 * 104)),
      targetCountsMatch (classAt (targetKernelClass ⟨104, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk104

theorem target_counts_kernel_chunk105 :
    ∀ i : Fin (min 128 (40547 - 128 * 105)),
      targetCountsMatch (classAt (targetKernelClass ⟨105, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk105

theorem target_counts_kernel_chunk106 :
    ∀ i : Fin (min 128 (40547 - 128 * 106)),
      targetCountsMatch (classAt (targetKernelClass ⟨106, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk106

theorem target_counts_kernel_chunk107 :
    ∀ i : Fin (min 128 (40547 - 128 * 107)),
      targetCountsMatch (classAt (targetKernelClass ⟨107, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk107


end TightCycleC5.Bridge.P33Arithmetic
