import P33PSDMatchingRowsBase
import P33PSDMatchingEntries3
import P33FlagRows3
namespace TightCycleC5.Bridge.P33PSDMatching

theorem source_row3 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block3 K p) :
    (sourceContribution P33Arithmetic.block3 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row3 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block3 rfl P33PSD.q3 P33PSD.scale source_entry3
    P33Flag.basis3 P33Flag.basis3_injective rfl (fun _ => rfl) P33Flag.type3 rfl K p hv
#print axioms source_row3

theorem source_row9 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block9 K p) :
    (sourceContribution P33Arithmetic.block9 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row9 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block9 rfl P33PSD.q9 P33PSD.scale source_entry9
    P33Flag.basis9 P33Flag.basis9_injective rfl (fun _ => rfl) P33Flag.type9 rfl K p hv
#print axioms source_row9

theorem source_row15 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block15 K p) :
    (sourceContribution P33Arithmetic.block15 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row15 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block15 rfl P33PSD.q15 P33PSD.scale source_entry15
    P33Flag.basis15 P33Flag.basis15_injective rfl (fun _ => rfl) P33Flag.type15 rfl K p hv
#print axioms source_row15

theorem source_row21 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block21 K p) :
    (sourceContribution P33Arithmetic.block21 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row21 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block21 rfl P33PSD.q21 P33PSD.scale source_entry21
    P33Flag.basis21 P33Flag.basis21_injective rfl (fun _ => rfl) P33Flag.type21 rfl K p hv
#print axioms source_row21

theorem source_row27 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block27 K p) :
    (sourceContribution P33Arithmetic.block27 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row27 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block27 rfl P33PSD.q27 P33PSD.scale source_entry27
    P33Flag.basis27 P33Flag.basis27_injective rfl (fun _ => rfl) P33Flag.type27 rfl K p hv
#print axioms source_row27

theorem source_row33 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block33 K p) :
    (sourceContribution P33Arithmetic.block33 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row33 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block33 rfl P33PSD.q33 P33PSD.scale source_entry33
    P33Flag.basis33 P33Flag.basis33_injective rfl (fun _ => rfl) P33Flag.type33 rfl K p hv
#print axioms source_row33

end TightCycleC5.Bridge.P33PSDMatching
