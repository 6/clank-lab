import KernelRowIndex
import KernelWitness20

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_20_0 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 0 * 256 + i.val))
      kernelWitness20Row0[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_0

theorem kernelBlock_20_1 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 1 * 256 + i.val))
      kernelWitness20Row1[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_1

theorem kernelBlock_20_2 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 2 * 256 + i.val))
      kernelWitness20Row2[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_2

theorem kernelBlock_20_3 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 3 * 256 + i.val))
      kernelWitness20Row3[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_3

theorem kernelBlock_20_4 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 4 * 256 + i.val))
      kernelWitness20Row4[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_4

theorem kernelBlock_20_5 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 5 * 256 + i.val))
      kernelWitness20Row5[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_5

theorem kernelBlock_20_6 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 6 * 256 + i.val))
      kernelWitness20Row6[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_6

theorem kernelBlock_20_7 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 7 * 256 + i.val))
      kernelWitness20Row7[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_7

theorem kernelBlock_20_8 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 8 * 256 + i.val))
      kernelWitness20Row8[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_8

theorem kernelBlock_20_9 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 9 * 256 + i.val))
      kernelWitness20Row9[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_9

theorem kernelBlock_20_10 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 10 * 256 + i.val))
      kernelWitness20Row10[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_10

theorem kernelBlock_20_11 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 11 * 256 + i.val))
      kernelWitness20Row11[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_11

theorem kernelBlock_20_12 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 12 * 256 + i.val))
      kernelWitness20Row12[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_12

theorem kernelBlock_20_13 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 13 * 256 + i.val))
      kernelWitness20Row13[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_13

theorem kernelBlock_20_14 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 14 * 256 + i.val))
      kernelWitness20Row14[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_14

theorem kernelBlock_20_15 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 15 * 256 + i.val))
      kernelWitness20Row15[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_15

theorem kernelBlock_20_16 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 16 * 256 + i.val))
      kernelWitness20Row16[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_16

theorem kernelBlock_20_17 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 17 * 256 + i.val))
      kernelWitness20Row17[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_17

theorem kernelBlock_20_18 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 18 * 256 + i.val))
      kernelWitness20Row18[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_18

theorem kernelBlock_20_19 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 19 * 256 + i.val))
      kernelWitness20Row19[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_19

theorem kernelBlock_20_20 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 20 * 256 + i.val))
      kernelWitness20Row20[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_20

theorem kernelBlock_20_21 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 21 * 256 + i.val))
      kernelWitness20Row21[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_21

theorem kernelBlock_20_22 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 22 * 256 + i.val))
      kernelWitness20Row22[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_22

theorem kernelBlock_20_23 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 23 * 256 + i.val))
      kernelWitness20Row23[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_23

theorem kernelBlock_20_24 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 24 * 256 + i.val))
      kernelWitness20Row24[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_24

theorem kernelBlock_20_25 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 25 * 256 + i.val))
      kernelWitness20Row25[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_25

theorem kernelBlock_20_26 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 26 * 256 + i.val))
      kernelWitness20Row26[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_26

theorem kernelBlock_20_27 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 27 * 256 + i.val))
      kernelWitness20Row27[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_27

theorem kernelBlock_20_28 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 28 * 256 + i.val))
      kernelWitness20Row28[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_28

theorem kernelBlock_20_29 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 29 * 256 + i.val))
      kernelWitness20Row29[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_29

theorem kernelBlock_20_30 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 30 * 256 + i.val))
      kernelWitness20Row30[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_30

theorem kernelBlock_20_31 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (20 * 32768 + 31 * 256 + i.val))
      kernelWitness20Row31[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_20_31

end TightCycleC5.Bridge.Cover
