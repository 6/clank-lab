-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk32 :
    ∀ i : Fin (min 128 (40547 - 128 * 32)),
      targetCountsMatch (classAt (targetKernelClass ⟨32, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk32

theorem target_counts_kernel_chunk33 :
    ∀ i : Fin (min 128 (40547 - 128 * 33)),
      targetCountsMatch (classAt (targetKernelClass ⟨33, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk33

theorem target_counts_kernel_chunk34 :
    ∀ i : Fin (min 128 (40547 - 128 * 34)),
      targetCountsMatch (classAt (targetKernelClass ⟨34, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk34

theorem target_counts_kernel_chunk35 :
    ∀ i : Fin (min 128 (40547 - 128 * 35)),
      targetCountsMatch (classAt (targetKernelClass ⟨35, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk35


end TightCycleC5.Bridge.P33Arithmetic
