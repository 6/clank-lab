import Statement

/-!
                                                                       

The only mechanism of this round that survived its finite test. For a
3-graph `H` on `Fin n` and weights `w`, `lagr H w = Σ_{e ∈ H} Π_{v ∈ e} w v`.
For a vertex set `A`, `lagr H w - lagr H[Aᶜ] w` is the weight of the edges
meeting `A`.

* `M4Statement` (the lemma): at an interior maximiser `w` of the Lagrangian
  of a `C₅³`-free, pair-covering `H`, some proper cut `A` has
  edges-meeting-`A` weight at most `w(A)² w(Aᶜ) / 2`.
* `M4AllStatement` (its strong form, tested exactly for integer weights):
  the same for every positive `w`, with no optimality.

Only `m4All_imp_m4` is proved here. The two `Prop`s are open; their finite
                                                             
`m4_implies_bound` (M4 bounds every `C₅³`-free 3-graph by `α n³ / 6`) is
proved in `Upper.lean`, and `Endpoint.lean` derives the endpoint from M4.
-/

namespace TightCycleC5

open Finset

/-- The Lagrangian polynomial of `H` at the weights `w`. -/
noncomputable def lagr {n : ℕ} (H : Finset (Finset (Fin n))) (w : Fin n → ℝ) : ℝ :=
  ∑ e ∈ H, ∏ v ∈ e, w v

/-- The standard simplex of weights on `Fin n`. -/
def simplex (n : ℕ) : Set (Fin n → ℝ) :=
  {w | (∀ v, 0 ≤ w v) ∧ ∑ v, w v = 1}

/-- Every two distinct vertices lie in a common edge. -/
def CoversPairs {n : ℕ} (H : Finset (Finset (Fin n))) : Prop :=
  ∀ u v : Fin n, u ≠ v → ∃ e ∈ H, u ∈ e ∧ v ∈ e

/-- The cut inequality of M4 for the cut `(A, Aᶜ)`. -/
def M4Cut {n : ℕ} (H : Finset (Finset (Fin n))) (w : Fin n → ℝ) (A : Finset (Fin n)) : Prop :=
  A.Nonempty ∧ Aᶜ.Nonempty ∧
    lagr H w - lagr (H.filter (fun e => e ⊆ Aᶜ)) w ≤
      (∑ v ∈ A, w v) ^ 2 * (∑ v ∈ Aᶜ, w v) / 2

/-- **Lemma M4.** At an interior maximiser of the Lagrangian of a
`C₅³`-free pair-covering 3-graph, some proper cut satisfies the cut
inequality. -/
def M4Statement : Prop :=
  ∀ (n : ℕ) (H : Finset (Finset (Fin n))), 2 ≤ n → IsThreeGraph H → ¬ ContainsC5 H →
    CoversPairs H → ∀ w ∈ simplex n, (∀ v, 0 < w v) →
      (∀ w' ∈ simplex n, lagr H w' ≤ lagr H w) → ∃ A, M4Cut H w A

/-- **M4-all**, the strong form: every positive weighting of a `C₅³`-free
3-graph has a proper cut satisfying the cut inequality. -/
def M4AllStatement : Prop :=
  ∀ (n : ℕ) (H : Finset (Finset (Fin n))), 2 ≤ n → IsThreeGraph H → ¬ ContainsC5 H →
    ∀ w : Fin n → ℝ, (∀ v, 0 < w v) → ∃ A, M4Cut H w A

/-- The strong form implies the lemma. -/
theorem m4All_imp_m4 (h : M4AllStatement) : M4Statement := by
  intro n H hn hH hC _ w _ hpos _
  exact h n H hn hH hC w hpos

end TightCycleC5
