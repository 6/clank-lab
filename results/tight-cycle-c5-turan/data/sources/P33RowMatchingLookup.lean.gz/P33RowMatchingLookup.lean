import P33ArithmeticCore

namespace TightCycleC5.Bridge.P33RowMatching

/-- A validated query cannot use idxOf's absent-key default. -/
theorem lookup_read (flags : Array Nat) (key : Nat)
    (hvalid : P33Arithmetic.lookup flags key < flags.size) :
    flags[P33Arithmetic.lookup flags key]! = key := by
  have hl : flags.toList.idxOf key < flags.toList.length := by
    simpa only [P33Arithmetic.lookup, Array.length_toList] using hvalid
  have he := List.getElem_idxOf (xs := flags.toList) (x := key) hl
  rw [getElem!_pos flags (P33Arithmetic.lookup flags key) hvalid]
  simpa only [P33Arithmetic.lookup, Array.getElem_toList] using he

/-- No completeness premise is needed: only a validated query and no
repeated basis code, both separately supplied by actual data/checker facts. -/
theorem lookup_eq_iff (flags : Array Nat) (hnodup : flags.toList.Nodup) (key i : Nat)
    (hi : i < flags.size) (hvalid : P33Arithmetic.lookup flags key < flags.size) :
    P33Arithmetic.lookup flags key = i ↔ key = flags[i]! := by
  constructor
  · intro h
    simpa only [h] using (lookup_read flags key hvalid).symm
  · intro h
    rw [h]
    have he := hnodup.idxOf_getElem (⟨i, by simpa only [Array.length_toList] using hi⟩ : Fin flags.toList.length) (by simpa only [Array.length_toList] using hi)
    rw [getElem!_pos flags i hi]
    simpa only [P33Arithmetic.lookup, Array.getElem_toList] using he

#print axioms lookup_read
#print axioms lookup_eq_iff
end TightCycleC5.Bridge.P33RowMatching
