import InjectionSampling

/-! Extending common free-vertex weights by zero on the roots. -/

namespace TightCycleC5.Bridge

open Finset

theorem uniformMean_const_mul {V : Type*} [Fintype V] (c : ℝ) (v : V → ℝ) :
    uniformMean (fun a => c * v a) = c * uniformMean v := by
  simp only [uniformMean, ← Finset.mul_sum]
  ring

theorem sum_outside_support {R V : Type*} [Fintype V] (root : R ↪ V)
    (v : V → ℝ) (hz : ∀ a, a ∈ Set.range root → v a = 0) :
    (∑ a : Outside root, v a.val) = ∑ a : V, v a := by
  classical
  rw [← Finset.sum_subtype (F := instFintypeOutside root)
    ((univ : Finset V).filter (fun a => a ∉ Set.range root)) (by intro a; simp) v]
  apply Finset.sum_subset (filter_subset _ _)
  intro a _ ha
  exact hz a (by simpa using ha)

theorem sum2_outside_support {R V : Type*} [Fintype V] (root : R ↪ V)
    (v : V → V → ℝ)
    (hz1 : ∀ a, a ∈ Set.range root → ∀ b, v a b = 0)
    (hz2 : ∀ a b, b ∈ Set.range root → v a b = 0) :
    (∑ a : Outside root, ∑ b : Outside root, v a.val b.val) =
      ∑ a : V, ∑ b : V, v a b := by
  classical
  calc
    _ = ∑ a : Outside root, ∑ b : V, v a.val b := by
      apply Finset.sum_congr rfl
      intro a _
      exact sum_outside_support root _ (fun b hb => hz2 a.val b hb)
    _ = _ := by
      apply sum_outside_support root (fun a : V => ∑ b : V, v a b)
      intro a ha
      simp [hz1 a ha]

theorem sum3_outside_support {R V : Type*} [Fintype V] (root : R ↪ V)
    (v : V → V → V → ℝ)
    (hz1 : ∀ a, a ∈ Set.range root → ∀ b c, v a b c = 0)
    (hz2 : ∀ a b, b ∈ Set.range root → ∀ c, v a b c = 0)
    (hz3 : ∀ a b c, c ∈ Set.range root → v a b c = 0) :
    (∑ a : Outside root, ∑ b : Outside root, ∑ c : Outside root, v a.val b.val c.val) =
      ∑ a : V, ∑ b : V, ∑ c : V, v a b c := by
  classical
  calc
    _ = ∑ a : Outside root, ∑ b : Outside root, ∑ c : V, v a.val b.val c := by
      apply Finset.sum_congr rfl
      intro a _
      apply Finset.sum_congr rfl
      intro b _
      exact sum_outside_support root _ (fun c hc => hz3 a.val b.val c hc)
    _ = ∑ a : Outside root, ∑ b : V, ∑ c : V, v a.val b c := by
      apply Finset.sum_congr rfl
      intro a _
      apply sum_outside_support root (fun b : V => ∑ c : V, v a.val b c)
      intro b hb
      simp [hz2 a.val b hb]
    _ = _ := by
      apply sum_outside_support root (fun a : V => ∑ b : V, ∑ c : V, v a b c)
      intro a ha
      simp [hz1 a ha]

#print axioms sum_outside_support
#print axioms sum2_outside_support
#print axioms sum3_outside_support
#print axioms uniformMean_const_mul

end TightCycleC5.Bridge
