import KernelShard31Blocks0
import KernelShard31Blocks1
import KernelShard31Blocks2
import KernelShard31Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard31 : kernelShardCheck 31 kernelWitness31 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (31 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness31 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_31_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard31
end TightCycleC5.Bridge.Cover
