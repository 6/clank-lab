import KernelRowIndex
import KernelWitness10

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_10_96 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 96 * 256 + i.val))
      kernelWitness10Row96[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_96

theorem kernelBlock_10_97 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 97 * 256 + i.val))
      kernelWitness10Row97[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_97

theorem kernelBlock_10_98 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 98 * 256 + i.val))
      kernelWitness10Row98[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_98

theorem kernelBlock_10_99 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 99 * 256 + i.val))
      kernelWitness10Row99[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_99

theorem kernelBlock_10_100 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 100 * 256 + i.val))
      kernelWitness10Row100[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_100

theorem kernelBlock_10_101 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 101 * 256 + i.val))
      kernelWitness10Row101[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_101

theorem kernelBlock_10_102 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 102 * 256 + i.val))
      kernelWitness10Row102[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_102

theorem kernelBlock_10_103 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 103 * 256 + i.val))
      kernelWitness10Row103[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_103

theorem kernelBlock_10_104 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 104 * 256 + i.val))
      kernelWitness10Row104[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_104

theorem kernelBlock_10_105 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 105 * 256 + i.val))
      kernelWitness10Row105[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_105

theorem kernelBlock_10_106 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 106 * 256 + i.val))
      kernelWitness10Row106[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_106

theorem kernelBlock_10_107 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 107 * 256 + i.val))
      kernelWitness10Row107[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_107

theorem kernelBlock_10_108 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 108 * 256 + i.val))
      kernelWitness10Row108[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_108

theorem kernelBlock_10_109 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 109 * 256 + i.val))
      kernelWitness10Row109[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_109

theorem kernelBlock_10_110 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 110 * 256 + i.val))
      kernelWitness10Row110[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_110

theorem kernelBlock_10_111 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 111 * 256 + i.val))
      kernelWitness10Row111[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_111

theorem kernelBlock_10_112 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 112 * 256 + i.val))
      kernelWitness10Row112[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_112

theorem kernelBlock_10_113 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 113 * 256 + i.val))
      kernelWitness10Row113[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_113

theorem kernelBlock_10_114 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 114 * 256 + i.val))
      kernelWitness10Row114[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_114

theorem kernelBlock_10_115 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 115 * 256 + i.val))
      kernelWitness10Row115[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_115

theorem kernelBlock_10_116 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 116 * 256 + i.val))
      kernelWitness10Row116[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_116

theorem kernelBlock_10_117 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 117 * 256 + i.val))
      kernelWitness10Row117[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_117

theorem kernelBlock_10_118 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 118 * 256 + i.val))
      kernelWitness10Row118[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_118

theorem kernelBlock_10_119 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 119 * 256 + i.val))
      kernelWitness10Row119[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_119

theorem kernelBlock_10_120 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 120 * 256 + i.val))
      kernelWitness10Row120[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_120

theorem kernelBlock_10_121 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 121 * 256 + i.val))
      kernelWitness10Row121[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_121

theorem kernelBlock_10_122 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 122 * 256 + i.val))
      kernelWitness10Row122[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_122

theorem kernelBlock_10_123 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 123 * 256 + i.val))
      kernelWitness10Row123[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_123

theorem kernelBlock_10_124 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 124 * 256 + i.val))
      kernelWitness10Row124[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_124

theorem kernelBlock_10_125 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 125 * 256 + i.val))
      kernelWitness10Row125[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_125

theorem kernelBlock_10_126 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 126 * 256 + i.val))
      kernelWitness10Row126[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_126

theorem kernelBlock_10_127 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 127 * 256 + i.val))
      kernelWitness10Row127[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_127

end TightCycleC5.Bridge.Cover
