import KernelRowIndex
import KernelWitness10

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_10_0 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 0 * 256 + i.val))
      kernelWitness10Row0[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_0

theorem kernelBlock_10_1 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 1 * 256 + i.val))
      kernelWitness10Row1[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_1

theorem kernelBlock_10_2 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 2 * 256 + i.val))
      kernelWitness10Row2[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_2

theorem kernelBlock_10_3 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 3 * 256 + i.val))
      kernelWitness10Row3[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_3

theorem kernelBlock_10_4 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 4 * 256 + i.val))
      kernelWitness10Row4[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_4

theorem kernelBlock_10_5 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 5 * 256 + i.val))
      kernelWitness10Row5[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_5

theorem kernelBlock_10_6 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 6 * 256 + i.val))
      kernelWitness10Row6[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_6

theorem kernelBlock_10_7 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 7 * 256 + i.val))
      kernelWitness10Row7[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_7

theorem kernelBlock_10_8 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 8 * 256 + i.val))
      kernelWitness10Row8[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_8

theorem kernelBlock_10_9 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 9 * 256 + i.val))
      kernelWitness10Row9[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_9

theorem kernelBlock_10_10 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 10 * 256 + i.val))
      kernelWitness10Row10[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_10

theorem kernelBlock_10_11 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 11 * 256 + i.val))
      kernelWitness10Row11[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_11

theorem kernelBlock_10_12 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 12 * 256 + i.val))
      kernelWitness10Row12[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_12

theorem kernelBlock_10_13 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 13 * 256 + i.val))
      kernelWitness10Row13[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_13

theorem kernelBlock_10_14 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 14 * 256 + i.val))
      kernelWitness10Row14[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_14

theorem kernelBlock_10_15 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 15 * 256 + i.val))
      kernelWitness10Row15[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_15

theorem kernelBlock_10_16 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 16 * 256 + i.val))
      kernelWitness10Row16[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_16

theorem kernelBlock_10_17 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 17 * 256 + i.val))
      kernelWitness10Row17[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_17

theorem kernelBlock_10_18 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 18 * 256 + i.val))
      kernelWitness10Row18[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_18

theorem kernelBlock_10_19 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 19 * 256 + i.val))
      kernelWitness10Row19[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_19

theorem kernelBlock_10_20 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 20 * 256 + i.val))
      kernelWitness10Row20[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_20

theorem kernelBlock_10_21 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 21 * 256 + i.val))
      kernelWitness10Row21[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_21

theorem kernelBlock_10_22 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 22 * 256 + i.val))
      kernelWitness10Row22[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_22

theorem kernelBlock_10_23 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 23 * 256 + i.val))
      kernelWitness10Row23[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_23

theorem kernelBlock_10_24 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 24 * 256 + i.val))
      kernelWitness10Row24[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_24

theorem kernelBlock_10_25 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 25 * 256 + i.val))
      kernelWitness10Row25[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_25

theorem kernelBlock_10_26 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 26 * 256 + i.val))
      kernelWitness10Row26[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_26

theorem kernelBlock_10_27 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 27 * 256 + i.val))
      kernelWitness10Row27[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_27

theorem kernelBlock_10_28 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 28 * 256 + i.val))
      kernelWitness10Row28[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_28

theorem kernelBlock_10_29 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 29 * 256 + i.val))
      kernelWitness10Row29[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_29

theorem kernelBlock_10_30 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 30 * 256 + i.val))
      kernelWitness10Row30[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_30

theorem kernelBlock_10_31 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (10 * 32768 + 31 * 256 + i.val))
      kernelWitness10Row31[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_10_31

end TightCycleC5.Bridge.Cover
