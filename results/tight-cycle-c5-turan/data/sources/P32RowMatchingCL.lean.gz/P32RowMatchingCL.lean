import P32RowMatchingData

namespace TightCycleC5.Bridge.P32RowMatching
open Finset
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000
set_option backward.isDefEq.respectTransparency false

def clDescriptor (strong : Bool) (i : Fin 510) : CLCertificate.Descriptor :=
  ⟨strong, decide (i.val / 255 = 1), BitVec.ofNat 8 (i.val % 255 + 1), none, univ⟩

theorem cl_descriptor_weak (i : Fin 510) :
    CertificateDescriptors.p32CL (Fin.castAdd 510 i) = clDescriptor false i := by
  have hi := i.isLt
  have hdiv : i.val / 510 = 0 := Nat.div_eq_of_lt hi
  have hmod : i.val % 510 = i.val := Nat.mod_eq_of_lt hi
  simp [CertificateDescriptors.p32CL, clDescriptor, hdiv, hmod]

theorem cl_descriptor_strong (i : Fin 510) :
    CertificateDescriptors.p32CL (Fin.natAdd 510 i) = clDescriptor true i := by
  have hi := i.isLt
  have hd : (510+i.val) / 510 = 1 := by omega
  have hm : (510+i.val) % 510 = i.val := by omega
  have hm' : (510+i.val) % 255 = i.val % 255 := by omega
  have hm0 : i.val % 510 = i.val := Nat.mod_eq_of_lt hi
  have hm1 : (i.val+510) % 255 = i.val % 255 := by omega
  simp [CertificateDescriptors.p32CL, clDescriptor, hd, hm, hm', hm0, hm1]

theorem cl_boolean_polynomial (s a b c d : Bool) :
    ((if s then (if a = true ∧ b = true ∧ ¬ c = true ∧ ¬ d = true then 1 else 0)
      else (if a = true ∧ b = true ∧ ¬ c = true then 1 else 0)) -
      (if d = true ∧ a = true ∧ b = true ∧ c = true then 1 else 0) : ℝ) =
    ((if s then
      P32Arithmetic.bit a * P32Arithmetic.bit b * (1-P32Arithmetic.bit c) *
        (1-P32Arithmetic.bit d) -
        P32Arithmetic.bit a * P32Arithmetic.bit b * P32Arithmetic.bit c * P32Arithmetic.bit d
    else P32Arithmetic.bit a * P32Arithmetic.bit b * (1-P32Arithmetic.bit c) -
        P32Arithmetic.bit a * P32Arithmetic.bit b * P32Arithmetic.bit c * P32Arithmetic.bit d : ℤ) : ℝ) := by
  cases s <;> cases a <;> cases b <;> cases c <;> cases d <;>
    norm_num [P32Arithmetic.bit]

theorem cl_tau_test (tau : Bool) (i : Fin 510) :
    (tau.toNat == i.val / 255) = decide (tau = decide (i.val / 255 = 1)) := by
  have hi := i.isLt
  have h : i.val / 255 = 0 ∨ i.val / 255 = 1 := by omega
  rcases h with h | h <;> cases tau <;> simp [h]

theorem cl_kernel_features (G : LabelledStructure 6) (s : Bool) :
    ((if CLCertificate.cherry s (fun a b c => G.edge {a,b,c}) 0 3 4 5 then 1 else 0) -
      (if CLCertificate.tetrahedron (fun a b c => G.edge {a,b,c}) 0 3 4 5 then 1 else 0) : ℝ) =
      ((if s then (P32Arithmetic.features G).cl4 else (P32Arithmetic.features G).cl3 : ℤ) : ℝ) := by
  cases s <;> cases ha : G.edge {0,3,4} <;> cases hb : G.edge {0,3,5} <;>
    cases hc : G.edge {0,4,5} <;> cases hd : G.edge {3,4,5} <;>
    norm_num [CLCertificate.cherry, CLCertificate.tetrahedron, P32Arithmetic.features,
      P32Arithmetic.bit, ha, hb, hc, hd]

theorem mask_test_nat (mask p : Nat) (hp : p < 8) :
    (BitVec.ofNat 8 mask).getLsbD p = mask.testBit p := by
  rw [BitVec.getLsbD_ofNat]
  simp [hp]

theorem cl_pass_eq (G : LabelledStructure 6) (i : Fin 510) :
    P32Arithmetic.clPass (P32Arithmetic.features G) i =
      decide (G.edge {0,1,2} = decide (i.val / 255 = 1) ∧
        (i.val%255+1).testBit (CLCertificate.pattern (fun a b c => G.edge {a,b,c}) 0 1 2 3) = true ∧
        (i.val%255+1).testBit (CLCertificate.pattern (fun a b c => G.edge {a,b,c}) 0 1 2 4) = true ∧
        (i.val%255+1).testBit (CLCertificate.pattern (fun a b c => G.edge {a,b,c}) 0 1 2 5) = true) := by
  simp [P32Arithmetic.clPass, P32Arithmetic.features, cl_tau_test]

theorem cl_row_features (G : LabelledStructure 6) (s : Bool) (i : Fin 510) :
    CLCertificate.row (clDescriptor s i) G =
      if P32Arithmetic.clPass (P32Arithmetic.features G) i then
        ((if s then (P32Arithmetic.features G).cl4 else (P32Arithmetic.features G).cl3 : ℤ) : ℝ)
      else 0 := by
  have h3 := CLCertificate.pattern_lt (fun a b c => G.edge {a,b,c}) 0 1 2 3
  have h4 := CLCertificate.pattern_lt (fun a b c => G.edge {a,b,c}) 0 1 2 4
  have h5 := CLCertificate.pattern_lt (fun a b c => G.edge {a,b,c}) 0 1 2 5
  rw [CLCertificate.row, CLCertificate.evaluate]
  simp only [clDescriptor]
  rw [cl_kernel_features, cl_pass_eq]
  simp only [CLCertificate.rootPass, CLCertificate.rootColorPass,
    CLCertificate.freePass, mem_univ, and_true, mask_test_nat _ _ h3,
    mask_test_nat _ _ h4, mask_test_nat _ _ h5, decide_eq_true_eq]
  split_ifs <;> simp_all

/-- The 510 weak and 510 strong arithmetic rows have the accepted descriptors. -/
theorem cl_contribution_eq (G : LabelledStructure 6) :
    P32Arithmetic.clContribution G =
      ∑ i : Fin 1020, CertificateDescriptors.p32CLWeight i *
        CLCertificate.row (CertificateDescriptors.p32CL i) G := by
  simp only [P32Arithmetic.clContribution, Rat.cast_div, Rat.cast_intCast]
  rw [P32Arithmetic.clNumerator, Int.cast_add, add_div]
  rw [Fin.sum_univ_add (a := 510) (b := 510)]
  simp only [cl_descriptor_weak, cl_descriptor_strong, cl_row_features,
    Bool.false_eq_true, ↓reduceIte, Int.cast_sum, Int.cast_ite,
    Int.cast_mul, Int.cast_zero, Finset.sum_div]
  congr 1 <;> apply Finset.sum_congr rfl <;> intro i _
  all_goals
    simp only [CertificateDescriptors.p32CLWeight, CertificateDescriptors.p32Weight,
      CertificateDescriptors.p32CLSourceIndex, ← numerator_eq, ← weight_scale_eq]
    split_ifs <;> simp_all <;> ring

#print axioms cl_descriptor_weak
#print axioms cl_descriptor_strong
#print axioms cl_boolean_polynomial
#print axioms cl_tau_test
#print axioms cl_kernel_features
#print axioms mask_test_nat
#print axioms cl_pass_eq
#print axioms cl_row_features
#print axioms cl_contribution_eq
end TightCycleC5.Bridge.P32RowMatching
