-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk220 :
    ∀ i : Fin (min 128 (40547 - 128 * 220)),
      targetCountsMatch (classAt (targetKernelClass ⟨220, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk220

theorem target_counts_kernel_chunk221 :
    ∀ i : Fin (min 128 (40547 - 128 * 221)),
      targetCountsMatch (classAt (targetKernelClass ⟨221, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk221

theorem target_counts_kernel_chunk222 :
    ∀ i : Fin (min 128 (40547 - 128 * 222)),
      targetCountsMatch (classAt (targetKernelClass ⟨222, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk222

theorem target_counts_kernel_chunk223 :
    ∀ i : Fin (min 128 (40547 - 128 * 223)),
      targetCountsMatch (classAt (targetKernelClass ⟨223, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk223


end TightCycleC5.Bridge.P33Arithmetic
