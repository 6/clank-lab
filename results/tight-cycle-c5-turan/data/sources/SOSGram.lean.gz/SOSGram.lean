import RationalGram

/-! Natural weighted sums of integer PSD matrices; P33 divides by scale once. -/
namespace TightCycleC5.Bridge
open Matrix Finset

def integerSOS {I K : Type*} [Fintype K]
    (w : K → ℕ) (A : K → Matrix I I ℤ) : Matrix I I ℤ :=
  fun i j => ∑ k, (w k : ℤ) * A k i j

theorem integer_sos_posSemidef {I K : Type*} [Finite I] [Fintype K]
    (w : K → ℕ) (A : K → Matrix I I ℤ)
    (hA : ∀ k, (intMatrixReal (A k)).PosSemidef) :
    (intMatrixReal (integerSOS w A)).PosSemidef := by
  have he : intMatrixReal (integerSOS w A) = ∑ k, (w k : ℝ) • intMatrixReal (A k) := by
    ext i j
    simp [integerSOS, intMatrixReal, Matrix.sum_apply, Matrix.smul_apply]
  rw [he]
  exact Matrix.posSemidef_sum _ (fun k _ => (hA k).smul (Nat.cast_nonneg _))

/-- Explicit finite diagonal bound; no dense SOS matrix is constructed. -/
def integerSOSBound {K : Type*} [Fintype K] (w b : K → ℕ) : ℕ :=
  ∑ k, w k * b k

theorem integer_sos_diagonal {I K : Type*} [Fintype K]
    (w b : K → ℕ) (A : K → Matrix I I ℤ)
    (hA : ∀ k i, A k i i ≤ (b k : ℤ)) :
    ∀ i, integerSOS w A i i ≤ (integerSOSBound w b : ℤ) := by
  intro i
  simp only [integerSOS, integerSOSBound, Nat.cast_sum, Nat.cast_mul]
  exact Finset.sum_le_sum (fun k _ => mul_le_mul_of_nonneg_left (hA k i) (Nat.cast_nonneg _))

noncomputable def scaleIntMatrix {I J : Type*} (Q : Matrix I J ℤ) (s : ℕ) :
    Matrix I J ℝ := fun i j => (Q i j : ℝ) / (s : ℝ)

theorem scale_int_posSemidef {I : Type*} (Q : Matrix I I ℤ) (s : ℕ)
    (hQ : (intMatrixReal Q).PosSemidef) : (scaleIntMatrix Q s).PosSemidef := by
  have he : scaleIntMatrix Q s = (s : ℝ)⁻¹ • intMatrixReal Q := by
    ext i j
    simp [scaleIntMatrix, intMatrixReal, div_eq_mul_inv, mul_comm]
  rw [he]
  exact hQ.smul (inv_nonneg.mpr (Nat.cast_nonneg _))

theorem scale_int_diagonal {I : Type*} (Q : Matrix I I ℤ) (s : ℕ) (m : ℤ)
    (hm : ∀ i, Q i i ≤ m) :
    ∀ i, scaleIntMatrix Q s i i ≤ (m : ℝ) / (s : ℝ) := by
  intro i
  exact div_le_div_of_nonneg_right (int_diagonal_bound Q m hm i) (Nat.cast_nonneg _)

theorem scale_int_bound_nonneg (s : ℕ) (m : ℤ) (hm : 0 ≤ m) :
    (0 : ℝ) ≤ (m : ℝ) / (s : ℝ) := by
  exact div_nonneg (by exact_mod_cast hm) (Nat.cast_nonneg _)

#print axioms integer_sos_posSemidef
#print axioms integer_sos_diagonal
#print axioms scale_int_posSemidef
#print axioms scale_int_diagonal
#print axioms scale_int_bound_nonneg
end TightCycleC5.Bridge
