-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk76 :
    ∀ i : Fin (min 128 (40547 - 128 * 76)),
      targetCountsMatch (classAt (targetKernelClass ⟨76, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk76

theorem target_counts_kernel_chunk77 :
    ∀ i : Fin (min 128 (40547 - 128 * 77)),
      targetCountsMatch (classAt (targetKernelClass ⟨77, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk77

theorem target_counts_kernel_chunk78 :
    ∀ i : Fin (min 128 (40547 - 128 * 78)),
      targetCountsMatch (classAt (targetKernelClass ⟨78, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk78

theorem target_counts_kernel_chunk79 :
    ∀ i : Fin (min 128 (40547 - 128 * 79)),
      targetCountsMatch (classAt (targetKernelClass ⟨79, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk79


end TightCycleC5.Bridge.P33Arithmetic
