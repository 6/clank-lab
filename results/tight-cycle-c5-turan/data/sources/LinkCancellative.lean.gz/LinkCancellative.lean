import Mathlib
import Statement

/-!
                                                                   

For a `C₅³`-free 3-graph `H`, a vertex `x` and weights `w ≥ 0`, let `L a b` mean
`{x, a, b} ∈ H` (the link of `x`) and `K a b c` mean that `{a, b, c}` is an edge whose three
pairs lie in the link (a `K₄³` through `x`). Then

  `∑ a b c, w a w b w c [K a b c] ≤ (3/2) ∑ a b c, w a w b w c [¬ L a b] [L a c]`.

`cl_abstract` proves it for any symmetric `K` inside the triangles of a symmetric `L` with
`K a b c → K a b d → ¬ L c d`; `cl_link` supplies that hypothesis from `C₅³`-freeness.
-/

open Finset

namespace TightCycleC5.HelperD

open TightCycleC5

section Abstract

variable {V : Type*} [Fintype V] [DecidableEq V]

lemma inv_add_le_quarter (p q : ℝ) (hp : 0 < p) (hq : 0 < q) :
    1 / (p + q) ≤ (1 / p + 1 / q) / 4 := by
  rw [div_add_div _ _ hp.ne' hq.ne', div_div, div_le_div_iff₀ (by positivity) (by positivity)]
  nlinarith [sq_nonneg (p - q)]

/-- Reindexing a triple sum along the cyclic shift `(a, b, c) ↦ (b, c, a)`. -/
lemma sum3_cycle (F : V → V → V → ℝ) :
    ∑ a, ∑ b, ∑ c, F a b c = ∑ a, ∑ b, ∑ c, F b c a := by
  exact (Finset.sum_congr rfl fun _ _ => Finset.sum_comm).trans Finset.sum_comm

/-- Reindexing a triple sum along the swap `(a, b, c) ↦ (a, c, b)`. -/
lemma sum3_swap23 (F : V → V → V → ℝ) :
    ∑ a, ∑ b, ∑ c, F a b c = ∑ a, ∑ b, ∑ c, F a c b := by
  refine Finset.sum_congr rfl fun a _ => ?_
  rw [Finset.sum_comm]

theorem cl_abstract (w : V → ℝ) (hw : ∀ v, 0 ≤ w v)
    (L : V → V → Prop) [DecidableRel L] (K : V → V → V → Prop) [∀ a b c, Decidable (K a b c)]
    (hL : ∀ a b, L a b → L b a)
    (hK₁ : ∀ a b c, K a b c → K b a c) (hK₂ : ∀ a b c, K a b c → K a c b)
    (hKL : ∀ a b c, K a b c → L a b)
    (hcanc : ∀ a b c d, K a b c → K a b d → ¬ L c d) :
    ∑ a, ∑ b, ∑ c, (if K a b c then w a * w b * w c else 0) ≤
      (3 / 2) * ∑ a, ∑ b, ∑ c,
        (if L a b then 0 else if L a c then w a * w b * w c else 0) := by
  classical
  -- symmetry of K under every permutation
  have hK₃ : ∀ a b c, K a b c → K b c a := fun a b c h => hK₂ _ _ _ (hK₁ _ _ _ h)
  have hKiff₁ : ∀ a b c, K a b c ↔ K b a c := fun a b c => ⟨hK₁ a b c, hK₁ b a c⟩
  have hKiff₂ : ∀ a b c, K a b c ↔ K a c b := fun a b c => ⟨hK₂ a b c, hK₂ a c b⟩
  have hKiff₃ : ∀ a b c, K a b c ↔ K b c a := fun a b c =>
    ⟨hK₃ a b c, fun h => hK₃ _ _ _ (hK₃ _ _ _ h)⟩
  set f : V → V → V → ℝ := fun a b c => if K a b c then w a * w b * w c else 0 with hf
  set t : V → V → ℝ := fun a b => ∑ c, if K a b c then w c else 0 with ht
  set ν : V → ℝ := fun c => ∑ d, if L c d then 0 else w d with hν
  set T : V → V → V → ℝ := fun a b c => t a b + t a c + t b c with hT
  have hf0 : ∀ a b c, 0 ≤ f a b c := fun a b c => by
    simp only [hf]; split_ifs
    · exact mul_nonneg (mul_nonneg (hw a) (hw b)) (hw c)
    · exact le_rfl
  have ht0 : ∀ a b, 0 ≤ t a b := fun a b =>
    Finset.sum_nonneg fun c _ => by split_ifs <;> simp [hw c]
  have hν0 : ∀ c, 0 ≤ ν c := fun c =>
    Finset.sum_nonneg fun d _ => by split_ifs <;> simp [hw d]
  have htsymm : ∀ a b, t a b = t b a := fun a b => by
    simp only [ht]; exact Finset.sum_congr rfl fun c _ => by simp only [hKiff₁ a b c]
  -- a single term of `t` is bounded by `t`
  have ht_ge : ∀ a b c, K a b c → w c ≤ t a b := fun a b c h => by
    simp only [ht]
    have := Finset.single_le_sum (f := fun d => if K a b d then w d else 0)
      (fun d _ => by split_ifs <;> simp [hw d]) (Finset.mem_univ c)
    simpa [h] using this
  -- (iii): t a b ≤ ν c whenever K a b c
  have ht_le_ν : ∀ a b c, K a b c → t a b ≤ ν c := fun a b c h => by
    simp only [ht, hν]
    refine Finset.sum_le_sum fun d _ => ?_
    by_cases hd : K a b d
    · have : ¬ L c d := hcanc a b c d h hd
      simp [hd, this]
    · simp only [hd, if_false]; split_ifs <;> simp [hw d]
  -- the symmetric weights h = f / T
  set g : V → V → V → ℝ := fun a b c => f a b c / T a b c with hg
  have hfT : ∀ a b c, f a b c = g a b c * T a b c := fun a b c => by
    simp only [hg]
    by_cases hK : K a b c
    · by_cases hc : w c = 0
      · simp [hf, hK, hc]
      · have hpos : 0 < T a b c := by
          have h1 := ht_ge a b c hK
          have : 0 < w c := lt_of_le_of_ne (hw c) (Ne.symm hc)
          simp only [hT]; linarith [ht0 a c, ht0 b c]
        rw [div_mul_cancel₀ _ hpos.ne']
    · simp [hf, hK]
  have hgsymm₂ : ∀ a b c, g a b c = g a c b := fun a b c => by
    simp only [hg, hf, hT, hKiff₂ a b c, htsymm c b]; ring_nf
  have hgsymm₃ : ∀ a b c, g a b c = g b c a := fun a b c => by
    simp only [hg, hf, hT, ← hKiff₃ a b c, htsymm b a, htsymm c a]
    split_ifs
    · congr 1 <;> ring
    · simp
  -- (ii): ∑ f = 3 ∑ g * t a b
  have hsplit : ∑ a, ∑ b, ∑ c, f a b c = 3 * ∑ a, ∑ b, ∑ c, g a b c * t a b := by
    have e1 : ∑ a, ∑ b, ∑ c, f a b c = ∑ a, ∑ b, ∑ c, g a b c * t a b
        + ∑ a, ∑ b, ∑ c, g a b c * t a c + ∑ a, ∑ b, ∑ c, g a b c * t b c := by
      simp only [← Finset.sum_add_distrib]
      refine Finset.sum_congr rfl fun a _ => Finset.sum_congr rfl fun b _ =>
        Finset.sum_congr rfl fun c _ => ?_
      rw [hfT a b c]; simp only [hT]; ring
    have e2 : ∑ a, ∑ b, ∑ c, g a b c * t a c = ∑ a, ∑ b, ∑ c, g a b c * t a b := by
      rw [sum3_swap23 (fun a b c => g a b c * t a c)]
      simp only [← hgsymm₂]
    have e3 : ∑ a, ∑ b, ∑ c, g a b c * t b c = ∑ a, ∑ b, ∑ c, g a b c * t a b := by
      rw [sum3_cycle (fun a b c => g a b c * t a b)]
      simp only [← hgsymm₃]
    rw [e1, e2, e3]; ring
  -- (iv): the pointwise bound
  have hpt : ∀ a b c, g a b c * t a b ≤
      (f a b c * ν c * (1 / t a c) + f a b c * ν c * (1 / t b c)) / 4 := fun a b c => by
    by_cases hK : K a b c
    · by_cases hz : w a * w b * w c = 0
      · simp [hg, hf, hK, hz]
      · have hwa : 0 < w a := lt_of_le_of_ne (hw a) (by intro h; apply hz; simp [← h])
        have hwb : 0 < w b := lt_of_le_of_ne (hw b) (by intro h; apply hz; simp [← h])
        have hpac : 0 < t a c := lt_of_lt_of_le hwb (ht_ge a c b (hK₂ _ _ _ hK))
        have hpbc : 0 < t b c := lt_of_lt_of_le hwa (ht_ge b c a (hK₃ _ _ _ hK))
        have hfpos : 0 ≤ f a b c := hf0 a b c
        have hTge : t a c + t b c ≤ T a b c := by simp only [hT]; linarith [ht0 a b]
        have hTpos : 0 < T a b c := lt_of_lt_of_le (by linarith) hTge
        have h1 : t a b / T a b c ≤ ν c * (1 / (t a c + t b c)) := by
          rw [div_le_iff₀ hTpos]
          calc t a b ≤ ν c := ht_le_ν a b c hK
            _ = ν c * (1 / (t a c + t b c)) * (t a c + t b c) := by
                field_simp
            _ ≤ ν c * (1 / (t a c + t b c)) * T a b c := by
                apply mul_le_mul_of_nonneg_left hTge
                have : 0 ≤ ν c := le_trans (ht0 a b) (ht_le_ν a b c hK)
                positivity
        have h2 := inv_add_le_quarter (t a c) (t b c) hpac hpbc
        have hν0 : 0 ≤ ν c := le_trans (ht0 a b) (ht_le_ν a b c hK)
        calc g a b c * t a b = f a b c * (t a b / T a b c) := by simp only [hg]; ring
          _ ≤ f a b c * (ν c * (1 / (t a c + t b c))) := mul_le_mul_of_nonneg_left h1 hfpos
          _ ≤ f a b c * (ν c * ((1 / t a c + 1 / t b c) / 4)) := by
              apply mul_le_mul_of_nonneg_left _ hfpos
              exact mul_le_mul_of_nonneg_left h2 hν0
          _ = _ := by ring
    · simp [hg, hf, hK]
  -- the two halves of the right side
  have hhalf₁ : ∑ a, ∑ b, ∑ c, f a b c * ν c * (1 / t a c) ≤
      ∑ a, ∑ c, (if L a c then w a * w c * ν c else 0) := by
    rw [show ∑ a, ∑ b, ∑ c, f a b c * ν c * (1 / t a c) =
        ∑ a, ∑ c, ∑ b, f a b c * ν c * (1 / t a c) from
      Finset.sum_congr rfl fun _ _ => Finset.sum_comm]
    refine Finset.sum_le_sum fun a _ => Finset.sum_le_sum fun c _ => ?_
    have hrw : ∑ b, f a b c * ν c * (1 / t a c) = w a * w c * ν c * (t a c / t a c) := by
      simp only [hf, ht, Finset.sum_div, Finset.mul_sum]
      refine Finset.sum_congr rfl fun b _ => ?_
      simp only [hKiff₂ a b c]; split_ifs <;> ring
    rw [hrw]
    by_cases hz : t a c = 0
    · simp only [hz, div_zero, mul_zero]; split_ifs
      · exact mul_nonneg (mul_nonneg (hw a) (hw c)) (hν0 c)
      · exact le_rfl
    · obtain ⟨b, hb⟩ : ∃ b, K a c b := by
        by_contra hne; push Not at hne; apply hz; simp [ht, hne]
      simp only [div_self hz, mul_one, if_pos (hKL a c b hb)]; exact le_rfl
  have hhalf₂ : ∑ a, ∑ b, ∑ c, f a b c * ν c * (1 / t b c) ≤
      ∑ a, ∑ c, (if L a c then w a * w c * ν c else 0) := by
    rw [show ∑ a, ∑ b, ∑ c, f a b c * ν c * (1 / t b c) =
        ∑ b, ∑ c, ∑ a, f a b c * ν c * (1 / t b c) from
      (Finset.sum_comm).trans (Finset.sum_congr rfl fun _ _ => Finset.sum_comm)]
    refine Finset.sum_le_sum fun b _ => Finset.sum_le_sum fun c _ => ?_
    have hrw : ∑ a, f a b c * ν c * (1 / t b c) = w b * w c * ν c * (t b c / t b c) := by
      simp only [hf, ht, Finset.sum_div, Finset.mul_sum]
      refine Finset.sum_congr rfl fun a _ => ?_
      simp only [hKiff₃ a b c]; split_ifs <;> ring
    rw [hrw]
    by_cases hz : t b c = 0
    · simp only [hz, div_zero, mul_zero]; split_ifs
      · exact mul_nonneg (mul_nonneg (hw b) (hw c)) (hν0 c)
      · exact le_rfl
    · obtain ⟨a, ha⟩ : ∃ a, K b c a := by
        by_contra hne; push Not at hne; apply hz; simp [ht, hne]
      simp only [div_self hz, mul_one, if_pos (hKL b c a ha)]; exact le_rfl
  -- the right side of the statement
  have hR' : ∑ a, ∑ c, (if L a c then w a * w c * ν c else 0) =
      ∑ a, ∑ c, (if L a c then w a * w c * ν a else 0) := by
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun a _ => Finset.sum_congr rfl fun c _ => ?_
    by_cases h : L a c
    · simp only [h, hL a c h, if_true]; ring
    · have : ¬ L c a := fun h' => h (hL c a h')
      simp [h, this]
  have hrhs : ∑ a, ∑ b, ∑ c, (if L a b then 0 else if L a c then w a * w b * w c else 0) =
      ∑ a, ∑ c, (if L a c then w a * w c * ν a else 0) := by
    refine Finset.sum_congr rfl fun a _ => ?_
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun c _ => ?_
    simp only [hν, Finset.mul_sum]
    by_cases h : L a c
    · simp only [h, if_true]
      refine Finset.sum_congr rfl fun b _ => ?_
      split_ifs <;> ring
    · simp [h]
  rw [hrhs, ← hR', hsplit]
  have hsum := Finset.sum_le_sum fun a (_ : a ∈ Finset.univ) => Finset.sum_le_sum
    fun b (_ : b ∈ Finset.univ) => Finset.sum_le_sum fun c (_ : c ∈ Finset.univ) => hpt a b c
  simp only [← Finset.sum_div, Finset.sum_add_distrib] at hsum
  linarith [hhalf₁, hhalf₂]

/-- **CL-2** (abstract): the right side counts induced cherries `c – a – d` of `L`. -/
theorem cl2_abstract (w : V → ℝ) (hw : ∀ v, 0 ≤ w v)
    (L : V → V → Prop) [DecidableRel L] (K : V → V → V → Prop) [∀ a b c, Decidable (K a b c)]
    (hL : ∀ a b, L a b → L b a)
    (hK₁ : ∀ a b c, K a b c → K b a c) (hK₂ : ∀ a b c, K a b c → K a c b)
    (hKL : ∀ a b c, K a b c → L a b)
    (hcanc : ∀ a b c d, K a b c → K a b d → ¬ L c d) :
    ∑ a, ∑ b, ∑ c, (if K a b c then w a * w b * w c else 0) ≤
      (3 / 2) * ∑ a, ∑ c, ∑ d,
        (if L a c ∧ L a d ∧ ¬ L c d then w a * w c * w d else 0) := by
  classical
  -- symmetry of K under every permutation
  have hK₃ : ∀ a b c, K a b c → K b c a := fun a b c h => hK₂ _ _ _ (hK₁ _ _ _ h)
  have hKiff₁ : ∀ a b c, K a b c ↔ K b a c := fun a b c => ⟨hK₁ a b c, hK₁ b a c⟩
  have hKiff₂ : ∀ a b c, K a b c ↔ K a c b := fun a b c => ⟨hK₂ a b c, hK₂ a c b⟩
  have hKiff₃ : ∀ a b c, K a b c ↔ K b c a := fun a b c =>
    ⟨hK₃ a b c, fun h => hK₃ _ _ _ (hK₃ _ _ _ h)⟩
  set f : V → V → V → ℝ := fun a b c => if K a b c then w a * w b * w c else 0 with hf
  set t : V → V → ℝ := fun a b => ∑ c, if K a b c then w c else 0 with ht
  set μ : V → V → ℝ := fun c a => ∑ d, if L a d ∧ ¬ L c d then w d else 0 with hμ
  set T : V → V → V → ℝ := fun a b c => t a b + t a c + t b c with hT
  have hf0 : ∀ a b c, 0 ≤ f a b c := fun a b c => by
    simp only [hf]; split_ifs
    · exact mul_nonneg (mul_nonneg (hw a) (hw b)) (hw c)
    · exact le_rfl
  have ht0 : ∀ a b, 0 ≤ t a b := fun a b =>
    Finset.sum_nonneg fun c _ => by split_ifs <;> simp [hw c]
  have hμ0 : ∀ c a, 0 ≤ μ c a := fun c a =>
    Finset.sum_nonneg fun d _ => by split_ifs <;> simp [hw d]
  have htsymm : ∀ a b, t a b = t b a := fun a b => by
    simp only [ht]; exact Finset.sum_congr rfl fun c _ => by simp only [hKiff₁ a b c]
  -- a single term of `t` is bounded by `t`
  have ht_ge : ∀ a b c, K a b c → w c ≤ t a b := fun a b c h => by
    simp only [ht]
    have := Finset.single_le_sum (f := fun d => if K a b d then w d else 0)
      (fun d _ => by split_ifs <;> simp [hw d]) (Finset.mem_univ c)
    simpa [h] using this
  -- (iii): t a b ≤ μ c a and t a b ≤ μ c b whenever K a b c
  have ht_le_μ : ∀ a b c, K a b c → t a b ≤ μ c a := fun a b c h => by
    simp only [ht, hμ]
    refine Finset.sum_le_sum fun d _ => ?_
    by_cases hd : K a b d
    · have h1 : ¬ L c d := hcanc a b c d h hd
      have h2 : L a d := hKL a d b (hK₂ a b d hd)
      simp [hd, h1, h2]
    · simp only [hd, if_false]; split_ifs <;> simp [hw d]
  have ht_le_μ' : ∀ a b c, K a b c → t a b ≤ μ c b := fun a b c h => by
    rw [htsymm a b]; exact ht_le_μ b a c (hK₁ a b c h)
  -- the symmetric weights h = f / T
  set g : V → V → V → ℝ := fun a b c => f a b c / T a b c with hg
  have hfT : ∀ a b c, f a b c = g a b c * T a b c := fun a b c => by
    simp only [hg]
    by_cases hK : K a b c
    · by_cases hc : w c = 0
      · simp [hf, hK, hc]
      · have hpos : 0 < T a b c := by
          have h1 := ht_ge a b c hK
          have : 0 < w c := lt_of_le_of_ne (hw c) (Ne.symm hc)
          simp only [hT]; linarith [ht0 a c, ht0 b c]
        rw [div_mul_cancel₀ _ hpos.ne']
    · simp [hf, hK]
  have hgsymm₂ : ∀ a b c, g a b c = g a c b := fun a b c => by
    simp only [hg, hf, hT, hKiff₂ a b c, htsymm c b]; ring_nf
  have hgsymm₃ : ∀ a b c, g a b c = g b c a := fun a b c => by
    simp only [hg, hf, hT, ← hKiff₃ a b c, htsymm b a, htsymm c a]
    split_ifs
    · congr 1 <;> ring
    · simp
  -- (ii): ∑ f = 3 ∑ g * t a b
  have hsplit : ∑ a, ∑ b, ∑ c, f a b c = 3 * ∑ a, ∑ b, ∑ c, g a b c * t a b := by
    have e1 : ∑ a, ∑ b, ∑ c, f a b c = ∑ a, ∑ b, ∑ c, g a b c * t a b
        + ∑ a, ∑ b, ∑ c, g a b c * t a c + ∑ a, ∑ b, ∑ c, g a b c * t b c := by
      simp only [← Finset.sum_add_distrib]
      refine Finset.sum_congr rfl fun a _ => Finset.sum_congr rfl fun b _ =>
        Finset.sum_congr rfl fun c _ => ?_
      rw [hfT a b c]; simp only [hT]; ring
    have e2 : ∑ a, ∑ b, ∑ c, g a b c * t a c = ∑ a, ∑ b, ∑ c, g a b c * t a b := by
      rw [sum3_swap23 (fun a b c => g a b c * t a c)]
      simp only [← hgsymm₂]
    have e3 : ∑ a, ∑ b, ∑ c, g a b c * t b c = ∑ a, ∑ b, ∑ c, g a b c * t a b := by
      rw [sum3_cycle (fun a b c => g a b c * t a b)]
      simp only [← hgsymm₃]
    rw [e1, e2, e3]; ring
  -- (iv): the pointwise bound
  have hpt : ∀ a b c, g a b c * t a b ≤
      (f a b c * μ c a * (1 / t a c) + f a b c * μ c b * (1 / t b c)) / 4 := fun a b c => by
    by_cases hK : K a b c
    · by_cases hz : w a * w b * w c = 0
      · simp [hg, hf, hK, hz]
      · have hwa : 0 < w a := lt_of_le_of_ne (hw a) (by intro h; apply hz; simp [← h])
        have hwb : 0 < w b := lt_of_le_of_ne (hw b) (by intro h; apply hz; simp [← h])
        have hpac : 0 < t a c := lt_of_lt_of_le hwb (ht_ge a c b (hK₂ _ _ _ hK))
        have hpbc : 0 < t b c := lt_of_lt_of_le hwa (ht_ge b c a (hK₃ _ _ _ hK))
        have hfpos : 0 ≤ f a b c := hf0 a b c
        have hTge : t a c + t b c ≤ T a b c := by simp only [hT]; linarith [ht0 a b]
        have hTpos : 0 < T a b c := lt_of_lt_of_le (by linarith) hTge
        have h1 : t a b / T a b c ≤ t a b * (1 / (t a c + t b c)) := by
          rw [div_le_iff₀ hTpos]
          calc t a b = t a b * (1 / (t a c + t b c)) * (t a c + t b c) := by
                field_simp
            _ ≤ t a b * (1 / (t a c + t b c)) * T a b c := by
                apply mul_le_mul_of_nonneg_left hTge
                have := ht0 a b
                positivity
        have h2 := inv_add_le_quarter (t a c) (t b c) hpac hpbc
        have h3 : t a b * (1 / t a c) ≤ μ c a * (1 / t a c) :=
          mul_le_mul_of_nonneg_right (ht_le_μ a b c hK) (by positivity)
        have h4 : t a b * (1 / t b c) ≤ μ c b * (1 / t b c) :=
          mul_le_mul_of_nonneg_right (ht_le_μ' a b c hK) (by positivity)
        calc g a b c * t a b = f a b c * (t a b / T a b c) := by simp only [hg]; ring
          _ ≤ f a b c * (t a b * (1 / (t a c + t b c))) := mul_le_mul_of_nonneg_left h1 hfpos
          _ ≤ f a b c * (t a b * ((1 / t a c + 1 / t b c) / 4)) := by
              apply mul_le_mul_of_nonneg_left _ hfpos
              exact mul_le_mul_of_nonneg_left h2 (ht0 a b)
          _ = f a b c * (t a b * (1 / t a c) + t a b * (1 / t b c)) / 4 := by ring
          _ ≤ f a b c * (μ c a * (1 / t a c) + μ c b * (1 / t b c)) / 4 := by
              apply div_le_div_of_nonneg_right _ (by norm_num)
              exact mul_le_mul_of_nonneg_left (add_le_add h3 h4) hfpos
          _ = _ := by ring
    · simp [hg, hf, hK]
  -- the two halves of the right side
  have hhalf₁ : ∑ a, ∑ b, ∑ c, f a b c * μ c a * (1 / t a c) ≤
      ∑ a, ∑ c, (if L a c then w a * w c * μ c a else 0) := by
    rw [show ∑ a, ∑ b, ∑ c, f a b c * μ c a * (1 / t a c) =
        ∑ a, ∑ c, ∑ b, f a b c * μ c a * (1 / t a c) from
      Finset.sum_congr rfl fun _ _ => Finset.sum_comm]
    refine Finset.sum_le_sum fun a _ => Finset.sum_le_sum fun c _ => ?_
    have hrw : ∑ b, f a b c * μ c a * (1 / t a c) = w a * w c * μ c a * (t a c / t a c) := by
      simp only [hf, ht, Finset.sum_div, Finset.mul_sum]
      refine Finset.sum_congr rfl fun b _ => ?_
      simp only [hKiff₂ a b c]; split_ifs <;> ring
    rw [hrw]
    by_cases hz : t a c = 0
    · simp only [hz, div_zero, mul_zero]; split_ifs
      · exact mul_nonneg (mul_nonneg (hw a) (hw c)) (hμ0 c a)
      · exact le_rfl
    · obtain ⟨b, hb⟩ : ∃ b, K a c b := by
        by_contra hne; push Not at hne; apply hz; simp [ht, hne]
      simp only [div_self hz, mul_one, if_pos (hKL a c b hb)]; exact le_rfl
  have hhalf₂ : ∑ a, ∑ b, ∑ c, f a b c * μ c b * (1 / t b c) ≤
      ∑ a, ∑ c, (if L a c then w a * w c * μ c a else 0) := by
    rw [show ∑ a, ∑ b, ∑ c, f a b c * μ c b * (1 / t b c) =
        ∑ b, ∑ c, ∑ a, f a b c * μ c b * (1 / t b c) from
      (Finset.sum_comm).trans (Finset.sum_congr rfl fun _ _ => Finset.sum_comm)]
    refine Finset.sum_le_sum fun b _ => Finset.sum_le_sum fun c _ => ?_
    have hrw : ∑ a, f a b c * μ c b * (1 / t b c) = w b * w c * μ c b * (t b c / t b c) := by
      simp only [hf, ht, Finset.sum_div, Finset.mul_sum]
      refine Finset.sum_congr rfl fun a _ => ?_
      simp only [hKiff₃ a b c]; split_ifs <;> ring
    rw [hrw]
    by_cases hz : t b c = 0
    · simp only [hz, div_zero, mul_zero]; split_ifs
      · exact mul_nonneg (mul_nonneg (hw b) (hw c)) (hμ0 c b)
      · exact le_rfl
    · obtain ⟨a, ha⟩ : ∃ a, K b c a := by
        by_contra hne; push Not at hne; apply hz; simp [ht, hne]
      simp only [div_self hz, mul_one, if_pos (hKL b c a ha)]; exact le_rfl
  -- the right side of the statement
  have hrhs : ∑ a, ∑ c, ∑ d, (if L a c ∧ L a d ∧ ¬ L c d then w a * w c * w d else 0) =
      ∑ a, ∑ c, (if L a c then w a * w c * μ c a else 0) := by
    refine Finset.sum_congr rfl fun a _ => Finset.sum_congr rfl fun c _ => ?_
    simp only [hμ, Finset.mul_sum]
    by_cases h : L a c
    · simp only [h, if_true, true_and]
      refine Finset.sum_congr rfl fun d _ => ?_
      split_ifs <;> ring
    · simp [h]
  rw [hrhs, hsplit]
  have hsum := Finset.sum_le_sum fun a (_ : a ∈ Finset.univ) => Finset.sum_le_sum
    fun b (_ : b ∈ Finset.univ) => Finset.sum_le_sum fun c (_ : c ∈ Finset.univ) => hpt a b c
  simp only [← Finset.sum_div, Finset.sum_add_distrib] at hsum
  linarith [hhalf₁, hhalf₂]

/-- **CL-3** (abstract, sharp constant 1): for each centre `a`, the `K`-link of `a` is a graph whose
neighbourhoods are `L`-independent; `∑ w_b w_c ≤ ∑ w_b w_c s_b / s_c` (AM–GM on `s_b/s_c + s_c/s_b`)
and `s_b ≤ μ(c, a)` give the bound. Equality holds for a single edge with equal weights. -/
theorem cl3_abstract (w : V → ℝ) (hw : ∀ v, 0 ≤ w v)
    (L : V → V → Prop) [DecidableRel L] (K : V → V → V → Prop) [∀ a b c, Decidable (K a b c)]
    (hK₂ : ∀ a b c, K a b c → K a c b)
    (hKL : ∀ a b c, K a b c → L a b)
    (hcanc : ∀ a b c d, K a b c → K a b d → ¬ L c d) :
    ∑ a, ∑ b, ∑ c, (if K a b c then w a * w b * w c else 0) ≤
      ∑ a, ∑ c, ∑ d, (if L a c ∧ L a d ∧ ¬ L c d then w a * w c * w d else 0) := by
  classical
  have hKiff₂ : ∀ a b c, K a b c ↔ K a c b := fun a b c => ⟨hK₂ a b c, hK₂ a c b⟩
  set μ : V → V → ℝ := fun c a => ∑ d, if L a d ∧ ¬ L c d then w d else 0 with hμ
  have hμ0 : ∀ c a, 0 ≤ μ c a := fun c a =>
    Finset.sum_nonneg fun d _ => by split_ifs <;> simp [hw d]
  -- the per-centre inequality
  have key : ∀ a, ∑ b, ∑ c, (if K a b c then w b * w c else 0) ≤
      ∑ c, (if L a c then w c * μ c a else 0) := by
    intro a
    set F : V → V → ℝ := fun b c => if K a b c then w b * w c else 0 with hF
    set s : V → ℝ := fun c => ∑ b, if K a b c then w b else 0 with hs
    have hF0 : ∀ b c, 0 ≤ F b c := fun b c => by
      simp only [hF]; split_ifs
      · exact mul_nonneg (hw b) (hw c)
      · exact le_rfl
    have hs0 : ∀ c, 0 ≤ s c := fun c =>
      Finset.sum_nonneg fun b _ => by split_ifs <;> simp [hw b]
    have hs_ge : ∀ b c, K a b c → w b ≤ s c := fun b c h => by
      simp only [hs]
      have := Finset.single_le_sum (f := fun d => if K a d c then w d else 0)
        (fun d _ => by split_ifs <;> simp [hw d]) (Finset.mem_univ b)
      simpa [h] using this
    have hFsymm : ∀ b c, F b c = F c b := fun b c => by
      simp only [hF, hKiff₂ a b c]; split_ifs <;> ring
    -- s_b ≤ μ(c, a) whenever abc ∈ K
    have hs_le : ∀ b c, K a b c → s b ≤ μ c a := fun b c h => by
      simp only [hs, hμ]
      refine Finset.sum_le_sum fun d _ => ?_
      by_cases hd : K a d b
      · have h1 : ¬ L c d := hcanc a b c d h (hK₂ _ _ _ hd)
        have h2 : L a d := hKL a d b hd
        simp [hd, h1, h2]
      · simp only [hd, if_false]; split_ifs <;> simp [hw d]
    -- AM–GM: F ≤ (F s_b/s_c + F s_c/s_b)/2
    have hpt : ∀ b c, F b c ≤ (F b c * (s b / s c) + F b c * (s c / s b)) / 2 := fun b c => by
      by_cases hK : K a b c
      · by_cases hz : w b * w c = 0
        · simp [hF, hK, hz]
        · have hwb : 0 < w b := lt_of_le_of_ne (hw b) (by intro h; apply hz; simp [← h])
          have hwc : 0 < w c := lt_of_le_of_ne (hw c) (by intro h; apply hz; simp [← h])
          have hsc : 0 < s c := lt_of_lt_of_le hwb (hs_ge b c hK)
          have hsb : 0 < s b := lt_of_lt_of_le hwc (hs_ge c b (hK₂ _ _ _ hK))
          have h2 : 2 ≤ s b / s c + s c / s b := by
            rw [div_add_div _ _ hsc.ne' hsb.ne', le_div_iff₀ (by positivity)]
            nlinarith [sq_nonneg (s b - s c)]
          have := mul_le_mul_of_nonneg_left h2 (hF0 b c)
          linarith
      · simp [hF, hK]
    have hX : ∑ b, ∑ c, F b c * (s c / s b) = ∑ b, ∑ c, F b c * (s b / s c) := by
      rw [Finset.sum_comm]
      refine Finset.sum_congr rfl fun c _ => Finset.sum_congr rfl fun b _ => ?_
      rw [hFsymm]
    have step1 : ∑ b, ∑ c, F b c ≤ ∑ b, ∑ c, F b c * (s b / s c) := by
      have hsum := Finset.sum_le_sum fun b (_ : b ∈ Finset.univ) =>
        Finset.sum_le_sum fun c (_ : c ∈ Finset.univ) => hpt b c
      simp only [← Finset.sum_div, Finset.sum_add_distrib, hX] at hsum
      linarith
    have step2 : ∑ b, ∑ c, F b c * (s b / s c) ≤ ∑ c, (if L a c then w c * μ c a else 0) := by
      rw [Finset.sum_comm]
      refine Finset.sum_le_sum fun c _ => ?_
      calc ∑ b, F b c * (s b / s c) ≤ ∑ b, F b c * (μ c a / s c) := by
            refine Finset.sum_le_sum fun b _ => ?_
            by_cases hK : K a b c
            · exact mul_le_mul_of_nonneg_left
                (div_le_div_of_nonneg_right (hs_le b c hK) (hs0 c)) (hF0 b c)
            · simp [hF, hK]
        _ = w c * μ c a * (s c / s c) := by
            simp only [hF, hs, Finset.sum_div, Finset.mul_sum]
            refine Finset.sum_congr rfl fun b _ => ?_
            split_ifs <;> ring
        _ ≤ if L a c then w c * μ c a else 0 := by
            by_cases hz : s c = 0
            · simp only [hz, div_zero, mul_zero]; split_ifs
              · exact mul_nonneg (hw c) (hμ0 c a)
              · exact le_rfl
            · obtain ⟨b, hb⟩ : ∃ b, K a b c := by
                by_contra hne; push Not at hne; apply hz; simp [hs, hne]
              simp only [div_self hz, mul_one, if_pos (hKL a c b (hK₂ _ _ _ hb))]; exact le_rfl
    exact step1.trans step2
  -- multiply by w a and sum over the centre
  calc ∑ a, ∑ b, ∑ c, (if K a b c then w a * w b * w c else 0)
      = ∑ a, w a * ∑ b, ∑ c, (if K a b c then w b * w c else 0) := by
        refine Finset.sum_congr rfl fun a _ => ?_
        simp only [Finset.mul_sum]
        refine Finset.sum_congr rfl fun b _ => Finset.sum_congr rfl fun c _ => ?_
        split_ifs <;> ring
    _ ≤ ∑ a, w a * ∑ c, (if L a c then w c * μ c a else 0) :=
        Finset.sum_le_sum fun a _ => mul_le_mul_of_nonneg_left (key a) (hw a)
    _ = ∑ a, ∑ c, ∑ d, (if L a c ∧ L a d ∧ ¬ L c d then w a * w c * w d else 0) := by
        refine Finset.sum_congr rfl fun a _ => ?_
        simp only [Finset.mul_sum]
        refine Finset.sum_congr rfl fun c _ => ?_
        simp only [hμ, Finset.mul_sum]
        by_cases h : L a c
        · simp only [h, if_true, true_and, Finset.mul_sum]
          refine Finset.sum_congr rfl fun d _ => ?_
          split_ifs <;> ring
        · simp [h]

/-- **CL-4** (abstract): CL-3 with any extra condition `P a c d` that co-neighbours satisfy.
CL-3 is the case `P = ⊤`. Original CL-3 doc: (abstract, sharp constant 1): for each centre `a`, the `K`-link of `a` is a graph whose
neighbourhoods are `L`-independent; `∑ w_b w_c ≤ ∑ w_b w_c s_b / s_c` (AM–GM on `s_b/s_c + s_c/s_b`)
and `s_b ≤ μ(c, a)` give the bound. Equality holds for a single edge with equal weights. -/
theorem cl4_abstract (w : V → ℝ) (hw : ∀ v, 0 ≤ w v)
    (L : V → V → Prop) [DecidableRel L] (K : V → V → V → Prop) [∀ a b c, Decidable (K a b c)]
    (P : V → V → V → Prop) [∀ a c d, Decidable (P a c d)]
    (hK₂ : ∀ a b c, K a b c → K a c b)
    (hKL : ∀ a b c, K a b c → L a b)
    (hcanc : ∀ a b c d, K a b c → K a b d → ¬ L c d ∧ P a c d) :
    ∑ a, ∑ b, ∑ c, (if K a b c then w a * w b * w c else 0) ≤
      ∑ a, ∑ c, ∑ d, (if L a c ∧ L a d ∧ ¬ L c d ∧ P a c d then w a * w c * w d else 0) := by
  classical
  have hKiff₂ : ∀ a b c, K a b c ↔ K a c b := fun a b c => ⟨hK₂ a b c, hK₂ a c b⟩
  set μ : V → V → ℝ := fun c a => ∑ d, if L a d ∧ ¬ L c d ∧ P a c d then w d else 0 with hμ
  have hμ0 : ∀ c a, 0 ≤ μ c a := fun c a =>
    Finset.sum_nonneg fun d _ => by split_ifs <;> simp [hw d]
  -- the per-centre inequality
  have key : ∀ a, ∑ b, ∑ c, (if K a b c then w b * w c else 0) ≤
      ∑ c, (if L a c then w c * μ c a else 0) := by
    intro a
    set F : V → V → ℝ := fun b c => if K a b c then w b * w c else 0 with hF
    set s : V → ℝ := fun c => ∑ b, if K a b c then w b else 0 with hs
    have hF0 : ∀ b c, 0 ≤ F b c := fun b c => by
      simp only [hF]; split_ifs
      · exact mul_nonneg (hw b) (hw c)
      · exact le_rfl
    have hs0 : ∀ c, 0 ≤ s c := fun c =>
      Finset.sum_nonneg fun b _ => by split_ifs <;> simp [hw b]
    have hs_ge : ∀ b c, K a b c → w b ≤ s c := fun b c h => by
      simp only [hs]
      have := Finset.single_le_sum (f := fun d => if K a d c then w d else 0)
        (fun d _ => by split_ifs <;> simp [hw d]) (Finset.mem_univ b)
      simpa [h] using this
    have hFsymm : ∀ b c, F b c = F c b := fun b c => by
      simp only [hF, hKiff₂ a b c]; split_ifs <;> ring
    -- s_b ≤ μ(c, a) whenever abc ∈ K
    have hs_le : ∀ b c, K a b c → s b ≤ μ c a := fun b c h => by
      simp only [hs, hμ]
      refine Finset.sum_le_sum fun d _ => ?_
      by_cases hd : K a d b
      · have h1 := hcanc a b c d h (hK₂ _ _ _ hd)
        have h2 : L a d := hKL a d b hd
        simp [hd, h1.1, h1.2, h2]
      · simp only [hd, if_false]; split_ifs <;> simp [hw d]
    -- AM–GM: F ≤ (F s_b/s_c + F s_c/s_b)/2
    have hpt : ∀ b c, F b c ≤ (F b c * (s b / s c) + F b c * (s c / s b)) / 2 := fun b c => by
      by_cases hK : K a b c
      · by_cases hz : w b * w c = 0
        · simp [hF, hK, hz]
        · have hwb : 0 < w b := lt_of_le_of_ne (hw b) (by intro h; apply hz; simp [← h])
          have hwc : 0 < w c := lt_of_le_of_ne (hw c) (by intro h; apply hz; simp [← h])
          have hsc : 0 < s c := lt_of_lt_of_le hwb (hs_ge b c hK)
          have hsb : 0 < s b := lt_of_lt_of_le hwc (hs_ge c b (hK₂ _ _ _ hK))
          have h2 : 2 ≤ s b / s c + s c / s b := by
            rw [div_add_div _ _ hsc.ne' hsb.ne', le_div_iff₀ (by positivity)]
            nlinarith [sq_nonneg (s b - s c)]
          have := mul_le_mul_of_nonneg_left h2 (hF0 b c)
          linarith
      · simp [hF, hK]
    have hX : ∑ b, ∑ c, F b c * (s c / s b) = ∑ b, ∑ c, F b c * (s b / s c) := by
      rw [Finset.sum_comm]
      refine Finset.sum_congr rfl fun c _ => Finset.sum_congr rfl fun b _ => ?_
      rw [hFsymm]
    have step1 : ∑ b, ∑ c, F b c ≤ ∑ b, ∑ c, F b c * (s b / s c) := by
      have hsum := Finset.sum_le_sum fun b (_ : b ∈ Finset.univ) =>
        Finset.sum_le_sum fun c (_ : c ∈ Finset.univ) => hpt b c
      simp only [← Finset.sum_div, Finset.sum_add_distrib, hX] at hsum
      linarith
    have step2 : ∑ b, ∑ c, F b c * (s b / s c) ≤ ∑ c, (if L a c then w c * μ c a else 0) := by
      rw [Finset.sum_comm]
      refine Finset.sum_le_sum fun c _ => ?_
      calc ∑ b, F b c * (s b / s c) ≤ ∑ b, F b c * (μ c a / s c) := by
            refine Finset.sum_le_sum fun b _ => ?_
            by_cases hK : K a b c
            · exact mul_le_mul_of_nonneg_left
                (div_le_div_of_nonneg_right (hs_le b c hK) (hs0 c)) (hF0 b c)
            · simp [hF, hK]
        _ = w c * μ c a * (s c / s c) := by
            simp only [hF, hs, Finset.sum_div, Finset.mul_sum]
            refine Finset.sum_congr rfl fun b _ => ?_
            split_ifs <;> ring
        _ ≤ if L a c then w c * μ c a else 0 := by
            by_cases hz : s c = 0
            · simp only [hz, div_zero, mul_zero]; split_ifs
              · exact mul_nonneg (hw c) (hμ0 c a)
              · exact le_rfl
            · obtain ⟨b, hb⟩ : ∃ b, K a b c := by
                by_contra hne; push Not at hne; apply hz; simp [hs, hne]
              simp only [div_self hz, mul_one, if_pos (hKL a c b (hK₂ _ _ _ hb))]; exact le_rfl
    exact step1.trans step2
  -- multiply by w a and sum over the centre
  calc ∑ a, ∑ b, ∑ c, (if K a b c then w a * w b * w c else 0)
      = ∑ a, w a * ∑ b, ∑ c, (if K a b c then w b * w c else 0) := by
        refine Finset.sum_congr rfl fun a _ => ?_
        simp only [Finset.mul_sum]
        refine Finset.sum_congr rfl fun b _ => Finset.sum_congr rfl fun c _ => ?_
        split_ifs <;> ring
    _ ≤ ∑ a, w a * ∑ c, (if L a c then w c * μ c a else 0) :=
        Finset.sum_le_sum fun a _ => mul_le_mul_of_nonneg_left (key a) (hw a)
    _ = ∑ a, ∑ c, ∑ d, (if L a c ∧ L a d ∧ ¬ L c d ∧ P a c d then w a * w c * w d else 0) := by
        refine Finset.sum_congr rfl fun a _ => ?_
        simp only [Finset.mul_sum]
        refine Finset.sum_congr rfl fun c _ => ?_
        simp only [hμ, Finset.mul_sum]
        by_cases h : L a c
        · simp only [h, if_true, true_and, Finset.mul_sum]
          refine Finset.sum_congr rfl fun d _ => ?_
          split_ifs <;> ring
        · simp [h]

end Abstract

section C5

variable {n : ℕ}

/-- `L a b`: the pair `ab` is in the link of `x`. -/
abbrev Lk (H : Finset (Finset (Fin n))) (x a b : Fin n) : Prop :=
  ({x, a, b} : Finset (Fin n)) ∈ H

/-- `K a b c`: `abc` is an edge and its three pairs are in the link of `x` (a `K₄³` on `xabc`). -/
abbrev K4 (H : Finset (Finset (Fin n))) (x a b c : Fin n) : Prop :=
  ({a, b, c} : Finset (Fin n)) ∈ H ∧ Lk H x a b ∧ Lk H x a c ∧ Lk H x b c

lemma distinct_of_mem {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H) {a b c : Fin n}
    (h : ({a, b, c} : Finset (Fin n)) ∈ H) : a ≠ b ∧ a ≠ c ∧ b ≠ c := by
  have h3 := hH _ h
  refine ⟨?_, ?_, ?_⟩
  · rintro rfl
    have : ({a, a, c} : Finset (Fin n)) = {a, c} := by ext; simp
    rw [this] at h3; have := Finset.card_insert_le a ({c} : Finset (Fin n)); simp at this; omega
  · rintro rfl
    have : ({a, b, a} : Finset (Fin n)) = {a, b} := by ext; simp; tauto
    rw [this] at h3; have := Finset.card_insert_le a ({b} : Finset (Fin n)); simp at this; omega
  · rintro rfl
    have : ({a, b, b} : Finset (Fin n)) = {a, b} := by ext; simp
    rw [this] at h3; have := Finset.card_insert_le a ({b} : Finset (Fin n)); simp at this; omega

lemma mem_perm {H : Finset (Finset (Fin n))} {a b c : Fin n}
    (h : ({a, b, c} : Finset (Fin n)) ∈ H) :
    ({b, a, c} : Finset (Fin n)) ∈ H ∧ ({a, c, b} : Finset (Fin n)) ∈ H := by
  have e1 : ({b, a, c} : Finset (Fin n)) = {a, b, c} := by ext; simp; tauto
  have e2 : ({a, c, b} : Finset (Fin n)) = {a, b, c} := by ext; simp; tauto
  exact ⟨e1 ▸ h, e2 ▸ h⟩

/-- (i): two `K₄³`s `xabc`, `xabd` through the pair `ab` force `cd ∉ L(x)`, else
`(c, a, b, d, x)` is a tight 5-cycle. -/
lemma link_cancellative {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H) (hfree : ¬ ContainsC5 H)
    (x a b c d : Fin n) (h1 : K4 H x a b c) (h2 : K4 H x a b d) : ¬ Lk H x c d := by
  intro hcd
  obtain ⟨habc, hxab, hxac, hxbc⟩ := h1
  obtain ⟨habd, -, hxad, hxbd⟩ := h2
  obtain ⟨hab, hac, hbc⟩ := distinct_of_mem hH habc
  obtain ⟨-, had, hbd⟩ := distinct_of_mem hH habd
  obtain ⟨hxc, hxd, hcd'⟩ := distinct_of_mem hH hcd
  obtain ⟨hxa, -, -⟩ := distinct_of_mem hH hxab
  obtain ⟨-, hxb, -⟩ := distinct_of_mem hH hxab
  apply hfree
  refine ⟨⟨![c, a, b, d, x], ?_⟩, ?_⟩
  · intro i j hij
    fin_cases i <;> fin_cases j <;> simp_all [eq_comm]
  · intro i
    fin_cases i
    · have e : ({c, a, b} : Finset (Fin n)) = {a, b, c} := by ext; simp; tauto
      simpa [e] using habc
    · simpa using habd
    · have e : ({b, d, x} : Finset (Fin n)) = {x, b, d} := by ext; simp; tauto
      simpa [e] using hxbd
    · have e : ({d, x, c} : Finset (Fin n)) = {x, c, d} := by ext; simp; tauto
      simpa [e] using hcd
    · have e : ({x, c, a} : Finset (Fin n)) = {x, a, c} := by ext; simp; tauto
      simpa [e] using hxac

/-- **CL-1.** For a `C₅³`-free 3-graph `H`, a vertex `x` and weights `w ≥ 0`, the weighted
count of `K₄³`s `xabc` is at most `3/2` times the weighted count of triples `abc` with
`ab ∉ L(x)` and `ac ∈ L(x)` (ordered triples, repetitions allowed). -/
theorem cl_link (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H) (hfree : ¬ ContainsC5 H)
    (x : Fin n) (w : Fin n → ℝ) (hw : ∀ v, 0 ≤ w v) :
    ∑ a, ∑ b, ∑ c, (if K4 H x a b c then w a * w b * w c else 0) ≤
      (3 / 2) * ∑ a, ∑ b, ∑ c,
        (if Lk H x a b then 0 else if Lk H x a c then w a * w b * w c else 0) := by
  refine cl_abstract w hw (Lk H x) (K4 H x) ?_ ?_ ?_ ?_ ?_
  · intro a b h
    have e : ({x, b, a} : Finset (Fin n)) = {x, a, b} := by ext; simp; tauto
    simpa [Lk, e] using h
  · rintro a b c ⟨h, hab, hac, hbc⟩
    have e : ({x, b, a} : Finset (Fin n)) = {x, a, b} := by ext; simp; tauto
    exact ⟨(mem_perm h).1, by simpa [Lk, e] using hab, hbc, hac⟩
  · rintro a b c ⟨h, hab, hac, hbc⟩
    have e : ({x, c, b} : Finset (Fin n)) = {x, b, c} := by ext; simp; tauto
    exact ⟨(mem_perm h).2, hac, hab, by simpa [Lk, e] using hbc⟩
  · rintro a b c ⟨-, hab, -, -⟩; exact hab
  · exact link_cancellative hH hfree x

/-- **CL-2.** As `cl_link`, with the induced cherries `c – a – d` of `L(x)` (`ac, ad ∈ L(x)`,
`cd ∉ L(x)`) on the right; this implies `cl_link`. -/
theorem cl2_link (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H) (hfree : ¬ ContainsC5 H)
    (x : Fin n) (w : Fin n → ℝ) (hw : ∀ v, 0 ≤ w v) :
    ∑ a, ∑ b, ∑ c, (if K4 H x a b c then w a * w b * w c else 0) ≤
      (3 / 2) * ∑ a, ∑ c, ∑ d,
        (if Lk H x a c ∧ Lk H x a d ∧ ¬ Lk H x c d then w a * w c * w d else 0) := by
  refine cl2_abstract w hw (Lk H x) (K4 H x) ?_ ?_ ?_ ?_ ?_
  · intro a b h
    have e : ({x, b, a} : Finset (Fin n)) = {x, a, b} := by ext; simp; tauto
    simpa [Lk, e] using h
  · rintro a b c ⟨h, hab, hac, hbc⟩
    have e : ({x, b, a} : Finset (Fin n)) = {x, a, b} := by ext; simp; tauto
    exact ⟨(mem_perm h).1, by simpa [Lk, e] using hab, hbc, hac⟩
  · rintro a b c ⟨h, hab, hac, hbc⟩
    have e : ({x, c, b} : Finset (Fin n)) = {x, b, c} := by ext; simp; tauto
    exact ⟨(mem_perm h).2, hac, hab, by simpa [Lk, e] using hbc⟩
  · rintro a b c ⟨-, hab, -, -⟩; exact hab
  · exact link_cancellative hH hfree x

/-- **CL-3** (sharp): the weighted count of `K₄³`s `xabc` is at most the weighted count of
induced cherries `c – a – d` of `L(x)` (`ac, ad ∈ L(x)`, `cd ∉ L(x)`; `d = c` allowed). This
implies `cl2_link` and `cl_link`. -/
theorem cl3_link (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H) (hfree : ¬ ContainsC5 H)
    (x : Fin n) (w : Fin n → ℝ) (hw : ∀ v, 0 ≤ w v) :
    ∑ a, ∑ b, ∑ c, (if K4 H x a b c then w a * w b * w c else 0) ≤
      ∑ a, ∑ c, ∑ d,
        (if Lk H x a c ∧ Lk H x a d ∧ ¬ Lk H x c d then w a * w c * w d else 0) := by
  refine cl3_abstract w hw (Lk H x) (K4 H x) ?_ ?_ ?_
  · rintro a b c ⟨h, hab, hac, hbc⟩
    have e : ({x, c, b} : Finset (Fin n)) = {x, b, c} := by ext; simp; tauto
    exact ⟨(mem_perm h).2, hac, hab, by simpa [Lk, e] using hbc⟩
  · rintro a b c ⟨-, hab, -, -⟩; exact hab
  · exact link_cancellative hH hfree x

/-- **CL-4**: CL-3 with the extra condition `acd ∉ H` on the cherries: if `xabc`, `xabd` are
`K₄³`s and `acd ∈ H`, then `(x, b, c, a, d)` is a tight 5-cycle. -/
lemma link_cancellative_acd {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H)
    (hfree : ¬ ContainsC5 H) (x a b c d : Fin n) (h1 : K4 H x a b c) (h2 : K4 H x a b d) :
    ({a, c, d} : Finset (Fin n)) ∉ H := by
  intro hacd
  obtain ⟨habc, hxab, hxac, hxbc⟩ := h1
  obtain ⟨habd, -, hxad, hxbd⟩ := h2
  obtain ⟨hab, hac, hbc⟩ := distinct_of_mem hH habc
  obtain ⟨-, had, hbd⟩ := distinct_of_mem hH habd
  obtain ⟨-, -, hcd⟩ := distinct_of_mem hH hacd
  obtain ⟨hxa, -, -⟩ := distinct_of_mem hH hxab
  obtain ⟨-, hxb, -⟩ := distinct_of_mem hH hxab
  obtain ⟨-, hxc, -⟩ := distinct_of_mem hH hxac
  obtain ⟨-, hxd, -⟩ := distinct_of_mem hH hxad
  apply hfree
  refine ⟨⟨![x, b, c, a, d], ?_⟩, ?_⟩
  · intro i j hij
    fin_cases i <;> fin_cases j <;> simp_all [eq_comm]
  · intro i
    fin_cases i
    · simpa using hxbc
    · have e : ({b, c, a} : Finset (Fin n)) = {a, b, c} := by ext; simp; tauto
      simpa [e] using habc
    · have e : ({c, a, d} : Finset (Fin n)) = {a, c, d} := by ext; simp; tauto
      simpa [e] using hacd
    · have e : ({a, d, x} : Finset (Fin n)) = {x, a, d} := by ext; simp; tauto
      simpa [e] using hxad
    · have e : ({d, x, b} : Finset (Fin n)) = {x, b, d} := by ext; simp; tauto
      simpa [e] using hxbd

theorem cl4_link (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H) (hfree : ¬ ContainsC5 H)
    (x : Fin n) (w : Fin n → ℝ) (hw : ∀ v, 0 ≤ w v) :
    ∑ a, ∑ b, ∑ c, (if K4 H x a b c then w a * w b * w c else 0) ≤
      ∑ a, ∑ c, ∑ d, (if Lk H x a c ∧ Lk H x a d ∧ ¬ Lk H x c d ∧
          ({a, c, d} : Finset (Fin n)) ∉ H then w a * w c * w d else 0) := by
  refine cl4_abstract w hw (Lk H x) (K4 H x) (fun a c d => ({a, c, d} : Finset (Fin n)) ∉ H)
    ?_ ?_ ?_
  · rintro a b c ⟨h, hab, hac, hbc⟩
    have e : ({x, c, b} : Finset (Fin n)) = {x, b, c} := by ext; simp; tauto
    exact ⟨(mem_perm h).2, hac, hab, by simpa [Lk, e] using hbc⟩
  · rintro a b c ⟨-, hab, -, -⟩; exact hab
  · intro a b c d h1 h2
    exact ⟨link_cancellative hH hfree x a b c d h1 h2, link_cancellative_acd hH hfree x a b c d h1 h2⟩

end C5

end TightCycleC5.HelperD

#print axioms TightCycleC5.HelperD.cl_link
#print axioms TightCycleC5.HelperD.cl2_link
#print axioms TightCycleC5.HelperD.cl3_link
#print axioms TightCycleC5.HelperD.cl4_link
