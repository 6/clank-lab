-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk36 :
    ∀ i : Fin (min 128 (40547 - 128 * 36)),
      targetCountsMatch (classAt (targetKernelClass ⟨36, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk36

theorem target_counts_kernel_chunk37 :
    ∀ i : Fin (min 128 (40547 - 128 * 37)),
      targetCountsMatch (classAt (targetKernelClass ⟨37, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk37

theorem target_counts_kernel_chunk38 :
    ∀ i : Fin (min 128 (40547 - 128 * 38)),
      targetCountsMatch (classAt (targetKernelClass ⟨38, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk38

theorem target_counts_kernel_chunk39 :
    ∀ i : Fin (min 128 (40547 - 128 * 39)),
      targetCountsMatch (classAt (targetKernelClass ⟨39, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk39


end TightCycleC5.Bridge.P33Arithmetic
