-- Generated from the pinned P33 manifest; untrusted proof quotation.
import P33PSDMatchingCore
import P33FlagData
import P33ArithmeticBlocks0
import P33ArithmeticBlocks1
import P33ArithmeticBlocks2
import P33ArithmeticBlocks3
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000
namespace TightCycleC5.Bridge.P33PSDMatching
open Finset Matrix

theorem source_metadata5 :
    P33Arithmetic.block5.flags = P33Flag.basis5Data ∧
    P33Arithmetic.block5.roots = 4 ∧
    P33Arithmetic.block5.typeCode = P33Flag.type5 := by decide +kernel
theorem source_terms5 : ∀ k : Fin 17, ∀ i j : Fin 128,
    P33Arithmetic.termEntry P33Arithmetic.block5.terms[k.val]! i.val j.val =
      (P33PSD.weights5 k : ℤ) * P33PSD.terms5 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry5 : ∀ i j : Fin 128,
    P33Arithmetic.blockEntry P33Arithmetic.block5 i.val j.val = P33PSD.q5 i j :=
  blockEntry_eq_sos P33Arithmetic.block5 P33PSD.weights5 P33PSD.terms5 rfl source_terms5
#print axioms source_metadata5
#print axioms source_terms5
#print axioms source_entry5

theorem source_metadata11 :
    P33Arithmetic.block11.flags = P33Flag.basis11Data ∧
    P33Arithmetic.block11.roots = 4 ∧
    P33Arithmetic.block11.typeCode = P33Flag.type11 := by decide +kernel
theorem source_terms11 : ∀ k : Fin 5, ∀ i j : Fin 128,
    P33Arithmetic.termEntry P33Arithmetic.block11.terms[k.val]! i.val j.val =
      (P33PSD.weights11 k : ℤ) * P33PSD.terms11 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry11 : ∀ i j : Fin 128,
    P33Arithmetic.blockEntry P33Arithmetic.block11 i.val j.val = P33PSD.q11 i j :=
  blockEntry_eq_sos P33Arithmetic.block11 P33PSD.weights11 P33PSD.terms11 rfl source_terms11
#print axioms source_metadata11
#print axioms source_terms11
#print axioms source_entry11

theorem source_metadata17 :
    P33Arithmetic.block17.flags = P33Flag.basis17Data ∧
    P33Arithmetic.block17.roots = 4 ∧
    P33Arithmetic.block17.typeCode = P33Flag.type17 := by decide +kernel
theorem source_terms17 : ∀ k : Fin 17, ∀ i j : Fin 100,
    P33Arithmetic.termEntry P33Arithmetic.block17.terms[k.val]! i.val j.val =
      (P33PSD.weights17 k : ℤ) * P33PSD.terms17 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry17 : ∀ i j : Fin 100,
    P33Arithmetic.blockEntry P33Arithmetic.block17 i.val j.val = P33PSD.q17 i j :=
  blockEntry_eq_sos P33Arithmetic.block17 P33PSD.weights17 P33PSD.terms17 rfl source_terms17
#print axioms source_metadata17
#print axioms source_terms17
#print axioms source_entry17

theorem source_metadata23 :
    P33Arithmetic.block23.flags = P33Flag.basis23Data ∧
    P33Arithmetic.block23.roots = 4 ∧
    P33Arithmetic.block23.typeCode = P33Flag.type23 := by decide +kernel
theorem source_terms23 : ∀ k : Fin 8, ∀ i j : Fin 100,
    P33Arithmetic.termEntry P33Arithmetic.block23.terms[k.val]! i.val j.val =
      (P33PSD.weights23 k : ℤ) * P33PSD.terms23 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry23 : ∀ i j : Fin 100,
    P33Arithmetic.blockEntry P33Arithmetic.block23 i.val j.val = P33PSD.q23 i j :=
  blockEntry_eq_sos P33Arithmetic.block23 P33PSD.weights23 P33PSD.terms23 rfl source_terms23
#print axioms source_metadata23
#print axioms source_terms23
#print axioms source_entry23

theorem source_metadata29 :
    P33Arithmetic.block29.flags = P33Flag.basis29Data ∧
    P33Arithmetic.block29.roots = 4 ∧
    P33Arithmetic.block29.typeCode = P33Flag.type29 := by decide +kernel
theorem source_terms29 : ∀ k : Fin 9, ∀ i j : Fin 78,
    P33Arithmetic.termEntry P33Arithmetic.block29.terms[k.val]! i.val j.val =
      (P33PSD.weights29 k : ℤ) * P33PSD.terms29 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry29 : ∀ i j : Fin 78,
    P33Arithmetic.blockEntry P33Arithmetic.block29 i.val j.val = P33PSD.q29 i j :=
  blockEntry_eq_sos P33Arithmetic.block29 P33PSD.weights29 P33PSD.terms29 rfl source_terms29
#print axioms source_metadata29
#print axioms source_terms29
#print axioms source_entry29

theorem source_metadata35 :
    P33Arithmetic.block35.flags = P33Flag.basis35Data ∧
    P33Arithmetic.block35.roots = 4 ∧
    P33Arithmetic.block35.typeCode = P33Flag.type35 := by decide +kernel
theorem source_terms35 : ∀ k : Fin 6, ∀ i j : Fin 60,
    P33Arithmetic.termEntry P33Arithmetic.block35.terms[k.val]! i.val j.val =
      (P33PSD.weights35 k : ℤ) * P33PSD.terms35 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry35 : ∀ i j : Fin 60,
    P33Arithmetic.blockEntry P33Arithmetic.block35 i.val j.val = P33PSD.q35 i j :=
  blockEntry_eq_sos P33Arithmetic.block35 P33PSD.weights35 P33PSD.terms35 rfl source_terms35
#print axioms source_metadata35
#print axioms source_terms35
#print axioms source_entry35

end TightCycleC5.Bridge.P33PSDMatching
