import GramSoundness

/-! The certificate's integer Gram matrices have a square denominator. -/
namespace TightCycleC5.Bridge

noncomputable def normalizedIntMatrix {I J : Type*} (Q : Matrix I J ℤ) (s : ℤ) :
    Matrix I J ℝ := fun i j => (Q i j : ℝ) / (s : ℝ) ^ 2

theorem normalized_int_gram_posSemidef {I J : Type*} [Finite I] [Fintype J]
    (Q : Matrix I I ℤ) (U : Matrix I J ℤ) (s : ℤ) (hgram : Q = U * U.transpose) :
    (normalizedIntMatrix Q s).PosSemidef := by
  have he : normalizedIntMatrix Q s = ((s : ℝ) ^ 2)⁻¹ • intMatrixReal Q := by
    ext i j
    simp only [normalizedIntMatrix, intMatrixReal, Matrix.smul_apply, smul_eq_mul]
    rw [div_eq_mul_inv, mul_comm]
  rw [he]
  exact (int_gram_posSemidef Q U hgram).smul (inv_nonneg.mpr (sq_nonneg _))

theorem normalized_int_diagonal_bound {I : Type*} (Q : Matrix I I ℤ) (m s : ℤ)
    (hdiag : ∀ i, Q i i ≤ m) :
    ∀ i, normalizedIntMatrix Q s i i ≤ (m : ℝ) / (s : ℝ) ^ 2 := by
  intro i
  exact div_le_div_of_nonneg_right (int_diagonal_bound Q m hdiag i) (sq_nonneg _)

theorem normalized_bound_nonneg (m s : ℤ) (hm : (0 : ℝ) ≤ (m : ℝ)) :
    (0 : ℝ) ≤ (m : ℝ) / (s : ℝ) ^ 2 := div_nonneg hm (sq_nonneg _)

#print axioms normalized_int_gram_posSemidef
#print axioms normalized_int_diagonal_bound
#print axioms normalized_bound_nonneg
end TightCycleC5.Bridge
