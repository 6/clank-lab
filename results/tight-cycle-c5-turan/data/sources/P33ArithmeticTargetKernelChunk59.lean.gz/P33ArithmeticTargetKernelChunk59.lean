-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk236 :
    ∀ i : Fin (min 128 (40547 - 128 * 236)),
      targetCountsMatch (classAt (targetKernelClass ⟨236, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk236

theorem target_counts_kernel_chunk237 :
    ∀ i : Fin (min 128 (40547 - 128 * 237)),
      targetCountsMatch (classAt (targetKernelClass ⟨237, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk237

theorem target_counts_kernel_chunk238 :
    ∀ i : Fin (min 128 (40547 - 128 * 238)),
      targetCountsMatch (classAt (targetKernelClass ⟨238, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk238

theorem target_counts_kernel_chunk239 :
    ∀ i : Fin (min 128 (40547 - 128 * 239)),
      targetCountsMatch (classAt (targetKernelClass ⟨239, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk239


end TightCycleC5.Bridge.P33Arithmetic
