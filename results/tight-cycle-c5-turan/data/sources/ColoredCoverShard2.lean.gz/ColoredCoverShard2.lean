import ColoredCoverSemantics

namespace TightCycleC5.Bridge.ColoredCover
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def coloredWitness64 : Array Nat := #[1657440, 1658160, 1658880, 1659600, 1658904, 1659624, 1660320, 1661040, 1661760, 1662480, 1663200, 1663920, 1663224, 1663944, 1664640, 1665360, 1666080, 1666800, 1667520, 1668240, 1667544, 1668264, 1668960, 1669680, 1670400, 1671120, 1671840, 1672560, 1671864, 1672584, 1673280, 1674000, 1674720, 1675440, 1676160, 1676880, 1676184, 1676904, 1677600, 1678320, 1679040, 1679760, 1680480, 1681200, 1680504, 1681224, 1681920, 1682640, 1683360, 1684080, 1684800, 1685520, 1684824, 1685544, 1686240, 1686960, 1687680, 1688400, 1689120, 1689840, 1689144, 1689864, 1690560, 1691280]

theorem colored_row64 : ∀ c : Fin 64,
    readRow witnessRows (64 * 64 + c.val) = coloredWitness64[c.val]! := by
  decide +kernel
#print axioms colored_row64

theorem colored_check64 : ∀ c : Fin 64,
    checkColored 64 (BitVec.ofNat 6 c.val) (coloredWitness64[c.val]!) = true := by
  decide +kernel
#print axioms colored_check64

theorem colored_family64 : ∀ c : Fin 64,
    checkColored 64 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (64 * 64 + c.val)) = true := by
  intro c
  rw [colored_row64]
  exact colored_check64 c
#print axioms colored_family64

def coloredWitness65 : Array Nat := #[1692000, 1692720, 1693440, 1694160, 1694880, 1695600, 1696320, 1697040, 1694886, 1695606, 1696326, 1697046, 1697760, 1698480, 1699200, 1699920, 1700640, 1701360, 1702080, 1702800, 1703520, 1704240, 1704960, 1705680, 1703526, 1704246, 1704966, 1705686, 1706400, 1707120, 1707840, 1708560, 1709280, 1710000, 1710720, 1711440, 1712160, 1712880, 1713600, 1714320, 1712166, 1712886, 1713606, 1714326, 1715040, 1715760, 1716480, 1717200, 1717920, 1718640, 1719360, 1720080, 1720800, 1721520, 1722240, 1722960, 1720806, 1721526, 1722246, 1722966, 1723680, 1724400, 1725120, 1725840]

theorem colored_row65 : ∀ c : Fin 64,
    readRow witnessRows (65 * 64 + c.val) = coloredWitness65[c.val]! := by
  decide +kernel
#print axioms colored_row65

theorem colored_check65 : ∀ c : Fin 64,
    checkColored 65 (BitVec.ofNat 6 c.val) (coloredWitness65[c.val]!) = true := by
  decide +kernel
#print axioms colored_check65

theorem colored_family65 : ∀ c : Fin 64,
    checkColored 65 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (65 * 64 + c.val)) = true := by
  intro c
  rw [colored_row65]
  exact colored_check65 c
#print axioms colored_family65

def coloredWitness66 : Array Nat := #[1726560, 1727280, 1728000, 1728720, 1729440, 1730160, 1730880, 1731600, 1729446, 1730166, 1730886, 1731606, 1732320, 1733040, 1733760, 1734480, 1735200, 1735920, 1736640, 1737360, 1738080, 1738800, 1739520, 1740240, 1738086, 1738806, 1739526, 1740246, 1740960, 1741680, 1742400, 1743120, 1743840, 1744560, 1745280, 1746000, 1746720, 1747440, 1748160, 1748880, 1746726, 1747446, 1748166, 1748886, 1749600, 1750320, 1751040, 1751760, 1752480, 1753200, 1753920, 1754640, 1755360, 1756080, 1756800, 1757520, 1755366, 1756086, 1756806, 1757526, 1758240, 1758960, 1759680, 1760400]

theorem colored_row66 : ∀ c : Fin 64,
    readRow witnessRows (66 * 64 + c.val) = coloredWitness66[c.val]! := by
  decide +kernel
#print axioms colored_row66

theorem colored_check66 : ∀ c : Fin 64,
    checkColored 66 (BitVec.ofNat 6 c.val) (coloredWitness66[c.val]!) = true := by
  decide +kernel
#print axioms colored_check66

theorem colored_family66 : ∀ c : Fin 64,
    checkColored 66 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (66 * 64 + c.val)) = true := by
  intro c
  rw [colored_row66]
  exact colored_check66 c
#print axioms colored_family66

def coloredWitness67 : Array Nat := #[1761120, 1761840, 1762560, 1763280, 1764000, 1764720, 1765440, 1766160, 1766880, 1767600, 1768320, 1769040, 1769760, 1770480, 1771200, 1771920, 1772640, 1773360, 1774080, 1774800, 1775520, 1776240, 1776960, 1777680, 1778400, 1779120, 1779840, 1780560, 1781280, 1782000, 1782720, 1783440, 1784160, 1784880, 1785600, 1786320, 1787040, 1787760, 1788480, 1789200, 1789920, 1790640, 1791360, 1792080, 1792800, 1793520, 1794240, 1794960, 1795680, 1796400, 1797120, 1797840, 1798560, 1799280, 1800000, 1800720, 1801440, 1802160, 1802880, 1803600, 1804320, 1805040, 1805760, 1806480]

theorem colored_row67 : ∀ c : Fin 64,
    readRow witnessRows (67 * 64 + c.val) = coloredWitness67[c.val]! := by
  decide +kernel
#print axioms colored_row67

theorem colored_check67 : ∀ c : Fin 64,
    checkColored 67 (BitVec.ofNat 6 c.val) (coloredWitness67[c.val]!) = true := by
  decide +kernel
#print axioms colored_check67

theorem colored_family67 : ∀ c : Fin 64,
    checkColored 67 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (67 * 64 + c.val)) = true := by
  intro c
  rw [colored_row67]
  exact colored_check67 c
#print axioms colored_family67

def coloredWitness68 : Array Nat := #[1807200, 1807920, 1808640, 1809360, 1810080, 1810800, 1811520, 1812240, 1810086, 1810806, 1811526, 1812246, 1812960, 1813680, 1814400, 1815120, 1815840, 1816560, 1817280, 1818000, 1818720, 1819440, 1820160, 1820880, 1818726, 1819446, 1820166, 1820886, 1821600, 1822320, 1823040, 1823760, 1824480, 1825200, 1825920, 1826640, 1827360, 1828080, 1828800, 1829520, 1827366, 1828086, 1828806, 1829526, 1830240, 1830960, 1831680, 1832400, 1833120, 1833840, 1834560, 1835280, 1836000, 1836720, 1837440, 1838160, 1836006, 1836726, 1837446, 1838166, 1838880, 1839600, 1840320, 1841040]

theorem colored_row68 : ∀ c : Fin 64,
    readRow witnessRows (68 * 64 + c.val) = coloredWitness68[c.val]! := by
  decide +kernel
#print axioms colored_row68

theorem colored_check68 : ∀ c : Fin 64,
    checkColored 68 (BitVec.ofNat 6 c.val) (coloredWitness68[c.val]!) = true := by
  decide +kernel
#print axioms colored_check68

theorem colored_family68 : ∀ c : Fin 64,
    checkColored 68 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (68 * 64 + c.val)) = true := by
  intro c
  rw [colored_row68]
  exact colored_check68 c
#print axioms colored_family68

def coloredWitness69 : Array Nat := #[1841760, 1842480, 1843200, 1843920, 1844640, 1845360, 1846080, 1846800, 1844646, 1845366, 1846086, 1846806, 1847520, 1848240, 1848960, 1849680, 1850400, 1851120, 1851840, 1852560, 1853280, 1854000, 1854720, 1855440, 1853286, 1854006, 1854726, 1855446, 1856160, 1856880, 1857600, 1858320, 1859040, 1859760, 1860480, 1861200, 1861920, 1862640, 1863360, 1864080, 1861926, 1862646, 1863366, 1864086, 1864800, 1865520, 1866240, 1866960, 1867680, 1868400, 1869120, 1869840, 1870560, 1871280, 1872000, 1872720, 1870566, 1871286, 1872006, 1872726, 1873440, 1874160, 1874880, 1875600]

theorem colored_row69 : ∀ c : Fin 64,
    readRow witnessRows (69 * 64 + c.val) = coloredWitness69[c.val]! := by
  decide +kernel
#print axioms colored_row69

theorem colored_check69 : ∀ c : Fin 64,
    checkColored 69 (BitVec.ofNat 6 c.val) (coloredWitness69[c.val]!) = true := by
  decide +kernel
#print axioms colored_check69

theorem colored_family69 : ∀ c : Fin 64,
    checkColored 69 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (69 * 64 + c.val)) = true := by
  intro c
  rw [colored_row69]
  exact colored_check69 c
#print axioms colored_family69

def coloredWitness70 : Array Nat := #[1876320, 1877040, 1877760, 1878480, 1879200, 1879920, 1880640, 1881360, 1882080, 1882800, 1883520, 1884240, 1884960, 1885680, 1886400, 1887120, 1887840, 1888560, 1889280, 1890000, 1890720, 1891440, 1892160, 1892880, 1893600, 1894320, 1895040, 1895760, 1896480, 1897200, 1897920, 1898640, 1899360, 1900080, 1900800, 1901520, 1902240, 1902960, 1903680, 1904400, 1905120, 1905840, 1906560, 1907280, 1908000, 1908720, 1909440, 1910160, 1910880, 1911600, 1912320, 1913040, 1913760, 1914480, 1915200, 1915920, 1916640, 1917360, 1918080, 1918800, 1919520, 1920240, 1920960, 1921680]

theorem colored_row70 : ∀ c : Fin 64,
    readRow witnessRows (70 * 64 + c.val) = coloredWitness70[c.val]! := by
  decide +kernel
#print axioms colored_row70

theorem colored_check70 : ∀ c : Fin 64,
    checkColored 70 (BitVec.ofNat 6 c.val) (coloredWitness70[c.val]!) = true := by
  decide +kernel
#print axioms colored_check70

theorem colored_family70 : ∀ c : Fin 64,
    checkColored 70 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (70 * 64 + c.val)) = true := by
  intro c
  rw [colored_row70]
  exact colored_check70 c
#print axioms colored_family70

def coloredWitness71 : Array Nat := #[1922400, 1923120, 1923840, 1924560, 1925280, 1926000, 1926720, 1927440, 1925286, 1926006, 1926726, 1927446, 1928160, 1928880, 1929600, 1930320, 1931040, 1931760, 1932480, 1933200, 1933920, 1934640, 1935360, 1936080, 1933926, 1934646, 1935366, 1936086, 1936800, 1937520, 1938240, 1938960, 1939680, 1940400, 1941120, 1941840, 1942560, 1943280, 1944000, 1944720, 1942566, 1943286, 1944006, 1944726, 1945440, 1946160, 1946880, 1947600, 1948320, 1949040, 1949760, 1950480, 1951200, 1951920, 1952640, 1953360, 1951206, 1951926, 1952646, 1953366, 1954080, 1954800, 1955520, 1956240]

theorem colored_row71 : ∀ c : Fin 64,
    readRow witnessRows (71 * 64 + c.val) = coloredWitness71[c.val]! := by
  decide +kernel
#print axioms colored_row71

theorem colored_check71 : ∀ c : Fin 64,
    checkColored 71 (BitVec.ofNat 6 c.val) (coloredWitness71[c.val]!) = true := by
  decide +kernel
#print axioms colored_check71

theorem colored_family71 : ∀ c : Fin 64,
    checkColored 71 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (71 * 64 + c.val)) = true := by
  intro c
  rw [colored_row71]
  exact colored_check71 c
#print axioms colored_family71

def coloredWitness72 : Array Nat := #[1956960, 1957680, 1958400, 1959120, 1958424, 1959144, 1959840, 1960560, 1958448, 1959168, 1959846, 1960566, 1959870, 1960590, 1961280, 1962000, 1962720, 1963440, 1964160, 1964880, 1964184, 1964904, 1965600, 1966320, 1964208, 1964928, 1965606, 1966326, 1965630, 1966350, 1967040, 1967760, 1968480, 1969200, 1969920, 1970640, 1969944, 1970664, 1971360, 1972080, 1969968, 1970688, 1971366, 1972086, 1971390, 1972110, 1972800, 1973520, 1974240, 1974960, 1975680, 1976400, 1975704, 1976424, 1977120, 1977840, 1975728, 1976448, 1977126, 1977846, 1977150, 1977870, 1978560, 1979280]

theorem colored_row72 : ∀ c : Fin 64,
    readRow witnessRows (72 * 64 + c.val) = coloredWitness72[c.val]! := by
  decide +kernel
#print axioms colored_row72

theorem colored_check72 : ∀ c : Fin 64,
    checkColored 72 (BitVec.ofNat 6 c.val) (coloredWitness72[c.val]!) = true := by
  decide +kernel
#print axioms colored_check72

theorem colored_family72 : ∀ c : Fin 64,
    checkColored 72 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (72 * 64 + c.val)) = true := by
  intro c
  rw [colored_row72]
  exact colored_check72 c
#print axioms colored_family72

def coloredWitness73 : Array Nat := #[1980000, 1980720, 1981440, 1982160, 1982880, 1983600, 1984320, 1985040, 1982886, 1983606, 1984326, 1985046, 1985760, 1986480, 1987200, 1987920, 1988640, 1989360, 1990080, 1990800, 1991520, 1992240, 1992960, 1993680, 1991526, 1992246, 1992966, 1993686, 1994400, 1995120, 1995840, 1996560, 1997280, 1998000, 1998720, 1999440, 2000160, 2000880, 2001600, 2002320, 2000166, 2000886, 2001606, 2002326, 2003040, 2003760, 2004480, 2005200, 2005920, 2006640, 2007360, 2008080, 2008800, 2009520, 2010240, 2010960, 2008806, 2009526, 2010246, 2010966, 2011680, 2012400, 2013120, 2013840]

theorem colored_row73 : ∀ c : Fin 64,
    readRow witnessRows (73 * 64 + c.val) = coloredWitness73[c.val]! := by
  decide +kernel
#print axioms colored_row73

theorem colored_check73 : ∀ c : Fin 64,
    checkColored 73 (BitVec.ofNat 6 c.val) (coloredWitness73[c.val]!) = true := by
  decide +kernel
#print axioms colored_check73

theorem colored_family73 : ∀ c : Fin 64,
    checkColored 73 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (73 * 64 + c.val)) = true := by
  intro c
  rw [colored_row73]
  exact colored_check73 c
#print axioms colored_family73

def coloredWitness74 : Array Nat := #[2014560, 2015280, 2016000, 2016720, 2017440, 2018160, 2018880, 2019600, 2020320, 2021040, 2021760, 2022480, 2023200, 2023920, 2024640, 2025360, 2026080, 2026800, 2027520, 2028240, 2028960, 2029680, 2030400, 2031120, 2031840, 2032560, 2033280, 2034000, 2034720, 2035440, 2036160, 2036880, 2037600, 2038320, 2039040, 2039760, 2040480, 2041200, 2041920, 2042640, 2043360, 2044080, 2044800, 2045520, 2046240, 2046960, 2047680, 2048400, 2049120, 2049840, 2050560, 2051280, 2052000, 2052720, 2053440, 2054160, 2054880, 2055600, 2056320, 2057040, 2057760, 2058480, 2059200, 2059920]

theorem colored_row74 : ∀ c : Fin 64,
    readRow witnessRows (74 * 64 + c.val) = coloredWitness74[c.val]! := by
  decide +kernel
#print axioms colored_row74

theorem colored_check74 : ∀ c : Fin 64,
    checkColored 74 (BitVec.ofNat 6 c.val) (coloredWitness74[c.val]!) = true := by
  decide +kernel
#print axioms colored_check74

theorem colored_family74 : ∀ c : Fin 64,
    checkColored 74 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (74 * 64 + c.val)) = true := by
  intro c
  rw [colored_row74]
  exact colored_check74 c
#print axioms colored_family74

def coloredWitness75 : Array Nat := #[2060640, 2061360, 2062080, 2062800, 2063520, 2064240, 2064960, 2065680, 2063526, 2064246, 2064966, 2065686, 2066400, 2067120, 2067840, 2068560, 2069280, 2070000, 2070720, 2071440, 2072160, 2072880, 2073600, 2074320, 2072166, 2072886, 2073606, 2074326, 2075040, 2075760, 2076480, 2077200, 2077920, 2078640, 2079360, 2080080, 2080800, 2081520, 2082240, 2082960, 2080806, 2081526, 2082246, 2082966, 2083680, 2084400, 2085120, 2085840, 2086560, 2087280, 2088000, 2088720, 2089440, 2090160, 2090880, 2091600, 2089446, 2090166, 2090886, 2091606, 2092320, 2093040, 2093760, 2094480]

theorem colored_row75 : ∀ c : Fin 64,
    readRow witnessRows (75 * 64 + c.val) = coloredWitness75[c.val]! := by
  decide +kernel
#print axioms colored_row75

theorem colored_check75 : ∀ c : Fin 64,
    checkColored 75 (BitVec.ofNat 6 c.val) (coloredWitness75[c.val]!) = true := by
  decide +kernel
#print axioms colored_check75

theorem colored_family75 : ∀ c : Fin 64,
    checkColored 75 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (75 * 64 + c.val)) = true := by
  intro c
  rw [colored_row75]
  exact colored_check75 c
#print axioms colored_family75

def coloredWitness76 : Array Nat := #[2095200, 2095920, 2096640, 2097360, 2098080, 2098800, 2099520, 2100240, 2098086, 2098806, 2099526, 2100246, 2100960, 2101680, 2102400, 2103120, 2103840, 2104560, 2105280, 2106000, 2106720, 2107440, 2108160, 2108880, 2106726, 2107446, 2108166, 2108886, 2109600, 2110320, 2111040, 2111760, 2112480, 2113200, 2113920, 2114640, 2115360, 2116080, 2116800, 2117520, 2115366, 2116086, 2116806, 2117526, 2118240, 2118960, 2119680, 2120400, 2121120, 2121840, 2122560, 2123280, 2124000, 2124720, 2125440, 2126160, 2124006, 2124726, 2125446, 2126166, 2126880, 2127600, 2128320, 2129040]

theorem colored_row76 : ∀ c : Fin 64,
    readRow witnessRows (76 * 64 + c.val) = coloredWitness76[c.val]! := by
  decide +kernel
#print axioms colored_row76

theorem colored_check76 : ∀ c : Fin 64,
    checkColored 76 (BitVec.ofNat 6 c.val) (coloredWitness76[c.val]!) = true := by
  decide +kernel
#print axioms colored_check76

theorem colored_family76 : ∀ c : Fin 64,
    checkColored 76 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (76 * 64 + c.val)) = true := by
  intro c
  rw [colored_row76]
  exact colored_check76 c
#print axioms colored_family76

def coloredWitness77 : Array Nat := #[2129760, 2130480, 2131200, 2131920, 2132640, 2133360, 2134080, 2134800, 2135520, 2136240, 2136960, 2137680, 2138400, 2139120, 2139840, 2140560, 2141280, 2142000, 2142720, 2143440, 2144160, 2144880, 2145600, 2146320, 2147040, 2147760, 2148480, 2149200, 2149920, 2150640, 2151360, 2152080, 2152800, 2153520, 2154240, 2154960, 2155680, 2156400, 2157120, 2157840, 2158560, 2159280, 2160000, 2160720, 2161440, 2162160, 2162880, 2163600, 2164320, 2165040, 2165760, 2166480, 2167200, 2167920, 2168640, 2169360, 2170080, 2170800, 2171520, 2172240, 2172960, 2173680, 2174400, 2175120]

theorem colored_row77 : ∀ c : Fin 64,
    readRow witnessRows (77 * 64 + c.val) = coloredWitness77[c.val]! := by
  decide +kernel
#print axioms colored_row77

theorem colored_check77 : ∀ c : Fin 64,
    checkColored 77 (BitVec.ofNat 6 c.val) (coloredWitness77[c.val]!) = true := by
  decide +kernel
#print axioms colored_check77

theorem colored_family77 : ∀ c : Fin 64,
    checkColored 77 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (77 * 64 + c.val)) = true := by
  intro c
  rw [colored_row77]
  exact colored_check77 c
#print axioms colored_family77

def coloredWitness78 : Array Nat := #[2175840, 2176560, 2177280, 2178000, 2178720, 2179440, 2180160, 2180880, 2178726, 2179446, 2180166, 2180886, 2181600, 2182320, 2183040, 2183760, 2184480, 2185200, 2185920, 2186640, 2187360, 2188080, 2188800, 2189520, 2187366, 2188086, 2188806, 2189526, 2190240, 2190960, 2191680, 2192400, 2193120, 2193840, 2194560, 2195280, 2196000, 2196720, 2197440, 2198160, 2196006, 2196726, 2197446, 2198166, 2198880, 2199600, 2200320, 2201040, 2201760, 2202480, 2203200, 2203920, 2204640, 2205360, 2206080, 2206800, 2204646, 2205366, 2206086, 2206806, 2207520, 2208240, 2208960, 2209680]

theorem colored_row78 : ∀ c : Fin 64,
    readRow witnessRows (78 * 64 + c.val) = coloredWitness78[c.val]! := by
  decide +kernel
#print axioms colored_row78

theorem colored_check78 : ∀ c : Fin 64,
    checkColored 78 (BitVec.ofNat 6 c.val) (coloredWitness78[c.val]!) = true := by
  decide +kernel
#print axioms colored_check78

theorem colored_family78 : ∀ c : Fin 64,
    checkColored 78 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (78 * 64 + c.val)) = true := by
  intro c
  rw [colored_row78]
  exact colored_check78 c
#print axioms colored_family78

def coloredWitness79 : Array Nat := #[2210400, 2211120, 2211840, 2212560, 2213280, 2214000, 2214720, 2215440, 2213287, 2214007, 2214727, 2215447, 2216160, 2216880, 2217600, 2218320, 2219040, 2219760, 2220480, 2221200, 2221920, 2222640, 2223360, 2224080, 2224800, 2225520, 2226240, 2226960, 2227680, 2228400, 2229120, 2229840, 2219047, 2219767, 2220487, 2221207, 2224807, 2225527, 2226247, 2226967, 2221927, 2222647, 2223367, 2224087, 2227687, 2228407, 2229127, 2229847, 2230560, 2231280, 2232000, 2232720, 2233440, 2234160, 2234880, 2235600, 2233447, 2234167, 2234887, 2235607, 2236320, 2237040, 2237760, 2238480]

theorem colored_row79 : ∀ c : Fin 64,
    readRow witnessRows (79 * 64 + c.val) = coloredWitness79[c.val]! := by
  decide +kernel
#print axioms colored_row79

theorem colored_check79 : ∀ c : Fin 64,
    checkColored 79 (BitVec.ofNat 6 c.val) (coloredWitness79[c.val]!) = true := by
  decide +kernel
#print axioms colored_check79

theorem colored_family79 : ∀ c : Fin 64,
    checkColored 79 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (79 * 64 + c.val)) = true := by
  intro c
  rw [colored_row79]
  exact colored_check79 c
#print axioms colored_family79

def coloredWitness80 : Array Nat := #[2239200, 2239920, 2240640, 2241360, 2242080, 2242800, 2243520, 2244240, 2244960, 2245680, 2246400, 2247120, 2247840, 2248560, 2249280, 2250000, 2250720, 2251440, 2252160, 2252880, 2253600, 2254320, 2255040, 2255760, 2256480, 2257200, 2257920, 2258640, 2259360, 2260080, 2260800, 2261520, 2262240, 2262960, 2263680, 2264400, 2265120, 2265840, 2266560, 2267280, 2268000, 2268720, 2269440, 2270160, 2270880, 2271600, 2272320, 2273040, 2273760, 2274480, 2275200, 2275920, 2276640, 2277360, 2278080, 2278800, 2279520, 2280240, 2280960, 2281680, 2282400, 2283120, 2283840, 2284560]

theorem colored_row80 : ∀ c : Fin 64,
    readRow witnessRows (80 * 64 + c.val) = coloredWitness80[c.val]! := by
  decide +kernel
#print axioms colored_row80

theorem colored_check80 : ∀ c : Fin 64,
    checkColored 80 (BitVec.ofNat 6 c.val) (coloredWitness80[c.val]!) = true := by
  decide +kernel
#print axioms colored_check80

theorem colored_family80 : ∀ c : Fin 64,
    checkColored 80 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (80 * 64 + c.val)) = true := by
  intro c
  rw [colored_row80]
  exact colored_check80 c
#print axioms colored_family80

def coloredWitness81 : Array Nat := #[2285280, 2286000, 2286720, 2287440, 2288160, 2288880, 2289600, 2290320, 2288167, 2288887, 2289607, 2290327, 2291040, 2291760, 2292480, 2293200, 2293920, 2294640, 2295360, 2296080, 2296800, 2297520, 2298240, 2298960, 2299680, 2300400, 2301120, 2301840, 2302560, 2303280, 2304000, 2304720, 2293927, 2294647, 2295367, 2296087, 2299687, 2300407, 2301127, 2301847, 2296807, 2297527, 2298247, 2298967, 2302567, 2303287, 2304007, 2304727, 2305440, 2306160, 2306880, 2307600, 2308320, 2309040, 2309760, 2310480, 2308327, 2309047, 2309767, 2310487, 2311200, 2311920, 2312640, 2313360]

theorem colored_row81 : ∀ c : Fin 64,
    readRow witnessRows (81 * 64 + c.val) = coloredWitness81[c.val]! := by
  decide +kernel
#print axioms colored_row81

theorem colored_check81 : ∀ c : Fin 64,
    checkColored 81 (BitVec.ofNat 6 c.val) (coloredWitness81[c.val]!) = true := by
  decide +kernel
#print axioms colored_check81

theorem colored_family81 : ∀ c : Fin 64,
    checkColored 81 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (81 * 64 + c.val)) = true := by
  intro c
  rw [colored_row81]
  exact colored_check81 c
#print axioms colored_family81

def coloredWitness82 : Array Nat := #[2314080, 2314800, 2315520, 2316240, 2316960, 2317680, 2318400, 2319120, 2316967, 2317687, 2318407, 2319127, 2319840, 2320560, 2321280, 2322000, 2322720, 2323440, 2324160, 2324880, 2325600, 2326320, 2327040, 2327760, 2328480, 2329200, 2329920, 2330640, 2331360, 2332080, 2332800, 2333520, 2322727, 2323447, 2324167, 2324887, 2328487, 2329207, 2329927, 2330647, 2325607, 2326327, 2327047, 2327767, 2331367, 2332087, 2332807, 2333527, 2334240, 2334960, 2335680, 2336400, 2337120, 2337840, 2338560, 2339280, 2337127, 2337847, 2338567, 2339287, 2340000, 2340720, 2341440, 2342160]

theorem colored_row82 : ∀ c : Fin 64,
    readRow witnessRows (82 * 64 + c.val) = coloredWitness82[c.val]! := by
  decide +kernel
#print axioms colored_row82

theorem colored_check82 : ∀ c : Fin 64,
    checkColored 82 (BitVec.ofNat 6 c.val) (coloredWitness82[c.val]!) = true := by
  decide +kernel
#print axioms colored_check82

theorem colored_family82 : ∀ c : Fin 64,
    checkColored 82 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (82 * 64 + c.val)) = true := by
  intro c
  rw [colored_row82]
  exact colored_check82 c
#print axioms colored_family82

def coloredWitness83 : Array Nat := #[2342880, 2343600, 2344320, 2345040, 2345760, 2346480, 2347200, 2347920, 2348640, 2349360, 2350080, 2350800, 2351520, 2352240, 2352960, 2353680, 2354400, 2355120, 2355840, 2356560, 2357280, 2358000, 2358720, 2359440, 2360160, 2360880, 2361600, 2362320, 2363040, 2363760, 2364480, 2365200, 2365920, 2366640, 2367360, 2368080, 2368800, 2369520, 2370240, 2370960, 2371680, 2372400, 2373120, 2373840, 2374560, 2375280, 2376000, 2376720, 2377440, 2378160, 2378880, 2379600, 2380320, 2381040, 2381760, 2382480, 2383200, 2383920, 2384640, 2385360, 2386080, 2386800, 2387520, 2388240]

theorem colored_row83 : ∀ c : Fin 64,
    readRow witnessRows (83 * 64 + c.val) = coloredWitness83[c.val]! := by
  decide +kernel
#print axioms colored_row83

theorem colored_check83 : ∀ c : Fin 64,
    checkColored 83 (BitVec.ofNat 6 c.val) (coloredWitness83[c.val]!) = true := by
  decide +kernel
#print axioms colored_check83

theorem colored_family83 : ∀ c : Fin 64,
    checkColored 83 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (83 * 64 + c.val)) = true := by
  intro c
  rw [colored_row83]
  exact colored_check83 c
#print axioms colored_family83

def coloredWitness84 : Array Nat := #[2388960, 2389680, 2390400, 2391120, 2391840, 2392560, 2393280, 2394000, 2391847, 2392567, 2393287, 2394007, 2394720, 2395440, 2396160, 2396880, 2397600, 2398320, 2399040, 2399760, 2400480, 2401200, 2401920, 2402640, 2403360, 2404080, 2404800, 2405520, 2406240, 2406960, 2407680, 2408400, 2397607, 2398327, 2399047, 2399767, 2403367, 2404087, 2404807, 2405527, 2400487, 2401207, 2401927, 2402647, 2406247, 2406967, 2407687, 2408407, 2409120, 2409840, 2410560, 2411280, 2412000, 2412720, 2413440, 2414160, 2412007, 2412727, 2413447, 2414167, 2414880, 2415600, 2416320, 2417040]

theorem colored_row84 : ∀ c : Fin 64,
    readRow witnessRows (84 * 64 + c.val) = coloredWitness84[c.val]! := by
  decide +kernel
#print axioms colored_row84

theorem colored_check84 : ∀ c : Fin 64,
    checkColored 84 (BitVec.ofNat 6 c.val) (coloredWitness84[c.val]!) = true := by
  decide +kernel
#print axioms colored_check84

theorem colored_family84 : ∀ c : Fin 64,
    checkColored 84 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (84 * 64 + c.val)) = true := by
  intro c
  rw [colored_row84]
  exact colored_check84 c
#print axioms colored_family84

def coloredWitness85 : Array Nat := #[2417760, 2418480, 2419200, 2419920, 2419224, 2419944, 2420640, 2421360, 2422080, 2422800, 2423520, 2424240, 2423544, 2424264, 2424960, 2425680, 2426400, 2427120, 2427840, 2428560, 2427864, 2428584, 2429280, 2430000, 2430720, 2431440, 2432160, 2432880, 2432184, 2432904, 2433600, 2434320, 2435040, 2435760, 2436480, 2437200, 2436504, 2437224, 2437920, 2438640, 2439360, 2440080, 2440800, 2441520, 2440824, 2441544, 2442240, 2442960, 2443680, 2444400, 2445120, 2445840, 2445144, 2445864, 2446560, 2447280, 2448000, 2448720, 2449440, 2450160, 2449464, 2450184, 2450880, 2451600]

theorem colored_row85 : ∀ c : Fin 64,
    readRow witnessRows (85 * 64 + c.val) = coloredWitness85[c.val]! := by
  decide +kernel
#print axioms colored_row85

theorem colored_check85 : ∀ c : Fin 64,
    checkColored 85 (BitVec.ofNat 6 c.val) (coloredWitness85[c.val]!) = true := by
  decide +kernel
#print axioms colored_check85

theorem colored_family85 : ∀ c : Fin 64,
    checkColored 85 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (85 * 64 + c.val)) = true := by
  intro c
  rw [colored_row85]
  exact colored_check85 c
#print axioms colored_family85

def coloredWitness86 : Array Nat := #[2452320, 2453040, 2453760, 2454480, 2453784, 2454504, 2455200, 2455920, 2456640, 2457360, 2458080, 2458800, 2458104, 2458824, 2459520, 2460240, 2460960, 2461680, 2462400, 2463120, 2462424, 2463144, 2463840, 2464560, 2465280, 2466000, 2466720, 2467440, 2466744, 2467464, 2468160, 2468880, 2469600, 2470320, 2471040, 2471760, 2471064, 2471784, 2472480, 2473200, 2473920, 2474640, 2475360, 2476080, 2475384, 2476104, 2476800, 2477520, 2478240, 2478960, 2479680, 2480400, 2479704, 2480424, 2481120, 2481840, 2482560, 2483280, 2484000, 2484720, 2484024, 2484744, 2485440, 2486160]

theorem colored_row86 : ∀ c : Fin 64,
    readRow witnessRows (86 * 64 + c.val) = coloredWitness86[c.val]! := by
  decide +kernel
#print axioms colored_row86

theorem colored_check86 : ∀ c : Fin 64,
    checkColored 86 (BitVec.ofNat 6 c.val) (coloredWitness86[c.val]!) = true := by
  decide +kernel
#print axioms colored_check86

theorem colored_family86 : ∀ c : Fin 64,
    checkColored 86 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (86 * 64 + c.val)) = true := by
  intro c
  rw [colored_row86]
  exact colored_check86 c
#print axioms colored_family86

def coloredWitness87 : Array Nat := #[2486880, 2487600, 2488320, 2489040, 2489760, 2490480, 2491200, 2491920, 2492640, 2493360, 2494080, 2494800, 2495520, 2496240, 2496960, 2497680, 2498400, 2499120, 2499840, 2500560, 2501280, 2502000, 2502720, 2503440, 2504160, 2504880, 2505600, 2506320, 2507040, 2507760, 2508480, 2509200, 2509920, 2510640, 2511360, 2512080, 2512800, 2513520, 2514240, 2514960, 2515680, 2516400, 2517120, 2517840, 2518560, 2519280, 2520000, 2520720, 2521440, 2522160, 2522880, 2523600, 2524320, 2525040, 2525760, 2526480, 2527200, 2527920, 2528640, 2529360, 2530080, 2530800, 2531520, 2532240]

theorem colored_row87 : ∀ c : Fin 64,
    readRow witnessRows (87 * 64 + c.val) = coloredWitness87[c.val]! := by
  decide +kernel
#print axioms colored_row87

theorem colored_check87 : ∀ c : Fin 64,
    checkColored 87 (BitVec.ofNat 6 c.val) (coloredWitness87[c.val]!) = true := by
  decide +kernel
#print axioms colored_check87

theorem colored_family87 : ∀ c : Fin 64,
    checkColored 87 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (87 * 64 + c.val)) = true := by
  intro c
  rw [colored_row87]
  exact colored_check87 c
#print axioms colored_family87

def coloredWitness88 : Array Nat := #[2532960, 2533680, 2534400, 2535120, 2535840, 2536560, 2537280, 2538000, 2538720, 2539440, 2540160, 2540880, 2541600, 2542320, 2543040, 2543760, 2544480, 2545200, 2545920, 2546640, 2547360, 2548080, 2548800, 2549520, 2550240, 2550960, 2551680, 2552400, 2553120, 2553840, 2554560, 2555280, 2556000, 2556720, 2557440, 2558160, 2558880, 2559600, 2560320, 2561040, 2561760, 2562480, 2563200, 2563920, 2564640, 2565360, 2566080, 2566800, 2567520, 2568240, 2568960, 2569680, 2570400, 2571120, 2571840, 2572560, 2573280, 2574000, 2574720, 2575440, 2576160, 2576880, 2577600, 2578320]

theorem colored_row88 : ∀ c : Fin 64,
    readRow witnessRows (88 * 64 + c.val) = coloredWitness88[c.val]! := by
  decide +kernel
#print axioms colored_row88

theorem colored_check88 : ∀ c : Fin 64,
    checkColored 88 (BitVec.ofNat 6 c.val) (coloredWitness88[c.val]!) = true := by
  decide +kernel
#print axioms colored_check88

theorem colored_family88 : ∀ c : Fin 64,
    checkColored 88 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (88 * 64 + c.val)) = true := by
  intro c
  rw [colored_row88]
  exact colored_check88 c
#print axioms colored_family88

def coloredWitness89 : Array Nat := #[2579040, 2579760, 2580480, 2581200, 2580504, 2581224, 2581920, 2582640, 2583360, 2584080, 2584800, 2585520, 2584824, 2585544, 2586240, 2586960, 2587680, 2588400, 2589120, 2589840, 2589144, 2589864, 2590560, 2591280, 2592000, 2592720, 2593440, 2594160, 2593464, 2594184, 2594880, 2595600, 2596320, 2597040, 2597760, 2598480, 2597784, 2598504, 2599200, 2599920, 2600640, 2601360, 2602080, 2602800, 2602104, 2602824, 2603520, 2604240, 2604960, 2605680, 2606400, 2607120, 2606424, 2607144, 2607840, 2608560, 2609280, 2610000, 2610720, 2611440, 2610744, 2611464, 2612160, 2612880]

theorem colored_row89 : ∀ c : Fin 64,
    readRow witnessRows (89 * 64 + c.val) = coloredWitness89[c.val]! := by
  decide +kernel
#print axioms colored_row89

theorem colored_check89 : ∀ c : Fin 64,
    checkColored 89 (BitVec.ofNat 6 c.val) (coloredWitness89[c.val]!) = true := by
  decide +kernel
#print axioms colored_check89

theorem colored_family89 : ∀ c : Fin 64,
    checkColored 89 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (89 * 64 + c.val)) = true := by
  intro c
  rw [colored_row89]
  exact colored_check89 c
#print axioms colored_family89

def coloredWitness90 : Array Nat := #[2613600, 2614320, 2615040, 2615760, 2615064, 2615784, 2616480, 2617200, 2617920, 2618640, 2619360, 2620080, 2619384, 2620104, 2620800, 2621520, 2622240, 2622960, 2623680, 2624400, 2623704, 2624424, 2625120, 2625840, 2626560, 2627280, 2628000, 2628720, 2628024, 2628744, 2629440, 2630160, 2630880, 2631600, 2632320, 2633040, 2632344, 2633064, 2633760, 2634480, 2635200, 2635920, 2636640, 2637360, 2636664, 2637384, 2638080, 2638800, 2639520, 2640240, 2640960, 2641680, 2640984, 2641704, 2642400, 2643120, 2643840, 2644560, 2645280, 2646000, 2645304, 2646024, 2646720, 2647440]

theorem colored_row90 : ∀ c : Fin 64,
    readRow witnessRows (90 * 64 + c.val) = coloredWitness90[c.val]! := by
  decide +kernel
#print axioms colored_row90

theorem colored_check90 : ∀ c : Fin 64,
    checkColored 90 (BitVec.ofNat 6 c.val) (coloredWitness90[c.val]!) = true := by
  decide +kernel
#print axioms colored_check90

theorem colored_family90 : ∀ c : Fin 64,
    checkColored 90 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (90 * 64 + c.val)) = true := by
  intro c
  rw [colored_row90]
  exact colored_check90 c
#print axioms colored_family90

def coloredWitness91 : Array Nat := #[2648160, 2648880, 2649600, 2650320, 2649624, 2650344, 2651040, 2651760, 2649648, 2650368, 2651046, 2651766, 2651070, 2651790, 2652480, 2653200, 2653920, 2654640, 2655360, 2656080, 2655384, 2656104, 2656800, 2657520, 2655408, 2656128, 2656806, 2657526, 2656830, 2657550, 2658240, 2658960, 2653921, 2654641, 2655361, 2656081, 2655385, 2656105, 2656801, 2657521, 2655409, 2656129, 2656807, 2657527, 2656831, 2657551, 2658241, 2658961, 2659680, 2660400, 2661120, 2661840, 2661144, 2661864, 2662560, 2663280, 2661168, 2661888, 2662566, 2663286, 2662590, 2663310, 2664000, 2664720]

theorem colored_row91 : ∀ c : Fin 64,
    readRow witnessRows (91 * 64 + c.val) = coloredWitness91[c.val]! := by
  decide +kernel
#print axioms colored_row91

theorem colored_check91 : ∀ c : Fin 64,
    checkColored 91 (BitVec.ofNat 6 c.val) (coloredWitness91[c.val]!) = true := by
  decide +kernel
#print axioms colored_check91

theorem colored_family91 : ∀ c : Fin 64,
    checkColored 91 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (91 * 64 + c.val)) = true := by
  intro c
  rw [colored_row91]
  exact colored_check91 c
#print axioms colored_family91

def coloredWitness92 : Array Nat := #[2665440, 2666160, 2666880, 2667600, 2666904, 2667624, 2668320, 2669040, 2669760, 2670480, 2671200, 2671920, 2671224, 2671944, 2672640, 2673360, 2674080, 2674800, 2675520, 2676240, 2675544, 2676264, 2676960, 2677680, 2678400, 2679120, 2679840, 2680560, 2679864, 2680584, 2681280, 2682000, 2674081, 2674801, 2675521, 2676241, 2675545, 2676265, 2676961, 2677681, 2678401, 2679121, 2679841, 2680561, 2679865, 2680585, 2681281, 2682001, 2682720, 2683440, 2684160, 2684880, 2684184, 2684904, 2685600, 2686320, 2687040, 2687760, 2688480, 2689200, 2688504, 2689224, 2689920, 2690640]

theorem colored_row92 : ∀ c : Fin 64,
    readRow witnessRows (92 * 64 + c.val) = coloredWitness92[c.val]! := by
  decide +kernel
#print axioms colored_row92

theorem colored_check92 : ∀ c : Fin 64,
    checkColored 92 (BitVec.ofNat 6 c.val) (coloredWitness92[c.val]!) = true := by
  decide +kernel
#print axioms colored_check92

theorem colored_family92 : ∀ c : Fin 64,
    checkColored 92 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (92 * 64 + c.val)) = true := by
  intro c
  rw [colored_row92]
  exact colored_check92 c
#print axioms colored_family92

def coloredWitness93 : Array Nat := #[2691360, 2692080, 2692800, 2693520, 2694240, 2694960, 2695680, 2696400, 2694246, 2694966, 2695686, 2696406, 2697120, 2697840, 2698560, 2699280, 2700000, 2700720, 2701440, 2702160, 2702880, 2703600, 2704320, 2705040, 2702886, 2703606, 2704326, 2705046, 2705760, 2706480, 2707200, 2707920, 2700001, 2700721, 2701441, 2702161, 2702881, 2703601, 2704321, 2705041, 2702887, 2703607, 2704327, 2705047, 2705761, 2706481, 2707201, 2707921, 2708640, 2709360, 2710080, 2710800, 2711520, 2712240, 2712960, 2713680, 2711526, 2712246, 2712966, 2713686, 2714400, 2715120, 2715840, 2716560]

theorem colored_row93 : ∀ c : Fin 64,
    readRow witnessRows (93 * 64 + c.val) = coloredWitness93[c.val]! := by
  decide +kernel
#print axioms colored_row93

theorem colored_check93 : ∀ c : Fin 64,
    checkColored 93 (BitVec.ofNat 6 c.val) (coloredWitness93[c.val]!) = true := by
  decide +kernel
#print axioms colored_check93

theorem colored_family93 : ∀ c : Fin 64,
    checkColored 93 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (93 * 64 + c.val)) = true := by
  intro c
  rw [colored_row93]
  exact colored_check93 c
#print axioms colored_family93

def coloredWitness94 : Array Nat := #[2717280, 2718000, 2718720, 2719440, 2718744, 2719464, 2720160, 2720880, 2718768, 2719488, 2720166, 2720886, 2720190, 2720910, 2721600, 2722320, 2723040, 2723760, 2724480, 2725200, 2724504, 2725224, 2725920, 2726640, 2724528, 2725248, 2725926, 2726646, 2725950, 2726670, 2727360, 2728080, 2723041, 2723761, 2724481, 2725201, 2724505, 2725225, 2725921, 2726641, 2724529, 2725249, 2725927, 2726647, 2725951, 2726671, 2727361, 2728081, 2728800, 2729520, 2730240, 2730960, 2730264, 2730984, 2731680, 2732400, 2730288, 2731008, 2731686, 2732406, 2731710, 2732430, 2733120, 2733840]

theorem colored_row94 : ∀ c : Fin 64,
    readRow witnessRows (94 * 64 + c.val) = coloredWitness94[c.val]! := by
  decide +kernel
#print axioms colored_row94

theorem colored_check94 : ∀ c : Fin 64,
    checkColored 94 (BitVec.ofNat 6 c.val) (coloredWitness94[c.val]!) = true := by
  decide +kernel
#print axioms colored_check94

theorem colored_family94 : ∀ c : Fin 64,
    checkColored 94 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (94 * 64 + c.val)) = true := by
  intro c
  rw [colored_row94]
  exact colored_check94 c
#print axioms colored_family94

def coloredWitness95 : Array Nat := #[2734560, 2735280, 2735416, 2736000, 2735536, 2736024, 2736720, 2737440, 2735656, 2736048, 2736726, 2737446, 2736750, 2737470, 2738160, 2738880, 2735792, 2736856, 2736196, 2737576, 2736316, 2737696, 2737952, 2739600, 2736436, 2737816, 2737958, 2739606, 2737982, 2739630, 2739392, 2740320, 2735912, 2736862, 2736220, 2737582, 2736340, 2737702, 2738072, 2739601, 2736460, 2737822, 2738078, 2739607, 2738102, 2739631, 2739512, 2740321, 2736930, 2738296, 2737650, 2739016, 2737770, 2739136, 2739810, 2740456, 2737890, 2739256, 2739811, 2740457, 2739931, 2740577, 2740833, 2741040]

theorem colored_row95 : ∀ c : Fin 64,
    readRow witnessRows (95 * 64 + c.val) = coloredWitness95[c.val]! := by
  decide +kernel
#print axioms colored_row95

theorem colored_check95 : ∀ c : Fin 64,
    checkColored 95 (BitVec.ofNat 6 c.val) (coloredWitness95[c.val]!) = true := by
  decide +kernel
#print axioms colored_check95

theorem colored_family95 : ∀ c : Fin 64,
    checkColored 95 (BitVec.ofNat 6 c.val)
      (readRow witnessRows (95 * 64 + c.val)) = true := by
  intro c
  rw [colored_row95]
  exact colored_check95 c
#print axioms colored_family95

end TightCycleC5.Bridge.ColoredCover
