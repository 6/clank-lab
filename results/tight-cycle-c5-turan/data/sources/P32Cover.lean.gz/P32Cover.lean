import CoverAll

/-! P32 orbit coverage for actual six-injection samples. P32 forgets colours:
using the full cut makes every vertex's complement-colour bit zero. -/
namespace TightCycleC5.Bridge.Cover
open Finset MaskEncoding

theorem sample_colorCode_univ {n : ℕ} (σ : Fin 6 ↪ Fin n)
    (H : Finset (Finset (Fin n))) : colorCode (sampleStructure σ H univ) = 0 := by
  apply BitVec.eq_of_getLsbD_eq
  intro i hi
  rw [colorCode_bit _ ⟨i, hi⟩]
  simp [sampleStructure]

theorem permuteColor_zero (p : Equiv.Perm (Fin 6)) : permuteColor p 0 = 0 := by
  apply BitVec.eq_of_getLsbD_eq
  intro i hi
  change (colorCode (p • decodeStructure 0 0)).getLsbD i = (0 : BitVec 6).getLsbD i
  rw [colorCode_bit _ ⟨i, hi⟩]
  change (0 : BitVec 6).getLsbD (p.symm ⟨i, hi⟩).val = (0 : BitVec 6).getLsbD i
  simp

theorem p32_sample_cover {n : ℕ} (σ : Fin 6 ↪ Fin n)
    {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) :
    ∃ k : Fin 835, ∃ p : Equiv.Perm (Fin 6),
      sampleStructure σ H univ = p • decodeStructure (representative k) 0 := by
  obtain ⟨k, p, hp⟩ := p32_mask_cover (graphCode (sampleStructure σ H univ))
    (sample_code_c5free σ hH hC univ)
  refine ⟨k, p, ?_⟩
  have he := encode_sample σ hH univ
  rw [sample_colorCode_univ] at he
  calc
    sampleStructure σ H univ = decodeStructure (graphCode (sampleStructure σ H univ)) 0 := he.symm
    _ = decodeStructure (permuteMask p (representative k)) 0 := by rw [hp]
    _ = p • decodeStructure (representative k) 0 := by
      simpa only [permuteColor_zero] using decode_permute p (representative k) 0

noncomputable def p32ClassOf {n : ℕ} {H : Finset (Finset (Fin n))}
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (σ : Fin 6 ↪ Fin n) : Fin 835 :=
  Classical.choose (p32_sample_cover σ hH hC)

def p32ClassRep (k : Fin 835) : LabelledStructure 6 := decodeStructure (representative k) 0

theorem p32_classOf_cover {n : ℕ} {H : Finset (Finset (Fin n))}
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) :
    ∀ σ : Fin 6 ↪ Fin n, ∃ p : Equiv.Perm (Fin 6),
      sampleStructure σ H univ = p • p32ClassRep (p32ClassOf hH hC σ) := by
  intro σ
  exact Classical.choose_spec (p32_sample_cover σ hH hC)

theorem p32_class_probability {n : ℕ} (hn : 6 ≤ n)
    {H : Finset (Finset (Fin n))} (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) :
    (∀ k, 0 ≤ classMass (p32ClassOf hH hC) k) ∧
      ∑ k, classMass (p32ClassOf hH hC) k = 1 :=
  six_class_probability hn (p32ClassOf hH hC)

theorem p32_class_expansion {n : ℕ} {H : Finset (Finset (Fin n))}
    (hH : IsThreeGraph H) (hC : ¬ ContainsC5 H) (row : LabelledStructure 6 → ℝ) :
    uniformMean (fun σ : Fin 6 ↪ Fin n => row (sampleStructure σ H univ)) =
      ∑ k, classMass (p32ClassOf hH hC) k *
        uniformMean (fun p : Equiv.Perm (Fin 6) => row (p • p32ClassRep k)) :=
  six_class_expansion H univ (p32ClassOf hH hC) p32ClassRep (p32_classOf_cover hH hC) row

#print axioms sample_colorCode_univ
#print axioms permuteColor_zero
#print axioms p32_sample_cover
#print axioms p32_classOf_cover
#print axioms p32_class_probability
#print axioms p32_class_expansion
end TightCycleC5.Bridge.Cover
