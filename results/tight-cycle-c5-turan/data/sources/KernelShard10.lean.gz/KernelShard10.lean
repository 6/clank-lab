import KernelShard10Blocks0
import KernelShard10Blocks1
import KernelShard10Blocks2
import KernelShard10Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard10 : kernelShardCheck 10 kernelWitness10 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (10 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness10 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_10_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard10
end TightCycleC5.Bridge.Cover
