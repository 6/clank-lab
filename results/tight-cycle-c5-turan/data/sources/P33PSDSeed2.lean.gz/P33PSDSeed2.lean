import P33PSDSeed2Data

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33PSD

theorem seed2_weights : ∀ k, 0 ≤ weight2 k := by decide +kernel
theorem seed2_gram : (fun i j => (seed2 i j : ℚ)) =
    rationalGram weight2 vec2 := by decide +kernel
theorem seed2_psd : (intMatrixReal seed2).PosSemidef :=
  rational_gram_posSemidef seed2 weight2 vec2 seed2_weights seed2_gram

def changedSeed2 : Matrix (Fin 40) (Fin 40) ℤ :=
  fun i j => seed2 i j + if i = 0 ∧ j = 0 then 1 else 0
theorem seed2_rejects_corruption :
    (fun i j => (changedSeed2 i j : ℚ)) ≠ rationalGram weight2 vec2 := by decide +kernel

#print axioms seed2_weights
#print axioms seed2_gram
#print axioms seed2_psd
#print axioms seed2_rejects_corruption
end TightCycleC5.Bridge.P33PSD
