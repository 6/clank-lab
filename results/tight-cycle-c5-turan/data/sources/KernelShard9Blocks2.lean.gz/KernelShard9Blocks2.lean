import KernelRowIndex
import KernelWitness9

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_9_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 64 * 256 + i.val))
      kernelWitness9Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_64

theorem kernelBlock_9_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 65 * 256 + i.val))
      kernelWitness9Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_65

theorem kernelBlock_9_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 66 * 256 + i.val))
      kernelWitness9Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_66

theorem kernelBlock_9_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 67 * 256 + i.val))
      kernelWitness9Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_67

theorem kernelBlock_9_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 68 * 256 + i.val))
      kernelWitness9Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_68

theorem kernelBlock_9_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 69 * 256 + i.val))
      kernelWitness9Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_69

theorem kernelBlock_9_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 70 * 256 + i.val))
      kernelWitness9Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_70

theorem kernelBlock_9_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 71 * 256 + i.val))
      kernelWitness9Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_71

theorem kernelBlock_9_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 72 * 256 + i.val))
      kernelWitness9Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_72

theorem kernelBlock_9_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 73 * 256 + i.val))
      kernelWitness9Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_73

theorem kernelBlock_9_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 74 * 256 + i.val))
      kernelWitness9Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_74

theorem kernelBlock_9_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 75 * 256 + i.val))
      kernelWitness9Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_75

theorem kernelBlock_9_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 76 * 256 + i.val))
      kernelWitness9Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_76

theorem kernelBlock_9_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 77 * 256 + i.val))
      kernelWitness9Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_77

theorem kernelBlock_9_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 78 * 256 + i.val))
      kernelWitness9Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_78

theorem kernelBlock_9_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 79 * 256 + i.val))
      kernelWitness9Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_79

theorem kernelBlock_9_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 80 * 256 + i.val))
      kernelWitness9Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_80

theorem kernelBlock_9_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 81 * 256 + i.val))
      kernelWitness9Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_81

theorem kernelBlock_9_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 82 * 256 + i.val))
      kernelWitness9Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_82

theorem kernelBlock_9_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 83 * 256 + i.val))
      kernelWitness9Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_83

theorem kernelBlock_9_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 84 * 256 + i.val))
      kernelWitness9Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_84

theorem kernelBlock_9_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 85 * 256 + i.val))
      kernelWitness9Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_85

theorem kernelBlock_9_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 86 * 256 + i.val))
      kernelWitness9Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_86

theorem kernelBlock_9_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 87 * 256 + i.val))
      kernelWitness9Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_87

theorem kernelBlock_9_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 88 * 256 + i.val))
      kernelWitness9Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_88

theorem kernelBlock_9_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 89 * 256 + i.val))
      kernelWitness9Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_89

theorem kernelBlock_9_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 90 * 256 + i.val))
      kernelWitness9Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_90

theorem kernelBlock_9_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 91 * 256 + i.val))
      kernelWitness9Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_91

theorem kernelBlock_9_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 92 * 256 + i.val))
      kernelWitness9Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_92

theorem kernelBlock_9_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 93 * 256 + i.val))
      kernelWitness9Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_93

theorem kernelBlock_9_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 94 * 256 + i.val))
      kernelWitness9Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_94

theorem kernelBlock_9_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (9 * 32768 + 95 * 256 + i.val))
      kernelWitness9Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_9_95

end TightCycleC5.Bridge.Cover
