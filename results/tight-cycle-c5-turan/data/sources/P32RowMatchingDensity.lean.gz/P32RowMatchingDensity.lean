import P32RowMatchingData

namespace TightCycleC5.Bridge.P32RowMatching
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000
set_option backward.isDefEq.respectTransparency false

/-- Both density signs and source positions are preserved pointwise. -/
theorem density_contribution_eq (G : LabelledStructure 6) :
    P32Arithmetic.densityContribution G =
      CertificateDescriptors.densityWeight true * CertificateDescriptors.densityRow true G +
      CertificateDescriptors.densityWeight false * CertificateDescriptors.densityRow false G := by
  simp only [P32Arithmetic.densityContribution, Rat.cast_div, Rat.cast_mul,
    Rat.cast_intCast, Rat.cast_ofNat, CertificateDescriptors.densityWeight,
    CertificateDescriptors.p32Weight, CertificateDescriptors.densitySourceIndex,
    ← numerator_eq, ← weight_scale_eq]
  simp only [P32Arithmetic.densityNumerator,
    CertificateDescriptors.densityRow, CertificateDescriptors.densityBeta]
  change (((10000 * P32Arithmetic.bit (G.edge {0,1,2}) - 4641) *
      (P32Arithmetic.multipliers.get 9509 * P32Arithmetic.bit (G.edge {3,4,5}) +
        P32Arithmetic.multipliers.get 9510 * (1-P32Arithmetic.bit (G.edge {3,4,5}))) : ℤ) : ℝ) /
      (10000 * (P32Arithmetic.weightScale : ℝ)) = _
  cases h : G.edge {0,1,2} <;> cases h' : G.edge {3,4,5} <;>
    simp [h, h', P32Arithmetic.bit, P32Arithmetic.weightScale] <;> ring

#print axioms density_contribution_eq
end TightCycleC5.Bridge.P32RowMatching
