import P33PSDData
import P33PSDSeed23

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33PSD

theorem terms5_psd : ∀ k, (intMatrixReal (terms5 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector5x0
  · exact int_outer_posSemidef vector5x1
  · exact int_outer_posSemidef vector5x2
  · exact int_outer_posSemidef vector5x3
  · exact int_outer_posSemidef vector5x4
  · exact int_outer_posSemidef vector5x5
  · exact int_outer_posSemidef vector5x6
  · exact int_outer_posSemidef vector5x7
  · exact int_outer_posSemidef vector5x8
  · exact int_outer_posSemidef vector5x9
  · exact int_outer_posSemidef vector5x10
  · exact int_outer_posSemidef vector5x11
  · exact int_outer_posSemidef vector5x12
  · exact int_outer_posSemidef vector5x13
  · exact int_outer_posSemidef vector5x14
  · exact int_outer_posSemidef vector5x15
  · exact int_outer_posSemidef vector5x16
theorem terms5_diagonal : ∀ k i, terms5 k i i ≤ (diagBounds5 k : ℤ) := by
  decide +kernel
theorem psd5 : (intMatrixReal q5).PosSemidef :=
  integer_sos_posSemidef weights5 terms5 terms5_psd
theorem diagonal5 : ∀ i, q5 i i ≤ (m5 : ℤ) :=
  integer_sos_diagonal weights5 diagBounds5 terms5 terms5_diagonal
theorem normalized_psd5 : matrix5.PosSemidef :=
  scale_int_posSemidef q5 scale psd5
theorem normalized_diagonal5 : ∀ i, matrix5 i i ≤ bound5 :=
  scale_int_diagonal q5 scale m5 diagonal5
theorem normalized_nonneg5 : 0 ≤ bound5 :=
  scale_int_bound_nonneg scale m5 (Nat.cast_nonneg _)

#print axioms psd5
#print axioms diagonal5
#print axioms normalized_psd5
#print axioms normalized_diagonal5
#print axioms normalized_nonneg5
#print axioms terms5_psd
#print axioms terms5_diagonal

theorem terms11_psd : ∀ k, (intMatrixReal (terms11 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector11x0
  · exact int_outer_posSemidef vector11x1
  · exact int_outer_posSemidef vector11x2
  · exact int_outer_posSemidef vector11x3
  · exact int_outer_posSemidef vector11x4
theorem terms11_diagonal : ∀ k i, terms11 k i i ≤ (diagBounds11 k : ℤ) := by
  decide +kernel
theorem psd11 : (intMatrixReal q11).PosSemidef :=
  integer_sos_posSemidef weights11 terms11 terms11_psd
theorem diagonal11 : ∀ i, q11 i i ≤ (m11 : ℤ) :=
  integer_sos_diagonal weights11 diagBounds11 terms11 terms11_diagonal
theorem normalized_psd11 : matrix11.PosSemidef :=
  scale_int_posSemidef q11 scale psd11
theorem normalized_diagonal11 : ∀ i, matrix11 i i ≤ bound11 :=
  scale_int_diagonal q11 scale m11 diagonal11
theorem normalized_nonneg11 : 0 ≤ bound11 :=
  scale_int_bound_nonneg scale m11 (Nat.cast_nonneg _)

#print axioms psd11
#print axioms diagonal11
#print axioms normalized_psd11
#print axioms normalized_diagonal11
#print axioms normalized_nonneg11
#print axioms terms11_psd
#print axioms terms11_diagonal

theorem terms17_psd : ∀ k, (intMatrixReal (terms17 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector17x0
  · exact int_outer_posSemidef vector17x1
  · exact int_outer_posSemidef vector17x2
  · exact int_outer_posSemidef vector17x3
  · exact int_outer_posSemidef vector17x4
  · exact int_outer_posSemidef vector17x5
  · exact int_outer_posSemidef vector17x6
  · exact int_outer_posSemidef vector17x7
  · exact int_outer_posSemidef vector17x8
  · exact int_outer_posSemidef vector17x9
  · exact int_outer_posSemidef vector17x10
  · exact int_outer_posSemidef vector17x11
  · exact int_outer_posSemidef vector17x12
  · exact int_outer_posSemidef vector17x13
  · exact int_outer_posSemidef vector17x14
  · exact int_outer_posSemidef vector17x15
  · exact int_outer_posSemidef vector17x16
theorem terms17_diagonal : ∀ k i, terms17 k i i ≤ (diagBounds17 k : ℤ) := by
  decide +kernel
theorem psd17 : (intMatrixReal q17).PosSemidef :=
  integer_sos_posSemidef weights17 terms17 terms17_psd
theorem diagonal17 : ∀ i, q17 i i ≤ (m17 : ℤ) :=
  integer_sos_diagonal weights17 diagBounds17 terms17 terms17_diagonal
theorem normalized_psd17 : matrix17.PosSemidef :=
  scale_int_posSemidef q17 scale psd17
theorem normalized_diagonal17 : ∀ i, matrix17 i i ≤ bound17 :=
  scale_int_diagonal q17 scale m17 diagonal17
theorem normalized_nonneg17 : 0 ≤ bound17 :=
  scale_int_bound_nonneg scale m17 (Nat.cast_nonneg _)

#print axioms psd17
#print axioms diagonal17
#print axioms normalized_psd17
#print axioms normalized_diagonal17
#print axioms normalized_nonneg17
#print axioms terms17_psd
#print axioms terms17_diagonal

theorem terms23_psd : ∀ k, (intMatrixReal (terms23 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact seed23_psd
  · exact int_outer_posSemidef vector23x1
  · exact int_outer_posSemidef vector23x2
  · exact int_outer_posSemidef vector23x3
  · exact int_outer_posSemidef vector23x4
  · exact int_outer_posSemidef vector23x5
  · exact int_outer_posSemidef vector23x6
  · exact int_outer_posSemidef vector23x7
theorem terms23_diagonal : ∀ k i, terms23 k i i ≤ (diagBounds23 k : ℤ) := by
  decide +kernel
theorem psd23 : (intMatrixReal q23).PosSemidef :=
  integer_sos_posSemidef weights23 terms23 terms23_psd
theorem diagonal23 : ∀ i, q23 i i ≤ (m23 : ℤ) :=
  integer_sos_diagonal weights23 diagBounds23 terms23 terms23_diagonal
theorem normalized_psd23 : matrix23.PosSemidef :=
  scale_int_posSemidef q23 scale psd23
theorem normalized_diagonal23 : ∀ i, matrix23 i i ≤ bound23 :=
  scale_int_diagonal q23 scale m23 diagonal23
theorem normalized_nonneg23 : 0 ≤ bound23 :=
  scale_int_bound_nonneg scale m23 (Nat.cast_nonneg _)

#print axioms psd23
#print axioms diagonal23
#print axioms normalized_psd23
#print axioms normalized_diagonal23
#print axioms normalized_nonneg23
#print axioms terms23_psd
#print axioms terms23_diagonal

theorem terms29_psd : ∀ k, (intMatrixReal (terms29 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector29x0
  · exact int_outer_posSemidef vector29x1
  · exact int_outer_posSemidef vector29x2
  · exact int_outer_posSemidef vector29x3
  · exact int_outer_posSemidef vector29x4
  · exact int_outer_posSemidef vector29x5
  · exact int_outer_posSemidef vector29x6
  · exact int_outer_posSemidef vector29x7
  · exact int_outer_posSemidef vector29x8
theorem terms29_diagonal : ∀ k i, terms29 k i i ≤ (diagBounds29 k : ℤ) := by
  decide +kernel
theorem psd29 : (intMatrixReal q29).PosSemidef :=
  integer_sos_posSemidef weights29 terms29 terms29_psd
theorem diagonal29 : ∀ i, q29 i i ≤ (m29 : ℤ) :=
  integer_sos_diagonal weights29 diagBounds29 terms29 terms29_diagonal
theorem normalized_psd29 : matrix29.PosSemidef :=
  scale_int_posSemidef q29 scale psd29
theorem normalized_diagonal29 : ∀ i, matrix29 i i ≤ bound29 :=
  scale_int_diagonal q29 scale m29 diagonal29
theorem normalized_nonneg29 : 0 ≤ bound29 :=
  scale_int_bound_nonneg scale m29 (Nat.cast_nonneg _)

#print axioms psd29
#print axioms diagonal29
#print axioms normalized_psd29
#print axioms normalized_diagonal29
#print axioms normalized_nonneg29
#print axioms terms29_psd
#print axioms terms29_diagonal

theorem terms35_psd : ∀ k, (intMatrixReal (terms35 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector35x0
  · exact int_outer_posSemidef vector35x1
  · exact int_outer_posSemidef vector35x2
  · exact int_outer_posSemidef vector35x3
  · exact int_outer_posSemidef vector35x4
  · exact int_outer_posSemidef vector35x5
theorem terms35_diagonal : ∀ k i, terms35 k i i ≤ (diagBounds35 k : ℤ) := by
  decide +kernel
theorem psd35 : (intMatrixReal q35).PosSemidef :=
  integer_sos_posSemidef weights35 terms35 terms35_psd
theorem diagonal35 : ∀ i, q35 i i ≤ (m35 : ℤ) :=
  integer_sos_diagonal weights35 diagBounds35 terms35 terms35_diagonal
theorem normalized_psd35 : matrix35.PosSemidef :=
  scale_int_posSemidef q35 scale psd35
theorem normalized_diagonal35 : ∀ i, matrix35 i i ≤ bound35 :=
  scale_int_diagonal q35 scale m35 diagonal35
theorem normalized_nonneg35 : 0 ≤ bound35 :=
  scale_int_bound_nonneg scale m35 (Nat.cast_nonneg _)

#print axioms psd35
#print axioms diagonal35
#print axioms normalized_psd35
#print axioms normalized_diagonal35
#print axioms normalized_nonneg35
#print axioms terms35_psd
#print axioms terms35_diagonal

end TightCycleC5.Bridge.P33PSD
