import Mathlib

/-! The uniform finite PSD collision argument of PROOF §3 Lemma 3.
This module does not import the certificate search or native checks. -/

namespace TightCycleC5.Bridge

open Finset Matrix

variable {I A : Type*} [Fintype I] [DecidableEq I]
  [Fintype A] [DecidableEq A]

/-- A PSD matrix whose diagonal entries are at most m has every entry
bounded in absolute value by m. -/
theorem psd_entry_abs_le {Q : Matrix I I ℝ} (hQ : Q.PosSemidef)
    {m : ℝ} (hdiag : ∀ i, Q i i ≤ m) (i j : I) : |Q i j| ≤ m := by
  have hsymm : Q j i = Q i j := by simpa using hQ.1.apply i j
  have hp := hQ.dotProduct_mulVec_nonneg (Pi.single i 1 + Pi.single j 1)
  have hn := hQ.dotProduct_mulVec_nonneg (Pi.single i 1 - Pi.single j 1)
  simp [Matrix.mulVec_add, Matrix.mulVec_sub, add_dotProduct, sub_dotProduct,
    dotProduct_add, dotProduct_sub, Matrix.mulVec_single, single_dotProduct] at hp hn
  rw [hsymm] at hp hn
  exact abs_le.mpr ⟨by linarith [hdiag i, hdiag j], by linarith [hdiag i, hdiag j]⟩

omit [Fintype I] [DecidableEq I] in
/-- Sum all flag products on a finite set, allowing repetitions. Flag
values are indices, so the corresponding vectors are one-hot. -/
theorem psd_flag_sum_nonneg {Q : Matrix I I ℝ} (hQ : Q.PosSemidef)
    (s : Finset A) (flag : A → I) :
    0 ≤ ∑ a ∈ s, ∑ b ∈ s, Q (flag a) (flag b) := by
  have h := (hQ.submatrix flag).dotProduct_mulVec_nonneg
    (fun a => if a ∈ s then 1 else 0)
  simpa [dotProduct, Matrix.mulVec, Matrix.submatrix, Finset.mul_sum,
    Finset.sum_ite, Finset.filter_mem_eq_inter] using h

/-- Deleting C ordered pairs from a nonnegative PSD sum loses at most
card(C) times the largest permitted diagonal. -/
theorem psd_delete_pairs {Q : Matrix I I ℝ} (hQ : Q.PosSemidef)
    {m : ℝ} (hdiag : ∀ i, Q i i ≤ m)
    (s : Finset A) (flag : A → I) (C : Finset (A × A)) (hC : C ⊆ s ×ˢ s) :
    -(C.card : ℝ) * m ≤ ∑ ab ∈ (s ×ˢ s) \ C, Q (flag ab.1) (flag ab.2) := by
  have htotal : 0 ≤ ∑ ab ∈ s ×ˢ s, Q (flag ab.1) (flag ab.2) := by
    simpa [Finset.sum_product] using psd_flag_sum_nonneg hQ s flag
  have hloss : ∑ ab ∈ C, Q (flag ab.1) (flag ab.2) ≤ (C.card : ℝ) * m := by
    calc
      _ ≤ ∑ _ab ∈ C, m := Finset.sum_le_sum fun ab _ =>
        (le_abs_self _).trans (psd_entry_abs_le hQ hdiag _ _)
      _ = _ := by simp
  have hsplit := Finset.sum_sdiff (f := fun ab => Q (flag ab.1) (flag ab.2)) hC
  linarith

/-- Two ordered pairs of vertices have disjoint underlying vertex sets. -/
def Apart (p q : A × A) : Prop :=
  p.1 ≠ q.1 ∧ p.1 ≠ q.2 ∧ p.2 ≠ q.1 ∧ p.2 ≠ q.2

instance (p q : A × A) : Decidable (Apart p q) := inferInstanceAs
  (Decidable (p.1 ≠ q.1 ∧ p.1 ≠ q.2 ∧ p.2 ≠ q.1 ∧ p.2 ≠ q.2))

omit [Fintype A] in
/-- The ordered pairs avoiding both endpoints of p are precisely the
off-diagonal pairs of the twice-erased vertex set. -/
theorem apart_pairs_eq (s : Finset A) (p : A × A) :
    s.offDiag.filter (Apart p) = ((s.erase p.1).erase p.2).offDiag := by
  ext q
  simp only [mem_filter, mem_offDiag, mem_erase, Apart]
  tauto

omit [Fintype A] in
/-- For a fixed ordered pair of distinct vertices in s, exactly 4|s|-6
ordered pairs of distinct vertices in s overlap it. -/
theorem overlapping_pair_card (s : Finset A) {p : A × A} (hp : p ∈ s.offDiag) :
    (s.offDiag.filter (fun q => ¬ Apart p q)).card = 4 * s.card - 6 := by
  obtain ⟨hp1, hp2, hpne⟩ := mem_offDiag.mp hp
  have h2 : 2 ≤ s.card := by
    have hsub : ({p.1, p.2} : Finset A) ⊆ s := by
      intro a ha
      simp only [mem_insert, mem_singleton] at ha
      rcases ha with rfl | rfl <;> assumption
    have := Finset.card_le_card hsub
    simpa [hpne] using this
  have he : ((s.erase p.1).erase p.2).card = s.card - 2 := by
    rw [card_erase_of_mem (mem_erase.mpr ⟨hpne.symm, hp2⟩), card_erase_of_mem hp1]
    omega
  have hsplit := Finset.card_filter_add_card_filter_not (s := s.offDiag) (Apart p)
  rw [apart_pairs_eq, offDiag_card, he, offDiag_card] at hsplit
  have hsq := Nat.le_mul_self s.card
  have hsq' := Nat.le_mul_self (s.card - 2)
  have htop : 6 ≤ 4 * s.card := by omega
  have he2 : s.card - 2 + 2 = s.card := by omega
  have hs := Nat.sub_add_cancel hsq
  have hs' := Nat.sub_add_cancel hsq'
  have ht := Nat.sub_add_cancel htop
  nlinarith

/-- All overlapping ordered pair-pairs, with no symmetry quotient. -/
def overlappingPairs (s : Finset A) : Finset ((A × A) × (A × A)) :=
  (s.offDiag ×ˢ s.offDiag).filter (fun pq => ¬ Apart pq.1 pq.2)

omit [Fintype A] in
/-- The exact two-root overlap count, as a natural number. -/
theorem overlappingPairs_card (s : Finset A) :
    (overlappingPairs s).card = s.offDiag.card * (4 * s.card - 6) := by
  have heq : overlappingPairs s =
      s.offDiag.biUnion (fun p =>
        (s.offDiag.filter (fun q => ¬ Apart p q)).map
          ⟨fun q => (p, q), fun _ _ h => (Prod.mk.inj h).2⟩) := by
    ext pq
    constructor
    · intro h
      simp only [overlappingPairs, mem_filter, mem_product] at h
      exact mem_biUnion.mpr ⟨pq.1, h.1.1,
        mem_map.mpr ⟨pq.2, mem_filter.mpr ⟨h.1.2, h.2⟩, rfl⟩⟩
    · intro h
      obtain ⟨p, hp, hp'⟩ := mem_biUnion.mp h
      obtain ⟨q, hq, rfl⟩ := mem_map.mp hp'
      exact mem_filter.mpr ⟨mem_product.mpr ⟨hp, (mem_filter.mp hq).1⟩,
        (mem_filter.mp hq).2⟩
  rw [heq, card_biUnion]
  · calc
      _ = ∑ _p ∈ s.offDiag, (4 * s.card - 6) := by
        apply Finset.sum_congr rfl
        intro p hp
        rw [card_map, overlapping_pair_card s hp]
      _ = _ := by simp
  · intro p _ q _ hpq
    apply Finset.disjoint_left.mpr
    rintro ab hab hab'
    obtain ⟨_, _, hp⟩ := mem_map.mp hab
    obtain ⟨_, _, hq⟩ := mem_map.mp hab'
    exact hpq ((congrArg Prod.fst hp).trans (congrArg Prod.fst hq).symm)

/-- All disjoint ordered pair-pairs in the free vertex set. -/
def disjointPairs (s : Finset A) : Finset ((A × A) × (A × A)) :=
  (s.offDiag ×ˢ s.offDiag).filter (fun pq => Apart pq.1 pq.2)

omit [Fintype A] in
theorem overlappingPairs_subset (s : Finset A) :
    overlappingPairs s ⊆ s.offDiag ×ˢ s.offDiag := filter_subset _ _

omit [Fintype A] in
theorem disjointPairs_eq_sdiff (s : Finset A) :
    disjointPairs s = (s.offDiag ×ˢ s.offDiag) \ overlappingPairs s := by
  ext pq
  simp only [disjointPairs, overlappingPairs, mem_filter, mem_sdiff]
  tauto

omit [Fintype A] [DecidableEq A] in
/-- Cast the off-diagonal cardinality without introducing truncated real
subtraction. This also holds for an empty set. -/
theorem offDiag_card_real (s : Finset A) :
    (s.offDiag.card : ℝ) = (s.card : ℝ) * ((s.card : ℝ) - 1) := by
  rw [offDiag_card, Nat.cast_sub (Nat.le_mul_self _), Nat.cast_mul]
  ring

omit [Fintype A] in
/-- Exact real overlap count for at least two free vertices. -/
theorem overlappingPairs_card_real (s : Finset A) (hs : 2 ≤ s.card) :
    ((overlappingPairs s).card : ℝ) =
      (s.card : ℝ) * ((s.card : ℝ) - 1) * (4 * (s.card : ℝ) - 6) := by
  have h6 : 6 ≤ 4 * s.card := by omega
  rw [overlappingPairs_card, Nat.cast_mul, offDiag_card_real, Nat.cast_sub h6]
  norm_num

omit [Fintype A] in
/-- Exact denominator for disjoint ordered pair-pairs. -/
theorem disjointPairs_card_real (s : Finset A) (hs : 2 ≤ s.card) :
    ((disjointPairs s).card : ℝ) =
      (s.card : ℝ) * ((s.card : ℝ) - 1) * ((s.card : ℝ) - 2) * ((s.card : ℝ) - 3) := by
  have hle := Finset.card_le_card (overlappingPairs_subset s)
  rw [disjointPairs_eq_sdiff, card_sdiff_of_subset (overlappingPairs_subset s),
    Nat.cast_sub hle, card_product, Nat.cast_mul, offDiag_card_real,
    overlappingPairs_card_real s hs]
  ring

/-- The unnormalized four-root PSD bound: only equal free vertices
have been deleted. -/
theorem psd_offDiag_sum {Q : Matrix I I ℝ} (hQ : Q.PosSemidef)
    {m : ℝ} (hdiag : ∀ i, Q i i ≤ m) (s : Finset A) (flag : A → I) :
    -(s.card : ℝ) * m ≤ ∑ ab ∈ s.offDiag, Q (flag ab.1) (flag ab.2) := by
  have hsub : s.diag ⊆ s ×ˢ s := by
    intro ab hab
    obtain ⟨ha, hab⟩ := mem_diag.mp hab
    exact mem_product.mpr ⟨ha, hab ▸ ha⟩
  have heq : (s ×ˢ s) \ s.diag = s.offDiag := by
    ext ab
    simp only [mem_sdiff, mem_product, mem_diag, mem_offDiag]
    tauto
  simpa only [heq, diag_card] using psd_delete_pairs hQ hdiag s flag s.diag hsub

/-- The unnormalized two-root PSD bound. Each free object is an ordered
pair; every overlapping pair-pair is deleted exactly once. -/
theorem psd_disjointPairs_sum {Q : Matrix I I ℝ} (hQ : Q.PosSemidef)
    {m : ℝ} (hdiag : ∀ i, Q i i ≤ m) (s : Finset A) (hs : 2 ≤ s.card)
    (flag : A × A → I) :
    -((s.card : ℝ) * ((s.card : ℝ) - 1) * (4 * (s.card : ℝ) - 6)) * m ≤
      ∑ pq ∈ disjointPairs s, Q (flag pq.1) (flag pq.2) := by
  have h := psd_delete_pairs hQ hdiag s.offDiag flag (overlappingPairs s)
    (overlappingPairs_subset s)
  rw [overlappingPairs_card_real s hs, ← disjointPairs_eq_sdiff] at h
  exact h

/-- Lemma 3's four-root bound, conditioned on any fixed four roots.
The denominator is the actual number of ordered distinct free vertices. -/
theorem psd_four_root_average {Q : Matrix I I ℝ} (hQ : Q.PosSemidef)
    {m : ℝ} (hdiag : ∀ i, Q i i ≤ m) {n : ℕ} (hn : 12 ≤ n)
    (s : Finset A) (hs : s.card = n - 4) (flag : A → I) :
    -m / ((n : ℝ) - 5) ≤
      (∑ ab ∈ s.offDiag, Q (flag ab.1) (flag ab.2)) / (s.offDiag.card : ℝ) := by
  have hnR : (12 : ℝ) ≤ n := by exact_mod_cast hn
  have hsR : (s.card : ℝ) = (n : ℝ) - 4 := by
    rw [hs, Nat.cast_sub (by omega : 4 ≤ n)]
    norm_num
  have hraw := psd_offDiag_sum hQ hdiag s flag
  rw [hsR] at hraw
  rw [offDiag_card_real, hsR]
  have hd : 0 < ((n : ℝ) - 4) * (((n : ℝ) - 4) - 1) :=
    mul_pos (by linarith) (by linarith)
  apply (le_div_iff₀ hd).mpr
  calc
    _ = -((n : ℝ) - 4) * m := by
      have h5 : (n : ℝ) - 5 ≠ 0 := by linarith
      field_simp
      ring
    _ ≤ _ := hraw

/-- Lemma 3's two-root bound, conditioned on any fixed two roots.
The denominator counts exactly the disjoint ordered pair-pairs. -/
theorem psd_two_root_average {Q : Matrix I I ℝ} (hQ : Q.PosSemidef)
    {m : ℝ} (hdiag : ∀ i, Q i i ≤ m) {n : ℕ} (hn : 12 ≤ n)
    (s : Finset A) (hs : s.card = n - 2) (flag : A × A → I) :
    -((4 * (n : ℝ) - 14) * m / (((n : ℝ) - 4) * ((n : ℝ) - 5))) ≤
      (∑ pq ∈ disjointPairs s, Q (flag pq.1) (flag pq.2)) /
        ((disjointPairs s).card : ℝ) := by
  have hnR : (12 : ℝ) ≤ n := by exact_mod_cast hn
  have hsN : 2 ≤ s.card := by omega
  have hsR : (s.card : ℝ) = (n : ℝ) - 2 := by
    rw [hs, Nat.cast_sub (by omega : 2 ≤ n)]
    norm_num
  have hraw := psd_disjointPairs_sum hQ hdiag s hsN flag
  rw [hsR] at hraw
  rw [disjointPairs_card_real s hsN, hsR]
  have hd : 0 < ((n : ℝ) - 2) * (((n : ℝ) - 2) - 1) *
      (((n : ℝ) - 2) - 2) * (((n : ℝ) - 2) - 3) :=
    mul_pos (mul_pos (mul_pos (by linarith) (by linarith)) (by linarith)) (by linarith)
  apply (le_div_iff₀ hd).mpr
  calc
    _ = -(((n : ℝ) - 2) * (((n : ℝ) - 2) - 1) * (4 * ((n : ℝ) - 2) - 6)) * m := by
      have h4 : (n : ℝ) - 4 ≠ 0 := by linarith
      have h5 : (n : ℝ) - 5 ≠ 0 := by linarith
      field_simp
      ring
    _ ≤ _ := hraw

/-- A nonpositive lower bound survives a zero-or-one root-type multiplier. -/
theorem root_indicator_lower {c v g : ℝ} (hc : c ≤ 0) (hv : c ≤ v)
    (hg : g = 0 ∨ g = 1) : c ≤ g * v := by
  rcases hg with rfl | rfl
  · simpa using hc
  · simpa using hv

/-- A uniform lower bound survives uniform averaging over a nonempty
finite root space. The correspondence to six-vertex injections is separate. -/
theorem root_mean_lower {R : Type*} [Fintype R] [Nonempty R]
    (f : R → ℝ) {c : ℝ} (h : ∀ r, c ≤ f r) :
    c ≤ (∑ r, f r) / (Fintype.card R : ℝ) := by
  have hc : (0 : ℝ) < Fintype.card R := by exact_mod_cast Fintype.card_pos
  apply (le_div_iff₀ hc).mpr
  simpa [mul_comm] using Finset.sum_le_sum (s := (univ : Finset R)) (fun r _ => h r)

/-- Root-type-conditioned four-root rows averaged over any nonempty
uniform root space, using their actual free-sample denominators. -/
theorem psd_four_root_mean {R : Type*} [Fintype R] [Nonempty R]
    {Q : Matrix I I ℝ} (hQ : Q.PosSemidef) {m : ℝ} (hm : 0 ≤ m)
    (hdiag : ∀ i, Q i i ≤ m) {n : ℕ} (hn : 12 ≤ n)
    (s : R → Finset A) (hs : ∀ r, (s r).card = n - 4)
    (flag : R → A → I) (g : R → ℝ) (hg : ∀ r, g r = 0 ∨ g r = 1) :
    -m / ((n : ℝ) - 5) ≤
      (∑ r, g r * ((∑ ab ∈ (s r).offDiag, Q (flag r ab.1) (flag r ab.2)) /
        ((s r).offDiag.card : ℝ))) / (Fintype.card R : ℝ) := by
  apply root_mean_lower
  intro r
  apply root_indicator_lower _ (psd_four_root_average hQ hdiag hn (s r) (hs r) (flag r)) (hg r)
  exact div_nonpos_of_nonpos_of_nonneg (neg_nonpos.mpr hm) (by
    have : (12 : ℝ) ≤ n := by exact_mod_cast hn
    linarith)

/-- Root-type-conditioned two-root rows averaged over any nonempty
uniform root space, with every colliding ordered pair-pair removed. -/
theorem psd_two_root_mean {R : Type*} [Fintype R] [Nonempty R]
    {Q : Matrix I I ℝ} (hQ : Q.PosSemidef) {m : ℝ} (hm : 0 ≤ m)
    (hdiag : ∀ i, Q i i ≤ m) {n : ℕ} (hn : 12 ≤ n)
    (s : R → Finset A) (hs : ∀ r, (s r).card = n - 2)
    (flag : R → A × A → I) (g : R → ℝ) (hg : ∀ r, g r = 0 ∨ g r = 1) :
    -((4 * (n : ℝ) - 14) * m / (((n : ℝ) - 4) * ((n : ℝ) - 5))) ≤
      (∑ r, g r * ((∑ pq ∈ disjointPairs (s r), Q (flag r pq.1) (flag r pq.2)) /
        ((disjointPairs (s r)).card : ℝ))) / (Fintype.card R : ℝ) := by
  apply root_mean_lower
  intro r
  apply root_indicator_lower _ (psd_two_root_average hQ hdiag hn (s r) (hs r) (flag r)) (hg r)
  have hnR : (12 : ℝ) ≤ n := by exact_mod_cast hn
  apply neg_nonpos.mpr
  exact div_nonneg (mul_nonneg (by linarith) hm)
    (mul_nonneg (by linarith) (by linarith))

#print axioms psd_entry_abs_le
#print axioms psd_flag_sum_nonneg
#print axioms psd_delete_pairs
#print axioms apart_pairs_eq
#print axioms overlapping_pair_card
#print axioms overlappingPairs_card
#print axioms overlappingPairs_subset
#print axioms disjointPairs_eq_sdiff
#print axioms offDiag_card_real
#print axioms overlappingPairs_card_real
#print axioms disjointPairs_card_real
#print axioms psd_offDiag_sum
#print axioms psd_disjointPairs_sum
#print axioms psd_four_root_average
#print axioms psd_two_root_average
#print axioms root_indicator_lower
#print axioms root_mean_lower
#print axioms psd_four_root_mean
#print axioms psd_two_root_mean

end TightCycleC5.Bridge
