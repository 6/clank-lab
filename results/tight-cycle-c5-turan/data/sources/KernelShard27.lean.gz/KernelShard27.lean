import KernelShard27Blocks0
import KernelShard27Blocks1
import KernelShard27Blocks2
import KernelShard27Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard27 : kernelShardCheck 27 kernelWitness27 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (27 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness27 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_27_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard27
end TightCycleC5.Bridge.Cover
