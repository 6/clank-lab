import KernelQuarterIndex
import KernelWitness8

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_8_32 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 32 * 256 + i.val))
      kernelWitness8Row32[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_32

theorem kernelBlock_8_33 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 33 * 256 + i.val))
      kernelWitness8Row33[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_33

theorem kernelBlock_8_34 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 34 * 256 + i.val))
      kernelWitness8Row34[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_34

theorem kernelBlock_8_35 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 35 * 256 + i.val))
      kernelWitness8Row35[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_35

theorem kernelBlock_8_36 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 36 * 256 + i.val))
      kernelWitness8Row36[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_36

theorem kernelBlock_8_37 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 37 * 256 + i.val))
      kernelWitness8Row37[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_37

theorem kernelBlock_8_38 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 38 * 256 + i.val))
      kernelWitness8Row38[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_38

theorem kernelBlock_8_39 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 39 * 256 + i.val))
      kernelWitness8Row39[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_39

theorem kernelBlock_8_40 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 40 * 256 + i.val))
      kernelWitness8Row40[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_40

theorem kernelBlock_8_41 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 41 * 256 + i.val))
      kernelWitness8Row41[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_41

theorem kernelBlock_8_42 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 42 * 256 + i.val))
      kernelWitness8Row42[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_42

theorem kernelBlock_8_43 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 43 * 256 + i.val))
      kernelWitness8Row43[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_43

theorem kernelBlock_8_44 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 44 * 256 + i.val))
      kernelWitness8Row44[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_44

theorem kernelBlock_8_45 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 45 * 256 + i.val))
      kernelWitness8Row45[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_45

theorem kernelBlock_8_46 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 46 * 256 + i.val))
      kernelWitness8Row46[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_46

theorem kernelBlock_8_47 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 47 * 256 + i.val))
      kernelWitness8Row47[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_47

theorem kernelBlock_8_48 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 48 * 256 + i.val))
      kernelWitness8Row48[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_48

theorem kernelBlock_8_49 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 49 * 256 + i.val))
      kernelWitness8Row49[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_49

theorem kernelBlock_8_50 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 50 * 256 + i.val))
      kernelWitness8Row50[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_50

theorem kernelBlock_8_51 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 51 * 256 + i.val))
      kernelWitness8Row51[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_51

theorem kernelBlock_8_52 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 52 * 256 + i.val))
      kernelWitness8Row52[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_52

theorem kernelBlock_8_53 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 53 * 256 + i.val))
      kernelWitness8Row53[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_53

theorem kernelBlock_8_54 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 54 * 256 + i.val))
      kernelWitness8Row54[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_54

theorem kernelBlock_8_55 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 55 * 256 + i.val))
      kernelWitness8Row55[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_55

theorem kernelBlock_8_56 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 56 * 256 + i.val))
      kernelWitness8Row56[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_56

theorem kernelBlock_8_57 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 57 * 256 + i.val))
      kernelWitness8Row57[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_57

theorem kernelBlock_8_58 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 58 * 256 + i.val))
      kernelWitness8Row58[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_58

theorem kernelBlock_8_59 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 59 * 256 + i.val))
      kernelWitness8Row59[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_59

theorem kernelBlock_8_60 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 60 * 256 + i.val))
      kernelWitness8Row60[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_60

theorem kernelBlock_8_61 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 61 * 256 + i.val))
      kernelWitness8Row61[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_61

theorem kernelBlock_8_62 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 62 * 256 + i.val))
      kernelWitness8Row62[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_62

theorem kernelBlock_8_63 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (8 * 32768 + 63 * 256 + i.val))
      kernelWitness8Row63[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_8_63

end TightCycleC5.Bridge.Cover
