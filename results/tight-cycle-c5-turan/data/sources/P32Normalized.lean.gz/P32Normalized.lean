import P32PSD
import GramNormalization

/-! The actual square-normalized P32 certificate blocks. -/
namespace TightCycleC5.Bridge.P32PSD

theorem factorScale_pos : (0 : ℝ) < (factorScale : ℝ) := by norm_num [factorScale]

noncomputable def matrix0 : Matrix (Fin 64) (Fin 64) ℝ :=
  normalizedIntMatrix q0 factorScale
noncomputable def bound0 : ℝ := (m0 : ℝ) / (factorScale : ℝ) ^ 2

theorem normalized_psd0 : matrix0.PosSemidef :=
  normalized_int_gram_posSemidef q0 u0 factorScale gram0
theorem normalized_diagonal0 : ∀ i, matrix0 i i ≤ bound0 :=
  normalized_int_diagonal_bound q0 m0 factorScale diagonal0
theorem normalized_nonneg0 : 0 ≤ bound0 :=
  normalized_bound_nonneg m0 factorScale bound_nonneg0

noncomputable def matrix1 : Matrix (Fin 64) (Fin 64) ℝ :=
  normalizedIntMatrix q1 factorScale
noncomputable def bound1 : ℝ := (m1 : ℝ) / (factorScale : ℝ) ^ 2

theorem normalized_psd1 : matrix1.PosSemidef :=
  normalized_int_gram_posSemidef q1 u1 factorScale gram1
theorem normalized_diagonal1 : ∀ i, matrix1 i i ≤ bound1 :=
  normalized_int_diagonal_bound q1 m1 factorScale diagonal1
theorem normalized_nonneg1 : 0 ≤ bound1 :=
  normalized_bound_nonneg m1 factorScale bound_nonneg1

noncomputable def matrix2 : Matrix (Fin 50) (Fin 50) ℝ :=
  normalizedIntMatrix q2 factorScale
noncomputable def bound2 : ℝ := (m2 : ℝ) / (factorScale : ℝ) ^ 2

theorem normalized_psd2 : matrix2.PosSemidef :=
  normalized_int_gram_posSemidef q2 u2 factorScale gram2
theorem normalized_diagonal2 : ∀ i, matrix2 i i ≤ bound2 :=
  normalized_int_diagonal_bound q2 m2 factorScale diagonal2
theorem normalized_nonneg2 : 0 ≤ bound2 :=
  normalized_bound_nonneg m2 factorScale bound_nonneg2

noncomputable def matrix3 : Matrix (Fin 39) (Fin 39) ℝ :=
  normalizedIntMatrix q3 factorScale
noncomputable def bound3 : ℝ := (m3 : ℝ) / (factorScale : ℝ) ^ 2

theorem normalized_psd3 : matrix3.PosSemidef :=
  normalized_int_gram_posSemidef q3 u3 factorScale gram3
theorem normalized_diagonal3 : ∀ i, matrix3 i i ≤ bound3 :=
  normalized_int_diagonal_bound q3 m3 factorScale diagonal3
theorem normalized_nonneg3 : 0 ≤ bound3 :=
  normalized_bound_nonneg m3 factorScale bound_nonneg3

noncomputable def matrix4 : Matrix (Fin 30) (Fin 30) ℝ :=
  normalizedIntMatrix q4 factorScale
noncomputable def bound4 : ℝ := (m4 : ℝ) / (factorScale : ℝ) ^ 2

theorem normalized_psd4 : matrix4.PosSemidef :=
  normalized_int_gram_posSemidef q4 u4 factorScale gram4
theorem normalized_diagonal4 : ∀ i, matrix4 i i ≤ bound4 :=
  normalized_int_diagonal_bound q4 m4 factorScale diagonal4
theorem normalized_nonneg4 : 0 ≤ bound4 :=
  normalized_bound_nonneg m4 factorScale bound_nonneg4

noncomputable def matrix5 : Matrix (Fin 12) (Fin 12) ℝ :=
  normalizedIntMatrix q5 factorScale
noncomputable def bound5 : ℝ := (m5 : ℝ) / (factorScale : ℝ) ^ 2

theorem normalized_psd5 : matrix5.PosSemidef :=
  normalized_int_gram_posSemidef q5 u5 factorScale gram5
theorem normalized_diagonal5 : ∀ i, matrix5 i i ≤ bound5 :=
  normalized_int_diagonal_bound q5 m5 factorScale diagonal5
theorem normalized_nonneg5 : 0 ≤ bound5 :=
  normalized_bound_nonneg m5 factorScale bound_nonneg5

#print axioms factorScale_pos
#print axioms normalized_psd0
#print axioms normalized_diagonal0
#print axioms normalized_nonneg0
#print axioms normalized_psd1
#print axioms normalized_diagonal1
#print axioms normalized_nonneg1
#print axioms normalized_psd2
#print axioms normalized_diagonal2
#print axioms normalized_nonneg2
#print axioms normalized_psd3
#print axioms normalized_diagonal3
#print axioms normalized_nonneg3
#print axioms normalized_psd4
#print axioms normalized_diagonal4
#print axioms normalized_nonneg4
#print axioms normalized_psd5
#print axioms normalized_diagonal5
#print axioms normalized_nonneg5
end TightCycleC5.Bridge.P32PSD
