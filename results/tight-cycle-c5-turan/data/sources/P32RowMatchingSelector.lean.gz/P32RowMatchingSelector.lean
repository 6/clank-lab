import P32ArithmeticSemantics
import P32Selector

namespace TightCycleC5.Bridge.P32RowMatching
open Finset
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000
set_option backward.isDefEq.respectTransparency false

theorem selector_probability_scale : P32Arithmetic.probScale = P32Selector.probabilityScale := rfl
theorem selector_weight_scale : P32Arithmetic.weightScale = P32Selector.weightScale := rfl

theorem selector_root_quote : ∀ j : Fin 9,
    (P32Arithmetic.selectors.get j).tau = P32Selector.rootEdge j := by decide +kernel

theorem selector_weight_quote : ∀ j : Fin 9,
    (P32Arithmetic.selectors.get j).weight = P32Selector.weights[j.val]! := by decide +kernel

theorem selector_probability_quote : ∀ (j : Fin 9) (p : Fin 8),
    (P32Arithmetic.selectors.get j).pi.get p =
      (P32Selector.probabilities[j.val]!)[p.val]! := by decide +kernel

theorem selector_algebra (w a b d t P W : ℝ) (hP : P ≠ 0) (hW : W ≠ 0) :
    w * (5*t*(a*b*(P-d) + a*(P-b)*d + (P-a)*b*d) - 2*P^3) /
      (5*P^3*W) =
    (w/W) * (t * SelectorCertificate.twoPolynomial (a/P) (b/P) (d/P) - 2/5) := by
  unfold SelectorCertificate.twoPolynomial
  field_simp
  <;> ring

def selectorIntegerRow (f : P32Arithmetic.Features) (s : P32Arithmetic.Selector) : ℤ :=
  let a := s.pi.get (f.patterns.get 0)
  let b := s.pi.get (f.patterns.get 1)
  let d := s.pi.get (f.patterns.get 2)
  if s.tau = f.tau then
    s.weight * (5*f.target*(a*b*(P32Arithmetic.probScale-d) +
      a*(P32Arithmetic.probScale-b)*d + (P32Arithmetic.probScale-a)*b*d) -
      2*P32Arithmetic.probScale^3)
  else 0

theorem selector_single_eq (G : LabelledStructure 6) (j : Fin 9) :
    ((selectorIntegerRow (P32Arithmetic.features G) (P32Arithmetic.selectors.get j) : ℤ) : ℝ) /
      (5 * (P32Arithmetic.probScale : ℝ)^3 * (P32Arithmetic.weightScale : ℝ)) =
    P32Selector.weight j * (SelectorCertificate.numerator (P32Selector.descriptor j) G -
      (2/5 : ℝ) * SelectorCertificate.denominator (P32Selector.descriptor j) G) := by
  let f := P32Arithmetic.features G
  let s := P32Arithmetic.selectors.get j
  have hw : P32Selector.weight j = (s.weight : ℝ) / (P32Arithmetic.weightScale : ℝ) := by
    simp only [P32Selector.weight, ← selector_weight_quote, ← selector_weight_scale, s]
  have hp0 : P32Selector.probability j (SelectorCertificate.patternIndex (fun a b c => G.edge {a,b,c}) 0 1 2 3) =
      ((s.pi.get (f.patterns.get 0) : ℤ) : ℝ) / (P32Arithmetic.probScale : ℝ) := by
    rw [P32Selector.probability, ← selector_probability_quote, ← selector_probability_scale]
    rfl
  have hp1 : P32Selector.probability j (SelectorCertificate.patternIndex (fun a b c => G.edge {a,b,c}) 0 1 2 4) =
      ((s.pi.get (f.patterns.get 1) : ℤ) : ℝ) / (P32Arithmetic.probScale : ℝ) := by
    rw [P32Selector.probability, ← selector_probability_quote, ← selector_probability_scale]
    rfl
  have hp2 : P32Selector.probability j (SelectorCertificate.patternIndex (fun a b c => G.edge {a,b,c}) 0 1 2 5) =
      ((s.pi.get (f.patterns.get 2) : ℤ) : ℝ) / (P32Arithmetic.probScale : ℝ) := by
    rw [P32Selector.probability, ← selector_probability_quote, ← selector_probability_scale]
    rfl
  have htau : G.edge {0,1,2} = f.tau := rfl
  have ht : (if G.edge {3,4,5} then (1 : ℝ) else 0) = (f.target : ℝ) := by
    change (if G.edge {3,4,5} then (1 : ℝ) else 0) = ((P32Arithmetic.bit (G.edge {3,4,5}) : ℤ) : ℝ)
    cases G.edge {3,4,5} <;> simp [P32Arithmetic.bit]
  simp only [P32Selector.descriptor, SelectorCertificate.numerator, SelectorCertificate.evaluate,
    SelectorCertificate.denominator, ← selector_root_quote, hw, hp0, hp1, hp2, htau, ht]
  change ((selectorIntegerRow f s : ℤ) : ℝ) / _ = _
  by_cases h : s.tau = f.tau
  · have h' : f.tau = (P32Arithmetic.selectors.get j).tau := h.symm
    simp only [selectorIntegerRow, h, h', ↓reduceIte, Int.cast_mul, Int.cast_sub,
      Int.cast_add, Int.cast_pow, Int.cast_ofNat, one_mul, mul_one]
    exact selector_algebra (s.weight : ℝ)
      ((s.pi.get (f.patterns.get 0) : ℤ) : ℝ)
      ((s.pi.get (f.patterns.get 1) : ℤ) : ℝ)
      ((s.pi.get (f.patterns.get 2) : ℤ) : ℝ) (f.target : ℝ)
      (P32Arithmetic.probScale : ℝ) (P32Arithmetic.weightScale : ℝ)
      (by norm_num [P32Arithmetic.probScale]) (by norm_num [P32Arithmetic.weightScale])
  · have h' : f.tau ≠ (P32Arithmetic.selectors.get j).tau := Ne.symm h
    simp [selectorIntegerRow, h, h']

/-- Actual nine-selector margin, with no graph, support or class premise. -/
theorem selector_margin_eq (G : LabelledStructure 6) :
    P32Arithmetic.selectorMargin G = P32Selector.margin G := by
  simp only [P32Arithmetic.selectorMargin, Rat.cast_div, Rat.cast_mul, Rat.cast_pow,
    Rat.cast_intCast, Rat.cast_ofNat, P32Selector.margin]
  change ((∑ j : Fin 9, selectorIntegerRow (P32Arithmetic.features G)
    (P32Arithmetic.selectors.get j) : ℤ) : ℝ) / _ = _
  rw [Int.cast_sum, Finset.sum_div]
  apply Finset.sum_congr rfl
  intro j _
  exact selector_single_eq G j

#print axioms selector_probability_scale
#print axioms selector_weight_scale
#print axioms selector_root_quote
#print axioms selector_weight_quote
#print axioms selector_probability_quote
#print axioms selector_algebra
#print axioms selector_single_eq
#print axioms selector_margin_eq
end TightCycleC5.Bridge.P32RowMatching
