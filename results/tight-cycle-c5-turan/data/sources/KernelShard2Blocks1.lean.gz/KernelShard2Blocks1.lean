import KernelRowIndex
import KernelWitness2

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_2_32 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 32 * 256 + i.val))
      kernelWitness2Row32[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_32

theorem kernelBlock_2_33 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 33 * 256 + i.val))
      kernelWitness2Row33[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_33

theorem kernelBlock_2_34 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 34 * 256 + i.val))
      kernelWitness2Row34[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_34

theorem kernelBlock_2_35 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 35 * 256 + i.val))
      kernelWitness2Row35[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_35

theorem kernelBlock_2_36 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 36 * 256 + i.val))
      kernelWitness2Row36[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_36

theorem kernelBlock_2_37 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 37 * 256 + i.val))
      kernelWitness2Row37[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_37

theorem kernelBlock_2_38 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 38 * 256 + i.val))
      kernelWitness2Row38[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_38

theorem kernelBlock_2_39 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 39 * 256 + i.val))
      kernelWitness2Row39[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_39

theorem kernelBlock_2_40 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 40 * 256 + i.val))
      kernelWitness2Row40[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_40

theorem kernelBlock_2_41 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 41 * 256 + i.val))
      kernelWitness2Row41[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_41

theorem kernelBlock_2_42 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 42 * 256 + i.val))
      kernelWitness2Row42[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_42

theorem kernelBlock_2_43 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 43 * 256 + i.val))
      kernelWitness2Row43[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_43

theorem kernelBlock_2_44 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 44 * 256 + i.val))
      kernelWitness2Row44[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_44

theorem kernelBlock_2_45 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 45 * 256 + i.val))
      kernelWitness2Row45[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_45

theorem kernelBlock_2_46 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 46 * 256 + i.val))
      kernelWitness2Row46[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_46

theorem kernelBlock_2_47 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 47 * 256 + i.val))
      kernelWitness2Row47[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_47

theorem kernelBlock_2_48 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 48 * 256 + i.val))
      kernelWitness2Row48[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_48

theorem kernelBlock_2_49 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 49 * 256 + i.val))
      kernelWitness2Row49[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_49

theorem kernelBlock_2_50 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 50 * 256 + i.val))
      kernelWitness2Row50[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_50

theorem kernelBlock_2_51 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 51 * 256 + i.val))
      kernelWitness2Row51[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_51

theorem kernelBlock_2_52 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 52 * 256 + i.val))
      kernelWitness2Row52[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_52

theorem kernelBlock_2_53 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 53 * 256 + i.val))
      kernelWitness2Row53[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_53

theorem kernelBlock_2_54 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 54 * 256 + i.val))
      kernelWitness2Row54[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_54

theorem kernelBlock_2_55 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 55 * 256 + i.val))
      kernelWitness2Row55[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_55

theorem kernelBlock_2_56 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 56 * 256 + i.val))
      kernelWitness2Row56[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_56

theorem kernelBlock_2_57 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 57 * 256 + i.val))
      kernelWitness2Row57[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_57

theorem kernelBlock_2_58 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 58 * 256 + i.val))
      kernelWitness2Row58[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_58

theorem kernelBlock_2_59 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 59 * 256 + i.val))
      kernelWitness2Row59[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_59

theorem kernelBlock_2_60 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 60 * 256 + i.val))
      kernelWitness2Row60[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_60

theorem kernelBlock_2_61 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 61 * 256 + i.val))
      kernelWitness2Row61[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_61

theorem kernelBlock_2_62 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 62 * 256 + i.val))
      kernelWitness2Row62[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_62

theorem kernelBlock_2_63 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (2 * 32768 + 63 * 256 + i.val))
      kernelWitness2Row63[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_2_63

end TightCycleC5.Bridge.Cover
