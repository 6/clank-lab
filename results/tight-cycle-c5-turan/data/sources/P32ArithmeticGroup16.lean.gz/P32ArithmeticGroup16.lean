import P32ArithmeticCore
namespace TightCycleC5.Bridge.P32Arithmetic
set_option maxHeartbeats 0
theorem class_group16 : ∀ j : Fin 16, ClassStatement
    ⟨256 + j.val, by have := j.isLt; omega⟩ := by native_decide
#print axioms class_group16
end TightCycleC5.Bridge.P32Arithmetic
