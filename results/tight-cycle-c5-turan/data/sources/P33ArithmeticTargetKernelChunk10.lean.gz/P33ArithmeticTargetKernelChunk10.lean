-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk40 :
    ∀ i : Fin (min 128 (40547 - 128 * 40)),
      targetCountsMatch (classAt (targetKernelClass ⟨40, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk40

theorem target_counts_kernel_chunk41 :
    ∀ i : Fin (min 128 (40547 - 128 * 41)),
      targetCountsMatch (classAt (targetKernelClass ⟨41, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk41

theorem target_counts_kernel_chunk42 :
    ∀ i : Fin (min 128 (40547 - 128 * 42)),
      targetCountsMatch (classAt (targetKernelClass ⟨42, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk42

theorem target_counts_kernel_chunk43 :
    ∀ i : Fin (min 128 (40547 - 128 * 43)),
      targetCountsMatch (classAt (targetKernelClass ⟨43, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk43


end TightCycleC5.Bridge.P33Arithmetic
