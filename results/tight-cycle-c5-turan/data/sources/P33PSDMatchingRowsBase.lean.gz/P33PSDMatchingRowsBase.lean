import P33PSDMatchingCore
import P33PSDMatchingEncoding
import P33FlagRowsBase
namespace TightCycleC5.Bridge.P33PSDMatching
open Finset Matrix ColouredFlags P33Flag

theorem pair_root_query (b : P33Arithmetic.Block) (hr : b.roots = 2)
    (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) :
    rootQuery b K p = pairType (p.symm • decoded K.mask K.colours) := by
  simp only [rootQuery, hr, ↓reduceIte]
  change P33Arithmetic.encoded K.mask K.colours [(p 0).val,(p 1).val] = _
  exact encoded2_eq_root2 K.mask K.colours (p ∘ twoRoot)

theorem pair_left_query (b : P33Arithmetic.Block) (hr : b.roots = 2)
    (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) :
    leftQuery b K p = canonical4 (raw4 (p.symm • decoded K.mask K.colours).edge (p.symm • decoded K.mask K.colours).color pairLeft) := by
  simp only [leftQuery, hr, ↓reduceIte]
  change P33Arithmetic.canonical K.mask K.colours [(p 0).val,(p 1).val] [(p 2).val,(p 3).val] = _
  rw [raw4_smul]
  exact canonical_pair_eq_raw4 K.mask K.colours (p ∘ pairLeft) (p.injective.comp pairLeft_injective)

theorem pair_right_query (b : P33Arithmetic.Block) (hr : b.roots = 2)
    (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) :
    rightQuery b K p = canonical4 (raw4 (p.symm • decoded K.mask K.colours).edge (p.symm • decoded K.mask K.colours).color pairRight) := by
  simp only [rightQuery, hr, ↓reduceIte]
  change P33Arithmetic.canonical K.mask K.colours [(p 0).val,(p 1).val] [(p 4).val,(p 5).val] = _
  rw [raw4_smul]
  exact canonical_pair_eq_raw4 K.mask K.colours (p ∘ pairRight) (p.injective.comp pairRight_injective)

theorem four_root_query (b : P33Arithmetic.Block) (hr : b.roots = 4)
    (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) :
    rootQuery b K p = fourType (p.symm • decoded K.mask K.colours) := by
  simp only [rootQuery, hr, ↓reduceIte, fourType]
  change P33Arithmetic.encoded K.mask K.colours [(p 0).val,(p 1).val,(p 2).val,(p 3).val] = _
  rw [raw4_smul]
  exact encoded4_eq_raw4 K.mask K.colours (p ∘ fourRoot) (p.injective.comp fourRoot_injective)

theorem four_left_query (b : P33Arithmetic.Block) (hr : b.roots = 4)
    (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) :
    leftQuery b K p = (raw5 (p.symm • decoded K.mask K.colours).edge (p.symm • decoded K.mask K.colours).color fourLeft).toNat := by
  simp only [leftQuery, hr, ↓reduceIte]
  change P33Arithmetic.encoded K.mask K.colours [(p 0).val,(p 1).val,(p 2).val,(p 3).val,(p 4).val] = _
  rw [raw5_smul]
  exact encoded5_eq_raw5 K.mask K.colours (p ∘ fourLeft) (p.injective.comp fourLeft_injective)

theorem four_right_query (b : P33Arithmetic.Block) (hr : b.roots = 4)
    (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6)) :
    rightQuery b K p = (raw5 (p.symm • decoded K.mask K.colours).edge (p.symm • decoded K.mask K.colours).color fourRight).toNat := by
  simp only [rightQuery, hr, ↓reduceIte]
  change P33Arithmetic.encoded K.mask K.colours [(p 0).val,(p 1).val,(p 2).val,(p 3).val,(p 5).val] = _
  rw [raw5_smul]
  exact encoded5_eq_raw5 K.mask K.colours (p ∘ fourRight) (p.injective.comp fourRight_injective)

theorem pair_contribution_eq {d : ℕ} (b : P33Arithmetic.Block)
    (hr : b.roots = 2) (q : Matrix (Fin d) (Fin d) ℤ) (scale : ℕ)
    (hentry : ∀ i j : Fin d, P33Arithmetic.blockEntry b i.val j.val = q i j)
    (code : Fin d → ℕ) (hinj : Function.Injective code)
    (hsize : b.flags.size = d) (hcode : ∀ i : Fin d, code i = b.flags[i.val]!)
    (typ : ℕ) (htyp : b.typeCode = typ) (K : P33Arithmetic.Class)
    (p : Equiv.Perm (Fin 6)) (hv : ValidLookups b K p) :
    (sourceContribution b K p : ℝ) / (1000000000 * (scale : ℝ)) =
      pairRow (scaleIntMatrix q scale) code typ (p.symm • decoded K.mask K.colours) := by
  by_cases hroot : rootQuery b K p = b.typeCode
  · obtain ⟨ha,hb⟩ := hv hroot
    have had : P33Arithmetic.lookup b.flags (leftQuery b K p) < d := by simpa [hsize] using ha
    have hbd : P33Arithmetic.lookup b.flags (rightQuery b K p) < d := by simpa [hsize] using hb
    have hg : pairType (p.symm • decoded K.mask K.colours) = typ := by
      rw [← pair_root_query b hr K p, ← htyp]; exact hroot
    simp only [sourceContribution, hroot, ↓reduceIte, pairRow, hg, one_mul]
    rw [← pair_left_query b hr K p, ← pair_right_query b hr K p]
    rw [source_full_trace b q scale hentry code hinj hsize hcode _ _ had hbd]
    push_cast
    exact mul_div_mul_left _ _ (by norm_num : (1000000000 : ℝ) ≠ 0)
  · have hg : pairType (p.symm • decoded K.mask K.colours) ≠ typ := by
      simpa only [← pair_root_query b hr K p, ← htyp] using hroot
    simp only [sourceContribution, hroot, ↓reduceIte, pairRow, hg, zero_mul, Int.cast_zero, zero_div]

theorem four_contribution_eq {d : ℕ} (b : P33Arithmetic.Block)
    (hr : b.roots = 4) (q : Matrix (Fin d) (Fin d) ℤ) (scale : ℕ)
    (hentry : ∀ i j : Fin d, P33Arithmetic.blockEntry b i.val j.val = q i j)
    (code : Fin d → ℕ) (hinj : Function.Injective code)
    (hsize : b.flags.size = d) (hcode : ∀ i : Fin d, code i = b.flags[i.val]!)
    (typ : ℕ) (htyp : b.typeCode = typ) (K : P33Arithmetic.Class)
    (p : Equiv.Perm (Fin 6)) (hv : ValidLookups b K p) :
    (sourceContribution b K p : ℝ) / (1000000000 * (scale : ℝ)) =
      fourRow (scaleIntMatrix q scale) code typ (p.symm • decoded K.mask K.colours) := by
  by_cases hroot : rootQuery b K p = b.typeCode
  · obtain ⟨ha,hb⟩ := hv hroot
    have had : P33Arithmetic.lookup b.flags (leftQuery b K p) < d := by simpa [hsize] using ha
    have hbd : P33Arithmetic.lookup b.flags (rightQuery b K p) < d := by simpa [hsize] using hb
    have hg : fourType (p.symm • decoded K.mask K.colours) = typ := by
      rw [← four_root_query b hr K p, ← htyp]; exact hroot
    simp only [sourceContribution, hroot, ↓reduceIte, fourRow, hg, one_mul]
    rw [← four_left_query b hr K p, ← four_right_query b hr K p]
    rw [source_full_trace b q scale hentry code hinj hsize hcode _ _ had hbd]
    push_cast
    exact mul_div_mul_left _ _ (by norm_num : (1000000000 : ℝ) ≠ 0)
  · have hg : fourType (p.symm • decoded K.mask K.colours) ≠ typ := by
      simpa only [← four_root_query b hr K p, ← htyp] using hroot
    simp only [sourceContribution, hroot, ↓reduceIte, fourRow, hg, zero_mul, Int.cast_zero, zero_div]

#print axioms pair_root_query
#print axioms pair_left_query
#print axioms pair_right_query
#print axioms four_root_query
#print axioms four_left_query
#print axioms four_right_query
#print axioms pair_contribution_eq
#print axioms four_contribution_eq
end TightCycleC5.Bridge.P33PSDMatching
