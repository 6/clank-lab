import P33ArithmeticReplayShardIndex
import P33ArithmeticCheckpointRanges
import P33ArithmeticCheckpointShard0
import P33ArithmeticCheckpointShard1
import P33ArithmeticCheckpointShard2
import P33ArithmeticCheckpointShard3
import P33ArithmeticCheckpointShard4
import P33ArithmeticCheckpointShard5
import P33ArithmeticCheckpointShard6
import P33ArithmeticCheckpointShard7

/-! Exact original class domain [0, 512), assembled
from bounded native checks using kernel range concatenation. -/
namespace TightCycleC5.Bridge.P33Arithmetic
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem checkpoint_first_range :
    ∀ j : Fin (replayShardLength 0),
      classCheck (classAt (replayShardIndex 0 j)) = true := by
  have checked : rangeCheck 0 512 = true :=
    (rangeCheck_add 0 64 448 checkpoint_shard0 (rangeCheck_add 64 64 384 checkpoint_shard1 (rangeCheck_add 128 64 320 checkpoint_shard2 (rangeCheck_add 192 64 256 checkpoint_shard3 (rangeCheck_add 256 64 192 checkpoint_shard4 (rangeCheck_add 320 64 128 checkpoint_shard5 (rangeCheck_add 384 64 64 checkpoint_shard6 checkpoint_shard7)))))))
  intro j
  apply rangeCheck_sound 0 512 checked
  · simp only [replayShardIndex]
    omega
  · have hj := j.isLt
    norm_num [replayShardLength] at hj
    simp only [replayShardIndex]
    omega

#print axioms checkpoint_first_range
end TightCycleC5.Bridge.P33Arithmetic
