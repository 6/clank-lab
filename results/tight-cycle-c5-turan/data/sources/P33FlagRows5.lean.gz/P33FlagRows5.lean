import P33FlagRowsBase
import P33PSDGroup5
import P33FlagFacts5

namespace TightCycleC5.Bridge.P33Flag
open Finset Matrix

noncomputable def row5 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix5 basis5 type5 G

theorem row5_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row5 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix5)
        (fun root a => flagLookup basis5 (fourKey H S root a)) (fourIndicator type5 H S) :=
  four_row_eq P33PSD.matrix5 basis5 basis5_injective type5 H S

theorem row5_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound5 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row5 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd5 P33PSD.normalized_nonneg5
    P33PSD.normalized_diagonal5 hn basis5 basis5_injective type5 H S

#print axioms row5_eq_optional
#print axioms row5_lower

noncomputable def row11 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix11 basis11 type11 G

theorem row11_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row11 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix11)
        (fun root a => flagLookup basis11 (fourKey H S root a)) (fourIndicator type11 H S) :=
  four_row_eq P33PSD.matrix11 basis11 basis11_injective type11 H S

theorem row11_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound11 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row11 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd11 P33PSD.normalized_nonneg11
    P33PSD.normalized_diagonal11 hn basis11 basis11_injective type11 H S

#print axioms row11_eq_optional
#print axioms row11_lower

noncomputable def row17 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix17 basis17 type17 G

theorem row17_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row17 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix17)
        (fun root a => flagLookup basis17 (fourKey H S root a)) (fourIndicator type17 H S) :=
  four_row_eq P33PSD.matrix17 basis17 basis17_injective type17 H S

theorem row17_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound17 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row17 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd17 P33PSD.normalized_nonneg17
    P33PSD.normalized_diagonal17 hn basis17 basis17_injective type17 H S

#print axioms row17_eq_optional
#print axioms row17_lower

noncomputable def row23 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix23 basis23 type23 G

theorem row23_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row23 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix23)
        (fun root a => flagLookup basis23 (fourKey H S root a)) (fourIndicator type23 H S) :=
  four_row_eq P33PSD.matrix23 basis23 basis23_injective type23 H S

theorem row23_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound23 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row23 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd23 P33PSD.normalized_nonneg23
    P33PSD.normalized_diagonal23 hn basis23 basis23_injective type23 H S

#print axioms row23_eq_optional
#print axioms row23_lower

noncomputable def row29 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix29 basis29 type29 G

theorem row29_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row29 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix29)
        (fun root a => flagLookup basis29 (fourKey H S root a)) (fourIndicator type29 H S) :=
  four_row_eq P33PSD.matrix29 basis29 basis29_injective type29 H S

theorem row29_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound29 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row29 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd29 P33PSD.normalized_nonneg29
    P33PSD.normalized_diagonal29 hn basis29 basis29_injective type29 H S

#print axioms row29_eq_optional
#print axioms row29_lower

noncomputable def row35 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix35 basis35 type35 G

theorem row35_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row35 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix35)
        (fun root a => flagLookup basis35 (fourKey H S root a)) (fourIndicator type35 H S) :=
  four_row_eq P33PSD.matrix35 basis35 basis35_injective type35 H S

theorem row35_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound35 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row35 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd35 P33PSD.normalized_nonneg35
    P33PSD.normalized_diagonal35 hn basis35 basis35_injective type35 H S

#print axioms row35_eq_optional
#print axioms row35_lower

end TightCycleC5.Bridge.P33Flag
