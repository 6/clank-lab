import P33FlagRowsBase
import P33PSDGroup0
import P33FlagFacts0

namespace TightCycleC5.Bridge.P33Flag
open Finset Matrix

noncomputable def row0 (G : LabelledStructure 6) : ℝ :=
  pairRow P33PSD.matrix0 basis0 type0 G

theorem row0_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row0 (sampleStructure σ H S)) =
      psdTwoRootSixRow (zeroExtend P33PSD.matrix0)
        (fun root a => flagLookup basis0 (pairKey H S root a)) (pairIndicator type0 S) :=
  pair_row_eq P33PSD.matrix0 basis0 basis0_injective type0 H S

theorem row0_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -((4 * (n : ℝ) - 14) * P33PSD.bound0 / (((n : ℝ) - 4) * ((n : ℝ) - 5))) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row0 (sampleStructure σ H S)) :=
  pair_row_lower P33PSD.normalized_psd0 P33PSD.normalized_nonneg0
    P33PSD.normalized_diagonal0 hn basis0 basis0_injective type0 H S

#print axioms row0_eq_optional
#print axioms row0_lower

noncomputable def row6 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix6 basis6 type6 G

theorem row6_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row6 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix6)
        (fun root a => flagLookup basis6 (fourKey H S root a)) (fourIndicator type6 H S) :=
  four_row_eq P33PSD.matrix6 basis6 basis6_injective type6 H S

theorem row6_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound6 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row6 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd6 P33PSD.normalized_nonneg6
    P33PSD.normalized_diagonal6 hn basis6 basis6_injective type6 H S

#print axioms row6_eq_optional
#print axioms row6_lower

noncomputable def row12 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix12 basis12 type12 G

theorem row12_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row12 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix12)
        (fun root a => flagLookup basis12 (fourKey H S root a)) (fourIndicator type12 H S) :=
  four_row_eq P33PSD.matrix12 basis12 basis12_injective type12 H S

theorem row12_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound12 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row12 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd12 P33PSD.normalized_nonneg12
    P33PSD.normalized_diagonal12 hn basis12 basis12_injective type12 H S

#print axioms row12_eq_optional
#print axioms row12_lower

noncomputable def row18 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix18 basis18 type18 G

theorem row18_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row18 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix18)
        (fun root a => flagLookup basis18 (fourKey H S root a)) (fourIndicator type18 H S) :=
  four_row_eq P33PSD.matrix18 basis18 basis18_injective type18 H S

theorem row18_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound18 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row18 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd18 P33PSD.normalized_nonneg18
    P33PSD.normalized_diagonal18 hn basis18 basis18_injective type18 H S

#print axioms row18_eq_optional
#print axioms row18_lower

noncomputable def row24 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix24 basis24 type24 G

theorem row24_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row24 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix24)
        (fun root a => flagLookup basis24 (fourKey H S root a)) (fourIndicator type24 H S) :=
  four_row_eq P33PSD.matrix24 basis24 basis24_injective type24 H S

theorem row24_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound24 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row24 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd24 P33PSD.normalized_nonneg24
    P33PSD.normalized_diagonal24 hn basis24 basis24_injective type24 H S

#print axioms row24_eq_optional
#print axioms row24_lower

noncomputable def row30 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix30 basis30 type30 G

theorem row30_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row30 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix30)
        (fun root a => flagLookup basis30 (fourKey H S root a)) (fourIndicator type30 H S) :=
  four_row_eq P33PSD.matrix30 basis30 basis30_injective type30 H S

theorem row30_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound30 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row30 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd30 P33PSD.normalized_nonneg30
    P33PSD.normalized_diagonal30 hn basis30 basis30_injective type30 H S

#print axioms row30_eq_optional
#print axioms row30_lower

noncomputable def row36 (G : LabelledStructure 6) : ℝ :=
  fourRow P33PSD.matrix36 basis36 type36 G

theorem row36_eq_optional {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n)) :
    (fun σ : Fin 6 ↪ Fin n => row36 (sampleStructure σ H S)) =
      psdFourRootSixRow (zeroExtend P33PSD.matrix36)
        (fun root a => flagLookup basis36 (fourKey H S root a)) (fourIndicator type36 H S) :=
  four_row_eq P33PSD.matrix36 basis36 basis36_injective type36 H S

theorem row36_lower {n : ℕ} (H : Finset (Finset (Fin n))) (S : Finset (Fin n))
    (hn : 12 ≤ n) : -P33PSD.bound36 / ((n : ℝ) - 5) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => row36 (sampleStructure σ H S)) :=
  four_row_lower P33PSD.normalized_psd36 P33PSD.normalized_nonneg36
    P33PSD.normalized_diagonal36 hn basis36 basis36_injective type36 H S

#print axioms row36_eq_optional
#print axioms row36_lower

end TightCycleC5.Bridge.P33Flag
