import KernelRowIndex
import KernelWitness15

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_15_64 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 64 * 256 + i.val))
      kernelWitness15Row64[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_64

theorem kernelBlock_15_65 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 65 * 256 + i.val))
      kernelWitness15Row65[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_65

theorem kernelBlock_15_66 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 66 * 256 + i.val))
      kernelWitness15Row66[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_66

theorem kernelBlock_15_67 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 67 * 256 + i.val))
      kernelWitness15Row67[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_67

theorem kernelBlock_15_68 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 68 * 256 + i.val))
      kernelWitness15Row68[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_68

theorem kernelBlock_15_69 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 69 * 256 + i.val))
      kernelWitness15Row69[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_69

theorem kernelBlock_15_70 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 70 * 256 + i.val))
      kernelWitness15Row70[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_70

theorem kernelBlock_15_71 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 71 * 256 + i.val))
      kernelWitness15Row71[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_71

theorem kernelBlock_15_72 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 72 * 256 + i.val))
      kernelWitness15Row72[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_72

theorem kernelBlock_15_73 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 73 * 256 + i.val))
      kernelWitness15Row73[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_73

theorem kernelBlock_15_74 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 74 * 256 + i.val))
      kernelWitness15Row74[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_74

theorem kernelBlock_15_75 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 75 * 256 + i.val))
      kernelWitness15Row75[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_75

theorem kernelBlock_15_76 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 76 * 256 + i.val))
      kernelWitness15Row76[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_76

theorem kernelBlock_15_77 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 77 * 256 + i.val))
      kernelWitness15Row77[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_77

theorem kernelBlock_15_78 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 78 * 256 + i.val))
      kernelWitness15Row78[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_78

theorem kernelBlock_15_79 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 79 * 256 + i.val))
      kernelWitness15Row79[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_79

theorem kernelBlock_15_80 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 80 * 256 + i.val))
      kernelWitness15Row80[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_80

theorem kernelBlock_15_81 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 81 * 256 + i.val))
      kernelWitness15Row81[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_81

theorem kernelBlock_15_82 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 82 * 256 + i.val))
      kernelWitness15Row82[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_82

theorem kernelBlock_15_83 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 83 * 256 + i.val))
      kernelWitness15Row83[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_83

theorem kernelBlock_15_84 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 84 * 256 + i.val))
      kernelWitness15Row84[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_84

theorem kernelBlock_15_85 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 85 * 256 + i.val))
      kernelWitness15Row85[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_85

theorem kernelBlock_15_86 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 86 * 256 + i.val))
      kernelWitness15Row86[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_86

theorem kernelBlock_15_87 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 87 * 256 + i.val))
      kernelWitness15Row87[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_87

theorem kernelBlock_15_88 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 88 * 256 + i.val))
      kernelWitness15Row88[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_88

theorem kernelBlock_15_89 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 89 * 256 + i.val))
      kernelWitness15Row89[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_89

theorem kernelBlock_15_90 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 90 * 256 + i.val))
      kernelWitness15Row90[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_90

theorem kernelBlock_15_91 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 91 * 256 + i.val))
      kernelWitness15Row91[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_91

theorem kernelBlock_15_92 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 92 * 256 + i.val))
      kernelWitness15Row92[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_92

theorem kernelBlock_15_93 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 93 * 256 + i.val))
      kernelWitness15Row93[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_93

theorem kernelBlock_15_94 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 94 * 256 + i.val))
      kernelWitness15Row94[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_94

theorem kernelBlock_15_95 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (15 * 32768 + 95 * 256 + i.val))
      kernelWitness15Row95[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_15_95

end TightCycleC5.Bridge.Cover
