import P33PSDData
import P33PSDSeed2
import P33PSDSeed14

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33PSD

theorem terms2_psd : ∀ k, (intMatrixReal (terms2 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact seed2_psd
  · exact int_outer_posSemidef vector2x1
  · exact int_outer_posSemidef vector2x2
  · exact int_outer_posSemidef vector2x3
  · exact int_outer_posSemidef vector2x4
theorem terms2_diagonal : ∀ k i, terms2 k i i ≤ (diagBounds2 k : ℤ) := by
  decide +kernel
theorem psd2 : (intMatrixReal q2).PosSemidef :=
  integer_sos_posSemidef weights2 terms2 terms2_psd
theorem diagonal2 : ∀ i, q2 i i ≤ (m2 : ℤ) :=
  integer_sos_diagonal weights2 diagBounds2 terms2 terms2_diagonal
theorem normalized_psd2 : matrix2.PosSemidef :=
  scale_int_posSemidef q2 scale psd2
theorem normalized_diagonal2 : ∀ i, matrix2 i i ≤ bound2 :=
  scale_int_diagonal q2 scale m2 diagonal2
theorem normalized_nonneg2 : 0 ≤ bound2 :=
  scale_int_bound_nonneg scale m2 (Nat.cast_nonneg _)

#print axioms psd2
#print axioms diagonal2
#print axioms normalized_psd2
#print axioms normalized_diagonal2
#print axioms normalized_nonneg2
#print axioms terms2_psd
#print axioms terms2_diagonal

theorem terms8_psd : ∀ k, (intMatrixReal (terms8 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector8x0
  · exact int_outer_posSemidef vector8x1
  · exact int_outer_posSemidef vector8x2
  · exact int_outer_posSemidef vector8x3
  · exact int_outer_posSemidef vector8x4
  · exact int_outer_posSemidef vector8x5
  · exact int_outer_posSemidef vector8x6
  · exact int_outer_posSemidef vector8x7
theorem terms8_diagonal : ∀ k i, terms8 k i i ≤ (diagBounds8 k : ℤ) := by
  decide +kernel
theorem psd8 : (intMatrixReal q8).PosSemidef :=
  integer_sos_posSemidef weights8 terms8 terms8_psd
theorem diagonal8 : ∀ i, q8 i i ≤ (m8 : ℤ) :=
  integer_sos_diagonal weights8 diagBounds8 terms8 terms8_diagonal
theorem normalized_psd8 : matrix8.PosSemidef :=
  scale_int_posSemidef q8 scale psd8
theorem normalized_diagonal8 : ∀ i, matrix8 i i ≤ bound8 :=
  scale_int_diagonal q8 scale m8 diagonal8
theorem normalized_nonneg8 : 0 ≤ bound8 :=
  scale_int_bound_nonneg scale m8 (Nat.cast_nonneg _)

#print axioms psd8
#print axioms diagonal8
#print axioms normalized_psd8
#print axioms normalized_diagonal8
#print axioms normalized_nonneg8
#print axioms terms8_psd
#print axioms terms8_diagonal

theorem terms14_psd : ∀ k, (intMatrixReal (terms14 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact seed14_psd
  · exact int_outer_posSemidef vector14x1
  · exact int_outer_posSemidef vector14x2
  · exact int_outer_posSemidef vector14x3
  · exact int_outer_posSemidef vector14x4
  · exact int_outer_posSemidef vector14x5
  · exact int_outer_posSemidef vector14x6
  · exact int_outer_posSemidef vector14x7
  · exact int_outer_posSemidef vector14x8
  · exact int_outer_posSemidef vector14x9
  · exact int_outer_posSemidef vector14x10
theorem terms14_diagonal : ∀ k i, terms14 k i i ≤ (diagBounds14 k : ℤ) := by
  decide +kernel
theorem psd14 : (intMatrixReal q14).PosSemidef :=
  integer_sos_posSemidef weights14 terms14 terms14_psd
theorem diagonal14 : ∀ i, q14 i i ≤ (m14 : ℤ) :=
  integer_sos_diagonal weights14 diagBounds14 terms14 terms14_diagonal
theorem normalized_psd14 : matrix14.PosSemidef :=
  scale_int_posSemidef q14 scale psd14
theorem normalized_diagonal14 : ∀ i, matrix14 i i ≤ bound14 :=
  scale_int_diagonal q14 scale m14 diagonal14
theorem normalized_nonneg14 : 0 ≤ bound14 :=
  scale_int_bound_nonneg scale m14 (Nat.cast_nonneg _)

#print axioms psd14
#print axioms diagonal14
#print axioms normalized_psd14
#print axioms normalized_diagonal14
#print axioms normalized_nonneg14
#print axioms terms14_psd
#print axioms terms14_diagonal

theorem terms20_psd : ∀ k, (intMatrixReal (terms20 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector20x0
  · exact int_outer_posSemidef vector20x1
  · exact int_outer_posSemidef vector20x2
  · exact int_outer_posSemidef vector20x3
  · exact int_outer_posSemidef vector20x4
  · exact int_outer_posSemidef vector20x5
  · exact int_outer_posSemidef vector20x6
  · exact int_outer_posSemidef vector20x7
  · exact int_outer_posSemidef vector20x8
  · exact int_outer_posSemidef vector20x9
  · exact int_outer_posSemidef vector20x10
  · exact int_outer_posSemidef vector20x11
  · exact int_outer_posSemidef vector20x12
  · exact int_outer_posSemidef vector20x13
  · exact int_outer_posSemidef vector20x14
  · exact int_outer_posSemidef vector20x15
  · exact int_outer_posSemidef vector20x16
  · exact int_outer_posSemidef vector20x17
theorem terms20_diagonal : ∀ k i, terms20 k i i ≤ (diagBounds20 k : ℤ) := by
  decide +kernel
theorem psd20 : (intMatrixReal q20).PosSemidef :=
  integer_sos_posSemidef weights20 terms20 terms20_psd
theorem diagonal20 : ∀ i, q20 i i ≤ (m20 : ℤ) :=
  integer_sos_diagonal weights20 diagBounds20 terms20 terms20_diagonal
theorem normalized_psd20 : matrix20.PosSemidef :=
  scale_int_posSemidef q20 scale psd20
theorem normalized_diagonal20 : ∀ i, matrix20 i i ≤ bound20 :=
  scale_int_diagonal q20 scale m20 diagonal20
theorem normalized_nonneg20 : 0 ≤ bound20 :=
  scale_int_bound_nonneg scale m20 (Nat.cast_nonneg _)

#print axioms psd20
#print axioms diagonal20
#print axioms normalized_psd20
#print axioms normalized_diagonal20
#print axioms normalized_nonneg20
#print axioms terms20_psd
#print axioms terms20_diagonal

theorem terms26_psd : ∀ k, (intMatrixReal (terms26 k)).PosSemidef := by
  intro k
  fin_cases k
  · exact int_outer_posSemidef vector26x0
  · exact int_outer_posSemidef vector26x1
  · exact int_outer_posSemidef vector26x2
  · exact int_outer_posSemidef vector26x3
  · exact int_outer_posSemidef vector26x4
  · exact int_outer_posSemidef vector26x5
  · exact int_outer_posSemidef vector26x6
  · exact int_outer_posSemidef vector26x7
theorem terms26_diagonal : ∀ k i, terms26 k i i ≤ (diagBounds26 k : ℤ) := by
  decide +kernel
theorem psd26 : (intMatrixReal q26).PosSemidef :=
  integer_sos_posSemidef weights26 terms26 terms26_psd
theorem diagonal26 : ∀ i, q26 i i ≤ (m26 : ℤ) :=
  integer_sos_diagonal weights26 diagBounds26 terms26 terms26_diagonal
theorem normalized_psd26 : matrix26.PosSemidef :=
  scale_int_posSemidef q26 scale psd26
theorem normalized_diagonal26 : ∀ i, matrix26 i i ≤ bound26 :=
  scale_int_diagonal q26 scale m26 diagonal26
theorem normalized_nonneg26 : 0 ≤ bound26 :=
  scale_int_bound_nonneg scale m26 (Nat.cast_nonneg _)

#print axioms psd26
#print axioms diagonal26
#print axioms normalized_psd26
#print axioms normalized_diagonal26
#print axioms normalized_nonneg26
#print axioms terms26_psd
#print axioms terms26_diagonal

theorem terms32_psd : ∀ k, (intMatrixReal (terms32 k)).PosSemidef := by
  intro k
  fin_cases k
theorem terms32_diagonal : ∀ k i, terms32 k i i ≤ (diagBounds32 k : ℤ) := by
  decide +kernel
theorem psd32 : (intMatrixReal q32).PosSemidef :=
  integer_sos_posSemidef weights32 terms32 terms32_psd
theorem diagonal32 : ∀ i, q32 i i ≤ (m32 : ℤ) :=
  integer_sos_diagonal weights32 diagBounds32 terms32 terms32_diagonal
theorem normalized_psd32 : matrix32.PosSemidef :=
  scale_int_posSemidef q32 scale psd32
theorem normalized_diagonal32 : ∀ i, matrix32 i i ≤ bound32 :=
  scale_int_diagonal q32 scale m32 diagonal32
theorem normalized_nonneg32 : 0 ≤ bound32 :=
  scale_int_bound_nonneg scale m32 (Nat.cast_nonneg _)

#print axioms psd32
#print axioms diagonal32
#print axioms normalized_psd32
#print axioms normalized_diagonal32
#print axioms normalized_nonneg32
#print axioms terms32_psd
#print axioms terms32_diagonal

end TightCycleC5.Bridge.P33PSD
