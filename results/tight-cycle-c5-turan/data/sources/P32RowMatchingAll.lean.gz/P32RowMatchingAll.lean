import P32RowMatchingMeans
import P32RowMatchingSelector
import P32ArithmeticAll

namespace TightCycleC5.Bridge.P32RowMatching

/-- All stored classes discharge lookup validity internally. The selector and all contributions are expressed as actual literal rows. -/
theorem class_margin_bound_rows (i : Fin 835) :
    (1 : ℝ)/10000 +
      uniformMean (fun p : Equiv.Perm (Fin 6) => clRows (p • P32Arithmetic.classStructure i)) +
      uniformMean (fun p : Equiv.Perm (Fin 6) =>
        indicatorBookRows (p • P32Arithmetic.classStructure i) +
          weightedBookRows (p • P32Arithmetic.classStructure i)) +
      uniformMean (fun p : Equiv.Perm (Fin 6) => densityRows (p • P32Arithmetic.classStructure i)) +
      uniformMean (fun p : Equiv.Perm (Fin 6) => psdRows (p • P32Arithmetic.classStructure i)) ≤
      uniformMean (fun p : Equiv.Perm (Fin 6) => P32Selector.margin (p • P32Arithmetic.classStructure i)) := by
  simpa only [selector_margin_eq] using
    class_margin_bound_rows_of_check i (P32Arithmetic.all_classes i)

/-- The same literal-row class inequality at the accepted cover representative. -/
theorem cover_class_margin_bound_rows (i : Fin 835) :
    let G := MaskEncoding.decodeStructure (Cover.representative i) 0
    (1 : ℝ)/10000 +
      uniformMean (fun p : Equiv.Perm (Fin 6) => clRows (p • G)) +
      uniformMean (fun p : Equiv.Perm (Fin 6) => indicatorBookRows (p • G) + weightedBookRows (p • G)) +
      uniformMean (fun p : Equiv.Perm (Fin 6) => densityRows (p • G)) +
      uniformMean (fun p : Equiv.Perm (Fin 6) => psdRows (p • G)) ≤
      uniformMean (fun p : Equiv.Perm (Fin 6) => P32Selector.margin (p • G)) := by
  simpa only [P32Arithmetic.classStructure_eq_representative] using class_margin_bound_rows i

/-- The literal nuisance aggregate, in the parent's graph-row order. -/
noncomputable def literalNuisance (G : LabelledStructure 6) : ℝ :=
  clRows G + indicatorBookRows G + weightedBookRows G + densityRows G + psdRows G

/-- One-mean form of the finite class inequality; no lookup or arithmetic premise. -/
theorem class_margin_bound_literal (i : Fin 835) :
    (1 : ℝ)/10000 +
      uniformMean (fun p : Equiv.Perm (Fin 6) =>
        literalNuisance (p • P32Arithmetic.classStructure i)) ≤
      uniformMean (fun p : Equiv.Perm (Fin 6) =>
        P32Selector.margin (p • P32Arithmetic.classStructure i)) := by
  have h := class_margin_bound_rows i
  simpa only [literalNuisance, uniformMean, Finset.sum_add_distrib,
    add_div, add_assoc] using h

/-- Cover representative form. It is definitionally the requested
`Cover.p32ClassRep i` form once that sampling module is imported. -/
theorem cover_class_margin_bound_literal (i : Fin 835) :
    let G := MaskEncoding.decodeStructure (Cover.representative i) 0
    (1 : ℝ)/10000 +
      uniformMean (fun p : Equiv.Perm (Fin 6) => literalNuisance (p • G)) ≤
      uniformMean (fun p : Equiv.Perm (Fin 6) => P32Selector.margin (p • G)) := by
  simpa only [P32Arithmetic.classStructure_eq_representative] using
    class_margin_bound_literal i

#print axioms class_margin_bound_literal
#print axioms cover_class_margin_bound_literal

#print axioms class_margin_bound_rows
#print axioms cover_class_margin_bound_rows
end TightCycleC5.Bridge.P32RowMatching
