import P32RowMatchingCL

namespace TightCycleC5.Bridge.P32RowMatching
open Finset
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000
set_option backward.isDefEq.respectTransparency false

theorem book_root_feature (G : LabelledStructure 6) :
    PairBookCertificate.rootPattern (fun a b c => G.edge {a,b,c}) 0 1 2 3 =
      (P32Arithmetic.features G).bookRoot.val := by
  change 8 * (G.edge {0,1,2}).toNat + 4 * (G.edge {0,1,3}).toNat +
      2 * (G.edge {0,2,3}).toNat + (G.edge {1,2,3}).toNat =
    8 * (G.edge {0,1,2}).toNat + (4 * (G.edge {0,1,3}).toNat +
      2 * (G.edge {0,2,3}).toNat + (G.edge {1,2,3}).toNat)
  omega

theorem book_pattern_feature (G : LabelledStructure 6) (z : Fin 6) :
    PairBookCertificate.pattern (fun a b c => G.edge {a,b,c}) 0 1 2 3 z =
      P32Arithmetic.pattern5 (fun a b c => G.edge {a,b,c}) z := rfl

theorem book_row_features (G : LabelledStructure 6) (d : PairBookCertificate.Descriptor) :
    PairBookCertificate.row d G =
      (if (P32Arithmetic.features G).bookRoot = d.rootType then 1 else 0) *
      d.weight (P32Arithmetic.features G).bookA *
      d.weight (P32Arithmetic.features G).bookB *
      ((P32Arithmetic.features G).cl4 : ℝ) := by
  unfold PairBookCertificate.row PairBookCertificate.evaluate
  rw [book_root_feature]
  simp only [← Fin.ext_iff, book_pattern_feature]
  rw [cl_kernel_features G true]
  rfl

theorem weighted_book_row_features (G : LabelledStructure 6) (i : Fin 25) :
    PairBookCertificate.row (P32Book.descriptor i) G =
      (if (P32Arithmetic.cuts.get i).root = (P32Arithmetic.features G).bookRoot then
        (((P32Arithmetic.cuts.get i).beta.get (P32Arithmetic.features G).bookA : ℝ) /
          (P32Arithmetic.probScale : ℝ)) *
        (((P32Arithmetic.cuts.get i).beta.get (P32Arithmetic.features G).bookB : ℝ) /
          (P32Arithmetic.probScale : ℝ)) * ((P32Arithmetic.features G).cl4 : ℝ)
      else 0) := by
  rw [book_row_features]
  simp only [P32Book.descriptor, P32Book.normalizedWeight, ← cut_roots_eq,
    ← cut_weights_eq, ← probability_scale_eq]
  split_ifs <;> simp_all [eq_comm]

theorem indicator_book_row_features (G : LabelledStructure 6) (k : Fin 16) (r : Fin 529) :
    PairBookCertificate.row (CertificateDescriptors.p32BookDescriptor
      (CertificateDescriptors.bookFlatIndex k r)) G =
      if (P32Arithmetic.features G).bookRoot = k ∧
          (P32Arithmetic.bookRestriction r).testBit (P32Arithmetic.features G).bookA.val = true ∧
          (P32Arithmetic.bookRestriction r).testBit (P32Arithmetic.features G).bookB.val = true then
        ((P32Arithmetic.features G).cl4 : ℝ) else 0 := by
  rw [book_row_features]
  simp only [CertificateDescriptors.p32BookDescriptor,
    PairBookCertificate.indicatorDescriptor, CertificateDescriptors.book_flat_root,
    CertificateDescriptors.book_flat_restriction, CertificateDescriptors.bookMaskBits,
    ← book_restrictions_eq, BitVec.getLsbD_ofNat]
  have ha := (P32Arithmetic.features G).bookA.isLt
  have hb := (P32Arithmetic.features G).bookB.isLt
  split_ifs <;> simp_all

#print axioms book_root_feature
#print axioms book_pattern_feature
#print axioms book_row_features
#print axioms weighted_book_row_features
#print axioms indicator_book_row_features
end TightCycleC5.Bridge.P32RowMatching
