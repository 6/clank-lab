import P33ArithmeticFinite
import ClassSampling

namespace TightCycleC5.Bridge.P33RowMatching
open Finset

/-- Signed sparse coefficients are normalized exactly once. Zero scales are
also algebraically allowed here; positivity is a separate source-data fact. -/
theorem sparse_normalized_eq {n : Nat} (support : Array (Fin n × Int))
    (row : Fin n → Int) (actual : Fin n → ℝ) (scale : ℝ)
    (hrow : ∀ i, (row i : ℝ) / 1000000000 = actual i) :
    (P33Arithmetic.sparseValue support row : ℝ) / 1000000000 / scale =
      ∑ i : Fin n, (P33Arithmetic.sparseCoefficient support i : ℝ) / scale * actual i := by
  rw [P33Arithmetic.sparseValue_eq_full]
  simp only [Int.cast_sum, Int.cast_mul, Finset.sum_div]
  apply Finset.sum_congr rfl
  intro i _
  rw [← hrow i]
  ring

/-- Inversion changes the row orientation pointwise but preserves its full mean. -/
theorem mean_inverse {Γ : Type*} [Group Γ] [Fintype Γ] (f : Γ → ℝ) :
    uniformMean (fun p => f p⁻¹) = uniformMean f := by
  exact uniformMean_equiv (Equiv.inv Γ) f

#print axioms sparse_normalized_eq
#print axioms mean_inverse
end TightCycleC5.Bridge.P33RowMatching
