import KernelShard21Blocks0
import KernelShard21Blocks1
import KernelShard21Blocks2
import KernelShard21Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard21 : kernelShardCheck 21 kernelWitness21 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (21 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness21 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_21_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard21
end TightCycleC5.Bridge.Cover
