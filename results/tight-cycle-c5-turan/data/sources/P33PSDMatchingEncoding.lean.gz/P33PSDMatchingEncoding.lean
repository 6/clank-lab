import P33ArithmeticEncoding
import ColouredFlags
import SixSampling
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000
namespace TightCycleC5.Bridge.P33PSDMatching
open ColouredFlags

theorem encoded2_numeric (m c a b : ℕ) :
    P33Arithmetic.encoded m c [a,b] =
      1 * P33Arithmetic.colour c a +
      2 * P33Arithmetic.colour c b := by
  norm_num [P33Arithmetic.encoded, P33Arithmetic.triples, List.range_succ, Nat.shiftLeft_eq]
  ring

theorem encoded4_numeric (m c a b d e : ℕ) :
    P33Arithmetic.encoded m c [a,b,d,e] =
      1 * P33Arithmetic.colour c a +
      2 * P33Arithmetic.colour c b +
      4 * P33Arithmetic.colour c d +
      8 * P33Arithmetic.colour c e +
      16 * P33Arithmetic.edge m a b d +
      32 * P33Arithmetic.edge m a b e +
      64 * P33Arithmetic.edge m a d e +
      128 * P33Arithmetic.edge m b d e := by
  norm_num [P33Arithmetic.encoded, P33Arithmetic.triples, List.range_succ, Nat.shiftLeft_eq]
  ring

theorem encoded5_numeric (m c a b d e f : ℕ) :
    P33Arithmetic.encoded m c [a,b,d,e,f] =
      1 * P33Arithmetic.colour c a +
      2 * P33Arithmetic.colour c b +
      4 * P33Arithmetic.colour c d +
      8 * P33Arithmetic.colour c e +
      16 * P33Arithmetic.colour c f +
      32 * P33Arithmetic.edge m a b d +
      64 * P33Arithmetic.edge m a b e +
      128 * P33Arithmetic.edge m a b f +
      256 * P33Arithmetic.edge m a d e +
      512 * P33Arithmetic.edge m a d f +
      1024 * P33Arithmetic.edge m a e f +
      2048 * P33Arithmetic.edge m b d e +
      4096 * P33Arithmetic.edge m b d f +
      8192 * P33Arithmetic.edge m b e f +
      16384 * P33Arithmetic.edge m d e f := by
  norm_num [P33Arithmetic.encoded, P33Arithmetic.triples, List.range_succ, Nat.shiftLeft_eq]
  ring

theorem canonical_pair (m c x u a b : ℕ) :
    P33Arithmetic.canonical m c [x,u] [a,b] =
      min (P33Arithmetic.encoded m c [x,u,a,b]) (P33Arithmetic.encoded m c [x,u,b,a]) := by
  have hp : ([a,b] : List ℕ).permutations = [[a,b],[b,a]] := by
    simp [List.permutations, List.permutationsAux_cons, List.permutationsAux2]
  simp [P33Arithmetic.canonical, hp]

theorem raw4_smul (p : Equiv.Perm (Fin 6)) (G : LabelledStructure 6) (v : Fin 4 → Fin 6) :
    raw4 (p • G).edge (p • G).color v = raw4 G.edge G.color (p.symm ∘ v) := by
  apply congrArg pack
  funext i
  fin_cases i <;> simp [bits4, HSMul.hSMul, SMul.smul]

theorem raw5_smul (p : Equiv.Perm (Fin 6)) (G : LabelledStructure 6) (v : Fin 5 → Fin 6) :
    raw5 (p • G).edge (p • G).color v = raw5 G.edge G.color (p.symm ∘ v) := by
  apply congrArg pack
  funext i
  fin_cases i <;> simp [bits5, HSMul.hSMul, SMul.smul]

def decoded (m c : ℕ) : LabelledStructure 6 :=
  MaskEncoding.decodeStructure (BitVec.ofNat 20 m) (BitVec.ofNat 6 c)

theorem decoded_colour (m c : ℕ) (v : Fin 6) :
    P33Arithmetic.colour c v.val = ((decoded m c).color v).toNat :=
  P33Arithmetic.colour_eq_decoded m c v

theorem decoded_edge (m c : ℕ) (a b d : Fin 6)
    (hab : a ≠ b) (had : a ≠ d) (hbd : b ≠ d) :
    P33Arithmetic.edge m a.val b.val d.val = ((decoded m c).edge {a,b,d}).toNat :=
  P33Arithmetic.edge_eq_decoded m c a b d hab had hbd

theorem raw5_nested {V : Type*} [DecidableEq V] (E : Finset V → Bool)
    (C : V → Bool) (v : Fin 5 → V) :
    (raw5 E C v).toNat = (C (v 0)).toNat + 2 * ((C (v 1)).toNat + 2 * ((C (v 2)).toNat + 2 * ((C (v 3)).toNat + 2 * ((C (v 4)).toNat + 2 * ((E {v 0,v 1,v 2}).toNat + 2 * ((E {v 0,v 1,v 3}).toNat + 2 * ((E {v 0,v 1,v 4}).toNat + 2 * ((E {v 0,v 2,v 3}).toNat + 2 * ((E {v 0,v 2,v 4}).toNat + 2 * ((E {v 0,v 3,v 4}).toNat + 2 * ((E {v 1,v 2,v 3}).toNat + 2 * ((E {v 1,v 2,v 4}).toNat + 2 * ((E {v 1,v 3,v 4}).toNat + 2 * ((E {v 2,v 3,v 4}).toNat)))))))))))))) := by
  rw [raw5, pack_toNat]
  rfl

theorem encoded4_eq_raw4 (m c : ℕ) (v : Fin 4 → Fin 6)
    (hinj : Function.Injective v) :
    P33Arithmetic.encoded m c [(v 0).val,(v 1).val,(v 2).val,(v 3).val] =
      (raw4 (decoded m c).edge (decoded m c).color v).toNat := by
  have hn (i j : Fin 4) (h : i ≠ j) : v i ≠ v j := fun hij => h (hinj hij)
  rw [encoded4_numeric, raw4_toNat]
  rw [← decoded_colour m c (v 0)]
  rw [← decoded_colour m c (v 1)]
  rw [← decoded_colour m c (v 2)]
  rw [← decoded_colour m c (v 3)]
  rw [← decoded_edge m c (v 0) (v 1) (v 2)
    (hn 0 1 (by decide)) (hn 0 2 (by decide)) (hn 1 2 (by decide))]
  rw [← decoded_edge m c (v 0) (v 1) (v 3)
    (hn 0 1 (by decide)) (hn 0 3 (by decide)) (hn 1 3 (by decide))]
  rw [← decoded_edge m c (v 0) (v 2) (v 3)
    (hn 0 2 (by decide)) (hn 0 3 (by decide)) (hn 2 3 (by decide))]
  rw [← decoded_edge m c (v 1) (v 2) (v 3)
    (hn 1 2 (by decide)) (hn 1 3 (by decide)) (hn 2 3 (by decide))]
  ring

theorem encoded5_eq_raw5 (m c : ℕ) (v : Fin 5 → Fin 6)
    (hinj : Function.Injective v) :
    P33Arithmetic.encoded m c [(v 0).val,(v 1).val,(v 2).val,(v 3).val,(v 4).val] =
      (raw5 (decoded m c).edge (decoded m c).color v).toNat := by
  have hn (i j : Fin 5) (h : i ≠ j) : v i ≠ v j := fun hij => h (hinj hij)
  rw [encoded5_numeric, raw5_nested]
  rw [← decoded_colour m c (v 0)]
  rw [← decoded_colour m c (v 1)]
  rw [← decoded_colour m c (v 2)]
  rw [← decoded_colour m c (v 3)]
  rw [← decoded_colour m c (v 4)]
  rw [← decoded_edge m c (v 0) (v 1) (v 2)
    (hn 0 1 (by decide)) (hn 0 2 (by decide)) (hn 1 2 (by decide))]
  rw [← decoded_edge m c (v 0) (v 1) (v 3)
    (hn 0 1 (by decide)) (hn 0 3 (by decide)) (hn 1 3 (by decide))]
  rw [← decoded_edge m c (v 0) (v 1) (v 4)
    (hn 0 1 (by decide)) (hn 0 4 (by decide)) (hn 1 4 (by decide))]
  rw [← decoded_edge m c (v 0) (v 2) (v 3)
    (hn 0 2 (by decide)) (hn 0 3 (by decide)) (hn 2 3 (by decide))]
  rw [← decoded_edge m c (v 0) (v 2) (v 4)
    (hn 0 2 (by decide)) (hn 0 4 (by decide)) (hn 2 4 (by decide))]
  rw [← decoded_edge m c (v 0) (v 3) (v 4)
    (hn 0 3 (by decide)) (hn 0 4 (by decide)) (hn 3 4 (by decide))]
  rw [← decoded_edge m c (v 1) (v 2) (v 3)
    (hn 1 2 (by decide)) (hn 1 3 (by decide)) (hn 2 3 (by decide))]
  rw [← decoded_edge m c (v 1) (v 2) (v 4)
    (hn 1 2 (by decide)) (hn 1 4 (by decide)) (hn 2 4 (by decide))]
  rw [← decoded_edge m c (v 1) (v 3) (v 4)
    (hn 1 3 (by decide)) (hn 1 4 (by decide)) (hn 3 4 (by decide))]
  rw [← decoded_edge m c (v 2) (v 3) (v 4)
    (hn 2 3 (by decide)) (hn 2 4 (by decide)) (hn 3 4 (by decide))]
  ring

theorem encoded2_eq_root2 (m c : ℕ) (v : Fin 2 → Fin 6) :
    P33Arithmetic.encoded m c [(v 0).val,(v 1).val] = root2 (decoded m c).color v := by
  rw [encoded2_numeric, decoded_colour m c (v 0),
    decoded_colour m c (v 1)]
  cases h0 : (decoded m c).color (v 0) <;> cases h1 : (decoded m c).color (v 1) <;>
    simp_all [root2, decoded]

theorem canonical_pair_eq_raw4 (m c : ℕ) (v : Fin 4 → Fin 6)
    (hinj : Function.Injective v) :
    P33Arithmetic.canonical m c [(v 0).val,(v 1).val] [(v 2).val,(v 3).val] =
      canonical4 (raw4 (decoded m c).edge (decoded m c).color v) := by
  have hs : Function.Injective (v ∘ swap4) := hinj.comp swap4_involutive.injective
  have he := encoded4_eq_raw4 m c (v ∘ swap4) hs
  change P33Arithmetic.encoded m c [(v 0).val,(v 1).val,(v 3).val,(v 2).val] = _ at he
  rw [canonical_pair, encoded4_eq_raw4 m c v hinj, he, raw4_swap]
  rfl

#print axioms decoded_colour
#print axioms decoded_edge
#print axioms raw5_nested
#print axioms encoded4_eq_raw4
#print axioms encoded5_eq_raw5
#print axioms encoded2_eq_root2
#print axioms canonical_pair_eq_raw4
#print axioms encoded2_numeric
#print axioms encoded4_numeric
#print axioms encoded5_numeric
#print axioms canonical_pair
#print axioms raw4_smul
#print axioms raw5_smul
end TightCycleC5.Bridge.P33PSDMatching
