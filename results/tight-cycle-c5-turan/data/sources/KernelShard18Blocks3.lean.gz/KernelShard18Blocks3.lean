import KernelRowIndex
import KernelWitness18

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_18_96 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 96 * 256 + i.val))
      kernelWitness18Row96[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_96

theorem kernelBlock_18_97 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 97 * 256 + i.val))
      kernelWitness18Row97[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_97

theorem kernelBlock_18_98 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 98 * 256 + i.val))
      kernelWitness18Row98[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_98

theorem kernelBlock_18_99 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 99 * 256 + i.val))
      kernelWitness18Row99[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_99

theorem kernelBlock_18_100 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 100 * 256 + i.val))
      kernelWitness18Row100[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_100

theorem kernelBlock_18_101 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 101 * 256 + i.val))
      kernelWitness18Row101[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_101

theorem kernelBlock_18_102 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 102 * 256 + i.val))
      kernelWitness18Row102[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_102

theorem kernelBlock_18_103 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 103 * 256 + i.val))
      kernelWitness18Row103[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_103

theorem kernelBlock_18_104 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 104 * 256 + i.val))
      kernelWitness18Row104[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_104

theorem kernelBlock_18_105 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 105 * 256 + i.val))
      kernelWitness18Row105[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_105

theorem kernelBlock_18_106 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 106 * 256 + i.val))
      kernelWitness18Row106[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_106

theorem kernelBlock_18_107 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 107 * 256 + i.val))
      kernelWitness18Row107[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_107

theorem kernelBlock_18_108 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 108 * 256 + i.val))
      kernelWitness18Row108[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_108

theorem kernelBlock_18_109 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 109 * 256 + i.val))
      kernelWitness18Row109[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_109

theorem kernelBlock_18_110 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 110 * 256 + i.val))
      kernelWitness18Row110[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_110

theorem kernelBlock_18_111 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 111 * 256 + i.val))
      kernelWitness18Row111[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_111

theorem kernelBlock_18_112 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 112 * 256 + i.val))
      kernelWitness18Row112[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_112

theorem kernelBlock_18_113 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 113 * 256 + i.val))
      kernelWitness18Row113[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_113

theorem kernelBlock_18_114 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 114 * 256 + i.val))
      kernelWitness18Row114[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_114

theorem kernelBlock_18_115 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 115 * 256 + i.val))
      kernelWitness18Row115[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_115

theorem kernelBlock_18_116 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 116 * 256 + i.val))
      kernelWitness18Row116[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_116

theorem kernelBlock_18_117 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 117 * 256 + i.val))
      kernelWitness18Row117[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_117

theorem kernelBlock_18_118 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 118 * 256 + i.val))
      kernelWitness18Row118[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_118

theorem kernelBlock_18_119 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 119 * 256 + i.val))
      kernelWitness18Row119[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_119

theorem kernelBlock_18_120 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 120 * 256 + i.val))
      kernelWitness18Row120[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_120

theorem kernelBlock_18_121 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 121 * 256 + i.val))
      kernelWitness18Row121[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_121

theorem kernelBlock_18_122 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 122 * 256 + i.val))
      kernelWitness18Row122[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_122

theorem kernelBlock_18_123 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 123 * 256 + i.val))
      kernelWitness18Row123[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_123

theorem kernelBlock_18_124 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 124 * 256 + i.val))
      kernelWitness18Row124[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_124

theorem kernelBlock_18_125 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 125 * 256 + i.val))
      kernelWitness18Row125[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_125

theorem kernelBlock_18_126 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 126 * 256 + i.val))
      kernelWitness18Row126[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_126

theorem kernelBlock_18_127 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (18 * 32768 + 127 * 256 + i.val))
      kernelWitness18Row127[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_18_127

end TightCycleC5.Bridge.Cover
