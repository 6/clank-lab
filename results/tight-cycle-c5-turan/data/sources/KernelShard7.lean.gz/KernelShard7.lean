import KernelShard7Blocks0
import KernelShard7Blocks1
import KernelShard7Blocks2
import KernelShard7Blocks3

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernel_shard7 : kernelShardCheck 7 kernelWitness7 := by
  intro i
  have blocks : ∀ b : Fin 128, ∀ c : Fin 256,
      checkWitness (BitVec.ofNat 20 (7 * 32768 + b.val * 256 + c.val))
        (readKernelWitness kernelWitness7 (b.val * 256 + c.val)) = true := by
    intro b
    fin_cases b
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_0 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_1 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_2 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_3 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_4 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_5 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_6 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_7 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_8 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_9 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_10 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_11 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_12 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_13 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_14 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_15 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_16 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_17 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_18 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_19 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_20 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_21 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_22 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_23 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_24 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_25 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_26 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_27 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_28 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_29 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_30 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_31 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_32 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_33 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_34 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_35 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_36 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_37 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_38 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_39 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_40 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_41 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_42 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_43 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_44 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_45 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_46 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_47 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_48 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_49 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_50 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_51 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_52 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_53 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_54 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_55 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_56 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_57 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_58 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_59 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_60 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_61 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_62 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_63 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_64 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_65 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_66 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_67 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_68 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_69 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_70 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_71 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_72 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_73 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_74 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_75 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_76 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_77 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_78 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_79 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_80 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_81 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_82 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_83 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_84 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_85 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_86 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_87 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_88 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_89 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_90 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_91 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_92 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_93 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_94 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_95 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_96 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_97 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_98 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_99 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_100 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_101 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_102 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_103 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_104 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_105 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_106 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_107 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_108 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_109 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_110 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_111 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_112 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_113 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_114 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_115 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_116 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_117 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_118 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_119 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_120 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_121 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_122 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_123 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_124 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_125 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_126 c
    · intro c
      rw [kernelReadRow]
      exact kernelBlock_7_127 c
  let b : Fin 128 := ⟨i.val / 256, by have := i.isLt; omega⟩
  let c : Fin 256 := ⟨i.val % 256, Nat.mod_lt _ (by decide)⟩
  have he : b.val * 256 + c.val = i.val := by
    dsimp [b, c]
    omega
  simpa only [Nat.add_assoc, he] using blocks b c

#print axioms kernel_shard7
end TightCycleC5.Bridge.Cover
