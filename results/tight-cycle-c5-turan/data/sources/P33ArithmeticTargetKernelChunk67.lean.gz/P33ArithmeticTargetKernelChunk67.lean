-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk268 :
    ∀ i : Fin (min 128 (40547 - 128 * 268)),
      targetCountsMatch (classAt (targetKernelClass ⟨268, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk268

theorem target_counts_kernel_chunk269 :
    ∀ i : Fin (min 128 (40547 - 128 * 269)),
      targetCountsMatch (classAt (targetKernelClass ⟨269, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk269

theorem target_counts_kernel_chunk270 :
    ∀ i : Fin (min 128 (40547 - 128 * 270)),
      targetCountsMatch (classAt (targetKernelClass ⟨270, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk270

theorem target_counts_kernel_chunk271 :
    ∀ i : Fin (min 128 (40547 - 128 * 271)),
      targetCountsMatch (classAt (targetKernelClass ⟨271, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk271


end TightCycleC5.Bridge.P33Arithmetic
