-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk140 :
    ∀ i : Fin (min 128 (40547 - 128 * 140)),
      targetCountsMatch (classAt (targetKernelClass ⟨140, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk140

theorem target_counts_kernel_chunk141 :
    ∀ i : Fin (min 128 (40547 - 128 * 141)),
      targetCountsMatch (classAt (targetKernelClass ⟨141, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk141

theorem target_counts_kernel_chunk142 :
    ∀ i : Fin (min 128 (40547 - 128 * 142)),
      targetCountsMatch (classAt (targetKernelClass ⟨142, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk142

theorem target_counts_kernel_chunk143 :
    ∀ i : Fin (min 128 (40547 - 128 * 143)),
      targetCountsMatch (classAt (targetKernelClass ⟨143, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk143


end TightCycleC5.Bridge.P33Arithmetic
