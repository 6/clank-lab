import KernelRowIndex
import KernelWitness1

/-! One complete shard, assembled from small kernel reductions. -/
namespace TightCycleC5.Bridge.Cover

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem kernelBlock_1_0 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 0 * 256 + i.val))
      kernelWitness1Row0[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_0

theorem kernelBlock_1_1 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 1 * 256 + i.val))
      kernelWitness1Row1[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_1

theorem kernelBlock_1_2 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 2 * 256 + i.val))
      kernelWitness1Row2[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_2

theorem kernelBlock_1_3 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 3 * 256 + i.val))
      kernelWitness1Row3[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_3

theorem kernelBlock_1_4 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 4 * 256 + i.val))
      kernelWitness1Row4[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_4

theorem kernelBlock_1_5 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 5 * 256 + i.val))
      kernelWitness1Row5[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_5

theorem kernelBlock_1_6 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 6 * 256 + i.val))
      kernelWitness1Row6[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_6

theorem kernelBlock_1_7 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 7 * 256 + i.val))
      kernelWitness1Row7[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_7

theorem kernelBlock_1_8 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 8 * 256 + i.val))
      kernelWitness1Row8[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_8

theorem kernelBlock_1_9 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 9 * 256 + i.val))
      kernelWitness1Row9[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_9

theorem kernelBlock_1_10 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 10 * 256 + i.val))
      kernelWitness1Row10[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_10

theorem kernelBlock_1_11 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 11 * 256 + i.val))
      kernelWitness1Row11[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_11

theorem kernelBlock_1_12 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 12 * 256 + i.val))
      kernelWitness1Row12[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_12

theorem kernelBlock_1_13 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 13 * 256 + i.val))
      kernelWitness1Row13[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_13

theorem kernelBlock_1_14 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 14 * 256 + i.val))
      kernelWitness1Row14[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_14

theorem kernelBlock_1_15 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 15 * 256 + i.val))
      kernelWitness1Row15[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_15

theorem kernelBlock_1_16 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 16 * 256 + i.val))
      kernelWitness1Row16[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_16

theorem kernelBlock_1_17 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 17 * 256 + i.val))
      kernelWitness1Row17[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_17

theorem kernelBlock_1_18 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 18 * 256 + i.val))
      kernelWitness1Row18[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_18

theorem kernelBlock_1_19 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 19 * 256 + i.val))
      kernelWitness1Row19[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_19

theorem kernelBlock_1_20 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 20 * 256 + i.val))
      kernelWitness1Row20[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_20

theorem kernelBlock_1_21 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 21 * 256 + i.val))
      kernelWitness1Row21[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_21

theorem kernelBlock_1_22 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 22 * 256 + i.val))
      kernelWitness1Row22[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_22

theorem kernelBlock_1_23 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 23 * 256 + i.val))
      kernelWitness1Row23[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_23

theorem kernelBlock_1_24 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 24 * 256 + i.val))
      kernelWitness1Row24[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_24

theorem kernelBlock_1_25 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 25 * 256 + i.val))
      kernelWitness1Row25[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_25

theorem kernelBlock_1_26 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 26 * 256 + i.val))
      kernelWitness1Row26[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_26

theorem kernelBlock_1_27 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 27 * 256 + i.val))
      kernelWitness1Row27[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_27

theorem kernelBlock_1_28 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 28 * 256 + i.val))
      kernelWitness1Row28[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_28

theorem kernelBlock_1_29 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 29 * 256 + i.val))
      kernelWitness1Row29[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_29

theorem kernelBlock_1_30 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 30 * 256 + i.val))
      kernelWitness1Row30[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_30

theorem kernelBlock_1_31 : ∀ i : Fin 256,
    checkWitness (BitVec.ofNat 20 (1 * 32768 + 31 * 256 + i.val))
      kernelWitness1Row31[i.val]! = true := by
  decide +kernel

#print axioms kernelBlock_1_31

end TightCycleC5.Bridge.Cover
