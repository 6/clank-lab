-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk304 :
    ∀ i : Fin (min 128 (40547 - 128 * 304)),
      targetCountsMatch (classAt (targetKernelClass ⟨304, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk304

theorem target_counts_kernel_chunk305 :
    ∀ i : Fin (min 128 (40547 - 128 * 305)),
      targetCountsMatch (classAt (targetKernelClass ⟨305, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk305

theorem target_counts_kernel_chunk306 :
    ∀ i : Fin (min 128 (40547 - 128 * 306)),
      targetCountsMatch (classAt (targetKernelClass ⟨306, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk306

theorem target_counts_kernel_chunk307 :
    ∀ i : Fin (min 128 (40547 - 128 * 307)),
      targetCountsMatch (classAt (targetKernelClass ⟨307, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk307


end TightCycleC5.Bridge.P33Arithmetic
