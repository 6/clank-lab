import P33ArithmeticFinite

/-! Range cover for independent finite arithmetic replay. A true range
checks every index, and the last partial range is explicit. -/
namespace TightCycleC5.Bridge.P33Arithmetic

def rangeCheck (start count : Nat) : Bool :=
  (List.range count).all fun off =>
    if h : start + off < 40547 then classCheck (classAt ⟨start + off,h⟩) else false

/-- Convert the actual checked range into the requested class predicate. -/
theorem rangeCheck_sound (start count : Nat) (h : rangeCheck start count = true)
    (k : Fin 40547) (hlo : start ≤ k.val) (hhi : k.val < start + count) :
    classCheck (classAt k) = true := by
  have hoff : k.val-start < count := by omega
  have heq : start + (k.val-start) = k.val := by omega
  have hv := List.all_eq_true.mp h (k.val-start) (List.mem_range.mpr hoff)
  simp only [heq, k.isLt, ↓reduceDIte] at hv
  exact hv

#print axioms rangeCheck_sound
end TightCycleC5.Bridge.P33Arithmetic
