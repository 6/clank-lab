import DisjointSampling
import SixSampling

/-! Uniform marginals of injective vertex samples. -/
namespace TightCycleC5.Bridge
open Finset

theorem uniformMean_first_three {n : ℕ} (hn : 6 ≤ n) (v : (Fin 3 ↪ Fin n) → ℝ) :
    uniformMean (fun σ : Fin 6 ↪ Fin n => v ((Fin.castAddEmb 3).trans σ)) =
      uniformMean v := by
  classical
  rw [uniformMean_joinSample (r := 3) (f := 3)]
  have he : ∀ (root : Fin 3 ↪ Fin n) (free : Fin 3 ↪ Outside root),
      (Fin.castAddEmb 3).trans (joinSample root free) = root := by
    intro root free
    apply Function.Embedding.ext
    intro i
    exact joinSample_root root free i
  simp_rw [he]
  apply congrArg uniformMean
  funext root
  have hc : 3 ≤ Fintype.card (Outside root) := by
    rw [outside_card, Fintype.card_fin, Fintype.card_fin]
    omega
  letI : Nonempty (Fin 3 ↪ Outside root) :=
    ⟨(Fin.castLEEmb hc).trans (Fintype.equivFin (Outside root)).symm.toEmbedding⟩
  exact uniformMean_const _

/-- Any three distinct sample labels have the uniform ordered-triple law. -/
theorem uniformMean_restrict_three {n : ℕ} (hn : 6 ≤ n)
    (labels : Fin 3 ↪ Fin 6) (v : (Fin 3 ↪ Fin n) → ℝ) :
    uniformMean (fun σ : Fin 6 ↪ Fin n => v (labels.trans σ)) = uniformMean v := by
  classical
  let first : Fin 3 ↪ Fin 6 := Fin.castAddEmb 3
  obtain ⟨p, hp⟩ := Equiv.Perm.exists_extending_pair first labels first.injective labels.injective
  have he : ∀ σ : Fin 6 ↪ Fin n, labels.trans (samplePerm p σ) = first.trans σ := by
    intro σ
    apply Function.Embedding.ext
    intro i
    change σ (p.symm (labels i)) = σ (first i)
    rw [← hp i, p.symm_apply_apply]
  have h := uniformMean_equiv (samplePerm p) (fun σ => v (labels.trans σ))
  simp_rw [he] at h
  rw [← h]
  exact uniformMean_first_three hn v

#print axioms uniformMean_first_three
#print axioms uniformMean_restrict_three
end TightCycleC5.Bridge
