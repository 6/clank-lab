-- Generated from the pinned P33 manifest; untrusted proof quotation.
import P33PSDMatchingCore
import P33FlagData
import P33ArithmeticBlocks0
import P33ArithmeticBlocks1
import P33ArithmeticBlocks2
import P33ArithmeticBlocks3
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000
namespace TightCycleC5.Bridge.P33PSDMatching
open Finset Matrix

theorem source_metadata1 :
    P33Arithmetic.block1.flags = P33Flag.basis1Data ∧
    P33Arithmetic.block1.roots = 2 ∧
    P33Arithmetic.block1.typeCode = P33Flag.type1 := by decide +kernel
theorem source_terms1 : ∀ k : Fin 14, ∀ i j : Fin 40,
    P33Arithmetic.termEntry P33Arithmetic.block1.terms[k.val]! i.val j.val =
      (P33PSD.weights1 k : ℤ) * P33PSD.terms1 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry1 : ∀ i j : Fin 40,
    P33Arithmetic.blockEntry P33Arithmetic.block1 i.val j.val = P33PSD.q1 i j :=
  blockEntry_eq_sos P33Arithmetic.block1 P33PSD.weights1 P33PSD.terms1 rfl source_terms1
#print axioms source_metadata1
#print axioms source_terms1
#print axioms source_entry1

theorem source_metadata7 :
    P33Arithmetic.block7.flags = P33Flag.basis7Data ∧
    P33Arithmetic.block7.roots = 4 ∧
    P33Arithmetic.block7.typeCode = P33Flag.type7 := by decide +kernel
theorem source_terms7 : ∀ k : Fin 0, ∀ i j : Fin 128,
    P33Arithmetic.termEntry P33Arithmetic.block7.terms[k.val]! i.val j.val =
      (P33PSD.weights7 k : ℤ) * P33PSD.terms7 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry7 : ∀ i j : Fin 128,
    P33Arithmetic.blockEntry P33Arithmetic.block7 i.val j.val = P33PSD.q7 i j :=
  blockEntry_eq_sos P33Arithmetic.block7 P33PSD.weights7 P33PSD.terms7 rfl source_terms7
#print axioms source_metadata7
#print axioms source_terms7
#print axioms source_entry7

theorem source_metadata13 :
    P33Arithmetic.block13.flags = P33Flag.basis13Data ∧
    P33Arithmetic.block13.roots = 4 ∧
    P33Arithmetic.block13.typeCode = P33Flag.type13 := by decide +kernel
theorem source_terms13 : ∀ k : Fin 13, ∀ i j : Fin 128,
    P33Arithmetic.termEntry P33Arithmetic.block13.terms[k.val]! i.val j.val =
      (P33PSD.weights13 k : ℤ) * P33PSD.terms13 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry13 : ∀ i j : Fin 128,
    P33Arithmetic.blockEntry P33Arithmetic.block13 i.val j.val = P33PSD.q13 i j :=
  blockEntry_eq_sos P33Arithmetic.block13 P33PSD.weights13 P33PSD.terms13 rfl source_terms13
#print axioms source_metadata13
#print axioms source_terms13
#print axioms source_entry13

theorem source_metadata19 :
    P33Arithmetic.block19.flags = P33Flag.basis19Data ∧
    P33Arithmetic.block19.roots = 4 ∧
    P33Arithmetic.block19.typeCode = P33Flag.type19 := by decide +kernel
theorem source_terms19 : ∀ k : Fin 14, ∀ i j : Fin 100,
    P33Arithmetic.termEntry P33Arithmetic.block19.terms[k.val]! i.val j.val =
      (P33PSD.weights19 k : ℤ) * P33PSD.terms19 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry19 : ∀ i j : Fin 100,
    P33Arithmetic.blockEntry P33Arithmetic.block19 i.val j.val = P33PSD.q19 i j :=
  blockEntry_eq_sos P33Arithmetic.block19 P33PSD.weights19 P33PSD.terms19 rfl source_terms19
#print axioms source_metadata19
#print axioms source_terms19
#print axioms source_entry19

theorem source_metadata25 :
    P33Arithmetic.block25.flags = P33Flag.basis25Data ∧
    P33Arithmetic.block25.roots = 4 ∧
    P33Arithmetic.block25.typeCode = P33Flag.type25 := by decide +kernel
theorem source_terms25 : ∀ k : Fin 9, ∀ i j : Fin 78,
    P33Arithmetic.termEntry P33Arithmetic.block25.terms[k.val]! i.val j.val =
      (P33PSD.weights25 k : ℤ) * P33PSD.terms25 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry25 : ∀ i j : Fin 78,
    P33Arithmetic.blockEntry P33Arithmetic.block25 i.val j.val = P33PSD.q25 i j :=
  blockEntry_eq_sos P33Arithmetic.block25 P33PSD.weights25 P33PSD.terms25 rfl source_terms25
#print axioms source_metadata25
#print axioms source_terms25
#print axioms source_entry25

theorem source_metadata31 :
    P33Arithmetic.block31.flags = P33Flag.basis31Data ∧
    P33Arithmetic.block31.roots = 4 ∧
    P33Arithmetic.block31.typeCode = P33Flag.type31 := by decide +kernel
theorem source_terms31 : ∀ k : Fin 6, ∀ i j : Fin 78,
    P33Arithmetic.termEntry P33Arithmetic.block31.terms[k.val]! i.val j.val =
      (P33PSD.weights31 k : ℤ) * P33PSD.terms31 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry31 : ∀ i j : Fin 78,
    P33Arithmetic.blockEntry P33Arithmetic.block31 i.val j.val = P33PSD.q31 i j :=
  blockEntry_eq_sos P33Arithmetic.block31 P33PSD.weights31 P33PSD.terms31 rfl source_terms31
#print axioms source_metadata31
#print axioms source_terms31
#print axioms source_entry31

theorem source_metadata37 :
    P33Arithmetic.block37.flags = P33Flag.basis37Data ∧
    P33Arithmetic.block37.roots = 4 ∧
    P33Arithmetic.block37.typeCode = P33Flag.type37 := by decide +kernel
theorem source_terms37 : ∀ k : Fin 0, ∀ i j : Fin 60,
    P33Arithmetic.termEntry P33Arithmetic.block37.terms[k.val]! i.val j.val =
      (P33PSD.weights37 k : ℤ) * P33PSD.terms37 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry37 : ∀ i j : Fin 60,
    P33Arithmetic.blockEntry P33Arithmetic.block37 i.val j.val = P33PSD.q37 i j :=
  blockEntry_eq_sos P33Arithmetic.block37 P33PSD.weights37 P33PSD.terms37 rfl source_terms37
#print axioms source_metadata37
#print axioms source_terms37
#print axioms source_entry37

end TightCycleC5.Bridge.P33PSDMatching
