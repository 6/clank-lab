-- Generated from the pinned P33 manifest; untrusted proof quotation.
import P33PSDMatchingCore
import P33FlagData
import P33ArithmeticBlocks0
import P33ArithmeticBlocks1
import P33ArithmeticBlocks2
import P33ArithmeticBlocks3
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000
namespace TightCycleC5.Bridge.P33PSDMatching
open Finset Matrix

theorem source_metadata0 :
    P33Arithmetic.block0.flags = P33Flag.basis0Data ∧
    P33Arithmetic.block0.roots = 2 ∧
    P33Arithmetic.block0.typeCode = P33Flag.type0 := by decide +kernel
theorem source_terms0 : ∀ k : Fin 17, ∀ i j : Fin 40,
    P33Arithmetic.termEntry P33Arithmetic.block0.terms[k.val]! i.val j.val =
      (P33PSD.weights0 k : ℤ) * P33PSD.terms0 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry0 : ∀ i j : Fin 40,
    P33Arithmetic.blockEntry P33Arithmetic.block0 i.val j.val = P33PSD.q0 i j :=
  blockEntry_eq_sos P33Arithmetic.block0 P33PSD.weights0 P33PSD.terms0 rfl source_terms0
#print axioms source_metadata0
#print axioms source_terms0
#print axioms source_entry0

theorem source_metadata6 :
    P33Arithmetic.block6.flags = P33Flag.basis6Data ∧
    P33Arithmetic.block6.roots = 4 ∧
    P33Arithmetic.block6.typeCode = P33Flag.type6 := by decide +kernel
theorem source_terms6 : ∀ k : Fin 8, ∀ i j : Fin 128,
    P33Arithmetic.termEntry P33Arithmetic.block6.terms[k.val]! i.val j.val =
      (P33PSD.weights6 k : ℤ) * P33PSD.terms6 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry6 : ∀ i j : Fin 128,
    P33Arithmetic.blockEntry P33Arithmetic.block6 i.val j.val = P33PSD.q6 i j :=
  blockEntry_eq_sos P33Arithmetic.block6 P33PSD.weights6 P33PSD.terms6 rfl source_terms6
#print axioms source_metadata6
#print axioms source_terms6
#print axioms source_entry6

theorem source_metadata12 :
    P33Arithmetic.block12.flags = P33Flag.basis12Data ∧
    P33Arithmetic.block12.roots = 4 ∧
    P33Arithmetic.block12.typeCode = P33Flag.type12 := by decide +kernel
theorem source_terms12 : ∀ k : Fin 9, ∀ i j : Fin 128,
    P33Arithmetic.termEntry P33Arithmetic.block12.terms[k.val]! i.val j.val =
      (P33PSD.weights12 k : ℤ) * P33PSD.terms12 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry12 : ∀ i j : Fin 128,
    P33Arithmetic.blockEntry P33Arithmetic.block12 i.val j.val = P33PSD.q12 i j :=
  blockEntry_eq_sos P33Arithmetic.block12 P33PSD.weights12 P33PSD.terms12 rfl source_terms12
#print axioms source_metadata12
#print axioms source_terms12
#print axioms source_entry12

theorem source_metadata18 :
    P33Arithmetic.block18.flags = P33Flag.basis18Data ∧
    P33Arithmetic.block18.roots = 4 ∧
    P33Arithmetic.block18.typeCode = P33Flag.type18 := by decide +kernel
theorem source_terms18 : ∀ k : Fin 12, ∀ i j : Fin 100,
    P33Arithmetic.termEntry P33Arithmetic.block18.terms[k.val]! i.val j.val =
      (P33PSD.weights18 k : ℤ) * P33PSD.terms18 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry18 : ∀ i j : Fin 100,
    P33Arithmetic.blockEntry P33Arithmetic.block18 i.val j.val = P33PSD.q18 i j :=
  blockEntry_eq_sos P33Arithmetic.block18 P33PSD.weights18 P33PSD.terms18 rfl source_terms18
#print axioms source_metadata18
#print axioms source_terms18
#print axioms source_entry18

theorem source_metadata24 :
    P33Arithmetic.block24.flags = P33Flag.basis24Data ∧
    P33Arithmetic.block24.roots = 4 ∧
    P33Arithmetic.block24.typeCode = P33Flag.type24 := by decide +kernel
theorem source_terms24 : ∀ k : Fin 0, ∀ i j : Fin 100,
    P33Arithmetic.termEntry P33Arithmetic.block24.terms[k.val]! i.val j.val =
      (P33PSD.weights24 k : ℤ) * P33PSD.terms24 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry24 : ∀ i j : Fin 100,
    P33Arithmetic.blockEntry P33Arithmetic.block24 i.val j.val = P33PSD.q24 i j :=
  blockEntry_eq_sos P33Arithmetic.block24 P33PSD.weights24 P33PSD.terms24 rfl source_terms24
#print axioms source_metadata24
#print axioms source_terms24
#print axioms source_entry24

theorem source_metadata30 :
    P33Arithmetic.block30.flags = P33Flag.basis30Data ∧
    P33Arithmetic.block30.roots = 4 ∧
    P33Arithmetic.block30.typeCode = P33Flag.type30 := by decide +kernel
theorem source_terms30 : ∀ k : Fin 11, ∀ i j : Fin 78,
    P33Arithmetic.termEntry P33Arithmetic.block30.terms[k.val]! i.val j.val =
      (P33PSD.weights30 k : ℤ) * P33PSD.terms30 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry30 : ∀ i j : Fin 78,
    P33Arithmetic.blockEntry P33Arithmetic.block30 i.val j.val = P33PSD.q30 i j :=
  blockEntry_eq_sos P33Arithmetic.block30 P33PSD.weights30 P33PSD.terms30 rfl source_terms30
#print axioms source_metadata30
#print axioms source_terms30
#print axioms source_entry30

theorem source_metadata36 :
    P33Arithmetic.block36.flags = P33Flag.basis36Data ∧
    P33Arithmetic.block36.roots = 4 ∧
    P33Arithmetic.block36.typeCode = P33Flag.type36 := by decide +kernel
theorem source_terms36 : ∀ k : Fin 3, ∀ i j : Fin 60,
    P33Arithmetic.termEntry P33Arithmetic.block36.terms[k.val]! i.val j.val =
      (P33PSD.weights36 k : ℤ) * P33PSD.terms36 k i j := by
  intro k i j
  fin_cases k <;> rfl
theorem source_entry36 : ∀ i j : Fin 60,
    P33Arithmetic.blockEntry P33Arithmetic.block36 i.val j.val = P33PSD.q36 i j :=
  blockEntry_eq_sos P33Arithmetic.block36 P33PSD.weights36 P33PSD.terms36 rfl source_terms36
#print axioms source_metadata36
#print axioms source_terms36
#print axioms source_entry36

end TightCycleC5.Bridge.P33PSDMatching
