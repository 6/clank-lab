import P32ClassBridge
import P33ClassBridge

/-! Exact pinned endpoint type from the actual P32 proposition and the
explicit remaining P33 finite replay premise. No placeholder proof is used. -/
namespace TightCycleC5.Bridge

theorem mubayi_rodl_of_checked_p33_classes
    (hchecks : ∀ k : Fin 40547,
      P33Arithmetic.classCheck (P33Arithmetic.classAt k) = true) :
    type_of% @TightCycleC5.mubayi_rodl :=
  TightCycleC5.mubayi_rodl_of_bllp P32ClassBridge.p32
    (P33ClassBridge.p33_of_checked_classes hchecks)

#print axioms mubayi_rodl_of_checked_p33_classes
end TightCycleC5.Bridge
