-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk24 :
    ∀ i : Fin (min 128 (40547 - 128 * 24)),
      targetCountsMatch (classAt (targetKernelClass ⟨24, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk24

theorem target_counts_kernel_chunk25 :
    ∀ i : Fin (min 128 (40547 - 128 * 25)),
      targetCountsMatch (classAt (targetKernelClass ⟨25, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk25

theorem target_counts_kernel_chunk26 :
    ∀ i : Fin (min 128 (40547 - 128 * 26)),
      targetCountsMatch (classAt (targetKernelClass ⟨26, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk26

theorem target_counts_kernel_chunk27 :
    ∀ i : Fin (min 128 (40547 - 128 * 27)),
      targetCountsMatch (classAt (targetKernelClass ⟨27, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk27


end TightCycleC5.Bridge.P33Arithmetic
