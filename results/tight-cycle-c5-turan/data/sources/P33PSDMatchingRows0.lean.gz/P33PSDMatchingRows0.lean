import P33PSDMatchingRowsBase
import P33PSDMatchingEntries0
import P33FlagRows0
namespace TightCycleC5.Bridge.P33PSDMatching

theorem source_row0 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block0 K p) :
    (sourceContribution P33Arithmetic.block0 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row0 (p.symm • decoded K.mask K.colours) :=
  pair_contribution_eq P33Arithmetic.block0 rfl P33PSD.q0 P33PSD.scale source_entry0
    P33Flag.basis0 P33Flag.basis0_injective rfl (fun _ => rfl) P33Flag.type0 rfl K p hv
#print axioms source_row0

theorem source_row6 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block6 K p) :
    (sourceContribution P33Arithmetic.block6 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row6 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block6 rfl P33PSD.q6 P33PSD.scale source_entry6
    P33Flag.basis6 P33Flag.basis6_injective rfl (fun _ => rfl) P33Flag.type6 rfl K p hv
#print axioms source_row6

theorem source_row12 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block12 K p) :
    (sourceContribution P33Arithmetic.block12 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row12 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block12 rfl P33PSD.q12 P33PSD.scale source_entry12
    P33Flag.basis12 P33Flag.basis12_injective rfl (fun _ => rfl) P33Flag.type12 rfl K p hv
#print axioms source_row12

theorem source_row18 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block18 K p) :
    (sourceContribution P33Arithmetic.block18 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row18 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block18 rfl P33PSD.q18 P33PSD.scale source_entry18
    P33Flag.basis18 P33Flag.basis18_injective rfl (fun _ => rfl) P33Flag.type18 rfl K p hv
#print axioms source_row18

theorem source_row24 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block24 K p) :
    (sourceContribution P33Arithmetic.block24 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row24 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block24 rfl P33PSD.q24 P33PSD.scale source_entry24
    P33Flag.basis24 P33Flag.basis24_injective rfl (fun _ => rfl) P33Flag.type24 rfl K p hv
#print axioms source_row24

theorem source_row30 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block30 K p) :
    (sourceContribution P33Arithmetic.block30 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row30 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block30 rfl P33PSD.q30 P33PSD.scale source_entry30
    P33Flag.basis30 P33Flag.basis30_injective rfl (fun _ => rfl) P33Flag.type30 rfl K p hv
#print axioms source_row30

theorem source_row36 (K : P33Arithmetic.Class) (p : Equiv.Perm (Fin 6))
    (hv : ValidLookups P33Arithmetic.block36 K p) :
    (sourceContribution P33Arithmetic.block36 K p : ℝ) / (1000000000 * (P33PSD.scale : ℝ)) =
      P33Flag.row36 (p.symm • decoded K.mask K.colours) :=
  four_contribution_eq P33Arithmetic.block36 rfl P33PSD.q36 P33PSD.scale source_entry36
    P33Flag.basis36 P33Flag.basis36_injective rfl (fun _ => rfl) P33Flag.type36 rfl K p hv
#print axioms source_row36

end TightCycleC5.Bridge.P33PSDMatching
