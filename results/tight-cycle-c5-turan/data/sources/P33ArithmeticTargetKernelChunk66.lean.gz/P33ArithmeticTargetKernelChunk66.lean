-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk264 :
    ∀ i : Fin (min 128 (40547 - 128 * 264)),
      targetCountsMatch (classAt (targetKernelClass ⟨264, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk264

theorem target_counts_kernel_chunk265 :
    ∀ i : Fin (min 128 (40547 - 128 * 265)),
      targetCountsMatch (classAt (targetKernelClass ⟨265, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk265

theorem target_counts_kernel_chunk266 :
    ∀ i : Fin (min 128 (40547 - 128 * 266)),
      targetCountsMatch (classAt (targetKernelClass ⟨266, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk266

theorem target_counts_kernel_chunk267 :
    ∀ i : Fin (min 128 (40547 - 128 * 267)),
      targetCountsMatch (classAt (targetKernelClass ⟨267, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk267


end TightCycleC5.Bridge.P33Arithmetic
