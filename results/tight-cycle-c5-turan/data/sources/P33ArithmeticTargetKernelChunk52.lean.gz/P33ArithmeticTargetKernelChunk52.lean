-- Untrusted quotation from certificate SHA256 8f73f6ac39c0f9633ee4ec1cba2c6c2bcb849ff84af37547b4b57f5725c06799.
import P33ArithmeticTargetKernelBase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TightCycleC5.Bridge.P33Arithmetic

theorem target_counts_kernel_chunk208 :
    ∀ i : Fin (min 128 (40547 - 128 * 208)),
      targetCountsMatch (classAt (targetKernelClass ⟨208, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk208

theorem target_counts_kernel_chunk209 :
    ∀ i : Fin (min 128 (40547 - 128 * 209)),
      targetCountsMatch (classAt (targetKernelClass ⟨209, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk209

theorem target_counts_kernel_chunk210 :
    ∀ i : Fin (min 128 (40547 - 128 * 210)),
      targetCountsMatch (classAt (targetKernelClass ⟨210, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk210

theorem target_counts_kernel_chunk211 :
    ∀ i : Fin (min 128 (40547 - 128 * 211)),
      targetCountsMatch (classAt (targetKernelClass ⟨211, by decide⟩ i)) := by
  decide +kernel
#print axioms target_counts_kernel_chunk211


end TightCycleC5.Bridge.P33Arithmetic
