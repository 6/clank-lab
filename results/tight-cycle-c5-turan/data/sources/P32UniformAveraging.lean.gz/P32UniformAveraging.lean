import P32RowBounds
import P32RowMatchingMeans
import P32RowMatchingSamples
import P32KernelCover
import TheoremA

/-! Theorem A's exact passage from literal class means to graph margins.
The finite class inequalities remain explicit until the checked wrapper
is applied; the graph transport uses the kernel-only cover. -/
namespace TightCycleC5.Bridge.P32UniformAveraging
open Finset
set_option maxRecDepth 100000
set_option maxHeartbeats 2000000

noncomputable def nuisanceRows (G : LabelledStructure 6) : ℝ :=
  P32RowMatching.clRows G + P32RowMatching.indicatorBookRows G +
    P32RowMatching.weightedBookRows G + P32RowMatching.densityRows G +
    P32RowMatching.psdRows G

noncomputable def residual (G : LabelledStructure 6) : ℝ :=
  P32Selector.margin G - nuisanceRows G

theorem nuisance_sample_eq {n : Nat} (H : Finset (Finset (Fin n)))
    (S : Finset (Fin n)) (σ : Fin 6 ↪ Fin n) :
    nuisanceRows (sampleStructure σ H S) = P32RowBounds.nuisanceRows H S σ := by
  simp only [nuisanceRows, P32RowMatching.clRows,
    P32RowMatching.indicatorBookRows, P32RowMatching.weightedBookRows,
    P32RowMatching.densityRows, P32RowMatching.psd_rows_sample,
    P32RowBounds.nuisanceRows, P32RowBounds.clRows,
    P32RowBounds.indicatorBooks, P32RowBounds.weightedBooks,
    P32RowBounds.weightedBookWeight, P32RowBounds.densityRows,
    P32RowBounds.psdRows]

theorem mean_sub {ι : Type*} [Fintype ι] (f g : ι → ℝ) :
    uniformMean (fun i => f i - g i) = uniformMean f - uniformMean g := by
  simp only [uniformMean, sum_sub_distrib, sub_div]

/-- The only finite prerequisite is the exact literal class inequality. -/
theorem residual_mean_lower
    (hclasses : ∀ k : Fin 835,
      (1 : ℝ)/10000 + uniformMean (fun p : Equiv.Perm (Fin 6) =>
        nuisanceRows (p • Cover.p32KernelClassRep k)) ≤
      uniformMean (fun p : Equiv.Perm (Fin 6) =>
        P32Selector.margin (p • Cover.p32KernelClassRep k)))
    {n : Nat} (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (hC : ¬ ContainsC5 H) (hn : 6 ≤ n) :
    (1 : ℝ)/10000 ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n => residual (sampleStructure σ H univ)) := by
  have hclass : ∀ k : Fin 835,
      (1 : ℝ)/10000 ≤ uniformMean (fun p : Equiv.Perm (Fin 6) =>
        residual (p • Cover.p32KernelClassRep k)) := by
    intro k
    have h := hclasses k
    simp only [residual, mean_sub]
    linarith
  rw [Cover.p32_kernel_class_expansion hH hC residual]
  obtain ⟨hq, hsum⟩ := Cover.p32_kernel_class_probability hn hH hC
  have h := Finset.sum_le_sum (s := (univ : Finset (Fin 835)))
    (fun k _ => mul_le_mul_of_nonneg_left (hclass k) (hq k))
  rw [← Finset.sum_mul, hsum, one_mul] at h
  exact h

theorem uniform_margin_bound
    (hclasses : ∀ k : Fin 835,
      (1 : ℝ)/10000 + uniformMean (fun p : Equiv.Perm (Fin 6) =>
        nuisanceRows (p • Cover.p32KernelClassRep k)) ≤
      uniformMean (fun p : Equiv.Perm (Fin 6) =>
        P32Selector.margin (p • Cover.p32KernelClassRep k)))
    {n : Nat} (H : Finset (Finset (Fin n))) (hH : IsThreeGraph H)
    (hC : ¬ ContainsC5 H) (hn : 12 ≤ n)
    (hd : CertificateDescriptors.densityBeta * (n.choose 3 : ℝ) ≤ H.card) :
    (1 : ℝ)/10000 - P32RowBounds.errorConstant / (n : ℝ) ≤
      uniformMean (fun σ : Fin 6 ↪ Fin n =>
        P32Selector.margin (sampleStructure σ H univ)) := by
  have hc := residual_mean_lower hclasses H hH hC (by omega : 6 ≤ n)
  simp only [residual, mean_sub, nuisance_sample_eq] at hc
  have hr := P32RowBounds.nuisance_mean_lower H hH hC hn univ hd
  linarith

/-- PARTIAL until the finite literal class means are supplied. The exact
P32 graph hypotheses, threshold and epsilon quantifiers are retained. -/
theorem p32_of_literal_class_means
    (hclasses : ∀ k : Fin 835,
      (1 : ℝ)/10000 + uniformMean (fun p : Equiv.Perm (Fin 6) =>
        nuisanceRows (p • Cover.p32KernelClassRep k)) ≤
      uniformMean (fun p : Equiv.Perm (Fin 6) =>
        P32Selector.margin (p • Cover.p32KernelClassRep k))) : P32Statement := by
  apply p32_of_uniform_margin_bound
  refine ⟨P32RowBounds.errorConstant, P32RowBounds.error_constant_nonneg, ?_⟩
  intro n hn H hH hC hd
  apply uniform_margin_bound hclasses H hH hC hn
  convert hd using 1 <;> norm_num [CertificateDescriptors.densityBeta]

#print axioms nuisance_sample_eq
#print axioms mean_sub
#print axioms residual_mean_lower
#print axioms uniform_margin_bound
#print axioms p32_of_literal_class_means
end TightCycleC5.Bridge.P32UniformAveraging
